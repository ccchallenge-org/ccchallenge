(** * All4x4 counterexamples — batch 1
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa0 (Fin7) ---- *)

Definition refa0_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_1 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_3 | F7_0, F7_5 => F7_6 | F7_0, F7_6 => F7_5
  | F7_1, F7_0 => F7_3 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_5 | F7_1, F7_3 => F7_0 | F7_1, F7_4 => F7_6 | F7_1, F7_5 => F7_2 | F7_1, F7_6 => F7_4
  | F7_2, F7_0 => F7_4 | F7_2, F7_1 => F7_6 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_5 | F7_2, F7_4 => F7_0 | F7_2, F7_5 => F7_3 | F7_2, F7_6 => F7_1
  | F7_3, F7_0 => F7_6 | F7_3, F7_1 => F7_5 | F7_3, F7_2 => F7_4 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_2 | F7_3, F7_5 => F7_1 | F7_3, F7_6 => F7_0
  | F7_4, F7_0 => F7_5 | F7_4, F7_1 => F7_3 | F7_4, F7_2 => F7_6 | F7_4, F7_3 => F7_1 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_2
  | F7_5, F7_0 => F7_2 | F7_5, F7_1 => F7_4 | F7_5, F7_2 => F7_0 | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_1 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_3
  | F7_6, F7_0 => F7_1 | F7_6, F7_1 => F7_0 | F7_6, F7_2 => F7_3 | F7_6, F7_3 => F7_2 | F7_6, F7_4 => F7_5 | F7_6, F7_5 => F7_4 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa0_inst : Magma Fin7 := {| magma_op := refa0_op |}.

Lemma refa0_sat1286 : @Equation1286 Fin7 refa0_inst.
Proof. unfold Equation1286, magma_op, refa0_inst, refa0_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa0_sat2091 : @Equation2091 Fin7 refa0_inst.
Proof. unfold Equation2091, magma_op, refa0_inst, refa0_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa0_sat2301 : @Equation2301 Fin7 refa0_inst.
Proof. unfold Equation2301, magma_op, refa0_inst, refa0_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa0_sat2460 : @Equation2460 Fin7 refa0_inst.
Proof. unfold Equation2460, magma_op, refa0_inst, refa0_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa0_sat2900 : @Equation2900 Fin7 refa0_inst.
Proof. unfold Equation2900, magma_op, refa0_inst, refa0_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa0_sat3140 : @Equation3140 Fin7 refa0_inst.
Proof. unfold Equation3140, magma_op, refa0_inst, refa0_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa0_sat4081 : @Equation4081 Fin7 refa0_inst.
Proof. unfold Equation4081, magma_op, refa0_inst, refa0_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa0_not50 : ~ @Equation50 Fin7 refa0_inst.
Proof. unfold Equation50. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not56 : ~ @Equation56 Fin7 refa0_inst.
Proof. unfold Equation56. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not65 : ~ @Equation65 Fin7 refa0_inst.
Proof. unfold Equation65. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not66 : ~ @Equation66 Fin7 refa0_inst.
Proof. unfold Equation66. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not73 : ~ @Equation73 Fin7 refa0_inst.
Proof. unfold Equation73. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not75 : ~ @Equation75 Fin7 refa0_inst.
Proof. unfold Equation75. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not105 : ~ @Equation105 Fin7 refa0_inst.
Proof. unfold Equation105. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not107 : ~ @Equation107 Fin7 refa0_inst.
Proof. unfold Equation107. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not108 : ~ @Equation108 Fin7 refa0_inst.
Proof. unfold Equation108. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not115 : ~ @Equation115 Fin7 refa0_inst.
Proof. unfold Equation115. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not117 : ~ @Equation117 Fin7 refa0_inst.
Proof. unfold Equation117. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not118 : ~ @Equation118 Fin7 refa0_inst.
Proof. unfold Equation118. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not124 : ~ @Equation124 Fin7 refa0_inst.
Proof. unfold Equation124. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not159 : ~ @Equation159 Fin7 refa0_inst.
Proof. unfold Equation159. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not160 : ~ @Equation160 Fin7 refa0_inst.
Proof. unfold Equation160. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not167 : ~ @Equation167 Fin7 refa0_inst.
Proof. unfold Equation167. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not206 : ~ @Equation206 Fin7 refa0_inst.
Proof. unfold Equation206. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not209 : ~ @Equation209 Fin7 refa0_inst.
Proof. unfold Equation209. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not211 : ~ @Equation211 Fin7 refa0_inst.
Proof. unfold Equation211. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not218 : ~ @Equation218 Fin7 refa0_inst.
Proof. unfold Equation218. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not221 : ~ @Equation221 Fin7 refa0_inst.
Proof. unfold Equation221. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not229 : ~ @Equation229 Fin7 refa0_inst.
Proof. unfold Equation229. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not231 : ~ @Equation231 Fin7 refa0_inst.
Proof. unfold Equation231. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not257 : ~ @Equation257 Fin7 refa0_inst.
Proof. unfold Equation257. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not261 : ~ @Equation261 Fin7 refa0_inst.
Proof. unfold Equation261. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not263 : ~ @Equation263 Fin7 refa0_inst.
Proof. unfold Equation263. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not273 : ~ @Equation273 Fin7 refa0_inst.
Proof. unfold Equation273. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not274 : ~ @Equation274 Fin7 refa0_inst.
Proof. unfold Equation274. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not280 : ~ @Equation280 Fin7 refa0_inst.
Proof. unfold Equation280. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not283 : ~ @Equation283 Fin7 refa0_inst.
Proof. unfold Equation283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not308 : ~ @Equation308 Fin7 refa0_inst.
Proof. unfold Equation308. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not309 : ~ @Equation309 Fin7 refa0_inst.
Proof. unfold Equation309. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not323 : ~ @Equation323 Fin7 refa0_inst.
Proof. unfold Equation323. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not333 : ~ @Equation333 Fin7 refa0_inst.
Proof. unfold Equation333. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not335 : ~ @Equation335 Fin7 refa0_inst.
Proof. unfold Equation335. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not361 : ~ @Equation361 Fin7 refa0_inst.
Proof. unfold Equation361. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not365 : ~ @Equation365 Fin7 refa0_inst.
Proof. unfold Equation365. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not384 : ~ @Equation384 Fin7 refa0_inst.
Proof. unfold Equation384. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not385 : ~ @Equation385 Fin7 refa0_inst.
Proof. unfold Equation385. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not412 : ~ @Equation412 Fin7 refa0_inst.
Proof. unfold Equation412. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not413 : ~ @Equation413 Fin7 refa0_inst.
Proof. unfold Equation413. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not414 : ~ @Equation414 Fin7 refa0_inst.
Proof. unfold Equation414. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not416 : ~ @Equation416 Fin7 refa0_inst.
Proof. unfold Equation416. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not417 : ~ @Equation417 Fin7 refa0_inst.
Proof. unfold Equation417. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not420 : ~ @Equation420 Fin7 refa0_inst.
Proof. unfold Equation420. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not426 : ~ @Equation426 Fin7 refa0_inst.
Proof. unfold Equation426. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not427 : ~ @Equation427 Fin7 refa0_inst.
Proof. unfold Equation427. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not429 : ~ @Equation429 Fin7 refa0_inst.
Proof. unfold Equation429. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not430 : ~ @Equation430 Fin7 refa0_inst.
Proof. unfold Equation430. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not437 : ~ @Equation437 Fin7 refa0_inst.
Proof. unfold Equation437. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not439 : ~ @Equation439 Fin7 refa0_inst.
Proof. unfold Equation439. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not440 : ~ @Equation440 Fin7 refa0_inst.
Proof. unfold Equation440. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not464 : ~ @Equation464 Fin7 refa0_inst.
Proof. unfold Equation464. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not467 : ~ @Equation467 Fin7 refa0_inst.
Proof. unfold Equation467. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not473 : ~ @Equation473 Fin7 refa0_inst.
Proof. unfold Equation473. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not474 : ~ @Equation474 Fin7 refa0_inst.
Proof. unfold Equation474. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not476 : ~ @Equation476 Fin7 refa0_inst.
Proof. unfold Equation476. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not477 : ~ @Equation477 Fin7 refa0_inst.
Proof. unfold Equation477. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not501 : ~ @Equation501 Fin7 refa0_inst.
Proof. unfold Equation501. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not503 : ~ @Equation503 Fin7 refa0_inst.
Proof. unfold Equation503. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not504 : ~ @Equation504 Fin7 refa0_inst.
Proof. unfold Equation504. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not511 : ~ @Equation511 Fin7 refa0_inst.
Proof. unfold Equation511. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not615 : ~ @Equation615 Fin7 refa0_inst.
Proof. unfold Equation615. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not616 : ~ @Equation616 Fin7 refa0_inst.
Proof. unfold Equation616. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not617 : ~ @Equation617 Fin7 refa0_inst.
Proof. unfold Equation617. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not619 : ~ @Equation619 Fin7 refa0_inst.
Proof. unfold Equation619. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not620 : ~ @Equation620 Fin7 refa0_inst.
Proof. unfold Equation620. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not622 : ~ @Equation622 Fin7 refa0_inst.
Proof. unfold Equation622. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not623 : ~ @Equation623 Fin7 refa0_inst.
Proof. unfold Equation623. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not629 : ~ @Equation629 Fin7 refa0_inst.
Proof. unfold Equation629. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not630 : ~ @Equation630 Fin7 refa0_inst.
Proof. unfold Equation630. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not632 : ~ @Equation632 Fin7 refa0_inst.
Proof. unfold Equation632. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not633 : ~ @Equation633 Fin7 refa0_inst.
Proof. unfold Equation633. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not639 : ~ @Equation639 Fin7 refa0_inst.
Proof. unfold Equation639. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not640 : ~ @Equation640 Fin7 refa0_inst.
Proof. unfold Equation640. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not643 : ~ @Equation643 Fin7 refa0_inst.
Proof. unfold Equation643. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not667 : ~ @Equation667 Fin7 refa0_inst.
Proof. unfold Equation667. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not670 : ~ @Equation670 Fin7 refa0_inst.
Proof. unfold Equation670. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not676 : ~ @Equation676 Fin7 refa0_inst.
Proof. unfold Equation676. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not677 : ~ @Equation677 Fin7 refa0_inst.
Proof. unfold Equation677. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not679 : ~ @Equation679 Fin7 refa0_inst.
Proof. unfold Equation679. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not680 : ~ @Equation680 Fin7 refa0_inst.
Proof. unfold Equation680. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not704 : ~ @Equation704 Fin7 refa0_inst.
Proof. unfold Equation704. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not706 : ~ @Equation706 Fin7 refa0_inst.
Proof. unfold Equation706. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not707 : ~ @Equation707 Fin7 refa0_inst.
Proof. unfold Equation707. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not713 : ~ @Equation713 Fin7 refa0_inst.
Proof. unfold Equation713. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not716 : ~ @Equation716 Fin7 refa0_inst.
Proof. unfold Equation716. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not818 : ~ @Equation818 Fin7 refa0_inst.
Proof. unfold Equation818. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not819 : ~ @Equation819 Fin7 refa0_inst.
Proof. unfold Equation819. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not820 : ~ @Equation820 Fin7 refa0_inst.
Proof. unfold Equation820. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not822 : ~ @Equation822 Fin7 refa0_inst.
Proof. unfold Equation822. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not823 : ~ @Equation823 Fin7 refa0_inst.
Proof. unfold Equation823. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not825 : ~ @Equation825 Fin7 refa0_inst.
Proof. unfold Equation825. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not826 : ~ @Equation826 Fin7 refa0_inst.
Proof. unfold Equation826. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not832 : ~ @Equation832 Fin7 refa0_inst.
Proof. unfold Equation832. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not833 : ~ @Equation833 Fin7 refa0_inst.
Proof. unfold Equation833. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not835 : ~ @Equation835 Fin7 refa0_inst.
Proof. unfold Equation835. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not836 : ~ @Equation836 Fin7 refa0_inst.
Proof. unfold Equation836. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not842 : ~ @Equation842 Fin7 refa0_inst.
Proof. unfold Equation842. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not843 : ~ @Equation843 Fin7 refa0_inst.
Proof. unfold Equation843. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not846 : ~ @Equation846 Fin7 refa0_inst.
Proof. unfold Equation846. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not870 : ~ @Equation870 Fin7 refa0_inst.
Proof. unfold Equation870. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not872 : ~ @Equation872 Fin7 refa0_inst.
Proof. unfold Equation872. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not873 : ~ @Equation873 Fin7 refa0_inst.
Proof. unfold Equation873. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not879 : ~ @Equation879 Fin7 refa0_inst.
Proof. unfold Equation879. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not882 : ~ @Equation882 Fin7 refa0_inst.
Proof. unfold Equation882. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not883 : ~ @Equation883 Fin7 refa0_inst.
Proof. unfold Equation883. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not906 : ~ @Equation906 Fin7 refa0_inst.
Proof. unfold Equation906. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not907 : ~ @Equation907 Fin7 refa0_inst.
Proof. unfold Equation907. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not917 : ~ @Equation917 Fin7 refa0_inst.
Proof. unfold Equation917. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1021 : ~ @Equation1021 Fin7 refa0_inst.
Proof. unfold Equation1021. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1022 : ~ @Equation1022 Fin7 refa0_inst.
Proof. unfold Equation1022. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1023 : ~ @Equation1023 Fin7 refa0_inst.
Proof. unfold Equation1023. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1025 : ~ @Equation1025 Fin7 refa0_inst.
Proof. unfold Equation1025. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1026 : ~ @Equation1026 Fin7 refa0_inst.
Proof. unfold Equation1026. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1028 : ~ @Equation1028 Fin7 refa0_inst.
Proof. unfold Equation1028. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1029 : ~ @Equation1029 Fin7 refa0_inst.
Proof. unfold Equation1029. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1035 : ~ @Equation1035 Fin7 refa0_inst.
Proof. unfold Equation1035. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1036 : ~ @Equation1036 Fin7 refa0_inst.
Proof. unfold Equation1036. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1038 : ~ @Equation1038 Fin7 refa0_inst.
Proof. unfold Equation1038. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1039 : ~ @Equation1039 Fin7 refa0_inst.
Proof. unfold Equation1039. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1046 : ~ @Equation1046 Fin7 refa0_inst.
Proof. unfold Equation1046. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1048 : ~ @Equation1048 Fin7 refa0_inst.
Proof. unfold Equation1048. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1049 : ~ @Equation1049 Fin7 refa0_inst.
Proof. unfold Equation1049. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1076 : ~ @Equation1076 Fin7 refa0_inst.
Proof. unfold Equation1076. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1082 : ~ @Equation1082 Fin7 refa0_inst.
Proof. unfold Equation1082. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1085 : ~ @Equation1085 Fin7 refa0_inst.
Proof. unfold Equation1085. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1086 : ~ @Equation1086 Fin7 refa0_inst.
Proof. unfold Equation1086. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1109 : ~ @Equation1109 Fin7 refa0_inst.
Proof. unfold Equation1109. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1110 : ~ @Equation1110 Fin7 refa0_inst.
Proof. unfold Equation1110. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1112 : ~ @Equation1112 Fin7 refa0_inst.
Proof. unfold Equation1112. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1113 : ~ @Equation1113 Fin7 refa0_inst.
Proof. unfold Equation1113. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1119 : ~ @Equation1119 Fin7 refa0_inst.
Proof. unfold Equation1119. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1224 : ~ @Equation1224 Fin7 refa0_inst.
Proof. unfold Equation1224. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1225 : ~ @Equation1225 Fin7 refa0_inst.
Proof. unfold Equation1225. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1226 : ~ @Equation1226 Fin7 refa0_inst.
Proof. unfold Equation1226. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1228 : ~ @Equation1228 Fin7 refa0_inst.
Proof. unfold Equation1228. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1229 : ~ @Equation1229 Fin7 refa0_inst.
Proof. unfold Equation1229. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1231 : ~ @Equation1231 Fin7 refa0_inst.
Proof. unfold Equation1231. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1238 : ~ @Equation1238 Fin7 refa0_inst.
Proof. unfold Equation1238. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1241 : ~ @Equation1241 Fin7 refa0_inst.
Proof. unfold Equation1241. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1242 : ~ @Equation1242 Fin7 refa0_inst.
Proof. unfold Equation1242. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1248 : ~ @Equation1248 Fin7 refa0_inst.
Proof. unfold Equation1248. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1249 : ~ @Equation1249 Fin7 refa0_inst.
Proof. unfold Equation1249. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1251 : ~ @Equation1251 Fin7 refa0_inst.
Proof. unfold Equation1251. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1252 : ~ @Equation1252 Fin7 refa0_inst.
Proof. unfold Equation1252. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1276 : ~ @Equation1276 Fin7 refa0_inst.
Proof. unfold Equation1276. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1278 : ~ @Equation1278 Fin7 refa0_inst.
Proof. unfold Equation1278. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1279 : ~ @Equation1279 Fin7 refa0_inst.
Proof. unfold Equation1279. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1285 : ~ @Equation1285 Fin7 refa0_inst.
Proof. unfold Equation1285. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1288 : ~ @Equation1288 Fin7 refa0_inst.
Proof. unfold Equation1288. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1289 : ~ @Equation1289 Fin7 refa0_inst.
Proof. unfold Equation1289. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1312 : ~ @Equation1312 Fin7 refa0_inst.
Proof. unfold Equation1312. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1313 : ~ @Equation1313 Fin7 refa0_inst.
Proof. unfold Equation1313. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1315 : ~ @Equation1315 Fin7 refa0_inst.
Proof. unfold Equation1315. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1322 : ~ @Equation1322 Fin7 refa0_inst.
Proof. unfold Equation1322. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1427 : ~ @Equation1427 Fin7 refa0_inst.
Proof. unfold Equation1427. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1428 : ~ @Equation1428 Fin7 refa0_inst.
Proof. unfold Equation1428. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1429 : ~ @Equation1429 Fin7 refa0_inst.
Proof. unfold Equation1429. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1431 : ~ @Equation1431 Fin7 refa0_inst.
Proof. unfold Equation1431. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1432 : ~ @Equation1432 Fin7 refa0_inst.
Proof. unfold Equation1432. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1435 : ~ @Equation1435 Fin7 refa0_inst.
Proof. unfold Equation1435. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1441 : ~ @Equation1441 Fin7 refa0_inst.
Proof. unfold Equation1441. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1442 : ~ @Equation1442 Fin7 refa0_inst.
Proof. unfold Equation1442. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1445 : ~ @Equation1445 Fin7 refa0_inst.
Proof. unfold Equation1445. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1451 : ~ @Equation1451 Fin7 refa0_inst.
Proof. unfold Equation1451. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1454 : ~ @Equation1454 Fin7 refa0_inst.
Proof. unfold Equation1454. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1455 : ~ @Equation1455 Fin7 refa0_inst.
Proof. unfold Equation1455. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1478 : ~ @Equation1478 Fin7 refa0_inst.
Proof. unfold Equation1478. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1479 : ~ @Equation1479 Fin7 refa0_inst.
Proof. unfold Equation1479. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1481 : ~ @Equation1481 Fin7 refa0_inst.
Proof. unfold Equation1481. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1482 : ~ @Equation1482 Fin7 refa0_inst.
Proof. unfold Equation1482. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1488 : ~ @Equation1488 Fin7 refa0_inst.
Proof. unfold Equation1488. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1489 : ~ @Equation1489 Fin7 refa0_inst.
Proof. unfold Equation1489. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1491 : ~ @Equation1491 Fin7 refa0_inst.
Proof. unfold Equation1491. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1515 : ~ @Equation1515 Fin7 refa0_inst.
Proof. unfold Equation1515. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1516 : ~ @Equation1516 Fin7 refa0_inst.
Proof. unfold Equation1516. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1518 : ~ @Equation1518 Fin7 refa0_inst.
Proof. unfold Equation1518. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1519 : ~ @Equation1519 Fin7 refa0_inst.
Proof. unfold Equation1519. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1526 : ~ @Equation1526 Fin7 refa0_inst.
Proof. unfold Equation1526. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1630 : ~ @Equation1630 Fin7 refa0_inst.
Proof. unfold Equation1630. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1631 : ~ @Equation1631 Fin7 refa0_inst.
Proof. unfold Equation1631. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1632 : ~ @Equation1632 Fin7 refa0_inst.
Proof. unfold Equation1632. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1634 : ~ @Equation1634 Fin7 refa0_inst.
Proof. unfold Equation1634. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1635 : ~ @Equation1635 Fin7 refa0_inst.
Proof. unfold Equation1635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1637 : ~ @Equation1637 Fin7 refa0_inst.
Proof. unfold Equation1637. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1638 : ~ @Equation1638 Fin7 refa0_inst.
Proof. unfold Equation1638. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1644 : ~ @Equation1644 Fin7 refa0_inst.
Proof. unfold Equation1644. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1645 : ~ @Equation1645 Fin7 refa0_inst.
Proof. unfold Equation1645. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1648 : ~ @Equation1648 Fin7 refa0_inst.
Proof. unfold Equation1648. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1654 : ~ @Equation1654 Fin7 refa0_inst.
Proof. unfold Equation1654. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1655 : ~ @Equation1655 Fin7 refa0_inst.
Proof. unfold Equation1655. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1657 : ~ @Equation1657 Fin7 refa0_inst.
Proof. unfold Equation1657. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1658 : ~ @Equation1658 Fin7 refa0_inst.
Proof. unfold Equation1658. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1681 : ~ @Equation1681 Fin7 refa0_inst.
Proof. unfold Equation1681. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1682 : ~ @Equation1682 Fin7 refa0_inst.
Proof. unfold Equation1682. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1684 : ~ @Equation1684 Fin7 refa0_inst.
Proof. unfold Equation1684. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1692 : ~ @Equation1692 Fin7 refa0_inst.
Proof. unfold Equation1692. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1694 : ~ @Equation1694 Fin7 refa0_inst.
Proof. unfold Equation1694. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1719 : ~ @Equation1719 Fin7 refa0_inst.
Proof. unfold Equation1719. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1721 : ~ @Equation1721 Fin7 refa0_inst.
Proof. unfold Equation1721. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1722 : ~ @Equation1722 Fin7 refa0_inst.
Proof. unfold Equation1722. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1728 : ~ @Equation1728 Fin7 refa0_inst.
Proof. unfold Equation1728. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1833 : ~ @Equation1833 Fin7 refa0_inst.
Proof. unfold Equation1833. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1834 : ~ @Equation1834 Fin7 refa0_inst.
Proof. unfold Equation1834. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1837 : ~ @Equation1837 Fin7 refa0_inst.
Proof. unfold Equation1837. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1838 : ~ @Equation1838 Fin7 refa0_inst.
Proof. unfold Equation1838. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1841 : ~ @Equation1841 Fin7 refa0_inst.
Proof. unfold Equation1841. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1847 : ~ @Equation1847 Fin7 refa0_inst.
Proof. unfold Equation1847. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1848 : ~ @Equation1848 Fin7 refa0_inst.
Proof. unfold Equation1848. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1851 : ~ @Equation1851 Fin7 refa0_inst.
Proof. unfold Equation1851. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1857 : ~ @Equation1857 Fin7 refa0_inst.
Proof. unfold Equation1857. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1858 : ~ @Equation1858 Fin7 refa0_inst.
Proof. unfold Equation1858. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1860 : ~ @Equation1860 Fin7 refa0_inst.
Proof. unfold Equation1860. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1861 : ~ @Equation1861 Fin7 refa0_inst.
Proof. unfold Equation1861. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1884 : ~ @Equation1884 Fin7 refa0_inst.
Proof. unfold Equation1884. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1885 : ~ @Equation1885 Fin7 refa0_inst.
Proof. unfold Equation1885. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1887 : ~ @Equation1887 Fin7 refa0_inst.
Proof. unfold Equation1887. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1888 : ~ @Equation1888 Fin7 refa0_inst.
Proof. unfold Equation1888. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1894 : ~ @Equation1894 Fin7 refa0_inst.
Proof. unfold Equation1894. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1897 : ~ @Equation1897 Fin7 refa0_inst.
Proof. unfold Equation1897. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1922 : ~ @Equation1922 Fin7 refa0_inst.
Proof. unfold Equation1922. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1924 : ~ @Equation1924 Fin7 refa0_inst.
Proof. unfold Equation1924. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1925 : ~ @Equation1925 Fin7 refa0_inst.
Proof. unfold Equation1925. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not1931 : ~ @Equation1931 Fin7 refa0_inst.
Proof. unfold Equation1931. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2036 : ~ @Equation2036 Fin7 refa0_inst.
Proof. unfold Equation2036. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2037 : ~ @Equation2037 Fin7 refa0_inst.
Proof. unfold Equation2037. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2038 : ~ @Equation2038 Fin7 refa0_inst.
Proof. unfold Equation2038. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2040 : ~ @Equation2040 Fin7 refa0_inst.
Proof. unfold Equation2040. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2041 : ~ @Equation2041 Fin7 refa0_inst.
Proof. unfold Equation2041. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2043 : ~ @Equation2043 Fin7 refa0_inst.
Proof. unfold Equation2043. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2044 : ~ @Equation2044 Fin7 refa0_inst.
Proof. unfold Equation2044. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2050 : ~ @Equation2050 Fin7 refa0_inst.
Proof. unfold Equation2050. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2051 : ~ @Equation2051 Fin7 refa0_inst.
Proof. unfold Equation2051. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2053 : ~ @Equation2053 Fin7 refa0_inst.
Proof. unfold Equation2053. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2054 : ~ @Equation2054 Fin7 refa0_inst.
Proof. unfold Equation2054. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2060 : ~ @Equation2060 Fin7 refa0_inst.
Proof. unfold Equation2060. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2061 : ~ @Equation2061 Fin7 refa0_inst.
Proof. unfold Equation2061. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2063 : ~ @Equation2063 Fin7 refa0_inst.
Proof. unfold Equation2063. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2124 : ~ @Equation2124 Fin7 refa0_inst.
Proof. unfold Equation2124. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2128 : ~ @Equation2128 Fin7 refa0_inst.
Proof. unfold Equation2128. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2241 : ~ @Equation2241 Fin7 refa0_inst.
Proof. unfold Equation2241. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2246 : ~ @Equation2246 Fin7 refa0_inst.
Proof. unfold Equation2246. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2254 : ~ @Equation2254 Fin7 refa0_inst.
Proof. unfold Equation2254. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2256 : ~ @Equation2256 Fin7 refa0_inst.
Proof. unfold Equation2256. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2293 : ~ @Equation2293 Fin7 refa0_inst.
Proof. unfold Equation2293. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2300 : ~ @Equation2300 Fin7 refa0_inst.
Proof. unfold Equation2300. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2328 : ~ @Equation2328 Fin7 refa0_inst.
Proof. unfold Equation2328. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2330 : ~ @Equation2330 Fin7 refa0_inst.
Proof. unfold Equation2330. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2337 : ~ @Equation2337 Fin7 refa0_inst.
Proof. unfold Equation2337. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2338 : ~ @Equation2338 Fin7 refa0_inst.
Proof. unfold Equation2338. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2444 : ~ @Equation2444 Fin7 refa0_inst.
Proof. unfold Equation2444. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2446 : ~ @Equation2446 Fin7 refa0_inst.
Proof. unfold Equation2446. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2449 : ~ @Equation2449 Fin7 refa0_inst.
Proof. unfold Equation2449. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2450 : ~ @Equation2450 Fin7 refa0_inst.
Proof. unfold Equation2450. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2457 : ~ @Equation2457 Fin7 refa0_inst.
Proof. unfold Equation2457. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2466 : ~ @Equation2466 Fin7 refa0_inst.
Proof. unfold Equation2466. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2467 : ~ @Equation2467 Fin7 refa0_inst.
Proof. unfold Equation2467. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2503 : ~ @Equation2503 Fin7 refa0_inst.
Proof. unfold Equation2503. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2530 : ~ @Equation2530 Fin7 refa0_inst.
Proof. unfold Equation2530. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2533 : ~ @Equation2533 Fin7 refa0_inst.
Proof. unfold Equation2533. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2534 : ~ @Equation2534 Fin7 refa0_inst.
Proof. unfold Equation2534. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2541 : ~ @Equation2541 Fin7 refa0_inst.
Proof. unfold Equation2541. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2669 : ~ @Equation2669 Fin7 refa0_inst.
Proof. unfold Equation2669. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2672 : ~ @Equation2672 Fin7 refa0_inst.
Proof. unfold Equation2672. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2744 : ~ @Equation2744 Fin7 refa0_inst.
Proof. unfold Equation2744. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2855 : ~ @Equation2855 Fin7 refa0_inst.
Proof. unfold Equation2855. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2863 : ~ @Equation2863 Fin7 refa0_inst.
Proof. unfold Equation2863. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2865 : ~ @Equation2865 Fin7 refa0_inst.
Proof. unfold Equation2865. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2866 : ~ @Equation2866 Fin7 refa0_inst.
Proof. unfold Equation2866. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2872 : ~ @Equation2872 Fin7 refa0_inst.
Proof. unfold Equation2872. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2875 : ~ @Equation2875 Fin7 refa0_inst.
Proof. unfold Equation2875. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2939 : ~ @Equation2939 Fin7 refa0_inst.
Proof. unfold Equation2939. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2940 : ~ @Equation2940 Fin7 refa0_inst.
Proof. unfold Equation2940. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not2947 : ~ @Equation2947 Fin7 refa0_inst.
Proof. unfold Equation2947. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3056 : ~ @Equation3056 Fin7 refa0_inst.
Proof. unfold Equation3056. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3058 : ~ @Equation3058 Fin7 refa0_inst.
Proof. unfold Equation3058. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3066 : ~ @Equation3066 Fin7 refa0_inst.
Proof. unfold Equation3066. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3068 : ~ @Equation3068 Fin7 refa0_inst.
Proof. unfold Equation3068. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3069 : ~ @Equation3069 Fin7 refa0_inst.
Proof. unfold Equation3069. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3075 : ~ @Equation3075 Fin7 refa0_inst.
Proof. unfold Equation3075. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3079 : ~ @Equation3079 Fin7 refa0_inst.
Proof. unfold Equation3079. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3116 : ~ @Equation3116 Fin7 refa0_inst.
Proof. unfold Equation3116. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3139 : ~ @Equation3139 Fin7 refa0_inst.
Proof. unfold Equation3139. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3150 : ~ @Equation3150 Fin7 refa0_inst.
Proof. unfold Equation3150. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3269 : ~ @Equation3269 Fin7 refa0_inst.
Proof. unfold Equation3269. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3279 : ~ @Equation3279 Fin7 refa0_inst.
Proof. unfold Equation3279. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3281 : ~ @Equation3281 Fin7 refa0_inst.
Proof. unfold Equation3281. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3345 : ~ @Equation3345 Fin7 refa0_inst.
Proof. unfold Equation3345. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3459 : ~ @Equation3459 Fin7 refa0_inst.
Proof. unfold Equation3459. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3472 : ~ @Equation3472 Fin7 refa0_inst.
Proof. unfold Equation3472. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3474 : ~ @Equation3474 Fin7 refa0_inst.
Proof. unfold Equation3474. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3482 : ~ @Equation3482 Fin7 refa0_inst.
Proof. unfold Equation3482. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3518 : ~ @Equation3518 Fin7 refa0_inst.
Proof. unfold Equation3518. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3519 : ~ @Equation3519 Fin7 refa0_inst.
Proof. unfold Equation3519. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3521 : ~ @Equation3521 Fin7 refa0_inst.
Proof. unfold Equation3521. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3548 : ~ @Equation3548 Fin7 refa0_inst.
Proof. unfold Equation3548. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3662 : ~ @Equation3662 Fin7 refa0_inst.
Proof. unfold Equation3662. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3665 : ~ @Equation3665 Fin7 refa0_inst.
Proof. unfold Equation3665. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3667 : ~ @Equation3667 Fin7 refa0_inst.
Proof. unfold Equation3667. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3668 : ~ @Equation3668 Fin7 refa0_inst.
Proof. unfold Equation3668. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3675 : ~ @Equation3675 Fin7 refa0_inst.
Proof. unfold Equation3675. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3677 : ~ @Equation3677 Fin7 refa0_inst.
Proof. unfold Equation3677. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3684 : ~ @Equation3684 Fin7 refa0_inst.
Proof. unfold Equation3684. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3871 : ~ @Equation3871 Fin7 refa0_inst.
Proof. unfold Equation3871. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3888 : ~ @Equation3888 Fin7 refa0_inst.
Proof. unfold Equation3888. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3924 : ~ @Equation3924 Fin7 refa0_inst.
Proof. unfold Equation3924. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not3961 : ~ @Equation3961 Fin7 refa0_inst.
Proof. unfold Equation3961. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4068 : ~ @Equation4068 Fin7 refa0_inst.
Proof. unfold Equation4068. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4071 : ~ @Equation4071 Fin7 refa0_inst.
Proof. unfold Equation4071. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4073 : ~ @Equation4073 Fin7 refa0_inst.
Proof. unfold Equation4073. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4090 : ~ @Equation4090 Fin7 refa0_inst.
Proof. unfold Equation4090. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4120 : ~ @Equation4120 Fin7 refa0_inst.
Proof. unfold Equation4120. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4127 : ~ @Equation4127 Fin7 refa0_inst.
Proof. unfold Equation4127. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4131 : ~ @Equation4131 Fin7 refa0_inst.
Proof. unfold Equation4131. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4154 : ~ @Equation4154 Fin7 refa0_inst.
Proof. unfold Equation4154. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4270 : ~ @Equation4270 Fin7 refa0_inst.
Proof. unfold Equation4270. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4283 : ~ @Equation4283 Fin7 refa0_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4293 : ~ @Equation4293 Fin7 refa0_inst.
Proof. unfold Equation4293. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4314 : ~ @Equation4314 Fin7 refa0_inst.
Proof. unfold Equation4314. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4398 : ~ @Equation4398 Fin7 refa0_inst.
Proof. unfold Equation4398. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4399 : ~ @Equation4399 Fin7 refa0_inst.
Proof. unfold Equation4399. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4405 : ~ @Equation4405 Fin7 refa0_inst.
Proof. unfold Equation4405. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4442 : ~ @Equation4442 Fin7 refa0_inst.
Proof. unfold Equation4442. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4482 : ~ @Equation4482 Fin7 refa0_inst.
Proof. unfold Equation4482. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4585 : ~ @Equation4585 Fin7 refa0_inst.
Proof. unfold Equation4585. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4590 : ~ @Equation4590 Fin7 refa0_inst.
Proof. unfold Equation4590. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

Lemma refa0_not4635 : ~ @Equation4635 Fin7 refa0_inst.
Proof. unfold Equation4635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa0_inst, refa0_op in H. discriminate H. Qed.

(** ---- refa1 (Fin7) ---- *)

Definition refa1_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_1 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_6 | F7_0, F7_6 => F7_4
  | F7_1, F7_0 => F7_4 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_6 | F7_1, F7_3 => F7_0 | F7_1, F7_4 => F7_3 | F7_1, F7_5 => F7_2 | F7_1, F7_6 => F7_5
  | F7_2, F7_0 => F7_5 | F7_2, F7_1 => F7_0 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_4 | F7_2, F7_4 => F7_6 | F7_2, F7_5 => F7_1 | F7_2, F7_6 => F7_3
  | F7_3, F7_0 => F7_6 | F7_3, F7_1 => F7_5 | F7_3, F7_2 => F7_0 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_1 | F7_3, F7_5 => F7_4 | F7_3, F7_6 => F7_2
  | F7_4, F7_0 => F7_1 | F7_4, F7_1 => F7_6 | F7_4, F7_2 => F7_5 | F7_4, F7_3 => F7_2 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_3 | F7_4, F7_6 => F7_0
  | F7_5, F7_0 => F7_2 | F7_5, F7_1 => F7_3 | F7_5, F7_2 => F7_4 | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_0 | F7_5, F7_5 => F7_5 | F7_5, F7_6 => F7_1
  | F7_6, F7_0 => F7_3 | F7_6, F7_1 => F7_4 | F7_6, F7_2 => F7_1 | F7_6, F7_3 => F7_5 | F7_6, F7_4 => F7_2 | F7_6, F7_5 => F7_0 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa1_inst : Magma Fin7 := {| magma_op := refa1_op |}.

Lemma refa1_sat467 : @Equation467 Fin7 refa1_inst.
Proof. unfold Equation467, magma_op, refa1_inst, refa1_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa1_sat667 : @Equation667 Fin7 refa1_inst.
Proof. unfold Equation667, magma_op, refa1_inst, refa1_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa1_sat1112 : @Equation1112 Fin7 refa1_inst.
Proof. unfold Equation1112, magma_op, refa1_inst, refa1_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa1_sat1286 : @Equation1286 Fin7 refa1_inst.
Proof. unfold Equation1286, magma_op, refa1_inst, refa1_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa1_sat1516 : @Equation1516 Fin7 refa1_inst.
Proof. unfold Equation1516, magma_op, refa1_inst, refa1_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa1_sat2301 : @Equation2301 Fin7 refa1_inst.
Proof. unfold Equation2301, magma_op, refa1_inst, refa1_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa1_sat3269 : @Equation3269 Fin7 refa1_inst.
Proof. unfold Equation3269, magma_op, refa1_inst, refa1_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa1_not55 : ~ @Equation55 Fin7 refa1_inst.
Proof. unfold Equation55. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not108 : ~ @Equation108 Fin7 refa1_inst.
Proof. unfold Equation108. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not117 : ~ @Equation117 Fin7 refa1_inst.
Proof. unfold Equation117. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not118 : ~ @Equation118 Fin7 refa1_inst.
Proof. unfold Equation118. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not124 : ~ @Equation124 Fin7 refa1_inst.
Proof. unfold Equation124. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not127 : ~ @Equation127 Fin7 refa1_inst.
Proof. unfold Equation127. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not159 : ~ @Equation159 Fin7 refa1_inst.
Proof. unfold Equation159. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not167 : ~ @Equation167 Fin7 refa1_inst.
Proof. unfold Equation167. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not206 : ~ @Equation206 Fin7 refa1_inst.
Proof. unfold Equation206. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not209 : ~ @Equation209 Fin7 refa1_inst.
Proof. unfold Equation209. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not211 : ~ @Equation211 Fin7 refa1_inst.
Proof. unfold Equation211. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not229 : ~ @Equation229 Fin7 refa1_inst.
Proof. unfold Equation229. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not231 : ~ @Equation231 Fin7 refa1_inst.
Proof. unfold Equation231. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not261 : ~ @Equation261 Fin7 refa1_inst.
Proof. unfold Equation261. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not264 : ~ @Equation264 Fin7 refa1_inst.
Proof. unfold Equation264. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not274 : ~ @Equation274 Fin7 refa1_inst.
Proof. unfold Equation274. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not280 : ~ @Equation280 Fin7 refa1_inst.
Proof. unfold Equation280. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not283 : ~ @Equation283 Fin7 refa1_inst.
Proof. unfold Equation283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not377 : ~ @Equation377 Fin7 refa1_inst.
Proof. unfold Equation377. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not378 : ~ @Equation378 Fin7 refa1_inst.
Proof. unfold Equation378. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not412 : ~ @Equation412 Fin7 refa1_inst.
Proof. unfold Equation412. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not413 : ~ @Equation413 Fin7 refa1_inst.
Proof. unfold Equation413. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not414 : ~ @Equation414 Fin7 refa1_inst.
Proof. unfold Equation414. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not416 : ~ @Equation416 Fin7 refa1_inst.
Proof. unfold Equation416. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not417 : ~ @Equation417 Fin7 refa1_inst.
Proof. unfold Equation417. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not419 : ~ @Equation419 Fin7 refa1_inst.
Proof. unfold Equation419. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not420 : ~ @Equation420 Fin7 refa1_inst.
Proof. unfold Equation420. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not426 : ~ @Equation426 Fin7 refa1_inst.
Proof. unfold Equation426. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not429 : ~ @Equation429 Fin7 refa1_inst.
Proof. unfold Equation429. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not430 : ~ @Equation430 Fin7 refa1_inst.
Proof. unfold Equation430. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not436 : ~ @Equation436 Fin7 refa1_inst.
Proof. unfold Equation436. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not437 : ~ @Equation437 Fin7 refa1_inst.
Proof. unfold Equation437. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not440 : ~ @Equation440 Fin7 refa1_inst.
Proof. unfold Equation440. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not464 : ~ @Equation464 Fin7 refa1_inst.
Proof. unfold Equation464. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not466 : ~ @Equation466 Fin7 refa1_inst.
Proof. unfold Equation466. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not473 : ~ @Equation473 Fin7 refa1_inst.
Proof. unfold Equation473. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not474 : ~ @Equation474 Fin7 refa1_inst.
Proof. unfold Equation474. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not476 : ~ @Equation476 Fin7 refa1_inst.
Proof. unfold Equation476. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not477 : ~ @Equation477 Fin7 refa1_inst.
Proof. unfold Equation477. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not501 : ~ @Equation501 Fin7 refa1_inst.
Proof. unfold Equation501. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not503 : ~ @Equation503 Fin7 refa1_inst.
Proof. unfold Equation503. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not504 : ~ @Equation504 Fin7 refa1_inst.
Proof. unfold Equation504. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not511 : ~ @Equation511 Fin7 refa1_inst.
Proof. unfold Equation511. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not513 : ~ @Equation513 Fin7 refa1_inst.
Proof. unfold Equation513. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not615 : ~ @Equation615 Fin7 refa1_inst.
Proof. unfold Equation615. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not616 : ~ @Equation616 Fin7 refa1_inst.
Proof. unfold Equation616. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not619 : ~ @Equation619 Fin7 refa1_inst.
Proof. unfold Equation619. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not620 : ~ @Equation620 Fin7 refa1_inst.
Proof. unfold Equation620. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not622 : ~ @Equation622 Fin7 refa1_inst.
Proof. unfold Equation622. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not623 : ~ @Equation623 Fin7 refa1_inst.
Proof. unfold Equation623. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not629 : ~ @Equation629 Fin7 refa1_inst.
Proof. unfold Equation629. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not630 : ~ @Equation630 Fin7 refa1_inst.
Proof. unfold Equation630. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not632 : ~ @Equation632 Fin7 refa1_inst.
Proof. unfold Equation632. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not633 : ~ @Equation633 Fin7 refa1_inst.
Proof. unfold Equation633. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not639 : ~ @Equation639 Fin7 refa1_inst.
Proof. unfold Equation639. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not640 : ~ @Equation640 Fin7 refa1_inst.
Proof. unfold Equation640. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not642 : ~ @Equation642 Fin7 refa1_inst.
Proof. unfold Equation642. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not643 : ~ @Equation643 Fin7 refa1_inst.
Proof. unfold Equation643. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not669 : ~ @Equation669 Fin7 refa1_inst.
Proof. unfold Equation669. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not670 : ~ @Equation670 Fin7 refa1_inst.
Proof. unfold Equation670. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not676 : ~ @Equation676 Fin7 refa1_inst.
Proof. unfold Equation676. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not677 : ~ @Equation677 Fin7 refa1_inst.
Proof. unfold Equation677. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not679 : ~ @Equation679 Fin7 refa1_inst.
Proof. unfold Equation679. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not680 : ~ @Equation680 Fin7 refa1_inst.
Proof. unfold Equation680. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not704 : ~ @Equation704 Fin7 refa1_inst.
Proof. unfold Equation704. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not706 : ~ @Equation706 Fin7 refa1_inst.
Proof. unfold Equation706. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not707 : ~ @Equation707 Fin7 refa1_inst.
Proof. unfold Equation707. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not713 : ~ @Equation713 Fin7 refa1_inst.
Proof. unfold Equation713. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not818 : ~ @Equation818 Fin7 refa1_inst.
Proof. unfold Equation818. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not819 : ~ @Equation819 Fin7 refa1_inst.
Proof. unfold Equation819. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not820 : ~ @Equation820 Fin7 refa1_inst.
Proof. unfold Equation820. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not822 : ~ @Equation822 Fin7 refa1_inst.
Proof. unfold Equation822. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not823 : ~ @Equation823 Fin7 refa1_inst.
Proof. unfold Equation823. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not832 : ~ @Equation832 Fin7 refa1_inst.
Proof. unfold Equation832. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not835 : ~ @Equation835 Fin7 refa1_inst.
Proof. unfold Equation835. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not836 : ~ @Equation836 Fin7 refa1_inst.
Proof. unfold Equation836. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not842 : ~ @Equation842 Fin7 refa1_inst.
Proof. unfold Equation842. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not843 : ~ @Equation843 Fin7 refa1_inst.
Proof. unfold Equation843. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not845 : ~ @Equation845 Fin7 refa1_inst.
Proof. unfold Equation845. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not872 : ~ @Equation872 Fin7 refa1_inst.
Proof. unfold Equation872. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not873 : ~ @Equation873 Fin7 refa1_inst.
Proof. unfold Equation873. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not879 : ~ @Equation879 Fin7 refa1_inst.
Proof. unfold Equation879. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not882 : ~ @Equation882 Fin7 refa1_inst.
Proof. unfold Equation882. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not883 : ~ @Equation883 Fin7 refa1_inst.
Proof. unfold Equation883. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not906 : ~ @Equation906 Fin7 refa1_inst.
Proof. unfold Equation906. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not907 : ~ @Equation907 Fin7 refa1_inst.
Proof. unfold Equation907. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not917 : ~ @Equation917 Fin7 refa1_inst.
Proof. unfold Equation917. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1021 : ~ @Equation1021 Fin7 refa1_inst.
Proof. unfold Equation1021. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1022 : ~ @Equation1022 Fin7 refa1_inst.
Proof. unfold Equation1022. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1023 : ~ @Equation1023 Fin7 refa1_inst.
Proof. unfold Equation1023. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1025 : ~ @Equation1025 Fin7 refa1_inst.
Proof. unfold Equation1025. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1026 : ~ @Equation1026 Fin7 refa1_inst.
Proof. unfold Equation1026. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1028 : ~ @Equation1028 Fin7 refa1_inst.
Proof. unfold Equation1028. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1035 : ~ @Equation1035 Fin7 refa1_inst.
Proof. unfold Equation1035. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1036 : ~ @Equation1036 Fin7 refa1_inst.
Proof. unfold Equation1036. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1039 : ~ @Equation1039 Fin7 refa1_inst.
Proof. unfold Equation1039. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1045 : ~ @Equation1045 Fin7 refa1_inst.
Proof. unfold Equation1045. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1046 : ~ @Equation1046 Fin7 refa1_inst.
Proof. unfold Equation1046. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1048 : ~ @Equation1048 Fin7 refa1_inst.
Proof. unfold Equation1048. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1075 : ~ @Equation1075 Fin7 refa1_inst.
Proof. unfold Equation1075. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1076 : ~ @Equation1076 Fin7 refa1_inst.
Proof. unfold Equation1076. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1082 : ~ @Equation1082 Fin7 refa1_inst.
Proof. unfold Equation1082. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1085 : ~ @Equation1085 Fin7 refa1_inst.
Proof. unfold Equation1085. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1086 : ~ @Equation1086 Fin7 refa1_inst.
Proof. unfold Equation1086. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1109 : ~ @Equation1109 Fin7 refa1_inst.
Proof. unfold Equation1109. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1110 : ~ @Equation1110 Fin7 refa1_inst.
Proof. unfold Equation1110. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1113 : ~ @Equation1113 Fin7 refa1_inst.
Proof. unfold Equation1113. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1119 : ~ @Equation1119 Fin7 refa1_inst.
Proof. unfold Equation1119. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1122 : ~ @Equation1122 Fin7 refa1_inst.
Proof. unfold Equation1122. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1224 : ~ @Equation1224 Fin7 refa1_inst.
Proof. unfold Equation1224. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1225 : ~ @Equation1225 Fin7 refa1_inst.
Proof. unfold Equation1225. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1228 : ~ @Equation1228 Fin7 refa1_inst.
Proof. unfold Equation1228. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1229 : ~ @Equation1229 Fin7 refa1_inst.
Proof. unfold Equation1229. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1232 : ~ @Equation1232 Fin7 refa1_inst.
Proof. unfold Equation1232. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1238 : ~ @Equation1238 Fin7 refa1_inst.
Proof. unfold Equation1238. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1239 : ~ @Equation1239 Fin7 refa1_inst.
Proof. unfold Equation1239. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1241 : ~ @Equation1241 Fin7 refa1_inst.
Proof. unfold Equation1241. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1242 : ~ @Equation1242 Fin7 refa1_inst.
Proof. unfold Equation1242. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1248 : ~ @Equation1248 Fin7 refa1_inst.
Proof. unfold Equation1248. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1249 : ~ @Equation1249 Fin7 refa1_inst.
Proof. unfold Equation1249. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1251 : ~ @Equation1251 Fin7 refa1_inst.
Proof. unfold Equation1251. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1252 : ~ @Equation1252 Fin7 refa1_inst.
Proof. unfold Equation1252. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1276 : ~ @Equation1276 Fin7 refa1_inst.
Proof. unfold Equation1276. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1278 : ~ @Equation1278 Fin7 refa1_inst.
Proof. unfold Equation1278. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1279 : ~ @Equation1279 Fin7 refa1_inst.
Proof. unfold Equation1279. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1285 : ~ @Equation1285 Fin7 refa1_inst.
Proof. unfold Equation1285. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1288 : ~ @Equation1288 Fin7 refa1_inst.
Proof. unfold Equation1288. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1289 : ~ @Equation1289 Fin7 refa1_inst.
Proof. unfold Equation1289. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1312 : ~ @Equation1312 Fin7 refa1_inst.
Proof. unfold Equation1312. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1313 : ~ @Equation1313 Fin7 refa1_inst.
Proof. unfold Equation1313. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1322 : ~ @Equation1322 Fin7 refa1_inst.
Proof. unfold Equation1322. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1325 : ~ @Equation1325 Fin7 refa1_inst.
Proof. unfold Equation1325. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1427 : ~ @Equation1427 Fin7 refa1_inst.
Proof. unfold Equation1427. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1428 : ~ @Equation1428 Fin7 refa1_inst.
Proof. unfold Equation1428. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1429 : ~ @Equation1429 Fin7 refa1_inst.
Proof. unfold Equation1429. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1431 : ~ @Equation1431 Fin7 refa1_inst.
Proof. unfold Equation1431. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1432 : ~ @Equation1432 Fin7 refa1_inst.
Proof. unfold Equation1432. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1434 : ~ @Equation1434 Fin7 refa1_inst.
Proof. unfold Equation1434. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1435 : ~ @Equation1435 Fin7 refa1_inst.
Proof. unfold Equation1435. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1441 : ~ @Equation1441 Fin7 refa1_inst.
Proof. unfold Equation1441. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1444 : ~ @Equation1444 Fin7 refa1_inst.
Proof. unfold Equation1444. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1445 : ~ @Equation1445 Fin7 refa1_inst.
Proof. unfold Equation1445. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1451 : ~ @Equation1451 Fin7 refa1_inst.
Proof. unfold Equation1451. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1454 : ~ @Equation1454 Fin7 refa1_inst.
Proof. unfold Equation1454. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1478 : ~ @Equation1478 Fin7 refa1_inst.
Proof. unfold Equation1478. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1479 : ~ @Equation1479 Fin7 refa1_inst.
Proof. unfold Equation1479. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1482 : ~ @Equation1482 Fin7 refa1_inst.
Proof. unfold Equation1482. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1488 : ~ @Equation1488 Fin7 refa1_inst.
Proof. unfold Equation1488. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1491 : ~ @Equation1491 Fin7 refa1_inst.
Proof. unfold Equation1491. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1515 : ~ @Equation1515 Fin7 refa1_inst.
Proof. unfold Equation1515. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1518 : ~ @Equation1518 Fin7 refa1_inst.
Proof. unfold Equation1518. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1519 : ~ @Equation1519 Fin7 refa1_inst.
Proof. unfold Equation1519. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1525 : ~ @Equation1525 Fin7 refa1_inst.
Proof. unfold Equation1525. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1526 : ~ @Equation1526 Fin7 refa1_inst.
Proof. unfold Equation1526. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1630 : ~ @Equation1630 Fin7 refa1_inst.
Proof. unfold Equation1630. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1631 : ~ @Equation1631 Fin7 refa1_inst.
Proof. unfold Equation1631. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1634 : ~ @Equation1634 Fin7 refa1_inst.
Proof. unfold Equation1634. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1635 : ~ @Equation1635 Fin7 refa1_inst.
Proof. unfold Equation1635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1637 : ~ @Equation1637 Fin7 refa1_inst.
Proof. unfold Equation1637. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1638 : ~ @Equation1638 Fin7 refa1_inst.
Proof. unfold Equation1638. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1644 : ~ @Equation1644 Fin7 refa1_inst.
Proof. unfold Equation1644. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1645 : ~ @Equation1645 Fin7 refa1_inst.
Proof. unfold Equation1645. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1648 : ~ @Equation1648 Fin7 refa1_inst.
Proof. unfold Equation1648. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1655 : ~ @Equation1655 Fin7 refa1_inst.
Proof. unfold Equation1655. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1657 : ~ @Equation1657 Fin7 refa1_inst.
Proof. unfold Equation1657. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1681 : ~ @Equation1681 Fin7 refa1_inst.
Proof. unfold Equation1681. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1682 : ~ @Equation1682 Fin7 refa1_inst.
Proof. unfold Equation1682. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1684 : ~ @Equation1684 Fin7 refa1_inst.
Proof. unfold Equation1684. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1685 : ~ @Equation1685 Fin7 refa1_inst.
Proof. unfold Equation1685. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1691 : ~ @Equation1691 Fin7 refa1_inst.
Proof. unfold Equation1691. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1694 : ~ @Equation1694 Fin7 refa1_inst.
Proof. unfold Equation1694. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1719 : ~ @Equation1719 Fin7 refa1_inst.
Proof. unfold Equation1719. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1721 : ~ @Equation1721 Fin7 refa1_inst.
Proof. unfold Equation1721. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1722 : ~ @Equation1722 Fin7 refa1_inst.
Proof. unfold Equation1722. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1728 : ~ @Equation1728 Fin7 refa1_inst.
Proof. unfold Equation1728. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1731 : ~ @Equation1731 Fin7 refa1_inst.
Proof. unfold Equation1731. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1833 : ~ @Equation1833 Fin7 refa1_inst.
Proof. unfold Equation1833. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1834 : ~ @Equation1834 Fin7 refa1_inst.
Proof. unfold Equation1834. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1837 : ~ @Equation1837 Fin7 refa1_inst.
Proof. unfold Equation1837. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1840 : ~ @Equation1840 Fin7 refa1_inst.
Proof. unfold Equation1840. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1841 : ~ @Equation1841 Fin7 refa1_inst.
Proof. unfold Equation1841. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1847 : ~ @Equation1847 Fin7 refa1_inst.
Proof. unfold Equation1847. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1848 : ~ @Equation1848 Fin7 refa1_inst.
Proof. unfold Equation1848. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1851 : ~ @Equation1851 Fin7 refa1_inst.
Proof. unfold Equation1851. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1857 : ~ @Equation1857 Fin7 refa1_inst.
Proof. unfold Equation1857. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1858 : ~ @Equation1858 Fin7 refa1_inst.
Proof. unfold Equation1858. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1860 : ~ @Equation1860 Fin7 refa1_inst.
Proof. unfold Equation1860. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1884 : ~ @Equation1884 Fin7 refa1_inst.
Proof. unfold Equation1884. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1885 : ~ @Equation1885 Fin7 refa1_inst.
Proof. unfold Equation1885. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1887 : ~ @Equation1887 Fin7 refa1_inst.
Proof. unfold Equation1887. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1888 : ~ @Equation1888 Fin7 refa1_inst.
Proof. unfold Equation1888. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1894 : ~ @Equation1894 Fin7 refa1_inst.
Proof. unfold Equation1894. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1895 : ~ @Equation1895 Fin7 refa1_inst.
Proof. unfold Equation1895. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1897 : ~ @Equation1897 Fin7 refa1_inst.
Proof. unfold Equation1897. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1921 : ~ @Equation1921 Fin7 refa1_inst.
Proof. unfold Equation1921. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1924 : ~ @Equation1924 Fin7 refa1_inst.
Proof. unfold Equation1924. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1925 : ~ @Equation1925 Fin7 refa1_inst.
Proof. unfold Equation1925. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not1931 : ~ @Equation1931 Fin7 refa1_inst.
Proof. unfold Equation1931. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2036 : ~ @Equation2036 Fin7 refa1_inst.
Proof. unfold Equation2036. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2037 : ~ @Equation2037 Fin7 refa1_inst.
Proof. unfold Equation2037. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2038 : ~ @Equation2038 Fin7 refa1_inst.
Proof. unfold Equation2038. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2040 : ~ @Equation2040 Fin7 refa1_inst.
Proof. unfold Equation2040. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2041 : ~ @Equation2041 Fin7 refa1_inst.
Proof. unfold Equation2041. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2043 : ~ @Equation2043 Fin7 refa1_inst.
Proof. unfold Equation2043. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2050 : ~ @Equation2050 Fin7 refa1_inst.
Proof. unfold Equation2050. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2054 : ~ @Equation2054 Fin7 refa1_inst.
Proof. unfold Equation2054. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2061 : ~ @Equation2061 Fin7 refa1_inst.
Proof. unfold Equation2061. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2063 : ~ @Equation2063 Fin7 refa1_inst.
Proof. unfold Equation2063. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2064 : ~ @Equation2064 Fin7 refa1_inst.
Proof. unfold Equation2064. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2087 : ~ @Equation2087 Fin7 refa1_inst.
Proof. unfold Equation2087. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2088 : ~ @Equation2088 Fin7 refa1_inst.
Proof. unfold Equation2088. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2091 : ~ @Equation2091 Fin7 refa1_inst.
Proof. unfold Equation2091. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2097 : ~ @Equation2097 Fin7 refa1_inst.
Proof. unfold Equation2097. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2098 : ~ @Equation2098 Fin7 refa1_inst.
Proof. unfold Equation2098. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2101 : ~ @Equation2101 Fin7 refa1_inst.
Proof. unfold Equation2101. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2124 : ~ @Equation2124 Fin7 refa1_inst.
Proof. unfold Equation2124. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2125 : ~ @Equation2125 Fin7 refa1_inst.
Proof. unfold Equation2125. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2127 : ~ @Equation2127 Fin7 refa1_inst.
Proof. unfold Equation2127. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2128 : ~ @Equation2128 Fin7 refa1_inst.
Proof. unfold Equation2128. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2134 : ~ @Equation2134 Fin7 refa1_inst.
Proof. unfold Equation2134. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2240 : ~ @Equation2240 Fin7 refa1_inst.
Proof. unfold Equation2240. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2241 : ~ @Equation2241 Fin7 refa1_inst.
Proof. unfold Equation2241. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2243 : ~ @Equation2243 Fin7 refa1_inst.
Proof. unfold Equation2243. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2244 : ~ @Equation2244 Fin7 refa1_inst.
Proof. unfold Equation2244. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2246 : ~ @Equation2246 Fin7 refa1_inst.
Proof. unfold Equation2246. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2247 : ~ @Equation2247 Fin7 refa1_inst.
Proof. unfold Equation2247. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2253 : ~ @Equation2253 Fin7 refa1_inst.
Proof. unfold Equation2253. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2254 : ~ @Equation2254 Fin7 refa1_inst.
Proof. unfold Equation2254. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2257 : ~ @Equation2257 Fin7 refa1_inst.
Proof. unfold Equation2257. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2263 : ~ @Equation2263 Fin7 refa1_inst.
Proof. unfold Equation2263. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2264 : ~ @Equation2264 Fin7 refa1_inst.
Proof. unfold Equation2264. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2266 : ~ @Equation2266 Fin7 refa1_inst.
Proof. unfold Equation2266. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2290 : ~ @Equation2290 Fin7 refa1_inst.
Proof. unfold Equation2290. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2291 : ~ @Equation2291 Fin7 refa1_inst.
Proof. unfold Equation2291. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2294 : ~ @Equation2294 Fin7 refa1_inst.
Proof. unfold Equation2294. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2300 : ~ @Equation2300 Fin7 refa1_inst.
Proof. unfold Equation2300. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2303 : ~ @Equation2303 Fin7 refa1_inst.
Proof. unfold Equation2303. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2327 : ~ @Equation2327 Fin7 refa1_inst.
Proof. unfold Equation2327. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2328 : ~ @Equation2328 Fin7 refa1_inst.
Proof. unfold Equation2328. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2330 : ~ @Equation2330 Fin7 refa1_inst.
Proof. unfold Equation2330. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2338 : ~ @Equation2338 Fin7 refa1_inst.
Proof. unfold Equation2338. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2340 : ~ @Equation2340 Fin7 refa1_inst.
Proof. unfold Equation2340. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2443 : ~ @Equation2443 Fin7 refa1_inst.
Proof. unfold Equation2443. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2444 : ~ @Equation2444 Fin7 refa1_inst.
Proof. unfold Equation2444. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2446 : ~ @Equation2446 Fin7 refa1_inst.
Proof. unfold Equation2446. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2447 : ~ @Equation2447 Fin7 refa1_inst.
Proof. unfold Equation2447. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2450 : ~ @Equation2450 Fin7 refa1_inst.
Proof. unfold Equation2450. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2456 : ~ @Equation2456 Fin7 refa1_inst.
Proof. unfold Equation2456. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2459 : ~ @Equation2459 Fin7 refa1_inst.
Proof. unfold Equation2459. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2460 : ~ @Equation2460 Fin7 refa1_inst.
Proof. unfold Equation2460. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2466 : ~ @Equation2466 Fin7 refa1_inst.
Proof. unfold Equation2466. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2467 : ~ @Equation2467 Fin7 refa1_inst.
Proof. unfold Equation2467. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2469 : ~ @Equation2469 Fin7 refa1_inst.
Proof. unfold Equation2469. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2493 : ~ @Equation2493 Fin7 refa1_inst.
Proof. unfold Equation2493. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2496 : ~ @Equation2496 Fin7 refa1_inst.
Proof. unfold Equation2496. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2497 : ~ @Equation2497 Fin7 refa1_inst.
Proof. unfold Equation2497. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2503 : ~ @Equation2503 Fin7 refa1_inst.
Proof. unfold Equation2503. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2506 : ~ @Equation2506 Fin7 refa1_inst.
Proof. unfold Equation2506. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2530 : ~ @Equation2530 Fin7 refa1_inst.
Proof. unfold Equation2530. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2531 : ~ @Equation2531 Fin7 refa1_inst.
Proof. unfold Equation2531. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2533 : ~ @Equation2533 Fin7 refa1_inst.
Proof. unfold Equation2533. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2534 : ~ @Equation2534 Fin7 refa1_inst.
Proof. unfold Equation2534. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2540 : ~ @Equation2540 Fin7 refa1_inst.
Proof. unfold Equation2540. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2541 : ~ @Equation2541 Fin7 refa1_inst.
Proof. unfold Equation2541. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2543 : ~ @Equation2543 Fin7 refa1_inst.
Proof. unfold Equation2543. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2646 : ~ @Equation2646 Fin7 refa1_inst.
Proof. unfold Equation2646. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2647 : ~ @Equation2647 Fin7 refa1_inst.
Proof. unfold Equation2647. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2649 : ~ @Equation2649 Fin7 refa1_inst.
Proof. unfold Equation2649. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2650 : ~ @Equation2650 Fin7 refa1_inst.
Proof. unfold Equation2650. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2652 : ~ @Equation2652 Fin7 refa1_inst.
Proof. unfold Equation2652. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2659 : ~ @Equation2659 Fin7 refa1_inst.
Proof. unfold Equation2659. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2660 : ~ @Equation2660 Fin7 refa1_inst.
Proof. unfold Equation2660. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2662 : ~ @Equation2662 Fin7 refa1_inst.
Proof. unfold Equation2662. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2669 : ~ @Equation2669 Fin7 refa1_inst.
Proof. unfold Equation2669. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2670 : ~ @Equation2670 Fin7 refa1_inst.
Proof. unfold Equation2670. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2696 : ~ @Equation2696 Fin7 refa1_inst.
Proof. unfold Equation2696. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2697 : ~ @Equation2697 Fin7 refa1_inst.
Proof. unfold Equation2697. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2699 : ~ @Equation2699 Fin7 refa1_inst.
Proof. unfold Equation2699. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2700 : ~ @Equation2700 Fin7 refa1_inst.
Proof. unfold Equation2700. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2706 : ~ @Equation2706 Fin7 refa1_inst.
Proof. unfold Equation2706. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2709 : ~ @Equation2709 Fin7 refa1_inst.
Proof. unfold Equation2709. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2710 : ~ @Equation2710 Fin7 refa1_inst.
Proof. unfold Equation2710. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2733 : ~ @Equation2733 Fin7 refa1_inst.
Proof. unfold Equation2733. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2734 : ~ @Equation2734 Fin7 refa1_inst.
Proof. unfold Equation2734. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2736 : ~ @Equation2736 Fin7 refa1_inst.
Proof. unfold Equation2736. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2743 : ~ @Equation2743 Fin7 refa1_inst.
Proof. unfold Equation2743. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2744 : ~ @Equation2744 Fin7 refa1_inst.
Proof. unfold Equation2744. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2746 : ~ @Equation2746 Fin7 refa1_inst.
Proof. unfold Equation2746. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2849 : ~ @Equation2849 Fin7 refa1_inst.
Proof. unfold Equation2849. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2852 : ~ @Equation2852 Fin7 refa1_inst.
Proof. unfold Equation2852. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2853 : ~ @Equation2853 Fin7 refa1_inst.
Proof. unfold Equation2853. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2855 : ~ @Equation2855 Fin7 refa1_inst.
Proof. unfold Equation2855. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2856 : ~ @Equation2856 Fin7 refa1_inst.
Proof. unfold Equation2856. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2862 : ~ @Equation2862 Fin7 refa1_inst.
Proof. unfold Equation2862. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2865 : ~ @Equation2865 Fin7 refa1_inst.
Proof. unfold Equation2865. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2866 : ~ @Equation2866 Fin7 refa1_inst.
Proof. unfold Equation2866. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2872 : ~ @Equation2872 Fin7 refa1_inst.
Proof. unfold Equation2872. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2873 : ~ @Equation2873 Fin7 refa1_inst.
Proof. unfold Equation2873. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2899 : ~ @Equation2899 Fin7 refa1_inst.
Proof. unfold Equation2899. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2900 : ~ @Equation2900 Fin7 refa1_inst.
Proof. unfold Equation2900. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2902 : ~ @Equation2902 Fin7 refa1_inst.
Proof. unfold Equation2902. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2903 : ~ @Equation2903 Fin7 refa1_inst.
Proof. unfold Equation2903. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2909 : ~ @Equation2909 Fin7 refa1_inst.
Proof. unfold Equation2909. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2910 : ~ @Equation2910 Fin7 refa1_inst.
Proof. unfold Equation2910. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2912 : ~ @Equation2912 Fin7 refa1_inst.
Proof. unfold Equation2912. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2936 : ~ @Equation2936 Fin7 refa1_inst.
Proof. unfold Equation2936. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2937 : ~ @Equation2937 Fin7 refa1_inst.
Proof. unfold Equation2937. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2939 : ~ @Equation2939 Fin7 refa1_inst.
Proof. unfold Equation2939. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2940 : ~ @Equation2940 Fin7 refa1_inst.
Proof. unfold Equation2940. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2946 : ~ @Equation2946 Fin7 refa1_inst.
Proof. unfold Equation2946. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2947 : ~ @Equation2947 Fin7 refa1_inst.
Proof. unfold Equation2947. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not2949 : ~ @Equation2949 Fin7 refa1_inst.
Proof. unfold Equation2949. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3052 : ~ @Equation3052 Fin7 refa1_inst.
Proof. unfold Equation3052. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3055 : ~ @Equation3055 Fin7 refa1_inst.
Proof. unfold Equation3055. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3056 : ~ @Equation3056 Fin7 refa1_inst.
Proof. unfold Equation3056. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3065 : ~ @Equation3065 Fin7 refa1_inst.
Proof. unfold Equation3065. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3068 : ~ @Equation3068 Fin7 refa1_inst.
Proof. unfold Equation3068. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3069 : ~ @Equation3069 Fin7 refa1_inst.
Proof. unfold Equation3069. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3076 : ~ @Equation3076 Fin7 refa1_inst.
Proof. unfold Equation3076. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3078 : ~ @Equation3078 Fin7 refa1_inst.
Proof. unfold Equation3078. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3102 : ~ @Equation3102 Fin7 refa1_inst.
Proof. unfold Equation3102. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3103 : ~ @Equation3103 Fin7 refa1_inst.
Proof. unfold Equation3103. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3105 : ~ @Equation3105 Fin7 refa1_inst.
Proof. unfold Equation3105. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3106 : ~ @Equation3106 Fin7 refa1_inst.
Proof. unfold Equation3106. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3112 : ~ @Equation3112 Fin7 refa1_inst.
Proof. unfold Equation3112. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3113 : ~ @Equation3113 Fin7 refa1_inst.
Proof. unfold Equation3113. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3115 : ~ @Equation3115 Fin7 refa1_inst.
Proof. unfold Equation3115. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3116 : ~ @Equation3116 Fin7 refa1_inst.
Proof. unfold Equation3116. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3139 : ~ @Equation3139 Fin7 refa1_inst.
Proof. unfold Equation3139. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3140 : ~ @Equation3140 Fin7 refa1_inst.
Proof. unfold Equation3140. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3142 : ~ @Equation3142 Fin7 refa1_inst.
Proof. unfold Equation3142. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3143 : ~ @Equation3143 Fin7 refa1_inst.
Proof. unfold Equation3143. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3149 : ~ @Equation3149 Fin7 refa1_inst.
Proof. unfold Equation3149. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3150 : ~ @Equation3150 Fin7 refa1_inst.
Proof. unfold Equation3150. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3152 : ~ @Equation3152 Fin7 refa1_inst.
Proof. unfold Equation3152. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3254 : ~ @Equation3254 Fin7 refa1_inst.
Proof. unfold Equation3254. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3255 : ~ @Equation3255 Fin7 refa1_inst.
Proof. unfold Equation3255. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3256 : ~ @Equation3256 Fin7 refa1_inst.
Proof. unfold Equation3256. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3258 : ~ @Equation3258 Fin7 refa1_inst.
Proof. unfold Equation3258. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3259 : ~ @Equation3259 Fin7 refa1_inst.
Proof. unfold Equation3259. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3261 : ~ @Equation3261 Fin7 refa1_inst.
Proof. unfold Equation3261. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3262 : ~ @Equation3262 Fin7 refa1_inst.
Proof. unfold Equation3262. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3268 : ~ @Equation3268 Fin7 refa1_inst.
Proof. unfold Equation3268. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3271 : ~ @Equation3271 Fin7 refa1_inst.
Proof. unfold Equation3271. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3272 : ~ @Equation3272 Fin7 refa1_inst.
Proof. unfold Equation3272. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3278 : ~ @Equation3278 Fin7 refa1_inst.
Proof. unfold Equation3278. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3279 : ~ @Equation3279 Fin7 refa1_inst.
Proof. unfold Equation3279. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3306 : ~ @Equation3306 Fin7 refa1_inst.
Proof. unfold Equation3306. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3308 : ~ @Equation3308 Fin7 refa1_inst.
Proof. unfold Equation3308. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3309 : ~ @Equation3309 Fin7 refa1_inst.
Proof. unfold Equation3309. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3315 : ~ @Equation3315 Fin7 refa1_inst.
Proof. unfold Equation3315. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3316 : ~ @Equation3316 Fin7 refa1_inst.
Proof. unfold Equation3316. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3318 : ~ @Equation3318 Fin7 refa1_inst.
Proof. unfold Equation3318. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3342 : ~ @Equation3342 Fin7 refa1_inst.
Proof. unfold Equation3342. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3343 : ~ @Equation3343 Fin7 refa1_inst.
Proof. unfold Equation3343. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3346 : ~ @Equation3346 Fin7 refa1_inst.
Proof. unfold Equation3346. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3352 : ~ @Equation3352 Fin7 refa1_inst.
Proof. unfold Equation3352. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3353 : ~ @Equation3353 Fin7 refa1_inst.
Proof. unfold Equation3353. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3355 : ~ @Equation3355 Fin7 refa1_inst.
Proof. unfold Equation3355. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3457 : ~ @Equation3457 Fin7 refa1_inst.
Proof. unfold Equation3457. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3458 : ~ @Equation3458 Fin7 refa1_inst.
Proof. unfold Equation3458. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3461 : ~ @Equation3461 Fin7 refa1_inst.
Proof. unfold Equation3461. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3462 : ~ @Equation3462 Fin7 refa1_inst.
Proof. unfold Equation3462. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3464 : ~ @Equation3464 Fin7 refa1_inst.
Proof. unfold Equation3464. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3465 : ~ @Equation3465 Fin7 refa1_inst.
Proof. unfold Equation3465. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3475 : ~ @Equation3475 Fin7 refa1_inst.
Proof. unfold Equation3475. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3481 : ~ @Equation3481 Fin7 refa1_inst.
Proof. unfold Equation3481. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3482 : ~ @Equation3482 Fin7 refa1_inst.
Proof. unfold Equation3482. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3484 : ~ @Equation3484 Fin7 refa1_inst.
Proof. unfold Equation3484. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3509 : ~ @Equation3509 Fin7 refa1_inst.
Proof. unfold Equation3509. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3511 : ~ @Equation3511 Fin7 refa1_inst.
Proof. unfold Equation3511. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3512 : ~ @Equation3512 Fin7 refa1_inst.
Proof. unfold Equation3512. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3519 : ~ @Equation3519 Fin7 refa1_inst.
Proof. unfold Equation3519. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3521 : ~ @Equation3521 Fin7 refa1_inst.
Proof. unfold Equation3521. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3545 : ~ @Equation3545 Fin7 refa1_inst.
Proof. unfold Equation3545. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3546 : ~ @Equation3546 Fin7 refa1_inst.
Proof. unfold Equation3546. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3549 : ~ @Equation3549 Fin7 refa1_inst.
Proof. unfold Equation3549. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3555 : ~ @Equation3555 Fin7 refa1_inst.
Proof. unfold Equation3555. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3556 : ~ @Equation3556 Fin7 refa1_inst.
Proof. unfold Equation3556. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3558 : ~ @Equation3558 Fin7 refa1_inst.
Proof. unfold Equation3558. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3660 : ~ @Equation3660 Fin7 refa1_inst.
Proof. unfold Equation3660. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3661 : ~ @Equation3661 Fin7 refa1_inst.
Proof. unfold Equation3661. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3662 : ~ @Equation3662 Fin7 refa1_inst.
Proof. unfold Equation3662. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3664 : ~ @Equation3664 Fin7 refa1_inst.
Proof. unfold Equation3664. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3665 : ~ @Equation3665 Fin7 refa1_inst.
Proof. unfold Equation3665. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3667 : ~ @Equation3667 Fin7 refa1_inst.
Proof. unfold Equation3667. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3674 : ~ @Equation3674 Fin7 refa1_inst.
Proof. unfold Equation3674. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3675 : ~ @Equation3675 Fin7 refa1_inst.
Proof. unfold Equation3675. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3677 : ~ @Equation3677 Fin7 refa1_inst.
Proof. unfold Equation3677. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3678 : ~ @Equation3678 Fin7 refa1_inst.
Proof. unfold Equation3678. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3684 : ~ @Equation3684 Fin7 refa1_inst.
Proof. unfold Equation3684. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3685 : ~ @Equation3685 Fin7 refa1_inst.
Proof. unfold Equation3685. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3687 : ~ @Equation3687 Fin7 refa1_inst.
Proof. unfold Equation3687. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3712 : ~ @Equation3712 Fin7 refa1_inst.
Proof. unfold Equation3712. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3714 : ~ @Equation3714 Fin7 refa1_inst.
Proof. unfold Equation3714. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3721 : ~ @Equation3721 Fin7 refa1_inst.
Proof. unfold Equation3721. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3724 : ~ @Equation3724 Fin7 refa1_inst.
Proof. unfold Equation3724. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3725 : ~ @Equation3725 Fin7 refa1_inst.
Proof. unfold Equation3725. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3748 : ~ @Equation3748 Fin7 refa1_inst.
Proof. unfold Equation3748. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3749 : ~ @Equation3749 Fin7 refa1_inst.
Proof. unfold Equation3749. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3752 : ~ @Equation3752 Fin7 refa1_inst.
Proof. unfold Equation3752. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3759 : ~ @Equation3759 Fin7 refa1_inst.
Proof. unfold Equation3759. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3761 : ~ @Equation3761 Fin7 refa1_inst.
Proof. unfold Equation3761. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3864 : ~ @Equation3864 Fin7 refa1_inst.
Proof. unfold Equation3864. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3865 : ~ @Equation3865 Fin7 refa1_inst.
Proof. unfold Equation3865. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3867 : ~ @Equation3867 Fin7 refa1_inst.
Proof. unfold Equation3867. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3868 : ~ @Equation3868 Fin7 refa1_inst.
Proof. unfold Equation3868. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3870 : ~ @Equation3870 Fin7 refa1_inst.
Proof. unfold Equation3870. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3877 : ~ @Equation3877 Fin7 refa1_inst.
Proof. unfold Equation3877. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3878 : ~ @Equation3878 Fin7 refa1_inst.
Proof. unfold Equation3878. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3880 : ~ @Equation3880 Fin7 refa1_inst.
Proof. unfold Equation3880. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3881 : ~ @Equation3881 Fin7 refa1_inst.
Proof. unfold Equation3881. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3887 : ~ @Equation3887 Fin7 refa1_inst.
Proof. unfold Equation3887. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3888 : ~ @Equation3888 Fin7 refa1_inst.
Proof. unfold Equation3888. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3890 : ~ @Equation3890 Fin7 refa1_inst.
Proof. unfold Equation3890. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3917 : ~ @Equation3917 Fin7 refa1_inst.
Proof. unfold Equation3917. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3918 : ~ @Equation3918 Fin7 refa1_inst.
Proof. unfold Equation3918. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3925 : ~ @Equation3925 Fin7 refa1_inst.
Proof. unfold Equation3925. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3927 : ~ @Equation3927 Fin7 refa1_inst.
Proof. unfold Equation3927. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3928 : ~ @Equation3928 Fin7 refa1_inst.
Proof. unfold Equation3928. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3951 : ~ @Equation3951 Fin7 refa1_inst.
Proof. unfold Equation3951. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3952 : ~ @Equation3952 Fin7 refa1_inst.
Proof. unfold Equation3952. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3954 : ~ @Equation3954 Fin7 refa1_inst.
Proof. unfold Equation3954. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3955 : ~ @Equation3955 Fin7 refa1_inst.
Proof. unfold Equation3955. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3961 : ~ @Equation3961 Fin7 refa1_inst.
Proof. unfold Equation3961. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3962 : ~ @Equation3962 Fin7 refa1_inst.
Proof. unfold Equation3962. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not3964 : ~ @Equation3964 Fin7 refa1_inst.
Proof. unfold Equation3964. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4066 : ~ @Equation4066 Fin7 refa1_inst.
Proof. unfold Equation4066. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4067 : ~ @Equation4067 Fin7 refa1_inst.
Proof. unfold Equation4067. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4070 : ~ @Equation4070 Fin7 refa1_inst.
Proof. unfold Equation4070. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4074 : ~ @Equation4074 Fin7 refa1_inst.
Proof. unfold Equation4074. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4080 : ~ @Equation4080 Fin7 refa1_inst.
Proof. unfold Equation4080. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4081 : ~ @Equation4081 Fin7 refa1_inst.
Proof. unfold Equation4081. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4083 : ~ @Equation4083 Fin7 refa1_inst.
Proof. unfold Equation4083. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4084 : ~ @Equation4084 Fin7 refa1_inst.
Proof. unfold Equation4084. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4090 : ~ @Equation4090 Fin7 refa1_inst.
Proof. unfold Equation4090. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4091 : ~ @Equation4091 Fin7 refa1_inst.
Proof. unfold Equation4091. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4093 : ~ @Equation4093 Fin7 refa1_inst.
Proof. unfold Equation4093. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4120 : ~ @Equation4120 Fin7 refa1_inst.
Proof. unfold Equation4120. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4121 : ~ @Equation4121 Fin7 refa1_inst.
Proof. unfold Equation4121. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4128 : ~ @Equation4128 Fin7 refa1_inst.
Proof. unfold Equation4128. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4130 : ~ @Equation4130 Fin7 refa1_inst.
Proof. unfold Equation4130. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4154 : ~ @Equation4154 Fin7 refa1_inst.
Proof. unfold Equation4154. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4155 : ~ @Equation4155 Fin7 refa1_inst.
Proof. unfold Equation4155. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4157 : ~ @Equation4157 Fin7 refa1_inst.
Proof. unfold Equation4157. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4158 : ~ @Equation4158 Fin7 refa1_inst.
Proof. unfold Equation4158. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4164 : ~ @Equation4164 Fin7 refa1_inst.
Proof. unfold Equation4164. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4165 : ~ @Equation4165 Fin7 refa1_inst.
Proof. unfold Equation4165. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4167 : ~ @Equation4167 Fin7 refa1_inst.
Proof. unfold Equation4167. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4268 : ~ @Equation4268 Fin7 refa1_inst.
Proof. unfold Equation4268. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4269 : ~ @Equation4269 Fin7 refa1_inst.
Proof. unfold Equation4269. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4270 : ~ @Equation4270 Fin7 refa1_inst.
Proof. unfold Equation4270. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4272 : ~ @Equation4272 Fin7 refa1_inst.
Proof. unfold Equation4272. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4273 : ~ @Equation4273 Fin7 refa1_inst.
Proof. unfold Equation4273. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4275 : ~ @Equation4275 Fin7 refa1_inst.
Proof. unfold Equation4275. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4276 : ~ @Equation4276 Fin7 refa1_inst.
Proof. unfold Equation4276. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4283 : ~ @Equation4283 Fin7 refa1_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4284 : ~ @Equation4284 Fin7 refa1_inst.
Proof. unfold Equation4284. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4290 : ~ @Equation4290 Fin7 refa1_inst.
Proof. unfold Equation4290. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4291 : ~ @Equation4291 Fin7 refa1_inst.
Proof. unfold Equation4291. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4314 : ~ @Equation4314 Fin7 refa1_inst.
Proof. unfold Equation4314. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4320 : ~ @Equation4320 Fin7 refa1_inst.
Proof. unfold Equation4320. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4321 : ~ @Equation4321 Fin7 refa1_inst.
Proof. unfold Equation4321. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4343 : ~ @Equation4343 Fin7 refa1_inst.
Proof. unfold Equation4343. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4396 : ~ @Equation4396 Fin7 refa1_inst.
Proof. unfold Equation4396. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4398 : ~ @Equation4398 Fin7 refa1_inst.
Proof. unfold Equation4398. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4399 : ~ @Equation4399 Fin7 refa1_inst.
Proof. unfold Equation4399. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4405 : ~ @Equation4405 Fin7 refa1_inst.
Proof. unfold Equation4405. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4406 : ~ @Equation4406 Fin7 refa1_inst.
Proof. unfold Equation4406. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4408 : ~ @Equation4408 Fin7 refa1_inst.
Proof. unfold Equation4408. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4433 : ~ @Equation4433 Fin7 refa1_inst.
Proof. unfold Equation4433. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4436 : ~ @Equation4436 Fin7 refa1_inst.
Proof. unfold Equation4436. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4442 : ~ @Equation4442 Fin7 refa1_inst.
Proof. unfold Equation4442. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4443 : ~ @Equation4443 Fin7 refa1_inst.
Proof. unfold Equation4443. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4445 : ~ @Equation4445 Fin7 refa1_inst.
Proof. unfold Equation4445. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4472 : ~ @Equation4472 Fin7 refa1_inst.
Proof. unfold Equation4472. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4473 : ~ @Equation4473 Fin7 refa1_inst.
Proof. unfold Equation4473. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4479 : ~ @Equation4479 Fin7 refa1_inst.
Proof. unfold Equation4479. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4480 : ~ @Equation4480 Fin7 refa1_inst.
Proof. unfold Equation4480. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4482 : ~ @Equation4482 Fin7 refa1_inst.
Proof. unfold Equation4482. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4583 : ~ @Equation4583 Fin7 refa1_inst.
Proof. unfold Equation4583. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4584 : ~ @Equation4584 Fin7 refa1_inst.
Proof. unfold Equation4584. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4587 : ~ @Equation4587 Fin7 refa1_inst.
Proof. unfold Equation4587. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4588 : ~ @Equation4588 Fin7 refa1_inst.
Proof. unfold Equation4588. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4590 : ~ @Equation4590 Fin7 refa1_inst.
Proof. unfold Equation4590. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4591 : ~ @Equation4591 Fin7 refa1_inst.
Proof. unfold Equation4591. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4598 : ~ @Equation4598 Fin7 refa1_inst.
Proof. unfold Equation4598. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4599 : ~ @Equation4599 Fin7 refa1_inst.
Proof. unfold Equation4599. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4605 : ~ @Equation4605 Fin7 refa1_inst.
Proof. unfold Equation4605. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4606 : ~ @Equation4606 Fin7 refa1_inst.
Proof. unfold Equation4606. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4608 : ~ @Equation4608 Fin7 refa1_inst.
Proof. unfold Equation4608. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4629 : ~ @Equation4629 Fin7 refa1_inst.
Proof. unfold Equation4629. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4635 : ~ @Equation4635 Fin7 refa1_inst.
Proof. unfold Equation4635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4636 : ~ @Equation4636 Fin7 refa1_inst.
Proof. unfold Equation4636. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

Lemma refa1_not4658 : ~ @Equation4658 Fin7 refa1_inst.
Proof. unfold Equation4658. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa1_inst, refa1_op in H. discriminate H. Qed.

(** ---- refa10 (Fin7) ---- *)

Definition refa10_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_4 | F7_0, F7_3 => F7_0 | F7_0, F7_4 => F7_6 | F7_0, F7_5 => F7_5 | F7_0, F7_6 => F7_3
  | F7_1, F7_0 => F7_4 | F7_1, F7_1 => F7_3 | F7_1, F7_2 => F7_1 | F7_1, F7_3 => F7_5 | F7_1, F7_4 => F7_2 | F7_1, F7_5 => F7_0 | F7_1, F7_6 => F7_6
  | F7_2, F7_0 => F7_0 | F7_2, F7_1 => F7_6 | F7_2, F7_2 => F7_5 | F7_2, F7_3 => F7_1 | F7_2, F7_4 => F7_3 | F7_2, F7_5 => F7_4 | F7_2, F7_6 => F7_2
  | F7_3, F7_0 => F7_5 | F7_3, F7_1 => F7_0 | F7_3, F7_2 => F7_6 | F7_3, F7_3 => F7_2 | F7_3, F7_4 => F7_4 | F7_3, F7_5 => F7_3 | F7_3, F7_6 => F7_1
  | F7_4, F7_0 => F7_3 | F7_4, F7_1 => F7_4 | F7_4, F7_2 => F7_2 | F7_4, F7_3 => F7_6 | F7_4, F7_4 => F7_0 | F7_4, F7_5 => F7_1 | F7_4, F7_6 => F7_5
  | F7_5, F7_0 => F7_2 | F7_5, F7_1 => F7_1 | F7_5, F7_2 => F7_3 | F7_5, F7_3 => F7_4 | F7_5, F7_4 => F7_5 | F7_5, F7_5 => F7_6 | F7_5, F7_6 => F7_0
  | F7_6, F7_0 => F7_6 | F7_6, F7_1 => F7_5 | F7_6, F7_2 => F7_0 | F7_6, F7_3 => F7_3 | F7_6, F7_4 => F7_1 | F7_6, F7_5 => F7_2 | F7_6, F7_6 => F7_4
  end.

#[local] Instance refa10_inst : Magma Fin7 := {| magma_op := refa10_op |}.

Lemma refa10_sat880 : @Equation880 Fin7 refa10_inst.
Proof. unfold Equation880, magma_op, refa10_inst, refa10_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa10_not47 : ~ @Equation47 Fin7 refa10_inst.
Proof. unfold Equation47. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not99 : ~ @Equation99 Fin7 refa10_inst.
Proof. unfold Equation99. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not151 : ~ @Equation151 Fin7 refa10_inst.
Proof. unfold Equation151. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not221 : ~ @Equation221 Fin7 refa10_inst.
Proof. unfold Equation221. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not255 : ~ @Equation255 Fin7 refa10_inst.
Proof. unfold Equation255. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not411 : ~ @Equation411 Fin7 refa10_inst.
Proof. unfold Equation411. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not614 : ~ @Equation614 Fin7 refa10_inst.
Proof. unfold Equation614. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not819 : ~ @Equation819 Fin7 refa10_inst.
Proof. unfold Equation819. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not826 : ~ @Equation826 Fin7 refa10_inst.
Proof. unfold Equation826. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not832 : ~ @Equation832 Fin7 refa10_inst.
Proof. unfold Equation832. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not833 : ~ @Equation833 Fin7 refa10_inst.
Proof. unfold Equation833. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not835 : ~ @Equation835 Fin7 refa10_inst.
Proof. unfold Equation835. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not836 : ~ @Equation836 Fin7 refa10_inst.
Proof. unfold Equation836. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not842 : ~ @Equation842 Fin7 refa10_inst.
Proof. unfold Equation842. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not843 : ~ @Equation843 Fin7 refa10_inst.
Proof. unfold Equation843. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not845 : ~ @Equation845 Fin7 refa10_inst.
Proof. unfold Equation845. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not846 : ~ @Equation846 Fin7 refa10_inst.
Proof. unfold Equation846. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not870 : ~ @Equation870 Fin7 refa10_inst.
Proof. unfold Equation870. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not872 : ~ @Equation872 Fin7 refa10_inst.
Proof. unfold Equation872. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not879 : ~ @Equation879 Fin7 refa10_inst.
Proof. unfold Equation879. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not882 : ~ @Equation882 Fin7 refa10_inst.
Proof. unfold Equation882. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not883 : ~ @Equation883 Fin7 refa10_inst.
Proof. unfold Equation883. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not906 : ~ @Equation906 Fin7 refa10_inst.
Proof. unfold Equation906. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not907 : ~ @Equation907 Fin7 refa10_inst.
Proof. unfold Equation907. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not917 : ~ @Equation917 Fin7 refa10_inst.
Proof. unfold Equation917. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1020 : ~ @Equation1020 Fin7 refa10_inst.
Proof. unfold Equation1020. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1238 : ~ @Equation1238 Fin7 refa10_inst.
Proof. unfold Equation1238. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1239 : ~ @Equation1239 Fin7 refa10_inst.
Proof. unfold Equation1239. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1242 : ~ @Equation1242 Fin7 refa10_inst.
Proof. unfold Equation1242. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1248 : ~ @Equation1248 Fin7 refa10_inst.
Proof. unfold Equation1248. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1249 : ~ @Equation1249 Fin7 refa10_inst.
Proof. unfold Equation1249. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1251 : ~ @Equation1251 Fin7 refa10_inst.
Proof. unfold Equation1251. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1252 : ~ @Equation1252 Fin7 refa10_inst.
Proof. unfold Equation1252. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1276 : ~ @Equation1276 Fin7 refa10_inst.
Proof. unfold Equation1276. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1278 : ~ @Equation1278 Fin7 refa10_inst.
Proof. unfold Equation1278. intro H. specialize (H F7_0 F7_2). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1279 : ~ @Equation1279 Fin7 refa10_inst.
Proof. unfold Equation1279. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1285 : ~ @Equation1285 Fin7 refa10_inst.
Proof. unfold Equation1285. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1286 : ~ @Equation1286 Fin7 refa10_inst.
Proof. unfold Equation1286. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1288 : ~ @Equation1288 Fin7 refa10_inst.
Proof. unfold Equation1288. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1315 : ~ @Equation1315 Fin7 refa10_inst.
Proof. unfold Equation1315. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1322 : ~ @Equation1322 Fin7 refa10_inst.
Proof. unfold Equation1322. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1426 : ~ @Equation1426 Fin7 refa10_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1629 : ~ @Equation1629 Fin7 refa10_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not1832 : ~ @Equation1832 Fin7 refa10_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not2035 : ~ @Equation2035 Fin7 refa10_inst.
Proof. unfold Equation2035. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not2238 : ~ @Equation2238 Fin7 refa10_inst.
Proof. unfold Equation2238. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not2441 : ~ @Equation2441 Fin7 refa10_inst.
Proof. unfold Equation2441. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not2644 : ~ @Equation2644 Fin7 refa10_inst.
Proof. unfold Equation2644. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not2847 : ~ @Equation2847 Fin7 refa10_inst.
Proof. unfold Equation2847. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not3050 : ~ @Equation3050 Fin7 refa10_inst.
Proof. unfold Equation3050. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not3253 : ~ @Equation3253 Fin7 refa10_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not3456 : ~ @Equation3456 Fin7 refa10_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not3659 : ~ @Equation3659 Fin7 refa10_inst.
Proof. unfold Equation3659. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not3862 : ~ @Equation3862 Fin7 refa10_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4065 : ~ @Equation4065 Fin7 refa10_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4268 : ~ @Equation4268 Fin7 refa10_inst.
Proof. unfold Equation4268. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4269 : ~ @Equation4269 Fin7 refa10_inst.
Proof. unfold Equation4269. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4270 : ~ @Equation4270 Fin7 refa10_inst.
Proof. unfold Equation4270. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4272 : ~ @Equation4272 Fin7 refa10_inst.
Proof. unfold Equation4272. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4273 : ~ @Equation4273 Fin7 refa10_inst.
Proof. unfold Equation4273. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4275 : ~ @Equation4275 Fin7 refa10_inst.
Proof. unfold Equation4275. intro H. specialize (H F7_0 F7_2). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4283 : ~ @Equation4283 Fin7 refa10_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4284 : ~ @Equation4284 Fin7 refa10_inst.
Proof. unfold Equation4284. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4291 : ~ @Equation4291 Fin7 refa10_inst.
Proof. unfold Equation4291. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4293 : ~ @Equation4293 Fin7 refa10_inst.
Proof. unfold Equation4293. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4321 : ~ @Equation4321 Fin7 refa10_inst.
Proof. unfold Equation4321. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4343 : ~ @Equation4343 Fin7 refa10_inst.
Proof. unfold Equation4343. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4380 : ~ @Equation4380 Fin7 refa10_inst.
Proof. unfold Equation4380. intro H. specialize (H F7_0). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4583 : ~ @Equation4583 Fin7 refa10_inst.
Proof. unfold Equation4583. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4584 : ~ @Equation4584 Fin7 refa10_inst.
Proof. unfold Equation4584. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4585 : ~ @Equation4585 Fin7 refa10_inst.
Proof. unfold Equation4585. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4587 : ~ @Equation4587 Fin7 refa10_inst.
Proof. unfold Equation4587. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4590 : ~ @Equation4590 Fin7 refa10_inst.
Proof. unfold Equation4590. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4606 : ~ @Equation4606 Fin7 refa10_inst.
Proof. unfold Equation4606. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4608 : ~ @Equation4608 Fin7 refa10_inst.
Proof. unfold Equation4608. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4635 : ~ @Equation4635 Fin7 refa10_inst.
Proof. unfold Equation4635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4636 : ~ @Equation4636 Fin7 refa10_inst.
Proof. unfold Equation4636. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

Lemma refa10_not4658 : ~ @Equation4658 Fin7 refa10_inst.
Proof. unfold Equation4658. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa10_inst, refa10_op in H. discriminate H. Qed.

(** ---- refa100 (Fin3) ---- *)

Definition refa100_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa100_inst : Magma Fin3 := {| magma_op := refa100_op |}.

Lemma refa100_sat2285 : @Equation2285 Fin3 refa100_inst.
Proof. unfold Equation2285, magma_op, refa100_inst, refa100_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa100_not3509 : ~ @Equation3509 Fin3 refa100_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa100_inst, refa100_op in H. discriminate H. Qed.

(** ---- refa101 (Fin3) ---- *)

Definition refa101_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa101_inst : Magma Fin3 := {| magma_op := refa101_op |}.

Lemma refa101_sat3735 : @Equation3735 Fin3 refa101_inst.
Proof. unfold Equation3735, magma_op, refa101_inst, refa101_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa101_not3258 : ~ @Equation3258 Fin3 refa101_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3259 : ~ @Equation3259 Fin3 refa101_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3261 : ~ @Equation3261 Fin3 refa101_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3262 : ~ @Equation3262 Fin3 refa101_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3306 : ~ @Equation3306 Fin3 refa101_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3308 : ~ @Equation3308 Fin3 refa101_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3309 : ~ @Equation3309 Fin3 refa101_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3461 : ~ @Equation3461 Fin3 refa101_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3462 : ~ @Equation3462 Fin3 refa101_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3464 : ~ @Equation3464 Fin3 refa101_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3465 : ~ @Equation3465 Fin3 refa101_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3509 : ~ @Equation3509 Fin3 refa101_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3511 : ~ @Equation3511 Fin3 refa101_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3512 : ~ @Equation3512 Fin3 refa101_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3661 : ~ @Equation3661 Fin3 refa101_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3662 : ~ @Equation3662 Fin3 refa101_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3667 : ~ @Equation3667 Fin3 refa101_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3668 : ~ @Equation3668 Fin3 refa101_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3712 : ~ @Equation3712 Fin3 refa101_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3721 : ~ @Equation3721 Fin3 refa101_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3722 : ~ @Equation3722 Fin3 refa101_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3865 : ~ @Equation3865 Fin3 refa101_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3868 : ~ @Equation3868 Fin3 refa101_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3871 : ~ @Equation3871 Fin3 refa101_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3917 : ~ @Equation3917 Fin3 refa101_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3924 : ~ @Equation3924 Fin3 refa101_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not3927 : ~ @Equation3927 Fin3 refa101_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4066 : ~ @Equation4066 Fin3 refa101_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4068 : ~ @Equation4068 Fin3 refa101_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4071 : ~ @Equation4071 Fin3 refa101_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4074 : ~ @Equation4074 Fin3 refa101_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4120 : ~ @Equation4120 Fin3 refa101_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4127 : ~ @Equation4127 Fin3 refa101_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4130 : ~ @Equation4130 Fin3 refa101_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4269 : ~ @Equation4269 Fin3 refa101_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4270 : ~ @Equation4270 Fin3 refa101_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4283 : ~ @Equation4283 Fin3 refa101_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4284 : ~ @Equation4284 Fin3 refa101_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4396 : ~ @Equation4396 Fin3 refa101_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4399 : ~ @Equation4399 Fin3 refa101_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4435 : ~ @Equation4435 Fin3 refa101_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4472 : ~ @Equation4472 Fin3 refa101_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4583 : ~ @Equation4583 Fin3 refa101_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4598 : ~ @Equation4598 Fin3 refa101_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4629 : ~ @Equation4629 Fin3 refa101_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

Lemma refa101_not4656 : ~ @Equation4656 Fin3 refa101_inst.
Proof. unfold Equation4656. intro H. specialize (H F3_1 F3_0 F3_1). unfold magma_op, refa101_inst, refa101_op in H. discriminate H. Qed.

(** ---- refa102 (Fin3) ---- *)

Definition refa102_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa102_inst : Magma Fin3 := {| magma_op := refa102_op |}.

Lemma refa102_sat3259 : @Equation3259 Fin3 refa102_inst.
Proof. unfold Equation3259, magma_op, refa102_inst, refa102_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa102_sat3989 : @Equation3989 Fin3 refa102_inst.
Proof. unfold Equation3989, magma_op, refa102_inst, refa102_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa102_not3456 : ~ @Equation3456 Fin3 refa102_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa102_inst, refa102_op in H. discriminate H. Qed.

Lemma refa102_not3925 : ~ @Equation3925 Fin3 refa102_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa102_inst, refa102_op in H. discriminate H. Qed.

Lemma refa102_not3962 : ~ @Equation3962 Fin3 refa102_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa102_inst, refa102_op in H. discriminate H. Qed.

Lemma refa102_not4606 : ~ @Equation4606 Fin3 refa102_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa102_inst, refa102_op in H. discriminate H. Qed.

(** ---- refa103 (Fin3) ---- *)

Definition refa103_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa103_inst : Magma Fin3 := {| magma_op := refa103_op |}.

Lemma refa103_sat843 : @Equation843 Fin3 refa103_inst.
Proof. unfold Equation843, magma_op, refa103_inst, refa103_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa103_sat1035 : @Equation1035 Fin3 refa103_inst.
Proof. unfold Equation1035, magma_op, refa103_inst, refa103_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa103_sat1039 : @Equation1039 Fin3 refa103_inst.
Proof. unfold Equation1039, magma_op, refa103_inst, refa103_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa103_sat1045 : @Equation1045 Fin3 refa103_inst.
Proof. unfold Equation1045, magma_op, refa103_inst, refa103_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa103_sat1049 : @Equation1049 Fin3 refa103_inst.
Proof. unfold Equation1049, magma_op, refa103_inst, refa103_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa103_sat4673 : @Equation4673 Fin3 refa103_inst.
Proof. unfold Equation4673, magma_op, refa103_inst, refa103_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa103_not99 : ~ @Equation99 Fin3 refa103_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not411 : ~ @Equation411 Fin3 refa103_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not819 : ~ @Equation819 Fin3 refa103_inst.
Proof. unfold Equation819. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not842 : ~ @Equation842 Fin3 refa103_inst.
Proof. unfold Equation842. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not845 : ~ @Equation845 Fin3 refa103_inst.
Proof. unfold Equation845. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not1023 : ~ @Equation1023 Fin3 refa103_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not1028 : ~ @Equation1028 Fin3 refa103_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not1036 : ~ @Equation1036 Fin3 refa103_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not1038 : ~ @Equation1038 Fin3 refa103_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not1046 : ~ @Equation1046 Fin3 refa103_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not1223 : ~ @Equation1223 Fin3 refa103_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not1832 : ~ @Equation1832 Fin3 refa103_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not3253 : ~ @Equation3253 Fin3 refa103_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not3659 : ~ @Equation3659 Fin3 refa103_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not3862 : ~ @Equation3862 Fin3 refa103_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not4270 : ~ @Equation4270 Fin3 refa103_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

Lemma refa103_not4622 : ~ @Equation4622 Fin3 refa103_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa103_inst, refa103_op in H. discriminate H. Qed.

(** ---- refa104 (Fin3) ---- *)

Definition refa104_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa104_inst : Magma Fin3 := {| magma_op := refa104_op |}.

Lemma refa104_sat211 : @Equation211 Fin3 refa104_inst.
Proof. unfold Equation211, magma_op, refa104_inst, refa104_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa104_sat280 : @Equation280 Fin3 refa104_inst.
Proof. unfold Equation280, magma_op, refa104_inst, refa104_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa104_sat1452 : @Equation1452 Fin3 refa104_inst.
Proof. unfold Equation1452, magma_op, refa104_inst, refa104_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa104_sat1454 : @Equation1454 Fin3 refa104_inst.
Proof. unfold Equation1454, magma_op, refa104_inst, refa104_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa104_sat1459 : @Equation1459 Fin3 refa104_inst.
Proof. unfold Equation1459, magma_op, refa104_inst, refa104_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa104_sat1523 : @Equation1523 Fin3 refa104_inst.
Proof. unfold Equation1523, magma_op, refa104_inst, refa104_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa104_sat1673 : @Equation1673 Fin3 refa104_inst.
Proof. unfold Equation1673, magma_op, refa104_inst, refa104_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa104_sat1718 : @Equation1718 Fin3 refa104_inst.
Proof. unfold Equation1718, magma_op, refa104_inst, refa104_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa104_sat1835 : @Equation1835 Fin3 refa104_inst.
Proof. unfold Equation1835, magma_op, refa104_inst, refa104_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa104_sat2132 : @Equation2132 Fin3 refa104_inst.
Proof. unfold Equation2132, magma_op, refa104_inst, refa104_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa104_sat4497 : @Equation4497 Fin3 refa104_inst.
Proof. unfold Equation4497, magma_op, refa104_inst, refa104_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa104_not151 : ~ @Equation151 Fin3 refa104_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not411 : ~ @Equation411 Fin3 refa104_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not614 : ~ @Equation614 Fin3 refa104_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not817 : ~ @Equation817 Fin3 refa104_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1020 : ~ @Equation1020 Fin3 refa104_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1223 : ~ @Equation1223 Fin3 refa104_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1427 : ~ @Equation1427 Fin3 refa104_inst.
Proof. unfold Equation1427. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1428 : ~ @Equation1428 Fin3 refa104_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1431 : ~ @Equation1431 Fin3 refa104_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1434 : ~ @Equation1434 Fin3 refa104_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1435 : ~ @Equation1435 Fin3 refa104_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1441 : ~ @Equation1441 Fin3 refa104_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1445 : ~ @Equation1445 Fin3 refa104_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1632 : ~ @Equation1632 Fin3 refa104_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1635 : ~ @Equation1635 Fin3 refa104_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1654 : ~ @Equation1654 Fin3 refa104_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1691 : ~ @Equation1691 Fin3 refa104_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1722 : ~ @Equation1722 Fin3 refa104_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1838 : ~ @Equation1838 Fin3 refa104_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1840 : ~ @Equation1840 Fin3 refa104_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1848 : ~ @Equation1848 Fin3 refa104_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1921 : ~ @Equation1921 Fin3 refa104_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not1925 : ~ @Equation1925 Fin3 refa104_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2041 : ~ @Equation2041 Fin3 refa104_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2043 : ~ @Equation2043 Fin3 refa104_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2060 : ~ @Equation2060 Fin3 refa104_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2240 : ~ @Equation2240 Fin3 refa104_inst.
Proof. unfold Equation2240. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2243 : ~ @Equation2243 Fin3 refa104_inst.
Proof. unfold Equation2243. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2244 : ~ @Equation2244 Fin3 refa104_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2253 : ~ @Equation2253 Fin3 refa104_inst.
Proof. unfold Equation2253. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2256 : ~ @Equation2256 Fin3 refa104_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2257 : ~ @Equation2257 Fin3 refa104_inst.
Proof. unfold Equation2257. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2264 : ~ @Equation2264 Fin3 refa104_inst.
Proof. unfold Equation2264. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2266 : ~ @Equation2266 Fin3 refa104_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2293 : ~ @Equation2293 Fin3 refa104_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2300 : ~ @Equation2300 Fin3 refa104_inst.
Proof. unfold Equation2300. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2340 : ~ @Equation2340 Fin3 refa104_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2443 : ~ @Equation2443 Fin3 refa104_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2447 : ~ @Equation2447 Fin3 refa104_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2449 : ~ @Equation2449 Fin3 refa104_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2457 : ~ @Equation2457 Fin3 refa104_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2459 : ~ @Equation2459 Fin3 refa104_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2469 : ~ @Equation2469 Fin3 refa104_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2496 : ~ @Equation2496 Fin3 refa104_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2506 : ~ @Equation2506 Fin3 refa104_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2530 : ~ @Equation2530 Fin3 refa104_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2543 : ~ @Equation2543 Fin3 refa104_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2644 : ~ @Equation2644 Fin3 refa104_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not2847 : ~ @Equation2847 Fin3 refa104_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not3050 : ~ @Equation3050 Fin3 refa104_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not3253 : ~ @Equation3253 Fin3 refa104_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not3456 : ~ @Equation3456 Fin3 refa104_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not3667 : ~ @Equation3667 Fin3 refa104_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not3674 : ~ @Equation3674 Fin3 refa104_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not3712 : ~ @Equation3712 Fin3 refa104_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not3721 : ~ @Equation3721 Fin3 refa104_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not3725 : ~ @Equation3725 Fin3 refa104_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not3749 : ~ @Equation3749 Fin3 refa104_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not3752 : ~ @Equation3752 Fin3 refa104_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not3759 : ~ @Equation3759 Fin3 refa104_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not3862 : ~ @Equation3862 Fin3 refa104_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4065 : ~ @Equation4065 Fin3 refa104_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4268 : ~ @Equation4268 Fin3 refa104_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4269 : ~ @Equation4269 Fin3 refa104_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4275 : ~ @Equation4275 Fin3 refa104_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4283 : ~ @Equation4283 Fin3 refa104_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4284 : ~ @Equation4284 Fin3 refa104_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4290 : ~ @Equation4290 Fin3 refa104_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4314 : ~ @Equation4314 Fin3 refa104_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4320 : ~ @Equation4320 Fin3 refa104_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4396 : ~ @Equation4396 Fin3 refa104_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4398 : ~ @Equation4398 Fin3 refa104_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4433 : ~ @Equation4433 Fin3 refa104_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4435 : ~ @Equation4435 Fin3 refa104_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4442 : ~ @Equation4442 Fin3 refa104_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4473 : ~ @Equation4473 Fin3 refa104_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4480 : ~ @Equation4480 Fin3 refa104_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4584 : ~ @Equation4584 Fin3 refa104_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4585 : ~ @Equation4585 Fin3 refa104_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4587 : ~ @Equation4587 Fin3 refa104_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4598 : ~ @Equation4598 Fin3 refa104_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4599 : ~ @Equation4599 Fin3 refa104_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

Lemma refa104_not4635 : ~ @Equation4635 Fin3 refa104_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa104_inst, refa104_op in H. discriminate H. Qed.

(** ---- refa105 (Fin3) ---- *)

Definition refa105_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa105_inst : Magma Fin3 := {| magma_op := refa105_op |}.

Lemma refa105_sat4229 : @Equation4229 Fin3 refa105_inst.
Proof. unfold Equation4229, magma_op, refa105_inst, refa105_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa105_not3259 : ~ @Equation3259 Fin3 refa105_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3261 : ~ @Equation3261 Fin3 refa105_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3269 : ~ @Equation3269 Fin3 refa105_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3271 : ~ @Equation3271 Fin3 refa105_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3414 : ~ @Equation3414 Fin3 refa105_inst.
Proof. unfold Equation3414. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3459 : ~ @Equation3459 Fin3 refa105_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3462 : ~ @Equation3462 Fin3 refa105_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3474 : ~ @Equation3474 Fin3 refa105_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3481 : ~ @Equation3481 Fin3 refa105_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3588 : ~ @Equation3588 Fin3 refa105_inst.
Proof. unfold Equation3588. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3737 : ~ @Equation3737 Fin3 refa105_inst.
Proof. unfold Equation3737. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3794 : ~ @Equation3794 Fin3 refa105_inst.
Proof. unfold Equation3794. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3865 : ~ @Equation3865 Fin3 refa105_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3868 : ~ @Equation3868 Fin3 refa105_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3880 : ~ @Equation3880 Fin3 refa105_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3887 : ~ @Equation3887 Fin3 refa105_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not3994 : ~ @Equation3994 Fin3 refa105_inst.
Proof. unfold Equation3994. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4071 : ~ @Equation4071 Fin3 refa105_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4073 : ~ @Equation4073 Fin3 refa105_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4081 : ~ @Equation4081 Fin3 refa105_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4083 : ~ @Equation4083 Fin3 refa105_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4135 : ~ @Equation4135 Fin3 refa105_inst.
Proof. unfold Equation4135. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4273 : ~ @Equation4273 Fin3 refa105_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4275 : ~ @Equation4275 Fin3 refa105_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4290 : ~ @Equation4290 Fin3 refa105_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4320 : ~ @Equation4320 Fin3 refa105_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4396 : ~ @Equation4396 Fin3 refa105_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4433 : ~ @Equation4433 Fin3 refa105_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4473 : ~ @Equation4473 Fin3 refa105_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4480 : ~ @Equation4480 Fin3 refa105_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4598 : ~ @Equation4598 Fin3 refa105_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4605 : ~ @Equation4605 Fin3 refa105_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4647 : ~ @Equation4647 Fin3 refa105_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

Lemma refa105_not4656 : ~ @Equation4656 Fin3 refa105_inst.
Proof. unfold Equation4656. intro H. specialize (H F3_2 F3_0 F3_1). unfold magma_op, refa105_inst, refa105_op in H. discriminate H. Qed.

(** ---- refa106 (Fin3) ---- *)

Definition refa106_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa106_inst : Magma Fin3 := {| magma_op := refa106_op |}.

Lemma refa106_sat3315 : @Equation3315 Fin3 refa106_inst.
Proof. unfold Equation3315, magma_op, refa106_inst, refa106_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa106_sat3346 : @Equation3346 Fin3 refa106_inst.
Proof. unfold Equation3346, magma_op, refa106_inst, refa106_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa106_sat3509 : @Equation3509 Fin3 refa106_inst.
Proof. unfold Equation3509, magma_op, refa106_inst, refa106_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa106_sat3558 : @Equation3558 Fin3 refa106_inst.
Proof. unfold Equation3558, magma_op, refa106_inst, refa106_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa106_sat4120 : @Equation4120 Fin3 refa106_inst.
Proof. unfold Equation4120, magma_op, refa106_inst, refa106_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa106_sat4165 : @Equation4165 Fin3 refa106_inst.
Proof. unfold Equation4165, magma_op, refa106_inst, refa106_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa106_not3319 : ~ @Equation3319 Fin3 refa106_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa106_inst, refa106_op in H. discriminate H. Qed.

Lemma refa106_not3353 : ~ @Equation3353 Fin3 refa106_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa106_inst, refa106_op in H. discriminate H. Qed.

Lemma refa106_not3522 : ~ @Equation3522 Fin3 refa106_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa106_inst, refa106_op in H. discriminate H. Qed.

Lemma refa106_not3915 : ~ @Equation3915 Fin3 refa106_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa106_inst, refa106_op in H. discriminate H. Qed.

Lemma refa106_not3955 : ~ @Equation3955 Fin3 refa106_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa106_inst, refa106_op in H. discriminate H. Qed.

Lemma refa106_not3962 : ~ @Equation3962 Fin3 refa106_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa106_inst, refa106_op in H. discriminate H. Qed.

Lemma refa106_not4118 : ~ @Equation4118 Fin3 refa106_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa106_inst, refa106_op in H. discriminate H. Qed.

Lemma refa106_not4127 : ~ @Equation4127 Fin3 refa106_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa106_inst, refa106_op in H. discriminate H. Qed.

Lemma refa106_not4131 : ~ @Equation4131 Fin3 refa106_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa106_inst, refa106_op in H. discriminate H. Qed.

Lemma refa106_not4158 : ~ @Equation4158 Fin3 refa106_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa106_inst, refa106_op in H. discriminate H. Qed.

Lemma refa106_not4290 : ~ @Equation4290 Fin3 refa106_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa106_inst, refa106_op in H. discriminate H. Qed.

Lemma refa106_not4320 : ~ @Equation4320 Fin3 refa106_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa106_inst, refa106_op in H. discriminate H. Qed.

Lemma refa106_not4598 : ~ @Equation4598 Fin3 refa106_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa106_inst, refa106_op in H. discriminate H. Qed.

(** ---- refa107 (Fin3) ---- *)

Definition refa107_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa107_inst : Magma Fin3 := {| magma_op := refa107_op |}.

Lemma refa107_sat455 : @Equation455 Fin3 refa107_inst.
Proof. unfold Equation455, magma_op, refa107_inst, refa107_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa107_sat647 : @Equation647 Fin3 refa107_inst.
Proof. unfold Equation647, magma_op, refa107_inst, refa107_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa107_sat655 : @Equation655 Fin3 refa107_inst.
Proof. unfold Equation655, magma_op, refa107_inst, refa107_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa107_sat1061 : @Equation1061 Fin3 refa107_inst.
Proof. unfold Equation1061, magma_op, refa107_inst, refa107_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa107_not466 : ~ @Equation466 Fin3 refa107_inst.
Proof. unfold Equation466. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not473 : ~ @Equation473 Fin3 refa107_inst.
Proof. unfold Equation473. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not477 : ~ @Equation477 Fin3 refa107_inst.
Proof. unfold Equation477. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not504 : ~ @Equation504 Fin3 refa107_inst.
Proof. unfold Equation504. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not511 : ~ @Equation511 Fin3 refa107_inst.
Proof. unfold Equation511. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not513 : ~ @Equation513 Fin3 refa107_inst.
Proof. unfold Equation513. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not667 : ~ @Equation667 Fin3 refa107_inst.
Proof. unfold Equation667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not669 : ~ @Equation669 Fin3 refa107_inst.
Proof. unfold Equation669. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not676 : ~ @Equation676 Fin3 refa107_inst.
Proof. unfold Equation676. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not680 : ~ @Equation680 Fin3 refa107_inst.
Proof. unfold Equation680. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not707 : ~ @Equation707 Fin3 refa107_inst.
Proof. unfold Equation707. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not870 : ~ @Equation870 Fin3 refa107_inst.
Proof. unfold Equation870. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not872 : ~ @Equation872 Fin3 refa107_inst.
Proof. unfold Equation872. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not879 : ~ @Equation879 Fin3 refa107_inst.
Proof. unfold Equation879. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not883 : ~ @Equation883 Fin3 refa107_inst.
Proof. unfold Equation883. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not906 : ~ @Equation906 Fin3 refa107_inst.
Proof. unfold Equation906. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not917 : ~ @Equation917 Fin3 refa107_inst.
Proof. unfold Equation917. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1075 : ~ @Equation1075 Fin3 refa107_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1082 : ~ @Equation1082 Fin3 refa107_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1086 : ~ @Equation1086 Fin3 refa107_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1109 : ~ @Equation1109 Fin3 refa107_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1113 : ~ @Equation1113 Fin3 refa107_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1122 : ~ @Equation1122 Fin3 refa107_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1276 : ~ @Equation1276 Fin3 refa107_inst.
Proof. unfold Equation1276. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1278 : ~ @Equation1278 Fin3 refa107_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1285 : ~ @Equation1285 Fin3 refa107_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1426 : ~ @Equation1426 Fin3 refa107_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1629 : ~ @Equation1629 Fin3 refa107_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1838 : ~ @Equation1838 Fin3 refa107_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1840 : ~ @Equation1840 Fin3 refa107_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1848 : ~ @Equation1848 Fin3 refa107_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1850 : ~ @Equation1850 Fin3 refa107_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1885 : ~ @Equation1885 Fin3 refa107_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1887 : ~ @Equation1887 Fin3 refa107_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1894 : ~ @Equation1894 Fin3 refa107_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1921 : ~ @Equation1921 Fin3 refa107_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not1925 : ~ @Equation1925 Fin3 refa107_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not2035 : ~ @Equation2035 Fin3 refa107_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not2238 : ~ @Equation2238 Fin3 refa107_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not2441 : ~ @Equation2441 Fin3 refa107_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not2644 : ~ @Equation2644 Fin3 refa107_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not2847 : ~ @Equation2847 Fin3 refa107_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3050 : ~ @Equation3050 Fin3 refa107_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3342 : ~ @Equation3342 Fin3 refa107_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3346 : ~ @Equation3346 Fin3 refa107_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3353 : ~ @Equation3353 Fin3 refa107_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3545 : ~ @Equation3545 Fin3 refa107_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3549 : ~ @Equation3549 Fin3 refa107_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3556 : ~ @Equation3556 Fin3 refa107_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3558 : ~ @Equation3558 Fin3 refa107_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3712 : ~ @Equation3712 Fin3 refa107_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3714 : ~ @Equation3714 Fin3 refa107_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3748 : ~ @Equation3748 Fin3 refa107_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3752 : ~ @Equation3752 Fin3 refa107_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3759 : ~ @Equation3759 Fin3 refa107_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3761 : ~ @Equation3761 Fin3 refa107_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3917 : ~ @Equation3917 Fin3 refa107_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3924 : ~ @Equation3924 Fin3 refa107_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3951 : ~ @Equation3951 Fin3 refa107_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3955 : ~ @Equation3955 Fin3 refa107_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3962 : ~ @Equation3962 Fin3 refa107_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not3964 : ~ @Equation3964 Fin3 refa107_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4118 : ~ @Equation4118 Fin3 refa107_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4120 : ~ @Equation4120 Fin3 refa107_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4127 : ~ @Equation4127 Fin3 refa107_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4158 : ~ @Equation4158 Fin3 refa107_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4165 : ~ @Equation4165 Fin3 refa107_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4167 : ~ @Equation4167 Fin3 refa107_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4273 : ~ @Equation4273 Fin3 refa107_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4275 : ~ @Equation4275 Fin3 refa107_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4290 : ~ @Equation4290 Fin3 refa107_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4320 : ~ @Equation4320 Fin3 refa107_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4380 : ~ @Equation4380 Fin3 refa107_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4585 : ~ @Equation4585 Fin3 refa107_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4605 : ~ @Equation4605 Fin3 refa107_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

Lemma refa107_not4635 : ~ @Equation4635 Fin3 refa107_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa107_inst, refa107_op in H. discriminate H. Qed.

(** ---- refa108 (Fin3) ---- *)

Definition refa108_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa108_inst : Magma Fin3 := {| magma_op := refa108_op |}.

Lemma refa108_sat211 : @Equation211 Fin3 refa108_inst.
Proof. unfold Equation211, magma_op, refa108_inst, refa108_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa108_not2238 : ~ @Equation2238 Fin3 refa108_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa108_inst, refa108_op in H. discriminate H. Qed.

Lemma refa108_not2441 : ~ @Equation2441 Fin3 refa108_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, refa108_inst, refa108_op in H. discriminate H. Qed.

(** ---- refa109 (Fin3) ---- *)

Definition refa109_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa109_inst : Magma Fin3 := {| magma_op := refa109_op |}.

Lemma refa109_sat3274 : @Equation3274 Fin3 refa109_inst.
Proof. unfold Equation3274, magma_op, refa109_inst, refa109_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa109_sat3529 : @Equation3529 Fin3 refa109_inst.
Proof. unfold Equation3529, magma_op, refa109_inst, refa109_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa109_sat4226 : @Equation4226 Fin3 refa109_inst.
Proof. unfold Equation4226, magma_op, refa109_inst, refa109_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa109_sat4327 : @Equation4327 Fin3 refa109_inst.
Proof. unfold Equation4327, magma_op, refa109_inst, refa109_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa109_sat4494 : @Equation4494 Fin3 refa109_inst.
Proof. unfold Equation4494, magma_op, refa109_inst, refa109_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa109_not3522 : ~ @Equation3522 Fin3 refa109_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa109_inst, refa109_op in H. discriminate H. Qed.

Lemma refa109_not4470 : ~ @Equation4470 Fin3 refa109_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa109_inst, refa109_op in H. discriminate H. Qed.

Lemma refa109_not4590 : ~ @Equation4590 Fin3 refa109_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa109_inst, refa109_op in H. discriminate H. Qed.

Lemma refa109_not4599 : ~ @Equation4599 Fin3 refa109_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa109_inst, refa109_op in H. discriminate H. Qed.

(** ---- refa11 (Fin7) ---- *)

Definition refa11_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_0 | F7_0, F7_6 => F7_6
  | F7_1, F7_0 => F7_4 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_6 | F7_1, F7_3 => F7_5 | F7_1, F7_4 => F7_3 | F7_1, F7_5 => F7_2 | F7_1, F7_6 => F7_0
  | F7_2, F7_0 => F7_6 | F7_2, F7_1 => F7_3 | F7_2, F7_2 => F7_1 | F7_2, F7_3 => F7_0 | F7_2, F7_4 => F7_2 | F7_2, F7_5 => F7_5 | F7_2, F7_6 => F7_4
  | F7_3, F7_0 => F7_2 | F7_3, F7_1 => F7_0 | F7_3, F7_2 => F7_5 | F7_3, F7_3 => F7_1 | F7_3, F7_4 => F7_4 | F7_3, F7_5 => F7_6 | F7_3, F7_6 => F7_3
  | F7_4, F7_0 => F7_0 | F7_4, F7_1 => F7_6 | F7_4, F7_2 => F7_4 | F7_4, F7_3 => F7_2 | F7_4, F7_4 => F7_1 | F7_4, F7_5 => F7_3 | F7_4, F7_6 => F7_5
  | F7_5, F7_0 => F7_5 | F7_5, F7_1 => F7_4 | F7_5, F7_2 => F7_0 | F7_5, F7_3 => F7_3 | F7_5, F7_4 => F7_6 | F7_5, F7_5 => F7_1 | F7_5, F7_6 => F7_2
  | F7_6, F7_0 => F7_3 | F7_6, F7_1 => F7_5 | F7_6, F7_2 => F7_2 | F7_6, F7_3 => F7_6 | F7_6, F7_4 => F7_0 | F7_6, F7_5 => F7_4 | F7_6, F7_6 => F7_1
  end.

#[local] Instance refa11_inst : Magma Fin7 := {| magma_op := refa11_op |}.

Lemma refa11_sat677 : @Equation677 Fin7 refa11_inst.
Proof. unfold Equation677, magma_op, refa11_inst, refa11_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa11_not47 : ~ @Equation47 Fin7 refa11_inst.
Proof. unfold Equation47. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not99 : ~ @Equation99 Fin7 refa11_inst.
Proof. unfold Equation99. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not151 : ~ @Equation151 Fin7 refa11_inst.
Proof. unfold Equation151. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not203 : ~ @Equation203 Fin7 refa11_inst.
Proof. unfold Equation203. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not261 : ~ @Equation261 Fin7 refa11_inst.
Proof. unfold Equation261. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not274 : ~ @Equation274 Fin7 refa11_inst.
Proof. unfold Equation274. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not283 : ~ @Equation283 Fin7 refa11_inst.
Proof. unfold Equation283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not411 : ~ @Equation411 Fin7 refa11_inst.
Proof. unfold Equation411. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not670 : ~ @Equation670 Fin7 refa11_inst.
Proof. unfold Equation670. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not817 : ~ @Equation817 Fin7 refa11_inst.
Proof. unfold Equation817. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not1020 : ~ @Equation1020 Fin7 refa11_inst.
Proof. unfold Equation1020. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not1223 : ~ @Equation1223 Fin7 refa11_inst.
Proof. unfold Equation1223. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not1426 : ~ @Equation1426 Fin7 refa11_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not1629 : ~ @Equation1629 Fin7 refa11_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not1832 : ~ @Equation1832 Fin7 refa11_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not2035 : ~ @Equation2035 Fin7 refa11_inst.
Proof. unfold Equation2035. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not2238 : ~ @Equation2238 Fin7 refa11_inst.
Proof. unfold Equation2238. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not2441 : ~ @Equation2441 Fin7 refa11_inst.
Proof. unfold Equation2441. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not2644 : ~ @Equation2644 Fin7 refa11_inst.
Proof. unfold Equation2644. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not2847 : ~ @Equation2847 Fin7 refa11_inst.
Proof. unfold Equation2847. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not3050 : ~ @Equation3050 Fin7 refa11_inst.
Proof. unfold Equation3050. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not3253 : ~ @Equation3253 Fin7 refa11_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not3456 : ~ @Equation3456 Fin7 refa11_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not3722 : ~ @Equation3722 Fin7 refa11_inst.
Proof. unfold Equation3722. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not3749 : ~ @Equation3749 Fin7 refa11_inst.
Proof. unfold Equation3749. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not3862 : ~ @Equation3862 Fin7 refa11_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not4065 : ~ @Equation4065 Fin7 refa11_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not4283 : ~ @Equation4283 Fin7 refa11_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not4343 : ~ @Equation4343 Fin7 refa11_inst.
Proof. unfold Equation4343. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not4380 : ~ @Equation4380 Fin7 refa11_inst.
Proof. unfold Equation4380. intro H. specialize (H F7_0). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not4608 : ~ @Equation4608 Fin7 refa11_inst.
Proof. unfold Equation4608. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

Lemma refa11_not4635 : ~ @Equation4635 Fin7 refa11_inst.
Proof. unfold Equation4635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa11_inst, refa11_op in H. discriminate H. Qed.

(** ---- refa110 (Fin3) ---- *)

Definition refa110_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa110_inst : Magma Fin3 := {| magma_op := refa110_op |}.

Lemma refa110_sat842 : @Equation842 Fin3 refa110_inst.
Proof. unfold Equation842, magma_op, refa110_inst, refa110_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa110_sat2340 : @Equation2340 Fin3 refa110_inst.
Proof. unfold Equation2340, magma_op, refa110_inst, refa110_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa110_sat2761 : @Equation2761 Fin3 refa110_inst.
Proof. unfold Equation2761, magma_op, refa110_inst, refa110_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa110_not835 : ~ @Equation835 Fin3 refa110_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa110_inst, refa110_op in H. discriminate H. Qed.

Lemma refa110_not2246 : ~ @Equation2246 Fin3 refa110_inst.
Proof. unfold Equation2246. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa110_inst, refa110_op in H. discriminate H. Qed.

Lemma refa110_not2256 : ~ @Equation2256 Fin3 refa110_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa110_inst, refa110_op in H. discriminate H. Qed.

Lemma refa110_not2293 : ~ @Equation2293 Fin3 refa110_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa110_inst, refa110_op in H. discriminate H. Qed.

Lemma refa110_not2459 : ~ @Equation2459 Fin3 refa110_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa110_inst, refa110_op in H. discriminate H. Qed.

Lemma refa110_not3677 : ~ @Equation3677 Fin3 refa110_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa110_inst, refa110_op in H. discriminate H. Qed.

Lemma refa110_not3870 : ~ @Equation3870 Fin3 refa110_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa110_inst, refa110_op in H. discriminate H. Qed.

Lemma refa110_not3887 : ~ @Equation3887 Fin3 refa110_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa110_inst, refa110_op in H. discriminate H. Qed.

Lemma refa110_not4131 : ~ @Equation4131 Fin3 refa110_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa110_inst, refa110_op in H. discriminate H. Qed.

(** ---- refa111 (Fin3) ---- *)

Definition refa111_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa111_inst : Magma Fin3 := {| magma_op := refa111_op |}.

Lemma refa111_sat3755 : @Equation3755 Fin3 refa111_inst.
Proof. unfold Equation3755, magma_op, refa111_inst, refa111_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa111_not3268 : ~ @Equation3268 Fin3 refa111_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3271 : ~ @Equation3271 Fin3 refa111_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3278 : ~ @Equation3278 Fin3 refa111_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3281 : ~ @Equation3281 Fin3 refa111_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3343 : ~ @Equation3343 Fin3 refa111_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3346 : ~ @Equation3346 Fin3 refa111_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3353 : ~ @Equation3353 Fin3 refa111_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3474 : ~ @Equation3474 Fin3 refa111_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3481 : ~ @Equation3481 Fin3 refa111_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3484 : ~ @Equation3484 Fin3 refa111_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3546 : ~ @Equation3546 Fin3 refa111_inst.
Proof. unfold Equation3546. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3549 : ~ @Equation3549 Fin3 refa111_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3556 : ~ @Equation3556 Fin3 refa111_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3664 : ~ @Equation3664 Fin3 refa111_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3667 : ~ @Equation3667 Fin3 refa111_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3684 : ~ @Equation3684 Fin3 refa111_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3687 : ~ @Equation3687 Fin3 refa111_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3722 : ~ @Equation3722 Fin3 refa111_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3725 : ~ @Equation3725 Fin3 refa111_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3759 : ~ @Equation3759 Fin3 refa111_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3864 : ~ @Equation3864 Fin3 refa111_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3870 : ~ @Equation3870 Fin3 refa111_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3880 : ~ @Equation3880 Fin3 refa111_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3890 : ~ @Equation3890 Fin3 refa111_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3918 : ~ @Equation3918 Fin3 refa111_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3928 : ~ @Equation3928 Fin3 refa111_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not3955 : ~ @Equation3955 Fin3 refa111_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4067 : ~ @Equation4067 Fin3 refa111_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4073 : ~ @Equation4073 Fin3 refa111_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4083 : ~ @Equation4083 Fin3 refa111_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4093 : ~ @Equation4093 Fin3 refa111_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4121 : ~ @Equation4121 Fin3 refa111_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4131 : ~ @Equation4131 Fin3 refa111_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4158 : ~ @Equation4158 Fin3 refa111_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4272 : ~ @Equation4272 Fin3 refa111_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4275 : ~ @Equation4275 Fin3 refa111_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4291 : ~ @Equation4291 Fin3 refa111_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4320 : ~ @Equation4320 Fin3 refa111_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4399 : ~ @Equation4399 Fin3 refa111_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4435 : ~ @Equation4435 Fin3 refa111_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4445 : ~ @Equation4445 Fin3 refa111_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4473 : ~ @Equation4473 Fin3 refa111_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4599 : ~ @Equation4599 Fin3 refa111_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4622 : ~ @Equation4622 Fin3 refa111_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4631 : ~ @Equation4631 Fin3 refa111_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

Lemma refa111_not4635 : ~ @Equation4635 Fin3 refa111_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa111_inst, refa111_op in H. discriminate H. Qed.

(** ---- refa112 (Fin3) ---- *)

Definition refa112_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa112_inst : Magma Fin3 := {| magma_op := refa112_op |}.

Lemma refa112_sat361 : @Equation361 Fin3 refa112_inst.
Proof. unfold Equation361, magma_op, refa112_inst, refa112_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa112_sat1441 : @Equation1441 Fin3 refa112_inst.
Proof. unfold Equation1441, magma_op, refa112_inst, refa112_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa112_sat1867 : @Equation1867 Fin3 refa112_inst.
Proof. unfold Equation1867, magma_op, refa112_inst, refa112_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa112_sat2306 : @Equation2306 Fin3 refa112_inst.
Proof. unfold Equation2306, magma_op, refa112_inst, refa112_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa112_not2290 : ~ @Equation2290 Fin3 refa112_inst.
Proof. unfold Equation2290. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa112_inst, refa112_op in H. discriminate H. Qed.

Lemma refa112_not2327 : ~ @Equation2327 Fin3 refa112_inst.
Proof. unfold Equation2327. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa112_inst, refa112_op in H. discriminate H. Qed.

Lemma refa112_not2696 : ~ @Equation2696 Fin3 refa112_inst.
Proof. unfold Equation2696. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa112_inst, refa112_op in H. discriminate H. Qed.

Lemma refa112_not2733 : ~ @Equation2733 Fin3 refa112_inst.
Proof. unfold Equation2733. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa112_inst, refa112_op in H. discriminate H. Qed.

Lemma refa112_not3461 : ~ @Equation3461 Fin3 refa112_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa112_inst, refa112_op in H. discriminate H. Qed.

Lemma refa112_not3464 : ~ @Equation3464 Fin3 refa112_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa112_inst, refa112_op in H. discriminate H. Qed.

Lemma refa112_not3674 : ~ @Equation3674 Fin3 refa112_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa112_inst, refa112_op in H. discriminate H. Qed.

Lemma refa112_not3684 : ~ @Equation3684 Fin3 refa112_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa112_inst, refa112_op in H. discriminate H. Qed.

Lemma refa112_not3759 : ~ @Equation3759 Fin3 refa112_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa112_inst, refa112_op in H. discriminate H. Qed.

Lemma refa112_not4073 : ~ @Equation4073 Fin3 refa112_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa112_inst, refa112_op in H. discriminate H. Qed.

Lemma refa112_not4131 : ~ @Equation4131 Fin3 refa112_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa112_inst, refa112_op in H. discriminate H. Qed.

Lemma refa112_not4269 : ~ @Equation4269 Fin3 refa112_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa112_inst, refa112_op in H. discriminate H. Qed.

Lemma refa112_not4320 : ~ @Equation4320 Fin3 refa112_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa112_inst, refa112_op in H. discriminate H. Qed.

(** ---- refa113 (Fin3) ---- *)

Definition refa113_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa113_inst : Magma Fin3 := {| magma_op := refa113_op |}.

Lemma refa113_sat861 : @Equation861 Fin3 refa113_inst.
Proof. unfold Equation861, magma_op, refa113_inst, refa113_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa113_not43 : ~ @Equation43 Fin3 refa113_inst.
Proof. unfold Equation43. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not99 : ~ @Equation99 Fin3 refa113_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not359 : ~ @Equation359 Fin3 refa113_inst.
Proof. unfold Equation359. intro H. specialize (H F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not411 : ~ @Equation411 Fin3 refa113_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not614 : ~ @Equation614 Fin3 refa113_inst.
Proof. unfold Equation614. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not819 : ~ @Equation819 Fin3 refa113_inst.
Proof. unfold Equation819. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not832 : ~ @Equation832 Fin3 refa113_inst.
Proof. unfold Equation832. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not835 : ~ @Equation835 Fin3 refa113_inst.
Proof. unfold Equation835. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not836 : ~ @Equation836 Fin3 refa113_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not842 : ~ @Equation842 Fin3 refa113_inst.
Proof. unfold Equation842. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not843 : ~ @Equation843 Fin3 refa113_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not845 : ~ @Equation845 Fin3 refa113_inst.
Proof. unfold Equation845. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not870 : ~ @Equation870 Fin3 refa113_inst.
Proof. unfold Equation870. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not872 : ~ @Equation872 Fin3 refa113_inst.
Proof. unfold Equation872. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not879 : ~ @Equation879 Fin3 refa113_inst.
Proof. unfold Equation879. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not883 : ~ @Equation883 Fin3 refa113_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not906 : ~ @Equation906 Fin3 refa113_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not917 : ~ @Equation917 Fin3 refa113_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not1020 : ~ @Equation1020 Fin3 refa113_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not1223 : ~ @Equation1223 Fin3 refa113_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not1426 : ~ @Equation1426 Fin3 refa113_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not1629 : ~ @Equation1629 Fin3 refa113_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not1832 : ~ @Equation1832 Fin3 refa113_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not2035 : ~ @Equation2035 Fin3 refa113_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not2238 : ~ @Equation2238 Fin3 refa113_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not2441 : ~ @Equation2441 Fin3 refa113_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not2644 : ~ @Equation2644 Fin3 refa113_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not2847 : ~ @Equation2847 Fin3 refa113_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not3050 : ~ @Equation3050 Fin3 refa113_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not3253 : ~ @Equation3253 Fin3 refa113_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not3456 : ~ @Equation3456 Fin3 refa113_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not3659 : ~ @Equation3659 Fin3 refa113_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not3870 : ~ @Equation3870 Fin3 refa113_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not3880 : ~ @Equation3880 Fin3 refa113_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not3887 : ~ @Equation3887 Fin3 refa113_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not3928 : ~ @Equation3928 Fin3 refa113_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not3955 : ~ @Equation3955 Fin3 refa113_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not3962 : ~ @Equation3962 Fin3 refa113_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4066 : ~ @Equation4066 Fin3 refa113_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4067 : ~ @Equation4067 Fin3 refa113_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4070 : ~ @Equation4070 Fin3 refa113_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4073 : ~ @Equation4073 Fin3 refa113_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4118 : ~ @Equation4118 Fin3 refa113_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4120 : ~ @Equation4120 Fin3 refa113_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4127 : ~ @Equation4127 Fin3 refa113_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4269 : ~ @Equation4269 Fin3 refa113_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4273 : ~ @Equation4273 Fin3 refa113_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4290 : ~ @Equation4290 Fin3 refa113_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4314 : ~ @Equation4314 Fin3 refa113_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4583 : ~ @Equation4583 Fin3 refa113_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4584 : ~ @Equation4584 Fin3 refa113_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4585 : ~ @Equation4585 Fin3 refa113_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

Lemma refa113_not4598 : ~ @Equation4598 Fin3 refa113_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa113_inst, refa113_op in H. discriminate H. Qed.

(** ---- refa114 (Fin3) ---- *)

Definition refa114_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa114_inst : Magma Fin3 := {| magma_op := refa114_op |}.

Lemma refa114_sat50 : @Equation50 Fin3 refa114_inst.
Proof. unfold Equation50, magma_op, refa114_inst, refa114_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa114_sat107 : @Equation107 Fin3 refa114_inst.
Proof. unfold Equation107, magma_op, refa114_inst, refa114_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa114_sat1996 : @Equation1996 Fin3 refa114_inst.
Proof. unfold Equation1996, magma_op, refa114_inst, refa114_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa114_sat2063 : @Equation2063 Fin3 refa114_inst.
Proof. unfold Equation2063, magma_op, refa114_inst, refa114_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa114_sat2100 : @Equation2100 Fin3 refa114_inst.
Proof. unfold Equation2100, magma_op, refa114_inst, refa114_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa114_sat2152 : @Equation2152 Fin3 refa114_inst.
Proof. unfold Equation2152, magma_op, refa114_inst, refa114_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa114_not105 : ~ @Equation105 Fin3 refa114_inst.
Proof. unfold Equation105. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not108 : ~ @Equation108 Fin3 refa114_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not151 : ~ @Equation151 Fin3 refa114_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not411 : ~ @Equation411 Fin3 refa114_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not614 : ~ @Equation614 Fin3 refa114_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not817 : ~ @Equation817 Fin3 refa114_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1022 : ~ @Equation1022 Fin3 refa114_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1023 : ~ @Equation1023 Fin3 refa114_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1035 : ~ @Equation1035 Fin3 refa114_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1036 : ~ @Equation1036 Fin3 refa114_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1038 : ~ @Equation1038 Fin3 refa114_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1039 : ~ @Equation1039 Fin3 refa114_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1045 : ~ @Equation1045 Fin3 refa114_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1046 : ~ @Equation1046 Fin3 refa114_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1048 : ~ @Equation1048 Fin3 refa114_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1049 : ~ @Equation1049 Fin3 refa114_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1075 : ~ @Equation1075 Fin3 refa114_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1082 : ~ @Equation1082 Fin3 refa114_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1085 : ~ @Equation1085 Fin3 refa114_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1112 : ~ @Equation1112 Fin3 refa114_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1224 : ~ @Equation1224 Fin3 refa114_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1225 : ~ @Equation1225 Fin3 refa114_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1228 : ~ @Equation1228 Fin3 refa114_inst.
Proof. unfold Equation1228. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1229 : ~ @Equation1229 Fin3 refa114_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1238 : ~ @Equation1238 Fin3 refa114_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1239 : ~ @Equation1239 Fin3 refa114_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1241 : ~ @Equation1241 Fin3 refa114_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1242 : ~ @Equation1242 Fin3 refa114_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1249 : ~ @Equation1249 Fin3 refa114_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1251 : ~ @Equation1251 Fin3 refa114_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1252 : ~ @Equation1252 Fin3 refa114_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1285 : ~ @Equation1285 Fin3 refa114_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1288 : ~ @Equation1288 Fin3 refa114_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1315 : ~ @Equation1315 Fin3 refa114_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1322 : ~ @Equation1322 Fin3 refa114_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1631 : ~ @Equation1631 Fin3 refa114_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1632 : ~ @Equation1632 Fin3 refa114_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1634 : ~ @Equation1634 Fin3 refa114_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1644 : ~ @Equation1644 Fin3 refa114_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1654 : ~ @Equation1654 Fin3 refa114_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1657 : ~ @Equation1657 Fin3 refa114_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1681 : ~ @Equation1681 Fin3 refa114_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1684 : ~ @Equation1684 Fin3 refa114_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1691 : ~ @Equation1691 Fin3 refa114_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1694 : ~ @Equation1694 Fin3 refa114_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1721 : ~ @Equation1721 Fin3 refa114_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1728 : ~ @Equation1728 Fin3 refa114_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1834 : ~ @Equation1834 Fin3 refa114_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1837 : ~ @Equation1837 Fin3 refa114_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1838 : ~ @Equation1838 Fin3 refa114_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1840 : ~ @Equation1840 Fin3 refa114_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1847 : ~ @Equation1847 Fin3 refa114_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1851 : ~ @Equation1851 Fin3 refa114_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1860 : ~ @Equation1860 Fin3 refa114_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1894 : ~ @Equation1894 Fin3 refa114_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1897 : ~ @Equation1897 Fin3 refa114_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1921 : ~ @Equation1921 Fin3 refa114_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1924 : ~ @Equation1924 Fin3 refa114_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not1931 : ~ @Equation1931 Fin3 refa114_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not2037 : ~ @Equation2037 Fin3 refa114_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not2040 : ~ @Equation2040 Fin3 refa114_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not2050 : ~ @Equation2050 Fin3 refa114_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not2060 : ~ @Equation2060 Fin3 refa114_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not2087 : ~ @Equation2087 Fin3 refa114_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not2127 : ~ @Equation2127 Fin3 refa114_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not2134 : ~ @Equation2134 Fin3 refa114_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not2441 : ~ @Equation2441 Fin3 refa114_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not2644 : ~ @Equation2644 Fin3 refa114_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not2847 : ~ @Equation2847 Fin3 refa114_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not3050 : ~ @Equation3050 Fin3 refa114_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not3253 : ~ @Equation3253 Fin3 refa114_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not3456 : ~ @Equation3456 Fin3 refa114_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not3667 : ~ @Equation3667 Fin3 refa114_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not3724 : ~ @Equation3724 Fin3 refa114_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not3725 : ~ @Equation3725 Fin3 refa114_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not3862 : ~ @Equation3862 Fin3 refa114_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4065 : ~ @Equation4065 Fin3 refa114_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4268 : ~ @Equation4268 Fin3 refa114_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4269 : ~ @Equation4269 Fin3 refa114_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4272 : ~ @Equation4272 Fin3 refa114_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4275 : ~ @Equation4275 Fin3 refa114_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4284 : ~ @Equation4284 Fin3 refa114_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4291 : ~ @Equation4291 Fin3 refa114_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4314 : ~ @Equation4314 Fin3 refa114_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4320 : ~ @Equation4320 Fin3 refa114_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4396 : ~ @Equation4396 Fin3 refa114_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4398 : ~ @Equation4398 Fin3 refa114_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4399 : ~ @Equation4399 Fin3 refa114_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4433 : ~ @Equation4433 Fin3 refa114_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4435 : ~ @Equation4435 Fin3 refa114_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4436 : ~ @Equation4436 Fin3 refa114_inst.
Proof. unfold Equation4436. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4470 : ~ @Equation4470 Fin3 refa114_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4472 : ~ @Equation4472 Fin3 refa114_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4473 : ~ @Equation4473 Fin3 refa114_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4583 : ~ @Equation4583 Fin3 refa114_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4584 : ~ @Equation4584 Fin3 refa114_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4585 : ~ @Equation4585 Fin3 refa114_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4587 : ~ @Equation4587 Fin3 refa114_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4598 : ~ @Equation4598 Fin3 refa114_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4599 : ~ @Equation4599 Fin3 refa114_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4606 : ~ @Equation4606 Fin3 refa114_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4629 : ~ @Equation4629 Fin3 refa114_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

Lemma refa114_not4635 : ~ @Equation4635 Fin3 refa114_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa114_inst, refa114_op in H. discriminate H. Qed.

(** ---- refa115 (Fin3) ---- *)

Definition refa115_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa115_inst : Magma Fin3 := {| magma_op := refa115_op |}.

Lemma refa115_sat1430 : @Equation1430 Fin3 refa115_inst.
Proof. unfold Equation1430, magma_op, refa115_inst, refa115_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa115_sat3513 : @Equation3513 Fin3 refa115_inst.
Proof. unfold Equation3513, magma_op, refa115_inst, refa115_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa115_sat3523 : @Equation3523 Fin3 refa115_inst.
Proof. unfold Equation3523, magma_op, refa115_inst, refa115_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa115_sat4357 : @Equation4357 Fin3 refa115_inst.
Proof. unfold Equation4357, magma_op, refa115_inst, refa115_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa115_not1629 : ~ @Equation1629 Fin3 refa115_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_1). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not1832 : ~ @Equation1832 Fin3 refa115_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not2035 : ~ @Equation2035 Fin3 refa115_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not3253 : ~ @Equation3253 Fin3 refa115_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not3458 : ~ @Equation3458 Fin3 refa115_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not3459 : ~ @Equation3459 Fin3 refa115_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not3461 : ~ @Equation3461 Fin3 refa115_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not3462 : ~ @Equation3462 Fin3 refa115_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not3464 : ~ @Equation3464 Fin3 refa115_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not3465 : ~ @Equation3465 Fin3 refa115_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not3509 : ~ @Equation3509 Fin3 refa115_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not3518 : ~ @Equation3518 Fin3 refa115_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not3519 : ~ @Equation3519 Fin3 refa115_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not3659 : ~ @Equation3659 Fin3 refa115_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not3862 : ~ @Equation3862 Fin3 refa115_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not4065 : ~ @Equation4065 Fin3 refa115_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not4269 : ~ @Equation4269 Fin3 refa115_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not4270 : ~ @Equation4270 Fin3 refa115_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not4283 : ~ @Equation4283 Fin3 refa115_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not4284 : ~ @Equation4284 Fin3 refa115_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not4380 : ~ @Equation4380 Fin3 refa115_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not4583 : ~ @Equation4583 Fin3 refa115_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not4585 : ~ @Equation4585 Fin3 refa115_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not4598 : ~ @Equation4598 Fin3 refa115_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not4599 : ~ @Equation4599 Fin3 refa115_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

Lemma refa115_not4629 : ~ @Equation4629 Fin3 refa115_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa115_inst, refa115_op in H. discriminate H. Qed.

(** ---- refa116 (Fin3) ---- *)

Definition refa116_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa116_inst : Magma Fin3 := {| magma_op := refa116_op |}.

Lemma refa116_sat1684 : @Equation1684 Fin3 refa116_inst.
Proof. unfold Equation1684, magma_op, refa116_inst, refa116_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa116_not1654 : ~ @Equation1654 Fin3 refa116_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa116_inst, refa116_op in H. discriminate H. Qed.

(** ---- refa117 (Fin3) ---- *)

Definition refa117_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa117_inst : Magma Fin3 := {| magma_op := refa117_op |}.

Lemma refa117_sat316 : @Equation316 Fin3 refa117_inst.
Proof. unfold Equation316, magma_op, refa117_inst, refa117_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa117_sat2909 : @Equation2909 Fin3 refa117_inst.
Proof. unfold Equation2909, magma_op, refa117_inst, refa117_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa117_sat3007 : @Equation3007 Fin3 refa117_inst.
Proof. unfold Equation3007, magma_op, refa117_inst, refa117_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa117_sat3297 : @Equation3297 Fin3 refa117_inst.
Proof. unfold Equation3297, magma_op, refa117_inst, refa117_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa117_not47 : ~ @Equation47 Fin3 refa117_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not99 : ~ @Equation99 Fin3 refa117_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not151 : ~ @Equation151 Fin3 refa117_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not203 : ~ @Equation203 Fin3 refa117_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not283 : ~ @Equation283 Fin3 refa117_inst.
Proof. unfold Equation283. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not323 : ~ @Equation323 Fin3 refa117_inst.
Proof. unfold Equation323. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not411 : ~ @Equation411 Fin3 refa117_inst.
Proof. unfold Equation411. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not614 : ~ @Equation614 Fin3 refa117_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not817 : ~ @Equation817 Fin3 refa117_inst.
Proof. unfold Equation817. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1020 : ~ @Equation1020 Fin3 refa117_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1223 : ~ @Equation1223 Fin3 refa117_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1426 : ~ @Equation1426 Fin3 refa117_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1631 : ~ @Equation1631 Fin3 refa117_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1634 : ~ @Equation1634 Fin3 refa117_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1644 : ~ @Equation1644 Fin3 refa117_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1654 : ~ @Equation1654 Fin3 refa117_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1657 : ~ @Equation1657 Fin3 refa117_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1681 : ~ @Equation1681 Fin3 refa117_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1684 : ~ @Equation1684 Fin3 refa117_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1691 : ~ @Equation1691 Fin3 refa117_inst.
Proof. unfold Equation1691. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1694 : ~ @Equation1694 Fin3 refa117_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1721 : ~ @Equation1721 Fin3 refa117_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1728 : ~ @Equation1728 Fin3 refa117_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not1832 : ~ @Equation1832 Fin3 refa117_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2035 : ~ @Equation2035 Fin3 refa117_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2238 : ~ @Equation2238 Fin3 refa117_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2443 : ~ @Equation2443 Fin3 refa117_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2449 : ~ @Equation2449 Fin3 refa117_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2459 : ~ @Equation2459 Fin3 refa117_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2469 : ~ @Equation2469 Fin3 refa117_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2493 : ~ @Equation2493 Fin3 refa117_inst.
Proof. unfold Equation2493. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2496 : ~ @Equation2496 Fin3 refa117_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2506 : ~ @Equation2506 Fin3 refa117_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2530 : ~ @Equation2530 Fin3 refa117_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2533 : ~ @Equation2533 Fin3 refa117_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2540 : ~ @Equation2540 Fin3 refa117_inst.
Proof. unfold Equation2540. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2543 : ~ @Equation2543 Fin3 refa117_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2644 : ~ @Equation2644 Fin3 refa117_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2849 : ~ @Equation2849 Fin3 refa117_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2852 : ~ @Equation2852 Fin3 refa117_inst.
Proof. unfold Equation2852. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2853 : ~ @Equation2853 Fin3 refa117_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2855 : ~ @Equation2855 Fin3 refa117_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2862 : ~ @Equation2862 Fin3 refa117_inst.
Proof. unfold Equation2862. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2863 : ~ @Equation2863 Fin3 refa117_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2865 : ~ @Equation2865 Fin3 refa117_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2875 : ~ @Equation2875 Fin3 refa117_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2902 : ~ @Equation2902 Fin3 refa117_inst.
Proof. unfold Equation2902. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2912 : ~ @Equation2912 Fin3 refa117_inst.
Proof. unfold Equation2912. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2939 : ~ @Equation2939 Fin3 refa117_inst.
Proof. unfold Equation2939. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not2949 : ~ @Equation2949 Fin3 refa117_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3050 : ~ @Equation3050 Fin3 refa117_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3255 : ~ @Equation3255 Fin3 refa117_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3259 : ~ @Equation3259 Fin3 refa117_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3271 : ~ @Equation3271 Fin3 refa117_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3281 : ~ @Equation3281 Fin3 refa117_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3308 : ~ @Equation3308 Fin3 refa117_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3309 : ~ @Equation3309 Fin3 refa117_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3315 : ~ @Equation3315 Fin3 refa117_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3316 : ~ @Equation3316 Fin3 refa117_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3319 : ~ @Equation3319 Fin3 refa117_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3343 : ~ @Equation3343 Fin3 refa117_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3346 : ~ @Equation3346 Fin3 refa117_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3353 : ~ @Equation3353 Fin3 refa117_inst.
Proof. unfold Equation3353. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3456 : ~ @Equation3456 Fin3 refa117_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3661 : ~ @Equation3661 Fin3 refa117_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3667 : ~ @Equation3667 Fin3 refa117_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3687 : ~ @Equation3687 Fin3 refa117_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3712 : ~ @Equation3712 Fin3 refa117_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3722 : ~ @Equation3722 Fin3 refa117_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3725 : ~ @Equation3725 Fin3 refa117_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3749 : ~ @Equation3749 Fin3 refa117_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3752 : ~ @Equation3752 Fin3 refa117_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3759 : ~ @Equation3759 Fin3 refa117_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not3862 : ~ @Equation3862 Fin3 refa117_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4065 : ~ @Equation4065 Fin3 refa117_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4269 : ~ @Equation4269 Fin3 refa117_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4273 : ~ @Equation4273 Fin3 refa117_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4275 : ~ @Equation4275 Fin3 refa117_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4283 : ~ @Equation4283 Fin3 refa117_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4284 : ~ @Equation4284 Fin3 refa117_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4291 : ~ @Equation4291 Fin3 refa117_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4314 : ~ @Equation4314 Fin3 refa117_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4320 : ~ @Equation4320 Fin3 refa117_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4321 : ~ @Equation4321 Fin3 refa117_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4380 : ~ @Equation4380 Fin3 refa117_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4584 : ~ @Equation4584 Fin3 refa117_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4585 : ~ @Equation4585 Fin3 refa117_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4587 : ~ @Equation4587 Fin3 refa117_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4598 : ~ @Equation4598 Fin3 refa117_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4599 : ~ @Equation4599 Fin3 refa117_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4606 : ~ @Equation4606 Fin3 refa117_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4635 : ~ @Equation4635 Fin3 refa117_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

Lemma refa117_not4658 : ~ @Equation4658 Fin3 refa117_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa117_inst, refa117_op in H. discriminate H. Qed.

(** ---- refa118 (Fin3) ---- *)

Definition refa118_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa118_inst : Magma Fin3 := {| magma_op := refa118_op |}.

Lemma refa118_sat3488 : @Equation3488 Fin3 refa118_inst.
Proof. unfold Equation3488, magma_op, refa118_inst, refa118_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa118_sat4138 : @Equation4138 Fin3 refa118_inst.
Proof. unfold Equation4138, magma_op, refa118_inst, refa118_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa118_not3253 : ~ @Equation3253 Fin3 refa118_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa118_inst, refa118_op in H. discriminate H. Qed.

Lemma refa118_not3461 : ~ @Equation3461 Fin3 refa118_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa118_inst, refa118_op in H. discriminate H. Qed.

Lemma refa118_not3475 : ~ @Equation3475 Fin3 refa118_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa118_inst, refa118_op in H. discriminate H. Qed.

Lemma refa118_not3664 : ~ @Equation3664 Fin3 refa118_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa118_inst, refa118_op in H. discriminate H. Qed.

Lemma refa118_not3668 : ~ @Equation3668 Fin3 refa118_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa118_inst, refa118_op in H. discriminate H. Qed.

Lemma refa118_not3674 : ~ @Equation3674 Fin3 refa118_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa118_inst, refa118_op in H. discriminate H. Qed.

Lemma refa118_not3678 : ~ @Equation3678 Fin3 refa118_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa118_inst, refa118_op in H. discriminate H. Qed.

Lemma refa118_not4131 : ~ @Equation4131 Fin3 refa118_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa118_inst, refa118_op in H. discriminate H. Qed.

Lemma refa118_not4269 : ~ @Equation4269 Fin3 refa118_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa118_inst, refa118_op in H. discriminate H. Qed.

Lemma refa118_not4631 : ~ @Equation4631 Fin3 refa118_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa118_inst, refa118_op in H. discriminate H. Qed.

(** ---- refa119 (Fin3) ---- *)

Definition refa119_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa119_inst : Magma Fin3 := {| magma_op := refa119_op |}.

Lemma refa119_sat4040 : @Equation4040 Fin3 refa119_inst.
Proof. unfold Equation4040, magma_op, refa119_inst, refa119_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa119_sat4645 : @Equation4645 Fin3 refa119_inst.
Proof. unfold Equation4645, magma_op, refa119_inst, refa119_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa119_not4065 : ~ @Equation4065 Fin3 refa119_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_0). unfold magma_op, refa119_inst, refa119_op in H. discriminate H. Qed.

(** ---- refa12 (Fin7) ---- *)

Definition refa12_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_1 | F7_0, F7_2 => F7_2 | F7_0, F7_3 => F7_3 | F7_0, F7_4 => F7_4 | F7_0, F7_5 => F7_5 | F7_0, F7_6 => F7_6
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_3 | F7_1, F7_2 => F7_1 | F7_1, F7_3 => F7_4 | F7_1, F7_4 => F7_5 | F7_1, F7_5 => F7_6 | F7_1, F7_6 => F7_0
  | F7_2, F7_0 => F7_4 | F7_2, F7_1 => F7_6 | F7_2, F7_2 => F7_5 | F7_2, F7_3 => F7_0 | F7_2, F7_4 => F7_2 | F7_2, F7_5 => F7_1 | F7_2, F7_6 => F7_3
  | F7_3, F7_0 => F7_5 | F7_3, F7_1 => F7_0 | F7_3, F7_2 => F7_6 | F7_3, F7_3 => F7_2 | F7_3, F7_4 => F7_1 | F7_3, F7_5 => F7_3 | F7_3, F7_6 => F7_4
  | F7_4, F7_0 => F7_1 | F7_4, F7_1 => F7_4 | F7_4, F7_2 => F7_3 | F7_4, F7_3 => F7_5 | F7_4, F7_4 => F7_6 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_2
  | F7_5, F7_0 => F7_6 | F7_5, F7_1 => F7_2 | F7_5, F7_2 => F7_0 | F7_5, F7_3 => F7_1 | F7_5, F7_4 => F7_3 | F7_5, F7_5 => F7_4 | F7_5, F7_6 => F7_5
  | F7_6, F7_0 => F7_3 | F7_6, F7_1 => F7_5 | F7_6, F7_2 => F7_4 | F7_6, F7_3 => F7_6 | F7_6, F7_4 => F7_0 | F7_6, F7_5 => F7_2 | F7_6, F7_6 => F7_1
  end.

#[local] Instance refa12_inst : Magma Fin7 := {| magma_op := refa12_op |}.

Lemma refa12_sat677 : @Equation677 Fin7 refa12_inst.
Proof. unfold Equation677, magma_op, refa12_inst, refa12_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa12_sat907 : @Equation907 Fin7 refa12_inst.
Proof. unfold Equation907, magma_op, refa12_inst, refa12_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa12_sat1489 : @Equation1489 Fin7 refa12_inst.
Proof. unfold Equation1489, magma_op, refa12_inst, refa12_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa12_sat1516 : @Equation1516 Fin7 refa12_inst.
Proof. unfold Equation1516, magma_op, refa12_inst, refa12_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa12_not47 : ~ @Equation47 Fin7 refa12_inst.
Proof. unfold Equation47. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not99 : ~ @Equation99 Fin7 refa12_inst.
Proof. unfold Equation99. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not151 : ~ @Equation151 Fin7 refa12_inst.
Proof. unfold Equation151. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not203 : ~ @Equation203 Fin7 refa12_inst.
Proof. unfold Equation203. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not261 : ~ @Equation261 Fin7 refa12_inst.
Proof. unfold Equation261. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not274 : ~ @Equation274 Fin7 refa12_inst.
Proof. unfold Equation274. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not411 : ~ @Equation411 Fin7 refa12_inst.
Proof. unfold Equation411. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not619 : ~ @Equation619 Fin7 refa12_inst.
Proof. unfold Equation619. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not620 : ~ @Equation620 Fin7 refa12_inst.
Proof. unfold Equation620. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not622 : ~ @Equation622 Fin7 refa12_inst.
Proof. unfold Equation622. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not629 : ~ @Equation629 Fin7 refa12_inst.
Proof. unfold Equation629. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not630 : ~ @Equation630 Fin7 refa12_inst.
Proof. unfold Equation630. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not632 : ~ @Equation632 Fin7 refa12_inst.
Proof. unfold Equation632. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not633 : ~ @Equation633 Fin7 refa12_inst.
Proof. unfold Equation633. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not639 : ~ @Equation639 Fin7 refa12_inst.
Proof. unfold Equation639. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not642 : ~ @Equation642 Fin7 refa12_inst.
Proof. unfold Equation642. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not643 : ~ @Equation643 Fin7 refa12_inst.
Proof. unfold Equation643. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not667 : ~ @Equation667 Fin7 refa12_inst.
Proof. unfold Equation667. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not669 : ~ @Equation669 Fin7 refa12_inst.
Proof. unfold Equation669. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not670 : ~ @Equation670 Fin7 refa12_inst.
Proof. unfold Equation670. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not676 : ~ @Equation676 Fin7 refa12_inst.
Proof. unfold Equation676. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not679 : ~ @Equation679 Fin7 refa12_inst.
Proof. unfold Equation679. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not680 : ~ @Equation680 Fin7 refa12_inst.
Proof. unfold Equation680. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not704 : ~ @Equation704 Fin7 refa12_inst.
Proof. unfold Equation704. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not706 : ~ @Equation706 Fin7 refa12_inst.
Proof. unfold Equation706. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not707 : ~ @Equation707 Fin7 refa12_inst.
Proof. unfold Equation707. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not819 : ~ @Equation819 Fin7 refa12_inst.
Proof. unfold Equation819. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not825 : ~ @Equation825 Fin7 refa12_inst.
Proof. unfold Equation825. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not826 : ~ @Equation826 Fin7 refa12_inst.
Proof. unfold Equation826. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not832 : ~ @Equation832 Fin7 refa12_inst.
Proof. unfold Equation832. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not833 : ~ @Equation833 Fin7 refa12_inst.
Proof. unfold Equation833. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not835 : ~ @Equation835 Fin7 refa12_inst.
Proof. unfold Equation835. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not842 : ~ @Equation842 Fin7 refa12_inst.
Proof. unfold Equation842. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not845 : ~ @Equation845 Fin7 refa12_inst.
Proof. unfold Equation845. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not846 : ~ @Equation846 Fin7 refa12_inst.
Proof. unfold Equation846. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not870 : ~ @Equation870 Fin7 refa12_inst.
Proof. unfold Equation870. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not872 : ~ @Equation872 Fin7 refa12_inst.
Proof. unfold Equation872. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not873 : ~ @Equation873 Fin7 refa12_inst.
Proof. unfold Equation873. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not879 : ~ @Equation879 Fin7 refa12_inst.
Proof. unfold Equation879. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not882 : ~ @Equation882 Fin7 refa12_inst.
Proof. unfold Equation882. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not883 : ~ @Equation883 Fin7 refa12_inst.
Proof. unfold Equation883. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not906 : ~ @Equation906 Fin7 refa12_inst.
Proof. unfold Equation906. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not917 : ~ @Equation917 Fin7 refa12_inst.
Proof. unfold Equation917. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1020 : ~ @Equation1020 Fin7 refa12_inst.
Proof. unfold Equation1020. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1223 : ~ @Equation1223 Fin7 refa12_inst.
Proof. unfold Equation1223. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1427 : ~ @Equation1427 Fin7 refa12_inst.
Proof. unfold Equation1427. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1428 : ~ @Equation1428 Fin7 refa12_inst.
Proof. unfold Equation1428. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1429 : ~ @Equation1429 Fin7 refa12_inst.
Proof. unfold Equation1429. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1431 : ~ @Equation1431 Fin7 refa12_inst.
Proof. unfold Equation1431. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1434 : ~ @Equation1434 Fin7 refa12_inst.
Proof. unfold Equation1434. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1435 : ~ @Equation1435 Fin7 refa12_inst.
Proof. unfold Equation1435. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1441 : ~ @Equation1441 Fin7 refa12_inst.
Proof. unfold Equation1441. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1445 : ~ @Equation1445 Fin7 refa12_inst.
Proof. unfold Equation1445. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1451 : ~ @Equation1451 Fin7 refa12_inst.
Proof. unfold Equation1451. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1454 : ~ @Equation1454 Fin7 refa12_inst.
Proof. unfold Equation1454. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1478 : ~ @Equation1478 Fin7 refa12_inst.
Proof. unfold Equation1478. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1479 : ~ @Equation1479 Fin7 refa12_inst.
Proof. unfold Equation1479. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1488 : ~ @Equation1488 Fin7 refa12_inst.
Proof. unfold Equation1488. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1515 : ~ @Equation1515 Fin7 refa12_inst.
Proof. unfold Equation1515. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1519 : ~ @Equation1519 Fin7 refa12_inst.
Proof. unfold Equation1519. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1525 : ~ @Equation1525 Fin7 refa12_inst.
Proof. unfold Equation1525. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1629 : ~ @Equation1629 Fin7 refa12_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not1832 : ~ @Equation1832 Fin7 refa12_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not2035 : ~ @Equation2035 Fin7 refa12_inst.
Proof. unfold Equation2035. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not2238 : ~ @Equation2238 Fin7 refa12_inst.
Proof. unfold Equation2238. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not2441 : ~ @Equation2441 Fin7 refa12_inst.
Proof. unfold Equation2441. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not2644 : ~ @Equation2644 Fin7 refa12_inst.
Proof. unfold Equation2644. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not2847 : ~ @Equation2847 Fin7 refa12_inst.
Proof. unfold Equation2847. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not3050 : ~ @Equation3050 Fin7 refa12_inst.
Proof. unfold Equation3050. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not3253 : ~ @Equation3253 Fin7 refa12_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not3456 : ~ @Equation3456 Fin7 refa12_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not3659 : ~ @Equation3659 Fin7 refa12_inst.
Proof. unfold Equation3659. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not3862 : ~ @Equation3862 Fin7 refa12_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4065 : ~ @Equation4065 Fin7 refa12_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4268 : ~ @Equation4268 Fin7 refa12_inst.
Proof. unfold Equation4268. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4269 : ~ @Equation4269 Fin7 refa12_inst.
Proof. unfold Equation4269. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4270 : ~ @Equation4270 Fin7 refa12_inst.
Proof. unfold Equation4270. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4272 : ~ @Equation4272 Fin7 refa12_inst.
Proof. unfold Equation4272. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4273 : ~ @Equation4273 Fin7 refa12_inst.
Proof. unfold Equation4273. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4275 : ~ @Equation4275 Fin7 refa12_inst.
Proof. unfold Equation4275. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4276 : ~ @Equation4276 Fin7 refa12_inst.
Proof. unfold Equation4276. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4290 : ~ @Equation4290 Fin7 refa12_inst.
Proof. unfold Equation4290. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4291 : ~ @Equation4291 Fin7 refa12_inst.
Proof. unfold Equation4291. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4321 : ~ @Equation4321 Fin7 refa12_inst.
Proof. unfold Equation4321. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4343 : ~ @Equation4343 Fin7 refa12_inst.
Proof. unfold Equation4343. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4380 : ~ @Equation4380 Fin7 refa12_inst.
Proof. unfold Equation4380. intro H. specialize (H F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4583 : ~ @Equation4583 Fin7 refa12_inst.
Proof. unfold Equation4583. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4584 : ~ @Equation4584 Fin7 refa12_inst.
Proof. unfold Equation4584. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4585 : ~ @Equation4585 Fin7 refa12_inst.
Proof. unfold Equation4585. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4587 : ~ @Equation4587 Fin7 refa12_inst.
Proof. unfold Equation4587. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4588 : ~ @Equation4588 Fin7 refa12_inst.
Proof. unfold Equation4588. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4590 : ~ @Equation4590 Fin7 refa12_inst.
Proof. unfold Equation4590. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4598 : ~ @Equation4598 Fin7 refa12_inst.
Proof. unfold Equation4598. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4605 : ~ @Equation4605 Fin7 refa12_inst.
Proof. unfold Equation4605. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4606 : ~ @Equation4606 Fin7 refa12_inst.
Proof. unfold Equation4606. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4608 : ~ @Equation4608 Fin7 refa12_inst.
Proof. unfold Equation4608. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4629 : ~ @Equation4629 Fin7 refa12_inst.
Proof. unfold Equation4629. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4635 : ~ @Equation4635 Fin7 refa12_inst.
Proof. unfold Equation4635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4636 : ~ @Equation4636 Fin7 refa12_inst.
Proof. unfold Equation4636. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

Lemma refa12_not4658 : ~ @Equation4658 Fin7 refa12_inst.
Proof. unfold Equation4658. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa12_inst, refa12_op in H. discriminate H. Qed.

(** ---- refa120 (Fin3) ---- *)

Definition refa120_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa120_inst : Magma Fin3 := {| magma_op := refa120_op |}.

Lemma refa120_sat2052 : @Equation2052 Fin3 refa120_inst.
Proof. unfold Equation2052, magma_op, refa120_inst, refa120_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa120_sat3466 : @Equation3466 Fin3 refa120_inst.
Proof. unfold Equation3466, magma_op, refa120_inst, refa120_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa120_not255 : ~ @Equation255 Fin3 refa120_inst.
Proof. unfold Equation255. intro H. specialize (H F3_1). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not3459 : ~ @Equation3459 Fin3 refa120_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not3467 : ~ @Equation3467 Fin3 refa120_inst.
Proof. unfold Equation3467. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not3468 : ~ @Equation3468 Fin3 refa120_inst.
Proof. unfold Equation3468. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not3521 : ~ @Equation3521 Fin3 refa120_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not3522 : ~ @Equation3522 Fin3 refa120_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not3659 : ~ @Equation3659 Fin3 refa120_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_1). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not3862 : ~ @Equation3862 Fin3 refa120_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not4065 : ~ @Equation4065 Fin3 refa120_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not4269 : ~ @Equation4269 Fin3 refa120_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not4270 : ~ @Equation4270 Fin3 refa120_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not4283 : ~ @Equation4283 Fin3 refa120_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not4284 : ~ @Equation4284 Fin3 refa120_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not4380 : ~ @Equation4380 Fin3 refa120_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not4583 : ~ @Equation4583 Fin3 refa120_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not4598 : ~ @Equation4598 Fin3 refa120_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

Lemma refa120_not4631 : ~ @Equation4631 Fin3 refa120_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa120_inst, refa120_op in H. discriminate H. Qed.

(** ---- refa121 (Fin3) ---- *)

Definition refa121_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa121_inst : Magma Fin3 := {| magma_op := refa121_op |}.

Lemma refa121_sat4405 : @Equation4405 Fin3 refa121_inst.
Proof. unfold Equation4405, magma_op, refa121_inst, refa121_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa121_not4283 : ~ @Equation4283 Fin3 refa121_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa121_inst, refa121_op in H. discriminate H. Qed.

Lemma refa121_not4398 : ~ @Equation4398 Fin3 refa121_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa121_inst, refa121_op in H. discriminate H. Qed.

Lemma refa121_not4442 : ~ @Equation4442 Fin3 refa121_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa121_inst, refa121_op in H. discriminate H. Qed.

Lemma refa121_not4482 : ~ @Equation4482 Fin3 refa121_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa121_inst, refa121_op in H. discriminate H. Qed.

Lemma refa121_not4635 : ~ @Equation4635 Fin3 refa121_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa121_inst, refa121_op in H. discriminate H. Qed.

(** ---- refa122 (Fin3) ---- *)

Definition refa122_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa122_inst : Magma Fin3 := {| magma_op := refa122_op |}.

Lemma refa122_sat372 : @Equation372 Fin3 refa122_inst.
Proof. unfold Equation372, magma_op, refa122_inst, refa122_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa122_sat4101 : @Equation4101 Fin3 refa122_inst.
Proof. unfold Equation4101, magma_op, refa122_inst, refa122_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa122_not3253 : ~ @Equation3253 Fin3 refa122_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3456 : ~ @Equation3456 Fin3 refa122_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3664 : ~ @Equation3664 Fin3 refa122_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3667 : ~ @Equation3667 Fin3 refa122_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3668 : ~ @Equation3668 Fin3 refa122_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3674 : ~ @Equation3674 Fin3 refa122_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3675 : ~ @Equation3675 Fin3 refa122_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3678 : ~ @Equation3678 Fin3 refa122_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3712 : ~ @Equation3712 Fin3 refa122_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3714 : ~ @Equation3714 Fin3 refa122_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3721 : ~ @Equation3721 Fin3 refa122_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3722 : ~ @Equation3722 Fin3 refa122_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3724 : ~ @Equation3724 Fin3 refa122_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3725 : ~ @Equation3725 Fin3 refa122_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not3862 : ~ @Equation3862 Fin3 refa122_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4071 : ~ @Equation4071 Fin3 refa122_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4083 : ~ @Equation4083 Fin3 refa122_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4118 : ~ @Equation4118 Fin3 refa122_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4120 : ~ @Equation4120 Fin3 refa122_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4121 : ~ @Equation4121 Fin3 refa122_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4127 : ~ @Equation4127 Fin3 refa122_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4130 : ~ @Equation4130 Fin3 refa122_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4131 : ~ @Equation4131 Fin3 refa122_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4155 : ~ @Equation4155 Fin3 refa122_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4165 : ~ @Equation4165 Fin3 refa122_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4268 : ~ @Equation4268 Fin3 refa122_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4269 : ~ @Equation4269 Fin3 refa122_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4272 : ~ @Equation4272 Fin3 refa122_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4273 : ~ @Equation4273 Fin3 refa122_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4276 : ~ @Equation4276 Fin3 refa122_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4284 : ~ @Equation4284 Fin3 refa122_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4293 : ~ @Equation4293 Fin3 refa122_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4314 : ~ @Equation4314 Fin3 refa122_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4320 : ~ @Equation4320 Fin3 refa122_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4321 : ~ @Equation4321 Fin3 refa122_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4343 : ~ @Equation4343 Fin3 refa122_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4380 : ~ @Equation4380 Fin3 refa122_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4584 : ~ @Equation4584 Fin3 refa122_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4588 : ~ @Equation4588 Fin3 refa122_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4598 : ~ @Equation4598 Fin3 refa122_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4606 : ~ @Equation4606 Fin3 refa122_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4629 : ~ @Equation4629 Fin3 refa122_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4635 : ~ @Equation4635 Fin3 refa122_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4636 : ~ @Equation4636 Fin3 refa122_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

Lemma refa122_not4684 : ~ @Equation4684 Fin3 refa122_inst.
Proof. unfold Equation4684. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa122_inst, refa122_op in H. discriminate H. Qed.

(** ---- refa123 (Fin3) ---- *)

Definition refa123_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa123_inst : Magma Fin3 := {| magma_op := refa123_op |}.

Lemma refa123_sat437 : @Equation437 Fin3 refa123_inst.
Proof. unfold Equation437, magma_op, refa123_inst, refa123_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa123_sat1042 : @Equation1042 Fin3 refa123_inst.
Proof. unfold Equation1042, magma_op, refa123_inst, refa123_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa123_sat1267 : @Equation1267 Fin3 refa123_inst.
Proof. unfold Equation1267, magma_op, refa123_inst, refa123_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa123_not108 : ~ @Equation108 Fin3 refa123_inst.
Proof. unfold Equation108. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not413 : ~ @Equation413 Fin3 refa123_inst.
Proof. unfold Equation413. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not819 : ~ @Equation819 Fin3 refa123_inst.
Proof. unfold Equation819. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not832 : ~ @Equation832 Fin3 refa123_inst.
Proof. unfold Equation832. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not833 : ~ @Equation833 Fin3 refa123_inst.
Proof. unfold Equation833. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not836 : ~ @Equation836 Fin3 refa123_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not845 : ~ @Equation845 Fin3 refa123_inst.
Proof. unfold Equation845. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not1046 : ~ @Equation1046 Fin3 refa123_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not1053 : ~ @Equation1053 Fin3 refa123_inst.
Proof. unfold Equation1053. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not1224 : ~ @Equation1224 Fin3 refa123_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not1229 : ~ @Equation1229 Fin3 refa123_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not1242 : ~ @Equation1242 Fin3 refa123_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not1249 : ~ @Equation1249 Fin3 refa123_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not1851 : ~ @Equation1851 Fin3 refa123_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not3255 : ~ @Equation3255 Fin3 refa123_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not3279 : ~ @Equation3279 Fin3 refa123_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not3306 : ~ @Equation3306 Fin3 refa123_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not3318 : ~ @Equation3318 Fin3 refa123_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not3660 : ~ @Equation3660 Fin3 refa123_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not3661 : ~ @Equation3661 Fin3 refa123_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not3685 : ~ @Equation3685 Fin3 refa123_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not3687 : ~ @Equation3687 Fin3 refa123_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not3724 : ~ @Equation3724 Fin3 refa123_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not3865 : ~ @Equation3865 Fin3 refa123_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not3881 : ~ @Equation3881 Fin3 refa123_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not3888 : ~ @Equation3888 Fin3 refa123_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not4066 : ~ @Equation4066 Fin3 refa123_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not4071 : ~ @Equation4071 Fin3 refa123_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not4084 : ~ @Equation4084 Fin3 refa123_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not4091 : ~ @Equation4091 Fin3 refa123_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not4293 : ~ @Equation4293 Fin3 refa123_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not4314 : ~ @Equation4314 Fin3 refa123_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not4583 : ~ @Equation4583 Fin3 refa123_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not4591 : ~ @Equation4591 Fin3 refa123_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not4598 : ~ @Equation4598 Fin3 refa123_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not4608 : ~ @Equation4608 Fin3 refa123_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not4636 : ~ @Equation4636 Fin3 refa123_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

Lemma refa123_not4647 : ~ @Equation4647 Fin3 refa123_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa123_inst, refa123_op in H. discriminate H. Qed.

(** ---- refa124 (Fin3) ---- *)

Definition refa124_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa124_inst : Magma Fin3 := {| magma_op := refa124_op |}.

Lemma refa124_sat2998 : @Equation2998 Fin3 refa124_inst.
Proof. unfold Equation2998, magma_op, refa124_inst, refa124_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa124_sat3214 : @Equation3214 Fin3 refa124_inst.
Proof. unfold Equation3214, magma_op, refa124_inst, refa124_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa124_not3481 : ~ @Equation3481 Fin3 refa124_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa124_inst, refa124_op in H. discriminate H. Qed.

Lemma refa124_not3677 : ~ @Equation3677 Fin3 refa124_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa124_inst, refa124_op in H. discriminate H. Qed.

Lemma refa124_not4512 : ~ @Equation4512 Fin3 refa124_inst.
Proof. unfold Equation4512. intro H. specialize (H F3_2 F3_2 F3_1). unfold magma_op, refa124_inst, refa124_op in H. discriminate H. Qed.

Lemma refa124_not4525 : ~ @Equation4525 Fin3 refa124_inst.
Proof. unfold Equation4525. intro H. specialize (H F3_2 F3_2 F3_1). unfold magma_op, refa124_inst, refa124_op in H. discriminate H. Qed.

(** ---- refa125 (Fin3) ---- *)

Definition refa125_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa125_inst : Magma Fin3 := {| magma_op := refa125_op |}.

Lemma refa125_sat2088 : @Equation2088 Fin3 refa125_inst.
Proof. unfold Equation2088, magma_op, refa125_inst, refa125_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa125_not1426 : ~ @Equation1426 Fin3 refa125_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_2). unfold magma_op, refa125_inst, refa125_op in H. discriminate H. Qed.

Lemma refa125_not1629 : ~ @Equation1629 Fin3 refa125_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa125_inst, refa125_op in H. discriminate H. Qed.

Lemma refa125_not1832 : ~ @Equation1832 Fin3 refa125_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa125_inst, refa125_op in H. discriminate H. Qed.

Lemma refa125_not2053 : ~ @Equation2053 Fin3 refa125_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa125_inst, refa125_op in H. discriminate H. Qed.

Lemma refa125_not2124 : ~ @Equation2124 Fin3 refa125_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa125_inst, refa125_op in H. discriminate H. Qed.

Lemma refa125_not3456 : ~ @Equation3456 Fin3 refa125_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa125_inst, refa125_op in H. discriminate H. Qed.

Lemma refa125_not3862 : ~ @Equation3862 Fin3 refa125_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa125_inst, refa125_op in H. discriminate H. Qed.

(** ---- refa126 (Fin3) ---- *)

Definition refa126_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa126_inst : Magma Fin3 := {| magma_op := refa126_op |}.

Lemma refa126_sat1056 : @Equation1056 Fin3 refa126_inst.
Proof. unfold Equation1056, magma_op, refa126_inst, refa126_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa126_not99 : ~ @Equation99 Fin3 refa126_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not359 : ~ @Equation359 Fin3 refa126_inst.
Proof. unfold Equation359. intro H. specialize (H F3_2). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not413 : ~ @Equation413 Fin3 refa126_inst.
Proof. unfold Equation413. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not437 : ~ @Equation437 Fin3 refa126_inst.
Proof. unfold Equation437. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not843 : ~ @Equation843 Fin3 refa126_inst.
Proof. unfold Equation843. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not1039 : ~ @Equation1039 Fin3 refa126_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not1229 : ~ @Equation1229 Fin3 refa126_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not1231 : ~ @Equation1231 Fin3 refa126_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not1239 : ~ @Equation1239 Fin3 refa126_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not1241 : ~ @Equation1241 Fin3 refa126_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not1242 : ~ @Equation1242 Fin3 refa126_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not1249 : ~ @Equation1249 Fin3 refa126_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not1251 : ~ @Equation1251 Fin3 refa126_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not3255 : ~ @Equation3255 Fin3 refa126_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not3316 : ~ @Equation3316 Fin3 refa126_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not3724 : ~ @Equation3724 Fin3 refa126_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not3925 : ~ @Equation3925 Fin3 refa126_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

Lemma refa126_not4598 : ~ @Equation4598 Fin3 refa126_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa126_inst, refa126_op in H. discriminate H. Qed.

(** ---- refa127 (Fin3) ---- *)

Definition refa127_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa127_inst : Magma Fin3 := {| magma_op := refa127_op |}.

Lemma refa127_sat3478 : @Equation3478 Fin3 refa127_inst.
Proof. unfold Equation3478, magma_op, refa127_inst, refa127_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa127_sat3683 : @Equation3683 Fin3 refa127_inst.
Proof. unfold Equation3683, magma_op, refa127_inst, refa127_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa127_sat4485 : @Equation4485 Fin3 refa127_inst.
Proof. unfold Equation4485, magma_op, refa127_inst, refa127_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa127_not307 : ~ @Equation307 Fin3 refa127_inst.
Proof. unfold Equation307. intro H. specialize (H F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3255 : ~ @Equation3255 Fin3 refa127_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3258 : ~ @Equation3258 Fin3 refa127_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3259 : ~ @Equation3259 Fin3 refa127_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3261 : ~ @Equation3261 Fin3 refa127_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3262 : ~ @Equation3262 Fin3 refa127_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3268 : ~ @Equation3268 Fin3 refa127_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3269 : ~ @Equation3269 Fin3 refa127_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3271 : ~ @Equation3271 Fin3 refa127_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3272 : ~ @Equation3272 Fin3 refa127_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3279 : ~ @Equation3279 Fin3 refa127_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3281 : ~ @Equation3281 Fin3 refa127_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3306 : ~ @Equation3306 Fin3 refa127_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3309 : ~ @Equation3309 Fin3 refa127_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3316 : ~ @Equation3316 Fin3 refa127_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3459 : ~ @Equation3459 Fin3 refa127_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3474 : ~ @Equation3474 Fin3 refa127_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3481 : ~ @Equation3481 Fin3 refa127_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3484 : ~ @Equation3484 Fin3 refa127_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3509 : ~ @Equation3509 Fin3 refa127_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3512 : ~ @Equation3512 Fin3 refa127_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3519 : ~ @Equation3519 Fin3 refa127_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3522 : ~ @Equation3522 Fin3 refa127_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3712 : ~ @Equation3712 Fin3 refa127_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3722 : ~ @Equation3722 Fin3 refa127_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3725 : ~ @Equation3725 Fin3 refa127_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3749 : ~ @Equation3749 Fin3 refa127_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3759 : ~ @Equation3759 Fin3 refa127_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not3862 : ~ @Equation3862 Fin3 refa127_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4065 : ~ @Equation4065 Fin3 refa127_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4268 : ~ @Equation4268 Fin3 refa127_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4269 : ~ @Equation4269 Fin3 refa127_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4272 : ~ @Equation4272 Fin3 refa127_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4273 : ~ @Equation4273 Fin3 refa127_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4275 : ~ @Equation4275 Fin3 refa127_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4276 : ~ @Equation4276 Fin3 refa127_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4283 : ~ @Equation4283 Fin3 refa127_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4284 : ~ @Equation4284 Fin3 refa127_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4290 : ~ @Equation4290 Fin3 refa127_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4291 : ~ @Equation4291 Fin3 refa127_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4293 : ~ @Equation4293 Fin3 refa127_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4314 : ~ @Equation4314 Fin3 refa127_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4320 : ~ @Equation4320 Fin3 refa127_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4343 : ~ @Equation4343 Fin3 refa127_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4396 : ~ @Equation4396 Fin3 refa127_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4398 : ~ @Equation4398 Fin3 refa127_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4399 : ~ @Equation4399 Fin3 refa127_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4405 : ~ @Equation4405 Fin3 refa127_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4406 : ~ @Equation4406 Fin3 refa127_inst.
Proof. unfold Equation4406. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4408 : ~ @Equation4408 Fin3 refa127_inst.
Proof. unfold Equation4408. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4433 : ~ @Equation4433 Fin3 refa127_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4435 : ~ @Equation4435 Fin3 refa127_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4442 : ~ @Equation4442 Fin3 refa127_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4445 : ~ @Equation4445 Fin3 refa127_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4470 : ~ @Equation4470 Fin3 refa127_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4473 : ~ @Equation4473 Fin3 refa127_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4480 : ~ @Equation4480 Fin3 refa127_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4583 : ~ @Equation4583 Fin3 refa127_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4585 : ~ @Equation4585 Fin3 refa127_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4588 : ~ @Equation4588 Fin3 refa127_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4591 : ~ @Equation4591 Fin3 refa127_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4598 : ~ @Equation4598 Fin3 refa127_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4605 : ~ @Equation4605 Fin3 refa127_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4608 : ~ @Equation4608 Fin3 refa127_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4629 : ~ @Equation4629 Fin3 refa127_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4636 : ~ @Equation4636 Fin3 refa127_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

Lemma refa127_not4658 : ~ @Equation4658 Fin3 refa127_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa127_inst, refa127_op in H. discriminate H. Qed.

(** ---- refa128 (Fin3) ---- *)

Definition refa128_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa128_inst : Magma Fin3 := {| magma_op := refa128_op |}.

Lemma refa128_sat1251 : @Equation1251 Fin3 refa128_inst.
Proof. unfold Equation1251, magma_op, refa128_inst, refa128_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa128_not99 : ~ @Equation99 Fin3 refa128_inst.
Proof. unfold Equation99. intro H. specialize (H F3_2). unfold magma_op, refa128_inst, refa128_op in H. discriminate H. Qed.

Lemma refa128_not817 : ~ @Equation817 Fin3 refa128_inst.
Proof. unfold Equation817. intro H. specialize (H F3_2). unfold magma_op, refa128_inst, refa128_op in H. discriminate H. Qed.

Lemma refa128_not1049 : ~ @Equation1049 Fin3 refa128_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa128_inst, refa128_op in H. discriminate H. Qed.

Lemma refa128_not1238 : ~ @Equation1238 Fin3 refa128_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa128_inst, refa128_op in H. discriminate H. Qed.

Lemma refa128_not1239 : ~ @Equation1239 Fin3 refa128_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa128_inst, refa128_op in H. discriminate H. Qed.

Lemma refa128_not1241 : ~ @Equation1241 Fin3 refa128_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa128_inst, refa128_op in H. discriminate H. Qed.

Lemma refa128_not1242 : ~ @Equation1242 Fin3 refa128_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa128_inst, refa128_op in H. discriminate H. Qed.

Lemma refa128_not1248 : ~ @Equation1248 Fin3 refa128_inst.
Proof. unfold Equation1248. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa128_inst, refa128_op in H. discriminate H. Qed.

Lemma refa128_not1249 : ~ @Equation1249 Fin3 refa128_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa128_inst, refa128_op in H. discriminate H. Qed.

Lemma refa128_not1252 : ~ @Equation1252 Fin3 refa128_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa128_inst, refa128_op in H. discriminate H. Qed.

Lemma refa128_not4598 : ~ @Equation4598 Fin3 refa128_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa128_inst, refa128_op in H. discriminate H. Qed.

(** ---- refa129 (Fin3) ---- *)

Definition refa129_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa129_inst : Magma Fin3 := {| magma_op := refa129_op |}.

Lemma refa129_sat1885 : @Equation1885 Fin3 refa129_inst.
Proof. unfold Equation1885, magma_op, refa129_inst, refa129_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa129_sat2088 : @Equation2088 Fin3 refa129_inst.
Proof. unfold Equation2088, magma_op, refa129_inst, refa129_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa129_not40 : ~ @Equation40 Fin3 refa129_inst.
Proof. unfold Equation40. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not43 : ~ @Equation43 Fin3 refa129_inst.
Proof. unfold Equation43. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not414 : ~ @Equation414 Fin3 refa129_inst.
Proof. unfold Equation414. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not427 : ~ @Equation427 Fin3 refa129_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not429 : ~ @Equation429 Fin3 refa129_inst.
Proof. unfold Equation429. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not473 : ~ @Equation473 Fin3 refa129_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not477 : ~ @Equation477 Fin3 refa129_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not511 : ~ @Equation511 Fin3 refa129_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not513 : ~ @Equation513 Fin3 refa129_inst.
Proof. unfold Equation513. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not1682 : ~ @Equation1682 Fin3 refa129_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not1731 : ~ @Equation1731 Fin3 refa129_inst.
Proof. unfold Equation1731. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not1861 : ~ @Equation1861 Fin3 refa129_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not1934 : ~ @Equation1934 Fin3 refa129_inst.
Proof. unfold Equation1934. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not2470 : ~ @Equation2470 Fin3 refa129_inst.
Proof. unfold Equation2470. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not3056 : ~ @Equation3056 Fin3 refa129_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

Lemma refa129_not3079 : ~ @Equation3079 Fin3 refa129_inst.
Proof. unfold Equation3079. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa129_inst, refa129_op in H. discriminate H. Qed.

(** ---- refa13 (Fin7) ---- *)

Definition refa13_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_4 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_6 | F7_0, F7_6 => F7_0
  | F7_1, F7_0 => F7_4 | F7_1, F7_1 => F7_5 | F7_1, F7_2 => F7_6 | F7_1, F7_3 => F7_0 | F7_1, F7_4 => F7_1 | F7_1, F7_5 => F7_2 | F7_1, F7_6 => F7_3
  | F7_2, F7_0 => F7_0 | F7_2, F7_1 => F7_1 | F7_2, F7_2 => F7_2 | F7_2, F7_3 => F7_3 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_5 | F7_2, F7_6 => F7_6
  | F7_3, F7_0 => F7_3 | F7_3, F7_1 => F7_4 | F7_3, F7_2 => F7_5 | F7_3, F7_3 => F7_6 | F7_3, F7_4 => F7_0 | F7_3, F7_5 => F7_1 | F7_3, F7_6 => F7_2
  | F7_4, F7_0 => F7_6 | F7_4, F7_1 => F7_0 | F7_4, F7_2 => F7_1 | F7_4, F7_3 => F7_2 | F7_4, F7_4 => F7_3 | F7_4, F7_5 => F7_4 | F7_4, F7_6 => F7_5
  | F7_5, F7_0 => F7_2 | F7_5, F7_1 => F7_3 | F7_5, F7_2 => F7_4 | F7_5, F7_3 => F7_5 | F7_5, F7_4 => F7_6 | F7_5, F7_5 => F7_0 | F7_5, F7_6 => F7_1
  | F7_6, F7_0 => F7_5 | F7_6, F7_1 => F7_6 | F7_6, F7_2 => F7_0 | F7_6, F7_3 => F7_1 | F7_6, F7_4 => F7_2 | F7_6, F7_5 => F7_3 | F7_6, F7_6 => F7_4
  end.

#[local] Instance refa13_inst : Magma Fin7 := {| magma_op := refa13_op |}.

Lemma refa13_sat1279 : @Equation1279 Fin7 refa13_inst.
Proof. unfold Equation1279, magma_op, refa13_inst, refa13_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa13_not47 : ~ @Equation47 Fin7 refa13_inst.
Proof. unfold Equation47. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not99 : ~ @Equation99 Fin7 refa13_inst.
Proof. unfold Equation99. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not151 : ~ @Equation151 Fin7 refa13_inst.
Proof. unfold Equation151. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not211 : ~ @Equation211 Fin7 refa13_inst.
Proof. unfold Equation211. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not221 : ~ @Equation221 Fin7 refa13_inst.
Proof. unfold Equation221. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not255 : ~ @Equation255 Fin7 refa13_inst.
Proof. unfold Equation255. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not411 : ~ @Equation411 Fin7 refa13_inst.
Proof. unfold Equation411. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not614 : ~ @Equation614 Fin7 refa13_inst.
Proof. unfold Equation614. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not817 : ~ @Equation817 Fin7 refa13_inst.
Proof. unfold Equation817. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1020 : ~ @Equation1020 Fin7 refa13_inst.
Proof. unfold Equation1020. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1229 : ~ @Equation1229 Fin7 refa13_inst.
Proof. unfold Equation1229. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1238 : ~ @Equation1238 Fin7 refa13_inst.
Proof. unfold Equation1238. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1241 : ~ @Equation1241 Fin7 refa13_inst.
Proof. unfold Equation1241. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1242 : ~ @Equation1242 Fin7 refa13_inst.
Proof. unfold Equation1242. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1248 : ~ @Equation1248 Fin7 refa13_inst.
Proof. unfold Equation1248. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1249 : ~ @Equation1249 Fin7 refa13_inst.
Proof. unfold Equation1249. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1251 : ~ @Equation1251 Fin7 refa13_inst.
Proof. unfold Equation1251. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1252 : ~ @Equation1252 Fin7 refa13_inst.
Proof. unfold Equation1252. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1276 : ~ @Equation1276 Fin7 refa13_inst.
Proof. unfold Equation1276. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1278 : ~ @Equation1278 Fin7 refa13_inst.
Proof. unfold Equation1278. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1286 : ~ @Equation1286 Fin7 refa13_inst.
Proof. unfold Equation1286. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1288 : ~ @Equation1288 Fin7 refa13_inst.
Proof. unfold Equation1288. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1315 : ~ @Equation1315 Fin7 refa13_inst.
Proof. unfold Equation1315. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1322 : ~ @Equation1322 Fin7 refa13_inst.
Proof. unfold Equation1322. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1426 : ~ @Equation1426 Fin7 refa13_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1629 : ~ @Equation1629 Fin7 refa13_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not1832 : ~ @Equation1832 Fin7 refa13_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2036 : ~ @Equation2036 Fin7 refa13_inst.
Proof. unfold Equation2036. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2037 : ~ @Equation2037 Fin7 refa13_inst.
Proof. unfold Equation2037. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2038 : ~ @Equation2038 Fin7 refa13_inst.
Proof. unfold Equation2038. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2040 : ~ @Equation2040 Fin7 refa13_inst.
Proof. unfold Equation2040. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2041 : ~ @Equation2041 Fin7 refa13_inst.
Proof. unfold Equation2041. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2050 : ~ @Equation2050 Fin7 refa13_inst.
Proof. unfold Equation2050. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2060 : ~ @Equation2060 Fin7 refa13_inst.
Proof. unfold Equation2060. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2063 : ~ @Equation2063 Fin7 refa13_inst.
Proof. unfold Equation2063. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2087 : ~ @Equation2087 Fin7 refa13_inst.
Proof. unfold Equation2087. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2124 : ~ @Equation2124 Fin7 refa13_inst.
Proof. unfold Equation2124. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2125 : ~ @Equation2125 Fin7 refa13_inst.
Proof. unfold Equation2125. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2127 : ~ @Equation2127 Fin7 refa13_inst.
Proof. unfold Equation2127. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2128 : ~ @Equation2128 Fin7 refa13_inst.
Proof. unfold Equation2128. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2134 : ~ @Equation2134 Fin7 refa13_inst.
Proof. unfold Equation2134. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2238 : ~ @Equation2238 Fin7 refa13_inst.
Proof. unfold Equation2238. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2441 : ~ @Equation2441 Fin7 refa13_inst.
Proof. unfold Equation2441. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2644 : ~ @Equation2644 Fin7 refa13_inst.
Proof. unfold Equation2644. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not2847 : ~ @Equation2847 Fin7 refa13_inst.
Proof. unfold Equation2847. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not3050 : ~ @Equation3050 Fin7 refa13_inst.
Proof. unfold Equation3050. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not3253 : ~ @Equation3253 Fin7 refa13_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not3456 : ~ @Equation3456 Fin7 refa13_inst.
Proof. unfold Equation3456. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not3659 : ~ @Equation3659 Fin7 refa13_inst.
Proof. unfold Equation3659. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not3862 : ~ @Equation3862 Fin7 refa13_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4065 : ~ @Equation4065 Fin7 refa13_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4268 : ~ @Equation4268 Fin7 refa13_inst.
Proof. unfold Equation4268. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4269 : ~ @Equation4269 Fin7 refa13_inst.
Proof. unfold Equation4269. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4270 : ~ @Equation4270 Fin7 refa13_inst.
Proof. unfold Equation4270. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4272 : ~ @Equation4272 Fin7 refa13_inst.
Proof. unfold Equation4272. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4273 : ~ @Equation4273 Fin7 refa13_inst.
Proof. unfold Equation4273. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4275 : ~ @Equation4275 Fin7 refa13_inst.
Proof. unfold Equation4275. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4283 : ~ @Equation4283 Fin7 refa13_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4284 : ~ @Equation4284 Fin7 refa13_inst.
Proof. unfold Equation4284. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4290 : ~ @Equation4290 Fin7 refa13_inst.
Proof. unfold Equation4290. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4291 : ~ @Equation4291 Fin7 refa13_inst.
Proof. unfold Equation4291. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4293 : ~ @Equation4293 Fin7 refa13_inst.
Proof. unfold Equation4293. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4314 : ~ @Equation4314 Fin7 refa13_inst.
Proof. unfold Equation4314. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4321 : ~ @Equation4321 Fin7 refa13_inst.
Proof. unfold Equation4321. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4343 : ~ @Equation4343 Fin7 refa13_inst.
Proof. unfold Equation4343. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4380 : ~ @Equation4380 Fin7 refa13_inst.
Proof. unfold Equation4380. intro H. specialize (H F7_0). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4583 : ~ @Equation4583 Fin7 refa13_inst.
Proof. unfold Equation4583. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4584 : ~ @Equation4584 Fin7 refa13_inst.
Proof. unfold Equation4584. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4585 : ~ @Equation4585 Fin7 refa13_inst.
Proof. unfold Equation4585. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4587 : ~ @Equation4587 Fin7 refa13_inst.
Proof. unfold Equation4587. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4588 : ~ @Equation4588 Fin7 refa13_inst.
Proof. unfold Equation4588. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4590 : ~ @Equation4590 Fin7 refa13_inst.
Proof. unfold Equation4590. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4591 : ~ @Equation4591 Fin7 refa13_inst.
Proof. unfold Equation4591. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4598 : ~ @Equation4598 Fin7 refa13_inst.
Proof. unfold Equation4598. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4599 : ~ @Equation4599 Fin7 refa13_inst.
Proof. unfold Equation4599. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4605 : ~ @Equation4605 Fin7 refa13_inst.
Proof. unfold Equation4605. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4606 : ~ @Equation4606 Fin7 refa13_inst.
Proof. unfold Equation4606. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4608 : ~ @Equation4608 Fin7 refa13_inst.
Proof. unfold Equation4608. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4629 : ~ @Equation4629 Fin7 refa13_inst.
Proof. unfold Equation4629. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4635 : ~ @Equation4635 Fin7 refa13_inst.
Proof. unfold Equation4635. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

Lemma refa13_not4658 : ~ @Equation4658 Fin7 refa13_inst.
Proof. unfold Equation4658. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa13_inst, refa13_op in H. discriminate H. Qed.

(** ---- refa130 (Fin3) ---- *)

Definition refa130_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa130_inst : Magma Fin3 := {| magma_op := refa130_op |}.

Lemma refa130_sat311 : @Equation311 Fin3 refa130_inst.
Proof. unfold Equation311, magma_op, refa130_inst, refa130_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa130_sat4104 : @Equation4104 Fin3 refa130_inst.
Proof. unfold Equation4104, magma_op, refa130_inst, refa130_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa130_sat4636 : @Equation4636 Fin3 refa130_inst.
Proof. unfold Equation4636, magma_op, refa130_inst, refa130_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa130_not359 : ~ @Equation359 Fin3 refa130_inst.
Proof. unfold Equation359. intro H. specialize (H F3_2). unfold magma_op, refa130_inst, refa130_op in H. discriminate H. Qed.

Lemma refa130_not3659 : ~ @Equation3659 Fin3 refa130_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa130_inst, refa130_op in H. discriminate H. Qed.

Lemma refa130_not3862 : ~ @Equation3862 Fin3 refa130_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa130_inst, refa130_op in H. discriminate H. Qed.

Lemma refa130_not4090 : ~ @Equation4090 Fin3 refa130_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa130_inst, refa130_op in H. discriminate H. Qed.

Lemma refa130_not4131 : ~ @Equation4131 Fin3 refa130_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa130_inst, refa130_op in H. discriminate H. Qed.

Lemma refa130_not4293 : ~ @Equation4293 Fin3 refa130_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa130_inst, refa130_op in H. discriminate H. Qed.

Lemma refa130_not4583 : ~ @Equation4583 Fin3 refa130_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa130_inst, refa130_op in H. discriminate H. Qed.

Lemma refa130_not4598 : ~ @Equation4598 Fin3 refa130_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa130_inst, refa130_op in H. discriminate H. Qed.

Lemma refa130_not4622 : ~ @Equation4622 Fin3 refa130_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_2 F3_2). unfold magma_op, refa130_inst, refa130_op in H. discriminate H. Qed.

(** ---- refa131 (Fin3) ---- *)

Definition refa131_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa131_inst : Magma Fin3 := {| magma_op := refa131_op |}.

Lemma refa131_sat1437 : @Equation1437 Fin3 refa131_inst.
Proof. unfold Equation1437, magma_op, refa131_inst, refa131_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa131_sat1447 : @Equation1447 Fin3 refa131_inst.
Proof. unfold Equation1447, magma_op, refa131_inst, refa131_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa131_not1451 : ~ @Equation1451 Fin3 refa131_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa131_inst, refa131_op in H. discriminate H. Qed.

Lemma refa131_not1454 : ~ @Equation1454 Fin3 refa131_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa131_inst, refa131_op in H. discriminate H. Qed.

Lemma refa131_not4070 : ~ @Equation4070 Fin3 refa131_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa131_inst, refa131_op in H. discriminate H. Qed.

Lemma refa131_not4121 : ~ @Equation4121 Fin3 refa131_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa131_inst, refa131_op in H. discriminate H. Qed.

Lemma refa131_not4134 : ~ @Equation4134 Fin3 refa131_inst.
Proof. unfold Equation4134. intro H. specialize (H F3_1 F3_2 F3_0). unfold magma_op, refa131_inst, refa131_op in H. discriminate H. Qed.

Lemma refa131_not4360 : ~ @Equation4360 Fin3 refa131_inst.
Proof. unfold Equation4360. intro H. specialize (H F3_0 F3_0 F3_1 F3_2). unfold magma_op, refa131_inst, refa131_op in H. discriminate H. Qed.

Lemma refa131_not4599 : ~ @Equation4599 Fin3 refa131_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa131_inst, refa131_op in H. discriminate H. Qed.

Lemma refa131_not4631 : ~ @Equation4631 Fin3 refa131_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_1 F3_0 F3_1). unfold magma_op, refa131_inst, refa131_op in H. discriminate H. Qed.

(** ---- refa132 (Fin3) ---- *)

Definition refa132_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa132_inst : Magma Fin3 := {| magma_op := refa132_op |}.

Lemma refa132_sat1641 : @Equation1641 Fin3 refa132_inst.
Proof. unfold Equation1641, magma_op, refa132_inst, refa132_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa132_sat3262 : @Equation3262 Fin3 refa132_inst.
Proof. unfold Equation3262, magma_op, refa132_inst, refa132_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa132_sat3468 : @Equation3468 Fin3 refa132_inst.
Proof. unfold Equation3468, magma_op, refa132_inst, refa132_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa132_sat3524 : @Equation3524 Fin3 refa132_inst.
Proof. unfold Equation3524, magma_op, refa132_inst, refa132_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa132_not159 : ~ @Equation159 Fin3 refa132_inst.
Proof. unfold Equation159. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not203 : ~ @Equation203 Fin3 refa132_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not307 : ~ @Equation307 Fin3 refa132_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1427 : ~ @Equation1427 Fin3 refa132_inst.
Proof. unfold Equation1427. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1428 : ~ @Equation1428 Fin3 refa132_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1429 : ~ @Equation1429 Fin3 refa132_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1431 : ~ @Equation1431 Fin3 refa132_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1434 : ~ @Equation1434 Fin3 refa132_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1441 : ~ @Equation1441 Fin3 refa132_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1445 : ~ @Equation1445 Fin3 refa132_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1451 : ~ @Equation1451 Fin3 refa132_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1454 : ~ @Equation1454 Fin3 refa132_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1632 : ~ @Equation1632 Fin3 refa132_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1634 : ~ @Equation1634 Fin3 refa132_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1637 : ~ @Equation1637 Fin3 refa132_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1644 : ~ @Equation1644 Fin3 refa132_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1647 : ~ @Equation1647 Fin3 refa132_inst.
Proof. unfold Equation1647. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1648 : ~ @Equation1648 Fin3 refa132_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1654 : ~ @Equation1654 Fin3 refa132_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1655 : ~ @Equation1655 Fin3 refa132_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1657 : ~ @Equation1657 Fin3 refa132_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not1832 : ~ @Equation1832 Fin3 refa132_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not2050 : ~ @Equation2050 Fin3 refa132_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not2053 : ~ @Equation2053 Fin3 refa132_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not2238 : ~ @Equation2238 Fin3 refa132_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not2441 : ~ @Equation2441 Fin3 refa132_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3050 : ~ @Equation3050 Fin3 refa132_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3255 : ~ @Equation3255 Fin3 refa132_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3256 : ~ @Equation3256 Fin3 refa132_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3258 : ~ @Equation3258 Fin3 refa132_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3259 : ~ @Equation3259 Fin3 refa132_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3308 : ~ @Equation3308 Fin3 refa132_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3309 : ~ @Equation3309 Fin3 refa132_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3315 : ~ @Equation3315 Fin3 refa132_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3316 : ~ @Equation3316 Fin3 refa132_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3318 : ~ @Equation3318 Fin3 refa132_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3319 : ~ @Equation3319 Fin3 refa132_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3457 : ~ @Equation3457 Fin3 refa132_inst.
Proof. unfold Equation3457. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3459 : ~ @Equation3459 Fin3 refa132_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3461 : ~ @Equation3461 Fin3 refa132_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3464 : ~ @Equation3464 Fin3 refa132_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3509 : ~ @Equation3509 Fin3 refa132_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3511 : ~ @Equation3511 Fin3 refa132_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3512 : ~ @Equation3512 Fin3 refa132_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3519 : ~ @Equation3519 Fin3 refa132_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3522 : ~ @Equation3522 Fin3 refa132_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3660 : ~ @Equation3660 Fin3 refa132_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3661 : ~ @Equation3661 Fin3 refa132_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3662 : ~ @Equation3662 Fin3 refa132_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3665 : ~ @Equation3665 Fin3 refa132_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3667 : ~ @Equation3667 Fin3 refa132_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3668 : ~ @Equation3668 Fin3 refa132_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3714 : ~ @Equation3714 Fin3 refa132_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not3862 : ~ @Equation3862 Fin3 refa132_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not4065 : ~ @Equation4065 Fin3 refa132_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not4268 : ~ @Equation4268 Fin3 refa132_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not4269 : ~ @Equation4269 Fin3 refa132_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not4270 : ~ @Equation4270 Fin3 refa132_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not4283 : ~ @Equation4283 Fin3 refa132_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not4284 : ~ @Equation4284 Fin3 refa132_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not4380 : ~ @Equation4380 Fin3 refa132_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not4583 : ~ @Equation4583 Fin3 refa132_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not4584 : ~ @Equation4584 Fin3 refa132_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not4585 : ~ @Equation4585 Fin3 refa132_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not4598 : ~ @Equation4598 Fin3 refa132_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not4599 : ~ @Equation4599 Fin3 refa132_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

Lemma refa132_not4629 : ~ @Equation4629 Fin3 refa132_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa132_inst, refa132_op in H. discriminate H. Qed.

(** ---- refa133 (Fin3) ---- *)

Definition refa133_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa133_inst : Magma Fin3 := {| magma_op := refa133_op |}.

Lemma refa133_sat160 : @Equation160 Fin3 refa133_inst.
Proof. unfold Equation160, magma_op, refa133_inst, refa133_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa133_sat362 : @Equation362 Fin3 refa133_inst.
Proof. unfold Equation362, magma_op, refa133_inst, refa133_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa133_sat1454 : @Equation1454 Fin3 refa133_inst.
Proof. unfold Equation1454, magma_op, refa133_inst, refa133_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa133_sat2044 : @Equation2044 Fin3 refa133_inst.
Proof. unfold Equation2044, magma_op, refa133_inst, refa133_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa133_sat2264 : @Equation2264 Fin3 refa133_inst.
Proof. unfold Equation2264, magma_op, refa133_inst, refa133_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa133_sat2653 : @Equation2653 Fin3 refa133_inst.
Proof. unfold Equation2653, magma_op, refa133_inst, refa133_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa133_sat2850 : @Equation2850 Fin3 refa133_inst.
Proof. unfold Equation2850, magma_op, refa133_inst, refa133_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa133_sat3079 : @Equation3079 Fin3 refa133_inst.
Proof. unfold Equation3079, magma_op, refa133_inst, refa133_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa133_sat3668 : @Equation3668 Fin3 refa133_inst.
Proof. unfold Equation3668, magma_op, refa133_inst, refa133_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa133_sat4383 : @Equation4383 Fin3 refa133_inst.
Proof. unfold Equation4383, magma_op, refa133_inst, refa133_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa133_not1451 : ~ @Equation1451 Fin3 refa133_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not2053 : ~ @Equation2053 Fin3 refa133_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not2064 : ~ @Equation2064 Fin3 refa133_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not2240 : ~ @Equation2240 Fin3 refa133_inst.
Proof. unfold Equation2240. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not2254 : ~ @Equation2254 Fin3 refa133_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not2853 : ~ @Equation2853 Fin3 refa133_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not2863 : ~ @Equation2863 Fin3 refa133_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not3259 : ~ @Equation3259 Fin3 refa133_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not3261 : ~ @Equation3261 Fin3 refa133_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not3306 : ~ @Equation3306 Fin3 refa133_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not3308 : ~ @Equation3308 Fin3 refa133_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not3462 : ~ @Equation3462 Fin3 refa133_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not3511 : ~ @Equation3511 Fin3 refa133_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not3660 : ~ @Equation3660 Fin3 refa133_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not3661 : ~ @Equation3661 Fin3 refa133_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not3662 : ~ @Equation3662 Fin3 refa133_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not3664 : ~ @Equation3664 Fin3 refa133_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not3665 : ~ @Equation3665 Fin3 refa133_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4066 : ~ @Equation4066 Fin3 refa133_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4067 : ~ @Equation4067 Fin3 refa133_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4070 : ~ @Equation4070 Fin3 refa133_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4074 : ~ @Equation4074 Fin3 refa133_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4128 : ~ @Equation4128 Fin3 refa133_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4268 : ~ @Equation4268 Fin3 refa133_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4270 : ~ @Equation4270 Fin3 refa133_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4283 : ~ @Equation4283 Fin3 refa133_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4396 : ~ @Equation4396 Fin3 refa133_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4398 : ~ @Equation4398 Fin3 refa133_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4433 : ~ @Equation4433 Fin3 refa133_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4435 : ~ @Equation4435 Fin3 refa133_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4473 : ~ @Equation4473 Fin3 refa133_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4598 : ~ @Equation4598 Fin3 refa133_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

Lemma refa133_not4631 : ~ @Equation4631 Fin3 refa133_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa133_inst, refa133_op in H. discriminate H. Qed.

(** ---- refa134 (Fin3) ---- *)

Definition refa134_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa134_inst : Magma Fin3 := {| magma_op := refa134_op |}.

Lemma refa134_sat3081 : @Equation3081 Fin3 refa134_inst.
Proof. unfold Equation3081, magma_op, refa134_inst, refa134_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa134_not3309 : ~ @Equation3309 Fin3 refa134_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa134_inst, refa134_op in H. discriminate H. Qed.

Lemma refa134_not3316 : ~ @Equation3316 Fin3 refa134_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa134_inst, refa134_op in H. discriminate H. Qed.

Lemma refa134_not3319 : ~ @Equation3319 Fin3 refa134_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa134_inst, refa134_op in H. discriminate H. Qed.

Lemma refa134_not3509 : ~ @Equation3509 Fin3 refa134_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa134_inst, refa134_op in H. discriminate H. Qed.

Lemma refa134_not4284 : ~ @Equation4284 Fin3 refa134_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa134_inst, refa134_op in H. discriminate H. Qed.

(** ---- refa135 (Fin3) ---- *)

Definition refa135_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa135_inst : Magma Fin3 := {| magma_op := refa135_op |}.

Lemma refa135_sat2415 : @Equation2415 Fin3 refa135_inst.
Proof. unfold Equation2415, magma_op, refa135_inst, refa135_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa135_sat3529 : @Equation3529 Fin3 refa135_inst.
Proof. unfold Equation3529, magma_op, refa135_inst, refa135_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa135_sat3566 : @Equation3566 Fin3 refa135_inst.
Proof. unfold Equation3566, magma_op, refa135_inst, refa135_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa135_sat3790 : @Equation3790 Fin3 refa135_inst.
Proof. unfold Equation3790, magma_op, refa135_inst, refa135_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa135_sat4416 : @Equation4416 Fin3 refa135_inst.
Proof. unfold Equation4416, magma_op, refa135_inst, refa135_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa135_not55 : ~ @Equation55 Fin3 refa135_inst.
Proof. unfold Equation55. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not65 : ~ @Equation65 Fin3 refa135_inst.
Proof. unfold Equation65. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not75 : ~ @Equation75 Fin3 refa135_inst.
Proof. unfold Equation75. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not105 : ~ @Equation105 Fin3 refa135_inst.
Proof. unfold Equation105. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not107 : ~ @Equation107 Fin3 refa135_inst.
Proof. unfold Equation107. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not108 : ~ @Equation108 Fin3 refa135_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not124 : ~ @Equation124 Fin3 refa135_inst.
Proof. unfold Equation124. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not127 : ~ @Equation127 Fin3 refa135_inst.
Proof. unfold Equation127. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not159 : ~ @Equation159 Fin3 refa135_inst.
Proof. unfold Equation159. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not211 : ~ @Equation211 Fin3 refa135_inst.
Proof. unfold Equation211. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not221 : ~ @Equation221 Fin3 refa135_inst.
Proof. unfold Equation221. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not231 : ~ @Equation231 Fin3 refa135_inst.
Proof. unfold Equation231. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not263 : ~ @Equation263 Fin3 refa135_inst.
Proof. unfold Equation263. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not283 : ~ @Equation283 Fin3 refa135_inst.
Proof. unfold Equation283. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not413 : ~ @Equation413 Fin3 refa135_inst.
Proof. unfold Equation413. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not414 : ~ @Equation414 Fin3 refa135_inst.
Proof. unfold Equation414. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not416 : ~ @Equation416 Fin3 refa135_inst.
Proof. unfold Equation416. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not419 : ~ @Equation419 Fin3 refa135_inst.
Proof. unfold Equation419. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not426 : ~ @Equation426 Fin3 refa135_inst.
Proof. unfold Equation426. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not427 : ~ @Equation427 Fin3 refa135_inst.
Proof. unfold Equation427. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not429 : ~ @Equation429 Fin3 refa135_inst.
Proof. unfold Equation429. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not430 : ~ @Equation430 Fin3 refa135_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not436 : ~ @Equation436 Fin3 refa135_inst.
Proof. unfold Equation436. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not437 : ~ @Equation437 Fin3 refa135_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not439 : ~ @Equation439 Fin3 refa135_inst.
Proof. unfold Equation439. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not440 : ~ @Equation440 Fin3 refa135_inst.
Proof. unfold Equation440. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not466 : ~ @Equation466 Fin3 refa135_inst.
Proof. unfold Equation466. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not473 : ~ @Equation473 Fin3 refa135_inst.
Proof. unfold Equation473. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not476 : ~ @Equation476 Fin3 refa135_inst.
Proof. unfold Equation476. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not503 : ~ @Equation503 Fin3 refa135_inst.
Proof. unfold Equation503. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not513 : ~ @Equation513 Fin3 refa135_inst.
Proof. unfold Equation513. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not616 : ~ @Equation616 Fin3 refa135_inst.
Proof. unfold Equation616. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not622 : ~ @Equation622 Fin3 refa135_inst.
Proof. unfold Equation622. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not629 : ~ @Equation629 Fin3 refa135_inst.
Proof. unfold Equation629. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not632 : ~ @Equation632 Fin3 refa135_inst.
Proof. unfold Equation632. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not639 : ~ @Equation639 Fin3 refa135_inst.
Proof. unfold Equation639. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not642 : ~ @Equation642 Fin3 refa135_inst.
Proof. unfold Equation642. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not669 : ~ @Equation669 Fin3 refa135_inst.
Proof. unfold Equation669. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not676 : ~ @Equation676 Fin3 refa135_inst.
Proof. unfold Equation676. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not679 : ~ @Equation679 Fin3 refa135_inst.
Proof. unfold Equation679. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not706 : ~ @Equation706 Fin3 refa135_inst.
Proof. unfold Equation706. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not713 : ~ @Equation713 Fin3 refa135_inst.
Proof. unfold Equation713. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not716 : ~ @Equation716 Fin3 refa135_inst.
Proof. unfold Equation716. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not818 : ~ @Equation818 Fin3 refa135_inst.
Proof. unfold Equation818. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not819 : ~ @Equation819 Fin3 refa135_inst.
Proof. unfold Equation819. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not820 : ~ @Equation820 Fin3 refa135_inst.
Proof. unfold Equation820. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not822 : ~ @Equation822 Fin3 refa135_inst.
Proof. unfold Equation822. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not823 : ~ @Equation823 Fin3 refa135_inst.
Proof. unfold Equation823. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not825 : ~ @Equation825 Fin3 refa135_inst.
Proof. unfold Equation825. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not833 : ~ @Equation833 Fin3 refa135_inst.
Proof. unfold Equation833. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not835 : ~ @Equation835 Fin3 refa135_inst.
Proof. unfold Equation835. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not836 : ~ @Equation836 Fin3 refa135_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not842 : ~ @Equation842 Fin3 refa135_inst.
Proof. unfold Equation842. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not843 : ~ @Equation843 Fin3 refa135_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not845 : ~ @Equation845 Fin3 refa135_inst.
Proof. unfold Equation845. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not846 : ~ @Equation846 Fin3 refa135_inst.
Proof. unfold Equation846. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not872 : ~ @Equation872 Fin3 refa135_inst.
Proof. unfold Equation872. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not879 : ~ @Equation879 Fin3 refa135_inst.
Proof. unfold Equation879. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not882 : ~ @Equation882 Fin3 refa135_inst.
Proof. unfold Equation882. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not906 : ~ @Equation906 Fin3 refa135_inst.
Proof. unfold Equation906. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1022 : ~ @Equation1022 Fin3 refa135_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1023 : ~ @Equation1023 Fin3 refa135_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1028 : ~ @Equation1028 Fin3 refa135_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1036 : ~ @Equation1036 Fin3 refa135_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1038 : ~ @Equation1038 Fin3 refa135_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1039 : ~ @Equation1039 Fin3 refa135_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1046 : ~ @Equation1046 Fin3 refa135_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1048 : ~ @Equation1048 Fin3 refa135_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1049 : ~ @Equation1049 Fin3 refa135_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1075 : ~ @Equation1075 Fin3 refa135_inst.
Proof. unfold Equation1075. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1082 : ~ @Equation1082 Fin3 refa135_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1085 : ~ @Equation1085 Fin3 refa135_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1109 : ~ @Equation1109 Fin3 refa135_inst.
Proof. unfold Equation1109. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1112 : ~ @Equation1112 Fin3 refa135_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1119 : ~ @Equation1119 Fin3 refa135_inst.
Proof. unfold Equation1119. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1122 : ~ @Equation1122 Fin3 refa135_inst.
Proof. unfold Equation1122. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1224 : ~ @Equation1224 Fin3 refa135_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1225 : ~ @Equation1225 Fin3 refa135_inst.
Proof. unfold Equation1225. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1226 : ~ @Equation1226 Fin3 refa135_inst.
Proof. unfold Equation1226. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1229 : ~ @Equation1229 Fin3 refa135_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1231 : ~ @Equation1231 Fin3 refa135_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1239 : ~ @Equation1239 Fin3 refa135_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1241 : ~ @Equation1241 Fin3 refa135_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1242 : ~ @Equation1242 Fin3 refa135_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1249 : ~ @Equation1249 Fin3 refa135_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1251 : ~ @Equation1251 Fin3 refa135_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1252 : ~ @Equation1252 Fin3 refa135_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1278 : ~ @Equation1278 Fin3 refa135_inst.
Proof. unfold Equation1278. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1285 : ~ @Equation1285 Fin3 refa135_inst.
Proof. unfold Equation1285. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1288 : ~ @Equation1288 Fin3 refa135_inst.
Proof. unfold Equation1288. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1312 : ~ @Equation1312 Fin3 refa135_inst.
Proof. unfold Equation1312. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1315 : ~ @Equation1315 Fin3 refa135_inst.
Proof. unfold Equation1315. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1322 : ~ @Equation1322 Fin3 refa135_inst.
Proof. unfold Equation1322. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1428 : ~ @Equation1428 Fin3 refa135_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1431 : ~ @Equation1431 Fin3 refa135_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1434 : ~ @Equation1434 Fin3 refa135_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1441 : ~ @Equation1441 Fin3 refa135_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1444 : ~ @Equation1444 Fin3 refa135_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1451 : ~ @Equation1451 Fin3 refa135_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1454 : ~ @Equation1454 Fin3 refa135_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1488 : ~ @Equation1488 Fin3 refa135_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1491 : ~ @Equation1491 Fin3 refa135_inst.
Proof. unfold Equation1491. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1515 : ~ @Equation1515 Fin3 refa135_inst.
Proof. unfold Equation1515. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1518 : ~ @Equation1518 Fin3 refa135_inst.
Proof. unfold Equation1518. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1525 : ~ @Equation1525 Fin3 refa135_inst.
Proof. unfold Equation1525. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1631 : ~ @Equation1631 Fin3 refa135_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1637 : ~ @Equation1637 Fin3 refa135_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1638 : ~ @Equation1638 Fin3 refa135_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1644 : ~ @Equation1644 Fin3 refa135_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1647 : ~ @Equation1647 Fin3 refa135_inst.
Proof. unfold Equation1647. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1654 : ~ @Equation1654 Fin3 refa135_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1657 : ~ @Equation1657 Fin3 refa135_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1684 : ~ @Equation1684 Fin3 refa135_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1694 : ~ @Equation1694 Fin3 refa135_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1721 : ~ @Equation1721 Fin3 refa135_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1728 : ~ @Equation1728 Fin3 refa135_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1731 : ~ @Equation1731 Fin3 refa135_inst.
Proof. unfold Equation1731. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1834 : ~ @Equation1834 Fin3 refa135_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1837 : ~ @Equation1837 Fin3 refa135_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1838 : ~ @Equation1838 Fin3 refa135_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1840 : ~ @Equation1840 Fin3 refa135_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1848 : ~ @Equation1848 Fin3 refa135_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1851 : ~ @Equation1851 Fin3 refa135_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1857 : ~ @Equation1857 Fin3 refa135_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1858 : ~ @Equation1858 Fin3 refa135_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1860 : ~ @Equation1860 Fin3 refa135_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1861 : ~ @Equation1861 Fin3 refa135_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1887 : ~ @Equation1887 Fin3 refa135_inst.
Proof. unfold Equation1887. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1894 : ~ @Equation1894 Fin3 refa135_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1897 : ~ @Equation1897 Fin3 refa135_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1924 : ~ @Equation1924 Fin3 refa135_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not1931 : ~ @Equation1931 Fin3 refa135_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2037 : ~ @Equation2037 Fin3 refa135_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2040 : ~ @Equation2040 Fin3 refa135_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2043 : ~ @Equation2043 Fin3 refa135_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2053 : ~ @Equation2053 Fin3 refa135_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2060 : ~ @Equation2060 Fin3 refa135_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2063 : ~ @Equation2063 Fin3 refa135_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2097 : ~ @Equation2097 Fin3 refa135_inst.
Proof. unfold Equation2097. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2100 : ~ @Equation2100 Fin3 refa135_inst.
Proof. unfold Equation2100. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2127 : ~ @Equation2127 Fin3 refa135_inst.
Proof. unfold Equation2127. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2134 : ~ @Equation2134 Fin3 refa135_inst.
Proof. unfold Equation2134. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2137 : ~ @Equation2137 Fin3 refa135_inst.
Proof. unfold Equation2137. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2240 : ~ @Equation2240 Fin3 refa135_inst.
Proof. unfold Equation2240. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2246 : ~ @Equation2246 Fin3 refa135_inst.
Proof. unfold Equation2246. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2256 : ~ @Equation2256 Fin3 refa135_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2266 : ~ @Equation2266 Fin3 refa135_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2293 : ~ @Equation2293 Fin3 refa135_inst.
Proof. unfold Equation2293. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2303 : ~ @Equation2303 Fin3 refa135_inst.
Proof. unfold Equation2303. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2330 : ~ @Equation2330 Fin3 refa135_inst.
Proof. unfold Equation2330. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2340 : ~ @Equation2340 Fin3 refa135_inst.
Proof. unfold Equation2340. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2443 : ~ @Equation2443 Fin3 refa135_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2449 : ~ @Equation2449 Fin3 refa135_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2459 : ~ @Equation2459 Fin3 refa135_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2469 : ~ @Equation2469 Fin3 refa135_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2496 : ~ @Equation2496 Fin3 refa135_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2506 : ~ @Equation2506 Fin3 refa135_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2533 : ~ @Equation2533 Fin3 refa135_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2543 : ~ @Equation2543 Fin3 refa135_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2646 : ~ @Equation2646 Fin3 refa135_inst.
Proof. unfold Equation2646. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2652 : ~ @Equation2652 Fin3 refa135_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2662 : ~ @Equation2662 Fin3 refa135_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2672 : ~ @Equation2672 Fin3 refa135_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2673 : ~ @Equation2673 Fin3 refa135_inst.
Proof. unfold Equation2673. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2699 : ~ @Equation2699 Fin3 refa135_inst.
Proof. unfold Equation2699. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2709 : ~ @Equation2709 Fin3 refa135_inst.
Proof. unfold Equation2709. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2736 : ~ @Equation2736 Fin3 refa135_inst.
Proof. unfold Equation2736. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2746 : ~ @Equation2746 Fin3 refa135_inst.
Proof. unfold Equation2746. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2849 : ~ @Equation2849 Fin3 refa135_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2855 : ~ @Equation2855 Fin3 refa135_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2865 : ~ @Equation2865 Fin3 refa135_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2875 : ~ @Equation2875 Fin3 refa135_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2902 : ~ @Equation2902 Fin3 refa135_inst.
Proof. unfold Equation2902. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2912 : ~ @Equation2912 Fin3 refa135_inst.
Proof. unfold Equation2912. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2939 : ~ @Equation2939 Fin3 refa135_inst.
Proof. unfold Equation2939. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not2949 : ~ @Equation2949 Fin3 refa135_inst.
Proof. unfold Equation2949. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3052 : ~ @Equation3052 Fin3 refa135_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3056 : ~ @Equation3056 Fin3 refa135_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3058 : ~ @Equation3058 Fin3 refa135_inst.
Proof. unfold Equation3058. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3068 : ~ @Equation3068 Fin3 refa135_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3078 : ~ @Equation3078 Fin3 refa135_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3079 : ~ @Equation3079 Fin3 refa135_inst.
Proof. unfold Equation3079. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3105 : ~ @Equation3105 Fin3 refa135_inst.
Proof. unfold Equation3105. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3115 : ~ @Equation3115 Fin3 refa135_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3142 : ~ @Equation3142 Fin3 refa135_inst.
Proof. unfold Equation3142. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3152 : ~ @Equation3152 Fin3 refa135_inst.
Proof. unfold Equation3152. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3255 : ~ @Equation3255 Fin3 refa135_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3256 : ~ @Equation3256 Fin3 refa135_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3258 : ~ @Equation3258 Fin3 refa135_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3259 : ~ @Equation3259 Fin3 refa135_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3261 : ~ @Equation3261 Fin3 refa135_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3268 : ~ @Equation3268 Fin3 refa135_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3271 : ~ @Equation3271 Fin3 refa135_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3278 : ~ @Equation3278 Fin3 refa135_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3279 : ~ @Equation3279 Fin3 refa135_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3281 : ~ @Equation3281 Fin3 refa135_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3308 : ~ @Equation3308 Fin3 refa135_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3342 : ~ @Equation3342 Fin3 refa135_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3355 : ~ @Equation3355 Fin3 refa135_inst.
Proof. unfold Equation3355. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3458 : ~ @Equation3458 Fin3 refa135_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3459 : ~ @Equation3459 Fin3 refa135_inst.
Proof. unfold Equation3459. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3462 : ~ @Equation3462 Fin3 refa135_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3464 : ~ @Equation3464 Fin3 refa135_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3472 : ~ @Equation3472 Fin3 refa135_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3474 : ~ @Equation3474 Fin3 refa135_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3481 : ~ @Equation3481 Fin3 refa135_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3484 : ~ @Equation3484 Fin3 refa135_inst.
Proof. unfold Equation3484. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3511 : ~ @Equation3511 Fin3 refa135_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3518 : ~ @Equation3518 Fin3 refa135_inst.
Proof. unfold Equation3518. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3545 : ~ @Equation3545 Fin3 refa135_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3549 : ~ @Equation3549 Fin3 refa135_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3660 : ~ @Equation3660 Fin3 refa135_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3661 : ~ @Equation3661 Fin3 refa135_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3662 : ~ @Equation3662 Fin3 refa135_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3664 : ~ @Equation3664 Fin3 refa135_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3665 : ~ @Equation3665 Fin3 refa135_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3667 : ~ @Equation3667 Fin3 refa135_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3668 : ~ @Equation3668 Fin3 refa135_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3677 : ~ @Equation3677 Fin3 refa135_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3684 : ~ @Equation3684 Fin3 refa135_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3687 : ~ @Equation3687 Fin3 refa135_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3721 : ~ @Equation3721 Fin3 refa135_inst.
Proof. unfold Equation3721. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3724 : ~ @Equation3724 Fin3 refa135_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3725 : ~ @Equation3725 Fin3 refa135_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3864 : ~ @Equation3864 Fin3 refa135_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3870 : ~ @Equation3870 Fin3 refa135_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3878 : ~ @Equation3878 Fin3 refa135_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3880 : ~ @Equation3880 Fin3 refa135_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3890 : ~ @Equation3890 Fin3 refa135_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3917 : ~ @Equation3917 Fin3 refa135_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3918 : ~ @Equation3918 Fin3 refa135_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3928 : ~ @Equation3928 Fin3 refa135_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3955 : ~ @Equation3955 Fin3 refa135_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not3964 : ~ @Equation3964 Fin3 refa135_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4067 : ~ @Equation4067 Fin3 refa135_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4068 : ~ @Equation4068 Fin3 refa135_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4073 : ~ @Equation4073 Fin3 refa135_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4083 : ~ @Equation4083 Fin3 refa135_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4093 : ~ @Equation4093 Fin3 refa135_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4121 : ~ @Equation4121 Fin3 refa135_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4127 : ~ @Equation4127 Fin3 refa135_inst.
Proof. unfold Equation4127. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4131 : ~ @Equation4131 Fin3 refa135_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4154 : ~ @Equation4154 Fin3 refa135_inst.
Proof. unfold Equation4154. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4158 : ~ @Equation4158 Fin3 refa135_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4167 : ~ @Equation4167 Fin3 refa135_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4269 : ~ @Equation4269 Fin3 refa135_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4270 : ~ @Equation4270 Fin3 refa135_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4272 : ~ @Equation4272 Fin3 refa135_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4273 : ~ @Equation4273 Fin3 refa135_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4275 : ~ @Equation4275 Fin3 refa135_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4283 : ~ @Equation4283 Fin3 refa135_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4314 : ~ @Equation4314 Fin3 refa135_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4386 : ~ @Equation4386 Fin3 refa135_inst.
Proof. unfold Equation4386. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4398 : ~ @Equation4398 Fin3 refa135_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4399 : ~ @Equation4399 Fin3 refa135_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4405 : ~ @Equation4405 Fin3 refa135_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4442 : ~ @Equation4442 Fin3 refa135_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4473 : ~ @Equation4473 Fin3 refa135_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4482 : ~ @Equation4482 Fin3 refa135_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4584 : ~ @Equation4584 Fin3 refa135_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4585 : ~ @Equation4585 Fin3 refa135_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4590 : ~ @Equation4590 Fin3 refa135_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4598 : ~ @Equation4598 Fin3 refa135_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4599 : ~ @Equation4599 Fin3 refa135_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

Lemma refa135_not4635 : ~ @Equation4635 Fin3 refa135_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa135_inst, refa135_op in H. discriminate H. Qed.

(** ---- refa136 (Fin3) ---- *)

Definition refa136_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa136_inst : Magma Fin3 := {| magma_op := refa136_op |}.

Lemma refa136_sat3910 : @Equation3910 Fin3 refa136_inst.
Proof. unfold Equation3910, magma_op, refa136_inst, refa136_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa136_not359 : ~ @Equation359 Fin3 refa136_inst.
Proof. unfold Equation359. intro H. specialize (H F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not3253 : ~ @Equation3253 Fin3 refa136_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not3724 : ~ @Equation3724 Fin3 refa136_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not3865 : ~ @Equation3865 Fin3 refa136_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not3887 : ~ @Equation3887 Fin3 refa136_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not3915 : ~ @Equation3915 Fin3 refa136_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not3925 : ~ @Equation3925 Fin3 refa136_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not3928 : ~ @Equation3928 Fin3 refa136_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4066 : ~ @Equation4066 Fin3 refa136_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4067 : ~ @Equation4067 Fin3 refa136_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4070 : ~ @Equation4070 Fin3 refa136_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4071 : ~ @Equation4071 Fin3 refa136_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4073 : ~ @Equation4073 Fin3 refa136_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4081 : ~ @Equation4081 Fin3 refa136_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4083 : ~ @Equation4083 Fin3 refa136_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4084 : ~ @Equation4084 Fin3 refa136_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4091 : ~ @Equation4091 Fin3 refa136_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4093 : ~ @Equation4093 Fin3 refa136_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4131 : ~ @Equation4131 Fin3 refa136_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4269 : ~ @Equation4269 Fin3 refa136_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4293 : ~ @Equation4293 Fin3 refa136_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4314 : ~ @Equation4314 Fin3 refa136_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4583 : ~ @Equation4583 Fin3 refa136_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4591 : ~ @Equation4591 Fin3 refa136_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4598 : ~ @Equation4598 Fin3 refa136_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4606 : ~ @Equation4606 Fin3 refa136_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4608 : ~ @Equation4608 Fin3 refa136_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4631 : ~ @Equation4631 Fin3 refa136_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4636 : ~ @Equation4636 Fin3 refa136_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

Lemma refa136_not4647 : ~ @Equation4647 Fin3 refa136_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_2 F3_1). unfold magma_op, refa136_inst, refa136_op in H. discriminate H. Qed.

(** ---- refa137 (Fin3) ---- *)

Definition refa137_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa137_inst : Magma Fin3 := {| magma_op := refa137_op |}.

Lemma refa137_sat832 : @Equation832 Fin3 refa137_inst.
Proof. unfold Equation832, magma_op, refa137_inst, refa137_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa137_sat833 : @Equation833 Fin3 refa137_inst.
Proof. unfold Equation833, magma_op, refa137_inst, refa137_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa137_sat836 : @Equation836 Fin3 refa137_inst.
Proof. unfold Equation836, magma_op, refa137_inst, refa137_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa137_sat1035 : @Equation1035 Fin3 refa137_inst.
Proof. unfold Equation1035, magma_op, refa137_inst, refa137_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa137_sat1038 : @Equation1038 Fin3 refa137_inst.
Proof. unfold Equation1038, magma_op, refa137_inst, refa137_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa137_sat1048 : @Equation1048 Fin3 refa137_inst.
Proof. unfold Equation1048, magma_op, refa137_inst, refa137_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa137_sat1240 : @Equation1240 Fin3 refa137_inst.
Proof. unfold Equation1240, magma_op, refa137_inst, refa137_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa137_sat1243 : @Equation1243 Fin3 refa137_inst.
Proof. unfold Equation1243, magma_op, refa137_inst, refa137_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa137_sat1244 : @Equation1244 Fin3 refa137_inst.
Proof. unfold Equation1244, magma_op, refa137_inst, refa137_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa137_sat1245 : @Equation1245 Fin3 refa137_inst.
Proof. unfold Equation1245, magma_op, refa137_inst, refa137_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa137_sat1250 : @Equation1250 Fin3 refa137_inst.
Proof. unfold Equation1250, magma_op, refa137_inst, refa137_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa137_sat1254 : @Equation1254 Fin3 refa137_inst.
Proof. unfold Equation1254, magma_op, refa137_inst, refa137_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa137_sat1255 : @Equation1255 Fin3 refa137_inst.
Proof. unfold Equation1255, magma_op, refa137_inst, refa137_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa137_sat1259 : @Equation1259 Fin3 refa137_inst.
Proof. unfold Equation1259, magma_op, refa137_inst, refa137_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa137_sat1262 : @Equation1262 Fin3 refa137_inst.
Proof. unfold Equation1262, magma_op, refa137_inst, refa137_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa137_sat1263 : @Equation1263 Fin3 refa137_inst.
Proof. unfold Equation1263, magma_op, refa137_inst, refa137_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa137_not411 : ~ @Equation411 Fin3 refa137_inst.
Proof. unfold Equation411. intro H. specialize (H F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not818 : ~ @Equation818 Fin3 refa137_inst.
Proof. unfold Equation818. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not819 : ~ @Equation819 Fin3 refa137_inst.
Proof. unfold Equation819. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not842 : ~ @Equation842 Fin3 refa137_inst.
Proof. unfold Equation842. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not843 : ~ @Equation843 Fin3 refa137_inst.
Proof. unfold Equation843. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not845 : ~ @Equation845 Fin3 refa137_inst.
Proof. unfold Equation845. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not1022 : ~ @Equation1022 Fin3 refa137_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not1023 : ~ @Equation1023 Fin3 refa137_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not1028 : ~ @Equation1028 Fin3 refa137_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not1036 : ~ @Equation1036 Fin3 refa137_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not1039 : ~ @Equation1039 Fin3 refa137_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not1046 : ~ @Equation1046 Fin3 refa137_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not1229 : ~ @Equation1229 Fin3 refa137_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not1832 : ~ @Equation1832 Fin3 refa137_inst.
Proof. unfold Equation1832. intro H. specialize (H F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not3253 : ~ @Equation3253 Fin3 refa137_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not3659 : ~ @Equation3659 Fin3 refa137_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not3862 : ~ @Equation3862 Fin3 refa137_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not4065 : ~ @Equation4065 Fin3 refa137_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not4269 : ~ @Equation4269 Fin3 refa137_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not4270 : ~ @Equation4270 Fin3 refa137_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not4293 : ~ @Equation4293 Fin3 refa137_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not4314 : ~ @Equation4314 Fin3 refa137_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not4583 : ~ @Equation4583 Fin3 refa137_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not4606 : ~ @Equation4606 Fin3 refa137_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not4608 : ~ @Equation4608 Fin3 refa137_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not4622 : ~ @Equation4622 Fin3 refa137_inst.
Proof. unfold Equation4622. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not4631 : ~ @Equation4631 Fin3 refa137_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_2 F3_0 F3_1). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not4636 : ~ @Equation4636 Fin3 refa137_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

Lemma refa137_not4647 : ~ @Equation4647 Fin3 refa137_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_0 F3_2). unfold magma_op, refa137_inst, refa137_op in H. discriminate H. Qed.

(** ---- refa138 (Fin3) ---- *)

Definition refa138_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa138_inst : Magma Fin3 := {| magma_op := refa138_op |}.

Lemma refa138_sat264 : @Equation264 Fin3 refa138_inst.
Proof. unfold Equation264, magma_op, refa138_inst, refa138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa138_sat271 : @Equation271 Fin3 refa138_inst.
Proof. unfold Equation271, magma_op, refa138_inst, refa138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa138_sat273 : @Equation273 Fin3 refa138_inst.
Proof. unfold Equation273, magma_op, refa138_inst, refa138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa138_sat280 : @Equation280 Fin3 refa138_inst.
Proof. unfold Equation280, magma_op, refa138_inst, refa138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa138_sat474 : @Equation474 Fin3 refa138_inst.
Proof. unfold Equation474, magma_op, refa138_inst, refa138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa138_sat543 : @Equation543 Fin3 refa138_inst.
Proof. unfold Equation543, magma_op, refa138_inst, refa138_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa138_sat882 : @Equation882 Fin3 refa138_inst.
Proof. unfold Equation882, magma_op, refa138_inst, refa138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa138_sat1083 : @Equation1083 Fin3 refa138_inst.
Proof. unfold Equation1083, magma_op, refa138_inst, refa138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa138_sat1895 : @Equation1895 Fin3 refa138_inst.
Proof. unfold Equation1895, magma_op, refa138_inst, refa138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa138_sat2506 : @Equation2506 Fin3 refa138_inst.
Proof. unfold Equation2506, magma_op, refa138_inst, refa138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa138_sat3345 : @Equation3345 Fin3 refa138_inst.
Proof. unfold Equation3345, magma_op, refa138_inst, refa138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa138_sat3749 : @Equation3749 Fin3 refa138_inst.
Proof. unfold Equation3749, magma_op, refa138_inst, refa138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa138_sat3954 : @Equation3954 Fin3 refa138_inst.
Proof. unfold Equation3954, magma_op, refa138_inst, refa138_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa138_not47 : ~ @Equation47 Fin3 refa138_inst.
Proof. unfold Equation47. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not99 : ~ @Equation99 Fin3 refa138_inst.
Proof. unfold Equation99. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not151 : ~ @Equation151 Fin3 refa138_inst.
Proof. unfold Equation151. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not203 : ~ @Equation203 Fin3 refa138_inst.
Proof. unfold Equation203. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not261 : ~ @Equation261 Fin3 refa138_inst.
Proof. unfold Equation261. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not274 : ~ @Equation274 Fin3 refa138_inst.
Proof. unfold Equation274. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not283 : ~ @Equation283 Fin3 refa138_inst.
Proof. unfold Equation283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not307 : ~ @Equation307 Fin3 refa138_inst.
Proof. unfold Equation307. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not413 : ~ @Equation413 Fin3 refa138_inst.
Proof. unfold Equation413. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not416 : ~ @Equation416 Fin3 refa138_inst.
Proof. unfold Equation416. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not417 : ~ @Equation417 Fin3 refa138_inst.
Proof. unfold Equation417. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not420 : ~ @Equation420 Fin3 refa138_inst.
Proof. unfold Equation420. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not426 : ~ @Equation426 Fin3 refa138_inst.
Proof. unfold Equation426. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not429 : ~ @Equation429 Fin3 refa138_inst.
Proof. unfold Equation429. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not430 : ~ @Equation430 Fin3 refa138_inst.
Proof. unfold Equation430. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not437 : ~ @Equation437 Fin3 refa138_inst.
Proof. unfold Equation437. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not467 : ~ @Equation467 Fin3 refa138_inst.
Proof. unfold Equation467. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not473 : ~ @Equation473 Fin3 refa138_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not476 : ~ @Equation476 Fin3 refa138_inst.
Proof. unfold Equation476. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not477 : ~ @Equation477 Fin3 refa138_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not501 : ~ @Equation501 Fin3 refa138_inst.
Proof. unfold Equation501. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not503 : ~ @Equation503 Fin3 refa138_inst.
Proof. unfold Equation503. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not511 : ~ @Equation511 Fin3 refa138_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not614 : ~ @Equation614 Fin3 refa138_inst.
Proof. unfold Equation614. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not819 : ~ @Equation819 Fin3 refa138_inst.
Proof. unfold Equation819. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not825 : ~ @Equation825 Fin3 refa138_inst.
Proof. unfold Equation825. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not826 : ~ @Equation826 Fin3 refa138_inst.
Proof. unfold Equation826. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not832 : ~ @Equation832 Fin3 refa138_inst.
Proof. unfold Equation832. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not833 : ~ @Equation833 Fin3 refa138_inst.
Proof. unfold Equation833. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not836 : ~ @Equation836 Fin3 refa138_inst.
Proof. unfold Equation836. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not843 : ~ @Equation843 Fin3 refa138_inst.
Proof. unfold Equation843. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not845 : ~ @Equation845 Fin3 refa138_inst.
Proof. unfold Equation845. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not872 : ~ @Equation872 Fin3 refa138_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not873 : ~ @Equation873 Fin3 refa138_inst.
Proof. unfold Equation873. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not879 : ~ @Equation879 Fin3 refa138_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not883 : ~ @Equation883 Fin3 refa138_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not907 : ~ @Equation907 Fin3 refa138_inst.
Proof. unfold Equation907. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1025 : ~ @Equation1025 Fin3 refa138_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1026 : ~ @Equation1026 Fin3 refa138_inst.
Proof. unfold Equation1026. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1029 : ~ @Equation1029 Fin3 refa138_inst.
Proof. unfold Equation1029. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1035 : ~ @Equation1035 Fin3 refa138_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1038 : ~ @Equation1038 Fin3 refa138_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1039 : ~ @Equation1039 Fin3 refa138_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1046 : ~ @Equation1046 Fin3 refa138_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1048 : ~ @Equation1048 Fin3 refa138_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1076 : ~ @Equation1076 Fin3 refa138_inst.
Proof. unfold Equation1076. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1082 : ~ @Equation1082 Fin3 refa138_inst.
Proof. unfold Equation1082. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1085 : ~ @Equation1085 Fin3 refa138_inst.
Proof. unfold Equation1085. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1086 : ~ @Equation1086 Fin3 refa138_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1110 : ~ @Equation1110 Fin3 refa138_inst.
Proof. unfold Equation1110. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1112 : ~ @Equation1112 Fin3 refa138_inst.
Proof. unfold Equation1112. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1223 : ~ @Equation1223 Fin3 refa138_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1426 : ~ @Equation1426 Fin3 refa138_inst.
Proof. unfold Equation1426. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1631 : ~ @Equation1631 Fin3 refa138_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1632 : ~ @Equation1632 Fin3 refa138_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1634 : ~ @Equation1634 Fin3 refa138_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1638 : ~ @Equation1638 Fin3 refa138_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1644 : ~ @Equation1644 Fin3 refa138_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1648 : ~ @Equation1648 Fin3 refa138_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1654 : ~ @Equation1654 Fin3 refa138_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1655 : ~ @Equation1655 Fin3 refa138_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1657 : ~ @Equation1657 Fin3 refa138_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1681 : ~ @Equation1681 Fin3 refa138_inst.
Proof. unfold Equation1681. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1684 : ~ @Equation1684 Fin3 refa138_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1692 : ~ @Equation1692 Fin3 refa138_inst.
Proof. unfold Equation1692. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1694 : ~ @Equation1694 Fin3 refa138_inst.
Proof. unfold Equation1694. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1719 : ~ @Equation1719 Fin3 refa138_inst.
Proof. unfold Equation1719. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1721 : ~ @Equation1721 Fin3 refa138_inst.
Proof. unfold Equation1721. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1722 : ~ @Equation1722 Fin3 refa138_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1728 : ~ @Equation1728 Fin3 refa138_inst.
Proof. unfold Equation1728. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1833 : ~ @Equation1833 Fin3 refa138_inst.
Proof. unfold Equation1833. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1834 : ~ @Equation1834 Fin3 refa138_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1837 : ~ @Equation1837 Fin3 refa138_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1838 : ~ @Equation1838 Fin3 refa138_inst.
Proof. unfold Equation1838. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1841 : ~ @Equation1841 Fin3 refa138_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1847 : ~ @Equation1847 Fin3 refa138_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1851 : ~ @Equation1851 Fin3 refa138_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1858 : ~ @Equation1858 Fin3 refa138_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1860 : ~ @Equation1860 Fin3 refa138_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1884 : ~ @Equation1884 Fin3 refa138_inst.
Proof. unfold Equation1884. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1885 : ~ @Equation1885 Fin3 refa138_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1888 : ~ @Equation1888 Fin3 refa138_inst.
Proof. unfold Equation1888. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1894 : ~ @Equation1894 Fin3 refa138_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1897 : ~ @Equation1897 Fin3 refa138_inst.
Proof. unfold Equation1897. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1922 : ~ @Equation1922 Fin3 refa138_inst.
Proof. unfold Equation1922. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1924 : ~ @Equation1924 Fin3 refa138_inst.
Proof. unfold Equation1924. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not1931 : ~ @Equation1931 Fin3 refa138_inst.
Proof. unfold Equation1931. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2035 : ~ @Equation2035 Fin3 refa138_inst.
Proof. unfold Equation2035. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2238 : ~ @Equation2238 Fin3 refa138_inst.
Proof. unfold Equation2238. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2443 : ~ @Equation2443 Fin3 refa138_inst.
Proof. unfold Equation2443. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2449 : ~ @Equation2449 Fin3 refa138_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2457 : ~ @Equation2457 Fin3 refa138_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2460 : ~ @Equation2460 Fin3 refa138_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2467 : ~ @Equation2467 Fin3 refa138_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2469 : ~ @Equation2469 Fin3 refa138_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2493 : ~ @Equation2493 Fin3 refa138_inst.
Proof. unfold Equation2493. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2496 : ~ @Equation2496 Fin3 refa138_inst.
Proof. unfold Equation2496. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2497 : ~ @Equation2497 Fin3 refa138_inst.
Proof. unfold Equation2497. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2504 : ~ @Equation2504 Fin3 refa138_inst.
Proof. unfold Equation2504. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2531 : ~ @Equation2531 Fin3 refa138_inst.
Proof. unfold Equation2531. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2533 : ~ @Equation2533 Fin3 refa138_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2540 : ~ @Equation2540 Fin3 refa138_inst.
Proof. unfold Equation2540. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2543 : ~ @Equation2543 Fin3 refa138_inst.
Proof. unfold Equation2543. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2644 : ~ @Equation2644 Fin3 refa138_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not2847 : ~ @Equation2847 Fin3 refa138_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3050 : ~ @Equation3050 Fin3 refa138_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3255 : ~ @Equation3255 Fin3 refa138_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3258 : ~ @Equation3258 Fin3 refa138_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3259 : ~ @Equation3259 Fin3 refa138_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3262 : ~ @Equation3262 Fin3 refa138_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3268 : ~ @Equation3268 Fin3 refa138_inst.
Proof. unfold Equation3268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3271 : ~ @Equation3271 Fin3 refa138_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3272 : ~ @Equation3272 Fin3 refa138_inst.
Proof. unfold Equation3272. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3279 : ~ @Equation3279 Fin3 refa138_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3281 : ~ @Equation3281 Fin3 refa138_inst.
Proof. unfold Equation3281. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3308 : ~ @Equation3308 Fin3 refa138_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3309 : ~ @Equation3309 Fin3 refa138_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3316 : ~ @Equation3316 Fin3 refa138_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3318 : ~ @Equation3318 Fin3 refa138_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3342 : ~ @Equation3342 Fin3 refa138_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3343 : ~ @Equation3343 Fin3 refa138_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3346 : ~ @Equation3346 Fin3 refa138_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3352 : ~ @Equation3352 Fin3 refa138_inst.
Proof. unfold Equation3352. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3456 : ~ @Equation3456 Fin3 refa138_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3660 : ~ @Equation3660 Fin3 refa138_inst.
Proof. unfold Equation3660. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3661 : ~ @Equation3661 Fin3 refa138_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3664 : ~ @Equation3664 Fin3 refa138_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3667 : ~ @Equation3667 Fin3 refa138_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3668 : ~ @Equation3668 Fin3 refa138_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3674 : ~ @Equation3674 Fin3 refa138_inst.
Proof. unfold Equation3674. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3675 : ~ @Equation3675 Fin3 refa138_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3678 : ~ @Equation3678 Fin3 refa138_inst.
Proof. unfold Equation3678. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3685 : ~ @Equation3685 Fin3 refa138_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3687 : ~ @Equation3687 Fin3 refa138_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3712 : ~ @Equation3712 Fin3 refa138_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3722 : ~ @Equation3722 Fin3 refa138_inst.
Proof. unfold Equation3722. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3724 : ~ @Equation3724 Fin3 refa138_inst.
Proof. unfold Equation3724. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3748 : ~ @Equation3748 Fin3 refa138_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3752 : ~ @Equation3752 Fin3 refa138_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3759 : ~ @Equation3759 Fin3 refa138_inst.
Proof. unfold Equation3759. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3864 : ~ @Equation3864 Fin3 refa138_inst.
Proof. unfold Equation3864. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3867 : ~ @Equation3867 Fin3 refa138_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3868 : ~ @Equation3868 Fin3 refa138_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3871 : ~ @Equation3871 Fin3 refa138_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3877 : ~ @Equation3877 Fin3 refa138_inst.
Proof. unfold Equation3877. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3880 : ~ @Equation3880 Fin3 refa138_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3881 : ~ @Equation3881 Fin3 refa138_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3888 : ~ @Equation3888 Fin3 refa138_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3890 : ~ @Equation3890 Fin3 refa138_inst.
Proof. unfold Equation3890. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3917 : ~ @Equation3917 Fin3 refa138_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3918 : ~ @Equation3918 Fin3 refa138_inst.
Proof. unfold Equation3918. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3925 : ~ @Equation3925 Fin3 refa138_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3927 : ~ @Equation3927 Fin3 refa138_inst.
Proof. unfold Equation3927. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3951 : ~ @Equation3951 Fin3 refa138_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3952 : ~ @Equation3952 Fin3 refa138_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3955 : ~ @Equation3955 Fin3 refa138_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3961 : ~ @Equation3961 Fin3 refa138_inst.
Proof. unfold Equation3961. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not3964 : ~ @Equation3964 Fin3 refa138_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4065 : ~ @Equation4065 Fin3 refa138_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4268 : ~ @Equation4268 Fin3 refa138_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4269 : ~ @Equation4269 Fin3 refa138_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4272 : ~ @Equation4272 Fin3 refa138_inst.
Proof. unfold Equation4272. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4273 : ~ @Equation4273 Fin3 refa138_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4276 : ~ @Equation4276 Fin3 refa138_inst.
Proof. unfold Equation4276. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4283 : ~ @Equation4283 Fin3 refa138_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4284 : ~ @Equation4284 Fin3 refa138_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4291 : ~ @Equation4291 Fin3 refa138_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4293 : ~ @Equation4293 Fin3 refa138_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4314 : ~ @Equation4314 Fin3 refa138_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4320 : ~ @Equation4320 Fin3 refa138_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4343 : ~ @Equation4343 Fin3 refa138_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4380 : ~ @Equation4380 Fin3 refa138_inst.
Proof. unfold Equation4380. intro H. specialize (H F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4583 : ~ @Equation4583 Fin3 refa138_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4584 : ~ @Equation4584 Fin3 refa138_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4585 : ~ @Equation4585 Fin3 refa138_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4587 : ~ @Equation4587 Fin3 refa138_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4591 : ~ @Equation4591 Fin3 refa138_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4599 : ~ @Equation4599 Fin3 refa138_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4605 : ~ @Equation4605 Fin3 refa138_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4606 : ~ @Equation4606 Fin3 refa138_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4608 : ~ @Equation4608 Fin3 refa138_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4629 : ~ @Equation4629 Fin3 refa138_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4635 : ~ @Equation4635 Fin3 refa138_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

Lemma refa138_not4636 : ~ @Equation4636 Fin3 refa138_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa138_inst, refa138_op in H. discriminate H. Qed.

(** ---- refa139 (Fin3) ---- *)

Definition refa139_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa139_inst : Magma Fin3 := {| magma_op := refa139_op |}.

Lemma refa139_sat658 : @Equation658 Fin3 refa139_inst.
Proof. unfold Equation658, magma_op, refa139_inst, refa139_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa139_sat676 : @Equation676 Fin3 refa139_inst.
Proof. unfold Equation676, magma_op, refa139_inst, refa139_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa139_sat1082 : @Equation1082 Fin3 refa139_inst.
Proof. unfold Equation1082, magma_op, refa139_inst, refa139_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa139_sat1481 : @Equation1481 Fin3 refa139_inst.
Proof. unfold Equation1481, magma_op, refa139_inst, refa139_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa139_sat1523 : @Equation1523 Fin3 refa139_inst.
Proof. unfold Equation1523, magma_op, refa139_inst, refa139_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa139_sat1543 : @Equation1543 Fin3 refa139_inst.
Proof. unfold Equation1543, magma_op, refa139_inst, refa139_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa139_sat1850 : @Equation1850 Fin3 refa139_inst.
Proof. unfold Equation1850, magma_op, refa139_inst, refa139_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa139_sat1929 : @Equation1929 Fin3 refa139_inst.
Proof. unfold Equation1929, magma_op, refa139_inst, refa139_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa139_sat2132 : @Equation2132 Fin3 refa139_inst.
Proof. unfold Equation2132, magma_op, refa139_inst, refa139_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa139_sat2402 : @Equation2402 Fin3 refa139_inst.
Proof. unfold Equation2402, magma_op, refa139_inst, refa139_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa139_sat2964 : @Equation2964 Fin3 refa139_inst.
Proof. unfold Equation2964, magma_op, refa139_inst, refa139_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa139_sat4424 : @Equation4424 Fin3 refa139_inst.
Proof. unfold Equation4424, magma_op, refa139_inst, refa139_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa139_not617 : ~ @Equation617 Fin3 refa139_inst.
Proof. unfold Equation617. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not632 : ~ @Equation632 Fin3 refa139_inst.
Proof. unfold Equation632. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not639 : ~ @Equation639 Fin3 refa139_inst.
Proof. unfold Equation639. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not669 : ~ @Equation669 Fin3 refa139_inst.
Proof. unfold Equation669. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not825 : ~ @Equation825 Fin3 refa139_inst.
Proof. unfold Equation825. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not870 : ~ @Equation870 Fin3 refa139_inst.
Proof. unfold Equation870. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not879 : ~ @Equation879 Fin3 refa139_inst.
Proof. unfold Equation879. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not917 : ~ @Equation917 Fin3 refa139_inst.
Proof. unfold Equation917. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1038 : ~ @Equation1038 Fin3 refa139_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1113 : ~ @Equation1113 Fin3 refa139_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1229 : ~ @Equation1229 Fin3 refa139_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1289 : ~ @Equation1289 Fin3 refa139_inst.
Proof. unfold Equation1289. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1444 : ~ @Equation1444 Fin3 refa139_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1451 : ~ @Equation1451 Fin3 refa139_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1479 : ~ @Equation1479 Fin3 refa139_inst.
Proof. unfold Equation1479. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1488 : ~ @Equation1488 Fin3 refa139_inst.
Proof. unfold Equation1488. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1635 : ~ @Equation1635 Fin3 refa139_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1645 : ~ @Equation1645 Fin3 refa139_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1654 : ~ @Equation1654 Fin3 refa139_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1658 : ~ @Equation1658 Fin3 refa139_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1682 : ~ @Equation1682 Fin3 refa139_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1684 : ~ @Equation1684 Fin3 refa139_inst.
Proof. unfold Equation1684. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1848 : ~ @Equation1848 Fin3 refa139_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1885 : ~ @Equation1885 Fin3 refa139_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not1894 : ~ @Equation1894 Fin3 refa139_inst.
Proof. unfold Equation1894. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2088 : ~ @Equation2088 Fin3 refa139_inst.
Proof. unfold Equation2088. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2254 : ~ @Equation2254 Fin3 refa139_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2267 : ~ @Equation2267 Fin3 refa139_inst.
Proof. unfold Equation2267. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2291 : ~ @Equation2291 Fin3 refa139_inst.
Proof. unfold Equation2291. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2338 : ~ @Equation2338 Fin3 refa139_inst.
Proof. unfold Equation2338. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2444 : ~ @Equation2444 Fin3 refa139_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2447 : ~ @Equation2447 Fin3 refa139_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2449 : ~ @Equation2449 Fin3 refa139_inst.
Proof. unfold Equation2449. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2534 : ~ @Equation2534 Fin3 refa139_inst.
Proof. unfold Equation2534. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2541 : ~ @Equation2541 Fin3 refa139_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2669 : ~ @Equation2669 Fin3 refa139_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2697 : ~ @Equation2697 Fin3 refa139_inst.
Proof. unfold Equation2697. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2900 : ~ @Equation2900 Fin3 refa139_inst.
Proof. unfold Equation2900. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2940 : ~ @Equation2940 Fin3 refa139_inst.
Proof. unfold Equation2940. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2947 : ~ @Equation2947 Fin3 refa139_inst.
Proof. unfold Equation2947. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not2998 : ~ @Equation2998 Fin3 refa139_inst.
Proof. unfold Equation2998. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3103 : ~ @Equation3103 Fin3 refa139_inst.
Proof. unfold Equation3103. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3116 : ~ @Equation3116 Fin3 refa139_inst.
Proof. unfold Equation3116. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3150 : ~ @Equation3150 Fin3 refa139_inst.
Proof. unfold Equation3150. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3201 : ~ @Equation3201 Fin3 refa139_inst.
Proof. unfold Equation3201. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3271 : ~ @Equation3271 Fin3 refa139_inst.
Proof. unfold Equation3271. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3342 : ~ @Equation3342 Fin3 refa139_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3474 : ~ @Equation3474 Fin3 refa139_inst.
Proof. unfold Equation3474. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3481 : ~ @Equation3481 Fin3 refa139_inst.
Proof. unfold Equation3481. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3545 : ~ @Equation3545 Fin3 refa139_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3556 : ~ @Equation3556 Fin3 refa139_inst.
Proof. unfold Equation3556. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3558 : ~ @Equation3558 Fin3 refa139_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3588 : ~ @Equation3588 Fin3 refa139_inst.
Proof. unfold Equation3588. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3667 : ~ @Equation3667 Fin3 refa139_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3675 : ~ @Equation3675 Fin3 refa139_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3714 : ~ @Equation3714 Fin3 refa139_inst.
Proof. unfold Equation3714. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3748 : ~ @Equation3748 Fin3 refa139_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3752 : ~ @Equation3752 Fin3 refa139_inst.
Proof. unfold Equation3752. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3761 : ~ @Equation3761 Fin3 refa139_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3880 : ~ @Equation3880 Fin3 refa139_inst.
Proof. unfold Equation3880. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3924 : ~ @Equation3924 Fin3 refa139_inst.
Proof. unfold Equation3924. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3951 : ~ @Equation3951 Fin3 refa139_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3964 : ~ @Equation3964 Fin3 refa139_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not3994 : ~ @Equation3994 Fin3 refa139_inst.
Proof. unfold Equation3994. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4073 : ~ @Equation4073 Fin3 refa139_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4081 : ~ @Equation4081 Fin3 refa139_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4083 : ~ @Equation4083 Fin3 refa139_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4158 : ~ @Equation4158 Fin3 refa139_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4167 : ~ @Equation4167 Fin3 refa139_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4273 : ~ @Equation4273 Fin3 refa139_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4320 : ~ @Equation4320 Fin3 refa139_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4369 : ~ @Equation4369 Fin3 refa139_inst.
Proof. unfold Equation4369. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4405 : ~ @Equation4405 Fin3 refa139_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4435 : ~ @Equation4435 Fin3 refa139_inst.
Proof. unfold Equation4435. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4473 : ~ @Equation4473 Fin3 refa139_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4480 : ~ @Equation4480 Fin3 refa139_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4531 : ~ @Equation4531 Fin3 refa139_inst.
Proof. unfold Equation4531. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4598 : ~ @Equation4598 Fin3 refa139_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4605 : ~ @Equation4605 Fin3 refa139_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4635 : ~ @Equation4635 Fin3 refa139_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

Lemma refa139_not4647 : ~ @Equation4647 Fin3 refa139_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa139_inst, refa139_op in H. discriminate H. Qed.

(** ---- refa14 (Fin7) ---- *)

Definition refa14_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_1 | F7_0, F7_4 => F7_6 | F7_0, F7_5 => F7_4 | F7_0, F7_6 => F7_5
  | F7_1, F7_0 => F7_1 | F7_1, F7_1 => F7_4 | F7_1, F7_2 => F7_5 | F7_1, F7_3 => F7_2 | F7_1, F7_4 => F7_0 | F7_1, F7_5 => F7_3 | F7_1, F7_6 => F7_6
  | F7_2, F7_0 => F7_2 | F7_2, F7_1 => F7_3 | F7_2, F7_2 => F7_6 | F7_2, F7_3 => F7_4 | F7_2, F7_4 => F7_1 | F7_2, F7_5 => F7_5 | F7_2, F7_6 => F7_0
  | F7_3, F7_0 => F7_3 | F7_3, F7_1 => F7_6 | F7_3, F7_2 => F7_1 | F7_3, F7_3 => F7_5 | F7_3, F7_4 => F7_4 | F7_3, F7_5 => F7_0 | F7_3, F7_6 => F7_2
  | F7_4, F7_0 => F7_4 | F7_4, F7_1 => F7_5 | F7_4, F7_2 => F7_0 | F7_4, F7_3 => F7_3 | F7_4, F7_4 => F7_2 | F7_4, F7_5 => F7_6 | F7_4, F7_6 => F7_1
  | F7_5, F7_0 => F7_5 | F7_5, F7_1 => F7_0 | F7_5, F7_2 => F7_2 | F7_5, F7_3 => F7_6 | F7_5, F7_4 => F7_3 | F7_5, F7_5 => F7_1 | F7_5, F7_6 => F7_4
  | F7_6, F7_0 => F7_6 | F7_6, F7_1 => F7_1 | F7_6, F7_2 => F7_4 | F7_6, F7_3 => F7_0 | F7_6, F7_4 => F7_5 | F7_6, F7_5 => F7_2 | F7_6, F7_6 => F7_3
  end.

#[local] Instance refa14_inst : Magma Fin7 := {| magma_op := refa14_op |}.

Lemma refa14_sat1313 : @Equation1313 Fin7 refa14_inst.
Proof. unfold Equation1313, magma_op, refa14_inst, refa14_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa14_sat1315 : @Equation1315 Fin7 refa14_inst.
Proof. unfold Equation1315, magma_op, refa14_inst, refa14_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa14_sat1322 : @Equation1322 Fin7 refa14_inst.
Proof. unfold Equation1322, magma_op, refa14_inst, refa14_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa14_not49 : ~ @Equation49 Fin7 refa14_inst.
Proof. unfold Equation49. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not65 : ~ @Equation65 Fin7 refa14_inst.
Proof. unfold Equation65. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not73 : ~ @Equation73 Fin7 refa14_inst.
Proof. unfold Equation73. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not99 : ~ @Equation99 Fin7 refa14_inst.
Proof. unfold Equation99. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not151 : ~ @Equation151 Fin7 refa14_inst.
Proof. unfold Equation151. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not203 : ~ @Equation203 Fin7 refa14_inst.
Proof. unfold Equation203. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not255 : ~ @Equation255 Fin7 refa14_inst.
Proof. unfold Equation255. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not411 : ~ @Equation411 Fin7 refa14_inst.
Proof. unfold Equation411. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not706 : ~ @Equation706 Fin7 refa14_inst.
Proof. unfold Equation706. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not713 : ~ @Equation713 Fin7 refa14_inst.
Proof. unfold Equation713. intro H. specialize (H F7_1 F7_0). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not1020 : ~ @Equation1020 Fin7 refa14_inst.
Proof. unfold Equation1020. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not1238 : ~ @Equation1238 Fin7 refa14_inst.
Proof. unfold Equation1238. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not1241 : ~ @Equation1241 Fin7 refa14_inst.
Proof. unfold Equation1241. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not1248 : ~ @Equation1248 Fin7 refa14_inst.
Proof. unfold Equation1248. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not1251 : ~ @Equation1251 Fin7 refa14_inst.
Proof. unfold Equation1251. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not1278 : ~ @Equation1278 Fin7 refa14_inst.
Proof. unfold Equation1278. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not1285 : ~ @Equation1285 Fin7 refa14_inst.
Proof. unfold Equation1285. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not1286 : ~ @Equation1286 Fin7 refa14_inst.
Proof. unfold Equation1286. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not1288 : ~ @Equation1288 Fin7 refa14_inst.
Proof. unfold Equation1288. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not1629 : ~ @Equation1629 Fin7 refa14_inst.
Proof. unfold Equation1629. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not1832 : ~ @Equation1832 Fin7 refa14_inst.
Proof. unfold Equation1832. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not2035 : ~ @Equation2035 Fin7 refa14_inst.
Proof. unfold Equation2035. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not2301 : ~ @Equation2301 Fin7 refa14_inst.
Proof. unfold Equation2301. intro H. specialize (H F7_1 F7_0). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not2504 : ~ @Equation2504 Fin7 refa14_inst.
Proof. unfold Equation2504. intro H. specialize (H F7_1 F7_0). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not2531 : ~ @Equation2531 Fin7 refa14_inst.
Proof. unfold Equation2531. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not2644 : ~ @Equation2644 Fin7 refa14_inst.
Proof. unfold Equation2644. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not2866 : ~ @Equation2866 Fin7 refa14_inst.
Proof. unfold Equation2866. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not3069 : ~ @Equation3069 Fin7 refa14_inst.
Proof. unfold Equation3069. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not3106 : ~ @Equation3106 Fin7 refa14_inst.
Proof. unfold Equation3106. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not3253 : ~ @Equation3253 Fin7 refa14_inst.
Proof. unfold Equation3253. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not3545 : ~ @Equation3545 Fin7 refa14_inst.
Proof. unfold Equation3545. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not3659 : ~ @Equation3659 Fin7 refa14_inst.
Proof. unfold Equation3659. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not3862 : ~ @Equation3862 Fin7 refa14_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not4065 : ~ @Equation4065 Fin7 refa14_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not4275 : ~ @Equation4275 Fin7 refa14_inst.
Proof. unfold Equation4275. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not4283 : ~ @Equation4283 Fin7 refa14_inst.
Proof. unfold Equation4283. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not4320 : ~ @Equation4320 Fin7 refa14_inst.
Proof. unfold Equation4320. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not4343 : ~ @Equation4343 Fin7 refa14_inst.
Proof. unfold Equation4343. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not4398 : ~ @Equation4398 Fin7 refa14_inst.
Proof. unfold Equation4398. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not4405 : ~ @Equation4405 Fin7 refa14_inst.
Proof. unfold Equation4405. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not4470 : ~ @Equation4470 Fin7 refa14_inst.
Proof. unfold Equation4470. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not4482 : ~ @Equation4482 Fin7 refa14_inst.
Proof. unfold Equation4482. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not4587 : ~ @Equation4587 Fin7 refa14_inst.
Proof. unfold Equation4587. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not4606 : ~ @Equation4606 Fin7 refa14_inst.
Proof. unfold Equation4606. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

Lemma refa14_not4608 : ~ @Equation4608 Fin7 refa14_inst.
Proof. unfold Equation4608. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa14_inst, refa14_op in H. discriminate H. Qed.

(** ---- refa140 (Fin3) ---- *)

Definition refa140_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_2
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa140_inst : Magma Fin3 := {| magma_op := refa140_op |}.

Lemma refa140_sat333 : @Equation333 Fin3 refa140_inst.
Proof. unfold Equation333, magma_op, refa140_inst, refa140_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa140_sat3346 : @Equation3346 Fin3 refa140_inst.
Proof. unfold Equation3346, magma_op, refa140_inst, refa140_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa140_not3306 : ~ @Equation3306 Fin3 refa140_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa140_inst, refa140_op in H. discriminate H. Qed.

Lemma refa140_not3549 : ~ @Equation3549 Fin3 refa140_inst.
Proof. unfold Equation3549. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa140_inst, refa140_op in H. discriminate H. Qed.

Lemma refa140_not3725 : ~ @Equation3725 Fin3 refa140_inst.
Proof. unfold Equation3725. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa140_inst, refa140_op in H. discriminate H. Qed.

Lemma refa140_not3928 : ~ @Equation3928 Fin3 refa140_inst.
Proof. unfold Equation3928. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa140_inst, refa140_op in H. discriminate H. Qed.

Lemma refa140_not3955 : ~ @Equation3955 Fin3 refa140_inst.
Proof. unfold Equation3955. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa140_inst, refa140_op in H. discriminate H. Qed.

Lemma refa140_not4131 : ~ @Equation4131 Fin3 refa140_inst.
Proof. unfold Equation4131. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa140_inst, refa140_op in H. discriminate H. Qed.

Lemma refa140_not4158 : ~ @Equation4158 Fin3 refa140_inst.
Proof. unfold Equation4158. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa140_inst, refa140_op in H. discriminate H. Qed.

Lemma refa140_not4399 : ~ @Equation4399 Fin3 refa140_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa140_inst, refa140_op in H. discriminate H. Qed.

Lemma refa140_not4442 : ~ @Equation4442 Fin3 refa140_inst.
Proof. unfold Equation4442. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa140_inst, refa140_op in H. discriminate H. Qed.

Lemma refa140_not4473 : ~ @Equation4473 Fin3 refa140_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa140_inst, refa140_op in H. discriminate H. Qed.

Lemma refa140_not4635 : ~ @Equation4635 Fin3 refa140_inst.
Proof. unfold Equation4635. intro H. specialize (H F3_2 F3_0). unfold magma_op, refa140_inst, refa140_op in H. discriminate H. Qed.

(** ---- refa141 (Fin3) ---- *)

Definition refa141_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa141_inst : Magma Fin3 := {| magma_op := refa141_op |}.

Lemma refa141_sat360 : @Equation360 Fin3 refa141_inst.
Proof. unfold Equation360, magma_op, refa141_inst, refa141_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa141_sat1227 : @Equation1227 Fin3 refa141_inst.
Proof. unfold Equation1227, magma_op, refa141_inst, refa141_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa141_not361 : ~ @Equation361 Fin3 refa141_inst.
Proof. unfold Equation361. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa141_inst, refa141_op in H. discriminate H. Qed.

Lemma refa141_not413 : ~ @Equation413 Fin3 refa141_inst.
Proof. unfold Equation413. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa141_inst, refa141_op in H. discriminate H. Qed.

Lemma refa141_not414 : ~ @Equation414 Fin3 refa141_inst.
Proof. unfold Equation414. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa141_inst, refa141_op in H. discriminate H. Qed.

Lemma refa141_not823 : ~ @Equation823 Fin3 refa141_inst.
Proof. unfold Equation823. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa141_inst, refa141_op in H. discriminate H. Qed.

Lemma refa141_not1022 : ~ @Equation1022 Fin3 refa141_inst.
Proof. unfold Equation1022. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa141_inst, refa141_op in H. discriminate H. Qed.

Lemma refa141_not1023 : ~ @Equation1023 Fin3 refa141_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa141_inst, refa141_op in H. discriminate H. Qed.

Lemma refa141_not1025 : ~ @Equation1025 Fin3 refa141_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa141_inst, refa141_op in H. discriminate H. Qed.

Lemma refa141_not1028 : ~ @Equation1028 Fin3 refa141_inst.
Proof. unfold Equation1028. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa141_inst, refa141_op in H. discriminate H. Qed.

Lemma refa141_not1228 : ~ @Equation1228 Fin3 refa141_inst.
Proof. unfold Equation1228. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa141_inst, refa141_op in H. discriminate H. Qed.

Lemma refa141_not1231 : ~ @Equation1231 Fin3 refa141_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa141_inst, refa141_op in H. discriminate H. Qed.

Lemma refa141_not3255 : ~ @Equation3255 Fin3 refa141_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa141_inst, refa141_op in H. discriminate H. Qed.

Lemma refa141_not3256 : ~ @Equation3256 Fin3 refa141_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa141_inst, refa141_op in H. discriminate H. Qed.

Lemma refa141_not3665 : ~ @Equation3665 Fin3 refa141_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa141_inst, refa141_op in H. discriminate H. Qed.

(** ---- refa142 (Fin3) ---- *)

Definition refa142_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa142_inst : Magma Fin3 := {| magma_op := refa142_op |}.

Lemma refa142_sat1442 : @Equation1442 Fin3 refa142_inst.
Proof. unfold Equation1442, magma_op, refa142_inst, refa142_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa142_sat1444 : @Equation1444 Fin3 refa142_inst.
Proof. unfold Equation1444, magma_op, refa142_inst, refa142_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa142_sat1445 : @Equation1445 Fin3 refa142_inst.
Proof. unfold Equation1445, magma_op, refa142_inst, refa142_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa142_sat1838 : @Equation1838 Fin3 refa142_inst.
Proof. unfold Equation1838, magma_op, refa142_inst, refa142_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa142_sat1848 : @Equation1848 Fin3 refa142_inst.
Proof. unfold Equation1848, magma_op, refa142_inst, refa142_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa142_sat1858 : @Equation1858 Fin3 refa142_inst.
Proof. unfold Equation1858, magma_op, refa142_inst, refa142_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa142_sat3523 : @Equation3523 Fin3 refa142_inst.
Proof. unfold Equation3523, magma_op, refa142_inst, refa142_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa142_sat3526 : @Equation3526 Fin3 refa142_inst.
Proof. unfold Equation3526, magma_op, refa142_inst, refa142_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa142_sat4127 : @Equation4127 Fin3 refa142_inst.
Proof. unfold Equation4127, magma_op, refa142_inst, refa142_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa142_not151 : ~ @Equation151 Fin3 refa142_inst.
Proof. unfold Equation151. intro H. specialize (H F3_0). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not1427 : ~ @Equation1427 Fin3 refa142_inst.
Proof. unfold Equation1427. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not1428 : ~ @Equation1428 Fin3 refa142_inst.
Proof. unfold Equation1428. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not1429 : ~ @Equation1429 Fin3 refa142_inst.
Proof. unfold Equation1429. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not1435 : ~ @Equation1435 Fin3 refa142_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not1629 : ~ @Equation1629 Fin3 refa142_inst.
Proof. unfold Equation1629. intro H. specialize (H F3_2). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not1837 : ~ @Equation1837 Fin3 refa142_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not1840 : ~ @Equation1840 Fin3 refa142_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not1847 : ~ @Equation1847 Fin3 refa142_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not1850 : ~ @Equation1850 Fin3 refa142_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not1857 : ~ @Equation1857 Fin3 refa142_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not2050 : ~ @Equation2050 Fin3 refa142_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not2051 : ~ @Equation2051 Fin3 refa142_inst.
Proof. unfold Equation2051. intro H. specialize (H F3_1 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not3253 : ~ @Equation3253 Fin3 refa142_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not3462 : ~ @Equation3462 Fin3 refa142_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not3464 : ~ @Equation3464 Fin3 refa142_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not3465 : ~ @Equation3465 Fin3 refa142_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not3509 : ~ @Equation3509 Fin3 refa142_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not3659 : ~ @Equation3659 Fin3 refa142_inst.
Proof. unfold Equation3659. intro H. specialize (H F3_0). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not3862 : ~ @Equation3862 Fin3 refa142_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not4068 : ~ @Equation4068 Fin3 refa142_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not4121 : ~ @Equation4121 Fin3 refa142_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not4283 : ~ @Equation4283 Fin3 refa142_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not4284 : ~ @Equation4284 Fin3 refa142_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not4314 : ~ @Equation4314 Fin3 refa142_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not4398 : ~ @Equation4398 Fin3 refa142_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_1 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not4472 : ~ @Equation4472 Fin3 refa142_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not4598 : ~ @Equation4598 Fin3 refa142_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.

Lemma refa142_not4599 : ~ @Equation4599 Fin3 refa142_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa142_inst, refa142_op in H. discriminate H. Qed.
