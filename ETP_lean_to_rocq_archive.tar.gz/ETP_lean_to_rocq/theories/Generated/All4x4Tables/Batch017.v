(** * All4x4 counterexamples — batch 17
    Auto-generated from Lean4 All4x4 files. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP Require Import FinMagma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

(** ---- refa82 (Fin3) ---- *)

Definition refa82_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_1
  end.

#[local] Instance refa82_inst : Magma Fin3 := {| magma_op := refa82_op |}.

Lemma refa82_sat3714 : @Equation3714 Fin3 refa82_inst.
Proof. unfold Equation3714, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat3721 : @Equation3721 Fin3 refa82_inst.
Proof. unfold Equation3721, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat3725 : @Equation3725 Fin3 refa82_inst.
Proof. unfold Equation3725, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat3748 : @Equation3748 Fin3 refa82_inst.
Proof. unfold Equation3748, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat3751 : @Equation3751 Fin3 refa82_inst.
Proof. unfold Equation3751, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat3752 : @Equation3752 Fin3 refa82_inst.
Proof. unfold Equation3752, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat3759 : @Equation3759 Fin3 refa82_inst.
Proof. unfold Equation3759, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat3761 : @Equation3761 Fin3 refa82_inst.
Proof. unfold Equation3761, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat4291 : @Equation4291 Fin3 refa82_inst.
Proof. unfold Equation4291, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat4293 : @Equation4293 Fin3 refa82_inst.
Proof. unfold Equation4293, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat4321 : @Equation4321 Fin3 refa82_inst.
Proof. unfold Equation4321, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat4399 : @Equation4399 Fin3 refa82_inst.
Proof. unfold Equation4399, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat4406 : @Equation4406 Fin3 refa82_inst.
Proof. unfold Equation4406, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat4436 : @Equation4436 Fin3 refa82_inst.
Proof. unfold Equation4436, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat4443 : @Equation4443 Fin3 refa82_inst.
Proof. unfold Equation4443, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat4629 : @Equation4629 Fin3 refa82_inst.
Proof. unfold Equation4629, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat4636 : @Equation4636 Fin3 refa82_inst.
Proof. unfold Equation4636, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_sat4658 : @Equation4658 Fin3 refa82_inst.
Proof. unfold Equation4658, magma_op, refa82_inst, refa82_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa82_not3253 : ~ @Equation3253 Fin3 refa82_inst.
Proof. unfold Equation3253. intro H. specialize (H F3_2). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not3456 : ~ @Equation3456 Fin3 refa82_inst.
Proof. unfold Equation3456. intro H. specialize (H F3_2). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not3662 : ~ @Equation3662 Fin3 refa82_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not3665 : ~ @Equation3665 Fin3 refa82_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not3667 : ~ @Equation3667 Fin3 refa82_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not3862 : ~ @Equation3862 Fin3 refa82_inst.
Proof. unfold Equation3862. intro H. specialize (H F3_2). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4065 : ~ @Equation4065 Fin3 refa82_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_2). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4284 : ~ @Equation4284 Fin3 refa82_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4290 : ~ @Equation4290 Fin3 refa82_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4314 : ~ @Equation4314 Fin3 refa82_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4320 : ~ @Equation4320 Fin3 refa82_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4343 : ~ @Equation4343 Fin3 refa82_inst.
Proof. unfold Equation4343. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4396 : ~ @Equation4396 Fin3 refa82_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4433 : ~ @Equation4433 Fin3 refa82_inst.
Proof. unfold Equation4433. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4445 : ~ @Equation4445 Fin3 refa82_inst.
Proof. unfold Equation4445. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4470 : ~ @Equation4470 Fin3 refa82_inst.
Proof. unfold Equation4470. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4472 : ~ @Equation4472 Fin3 refa82_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4473 : ~ @Equation4473 Fin3 refa82_inst.
Proof. unfold Equation4473. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4480 : ~ @Equation4480 Fin3 refa82_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4598 : ~ @Equation4598 Fin3 refa82_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4599 : ~ @Equation4599 Fin3 refa82_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4605 : ~ @Equation4605 Fin3 refa82_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4606 : ~ @Equation4606 Fin3 refa82_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

Lemma refa82_not4608 : ~ @Equation4608 Fin3 refa82_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa82_inst, refa82_op in H. discriminate H. Qed.

(** ---- refa820 (Fin9) ---- *)

Definition refa820_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_1 | F9_0, F9_1 => F9_0 | F9_0, F9_2 => F9_0 | F9_0, F9_3 => F9_5 | F9_0, F9_4 => F9_3 | F9_0, F9_5 => F9_4 | F9_0, F9_6 => F9_7 | F9_0, F9_7 => F9_1 | F9_0, F9_8 => F9_2
  | F9_1, F9_0 => F9_2 | F9_1, F9_1 => F9_3 | F9_1, F9_2 => F9_7 | F9_1, F9_3 => F9_1 | F9_1, F9_4 => F9_6 | F9_1, F9_5 => F9_8 | F9_1, F9_6 => F9_3 | F9_1, F9_7 => F9_0 | F9_1, F9_8 => F9_3
  | F9_2, F9_0 => F9_1 | F9_2, F9_1 => F9_2 | F9_2, F9_2 => F9_1 | F9_2, F9_3 => F9_3 | F9_2, F9_4 => F9_4 | F9_2, F9_5 => F9_5 | F9_2, F9_6 => F9_0 | F9_2, F9_7 => F9_0 | F9_2, F9_8 => F9_7
  | F9_3, F9_0 => F9_3 | F9_3, F9_1 => F9_6 | F9_3, F9_2 => F9_4 | F9_3, F9_3 => F9_0 | F9_3, F9_4 => F9_0 | F9_3, F9_5 => F9_4 | F9_3, F9_6 => F9_8 | F9_3, F9_7 => F9_5 | F9_3, F9_8 => F9_1
  | F9_4, F9_0 => F9_4 | F9_4, F9_1 => F9_8 | F9_4, F9_2 => F9_5 | F9_4, F9_3 => F9_4 | F9_4, F9_4 => F9_0 | F9_4, F9_5 => F9_0 | F9_4, F9_6 => F9_1 | F9_4, F9_7 => F9_3 | F9_4, F9_8 => F9_6
  | F9_5, F9_0 => F9_5 | F9_5, F9_1 => F9_1 | F9_5, F9_2 => F9_3 | F9_5, F9_3 => F9_0 | F9_5, F9_4 => F9_4 | F9_5, F9_5 => F9_0 | F9_5, F9_6 => F9_6 | F9_5, F9_7 => F9_4 | F9_5, F9_8 => F9_8
  | F9_6, F9_0 => F9_0 | F9_6, F9_1 => F9_3 | F9_6, F9_2 => F9_2 | F9_6, F9_3 => F9_6 | F9_6, F9_4 => F9_8 | F9_6, F9_5 => F9_1 | F9_6, F9_6 => F9_3 | F9_6, F9_7 => F9_7 | F9_6, F9_8 => F9_3
  | F9_7, F9_0 => F9_0 | F9_7, F9_1 => F9_7 | F9_7, F9_2 => F9_1 | F9_7, F9_3 => F9_4 | F9_7, F9_4 => F9_5 | F9_7, F9_5 => F9_3 | F9_7, F9_6 => F9_2 | F9_7, F9_7 => F9_1 | F9_7, F9_8 => F9_0
  | F9_8, F9_0 => F9_7 | F9_8, F9_1 => F9_3 | F9_8, F9_2 => F9_0 | F9_8, F9_3 => F9_8 | F9_8, F9_4 => F9_1 | F9_8, F9_5 => F9_6 | F9_8, F9_6 => F9_3 | F9_8, F9_7 => F9_2 | F9_8, F9_8 => F9_3
  end.

#[local] Instance refa820_inst : Magma Fin9 := {| magma_op := refa820_op |}.

Lemma refa820_sat4167 : @Equation4167 Fin9 refa820_inst.
Proof. unfold Equation4167, magma_op, refa820_inst, refa820_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa820_not3456 : ~ @Equation3456 Fin9 refa820_inst.
Proof. unfold Equation3456. intro H. specialize (H F9_0). unfold magma_op, refa820_inst, refa820_op in H. discriminate H. Qed.

(** ---- refa821 (Fin5) ---- *)

Definition refa821_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_4 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa821_inst : Magma Fin5 := {| magma_op := refa821_op |}.

Lemma refa821_sat4175 : @Equation4175 Fin5 refa821_inst.
Proof. unfold Equation4175, magma_op, refa821_inst, refa821_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa821_not4090 : ~ @Equation4090 Fin5 refa821_inst.
Proof. unfold Equation4090. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa821_inst, refa821_op in H. discriminate H. Qed.

Lemma refa821_not4118 : ~ @Equation4118 Fin5 refa821_inst.
Proof. unfold Equation4118. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa821_inst, refa821_op in H. discriminate H. Qed.

Lemma refa821_not4128 : ~ @Equation4128 Fin5 refa821_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa821_inst, refa821_op in H. discriminate H. Qed.

Lemma refa821_not4131 : ~ @Equation4131 Fin5 refa821_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa821_inst, refa821_op in H. discriminate H. Qed.

Lemma refa821_not4269 : ~ @Equation4269 Fin5 refa821_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa821_inst, refa821_op in H. discriminate H. Qed.

Lemma refa821_not4272 : ~ @Equation4272 Fin5 refa821_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa821_inst, refa821_op in H. discriminate H. Qed.

Lemma refa821_not4606 : ~ @Equation4606 Fin5 refa821_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa821_inst, refa821_op in H. discriminate H. Qed.

(** ---- refa822 (Fin5) ---- *)

Definition refa822_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa822_inst : Magma Fin5 := {| magma_op := refa822_op |}.

Lemma refa822_sat418 : @Equation418 Fin5 refa822_inst.
Proof. unfold Equation418, magma_op, refa822_inst, refa822_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa822_not1023 : ~ @Equation1023 Fin5 refa822_inst.
Proof. unfold Equation1023. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa822_inst, refa822_op in H. discriminate H. Qed.

Lemma refa822_not3320 : ~ @Equation3320 Fin5 refa822_inst.
Proof. unfold Equation3320. intro H. specialize (H F5_2 F5_0 F5_1). unfold magma_op, refa822_inst, refa822_op in H. discriminate H. Qed.

Lemma refa822_not4127 : ~ @Equation4127 Fin5 refa822_inst.
Proof. unfold Equation4127. intro H. specialize (H F5_0 F5_2). unfold magma_op, refa822_inst, refa822_op in H. discriminate H. Qed.

Lemma refa822_not4131 : ~ @Equation4131 Fin5 refa822_inst.
Proof. unfold Equation4131. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa822_inst, refa822_op in H. discriminate H. Qed.

(** ---- refa823 (Fin5) ---- *)

Definition refa823_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_0 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa823_inst : Magma Fin5 := {| magma_op := refa823_op |}.

Lemma refa823_sat418 : @Equation418 Fin5 refa823_inst.
Proof. unfold Equation418, magma_op, refa823_inst, refa823_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa823_not3318 : ~ @Equation3318 Fin5 refa823_inst.
Proof. unfold Equation3318. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa823_inst, refa823_op in H. discriminate H. Qed.

(** ---- refa824 (Fin5) ---- *)

Definition refa824_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa824_inst : Magma Fin5 := {| magma_op := refa824_op |}.

Lemma refa824_sat418 : @Equation418 Fin5 refa824_inst.
Proof. unfold Equation418, magma_op, refa824_inst, refa824_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa824_not617 : ~ @Equation617 Fin5 refa824_inst.
Proof. unfold Equation617. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa824_inst, refa824_op in H. discriminate H. Qed.

Lemma refa824_not620 : ~ @Equation620 Fin5 refa824_inst.
Proof. unfold Equation620. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa824_inst, refa824_op in H. discriminate H. Qed.

Lemma refa824_not1022 : ~ @Equation1022 Fin5 refa824_inst.
Proof. unfold Equation1022. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa824_inst, refa824_op in H. discriminate H. Qed.

(** ---- refa825 (Fin5) ---- *)

Definition refa825_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_1 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa825_inst : Magma Fin5 := {| magma_op := refa825_op |}.

Lemma refa825_sat428 : @Equation428 Fin5 refa825_inst.
Proof. unfold Equation428, magma_op, refa825_inst, refa825_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa825_not824 : ~ @Equation824 Fin5 refa825_inst.
Proof. unfold Equation824. intro H. specialize (H F5_0 F5_1 F5_2). unfold magma_op, refa825_inst, refa825_op in H. discriminate H. Qed.

Lemma refa825_not3723 : ~ @Equation3723 Fin5 refa825_inst.
Proof. unfold Equation3723. intro H. specialize (H F5_0 F5_1 F5_2). unfold magma_op, refa825_inst, refa825_op in H. discriminate H. Qed.

(** ---- refa826 (Fin5) ---- *)

Definition refa826_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa826_inst : Magma Fin5 := {| magma_op := refa826_op |}.

Lemma refa826_sat428 : @Equation428 Fin5 refa826_inst.
Proof. unfold Equation428, magma_op, refa826_inst, refa826_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa826_not837 : ~ @Equation837 Fin5 refa826_inst.
Proof. unfold Equation837. intro H. specialize (H F5_2 F5_0 F5_1). unfold magma_op, refa826_inst, refa826_op in H. discriminate H. Qed.

(** ---- refa827 (Fin5) ---- *)

Definition refa827_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa827_inst : Magma Fin5 := {| magma_op := refa827_op |}.

Lemma refa827_sat433 : @Equation433 Fin5 refa827_inst.
Proof. unfold Equation433, magma_op, refa827_inst, refa827_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa827_not819 : ~ @Equation819 Fin5 refa827_inst.
Proof. unfold Equation819. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa827_inst, refa827_op in H. discriminate H. Qed.

Lemma refa827_not1023 : ~ @Equation1023 Fin5 refa827_inst.
Proof. unfold Equation1023. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa827_inst, refa827_op in H. discriminate H. Qed.

Lemma refa827_not1224 : ~ @Equation1224 Fin5 refa827_inst.
Proof. unfold Equation1224. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa827_inst, refa827_op in H. discriminate H. Qed.

Lemma refa827_not1226 : ~ @Equation1226 Fin5 refa827_inst.
Proof. unfold Equation1226. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa827_inst, refa827_op in H. discriminate H. Qed.

Lemma refa827_not1229 : ~ @Equation1229 Fin5 refa827_inst.
Proof. unfold Equation1229. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa827_inst, refa827_op in H. discriminate H. Qed.

Lemma refa827_not3306 : ~ @Equation3306 Fin5 refa827_inst.
Proof. unfold Equation3306. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa827_inst, refa827_op in H. discriminate H. Qed.

Lemma refa827_not3873 : ~ @Equation3873 Fin5 refa827_inst.
Proof. unfold Equation3873. intro H. specialize (H F5_0 F5_2 F5_1). unfold magma_op, refa827_inst, refa827_op in H. discriminate H. Qed.

Lemma refa827_not4070 : ~ @Equation4070 Fin5 refa827_inst.
Proof. unfold Equation4070. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa827_inst, refa827_op in H. discriminate H. Qed.

Lemma refa827_not4073 : ~ @Equation4073 Fin5 refa827_inst.
Proof. unfold Equation4073. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa827_inst, refa827_op in H. discriminate H. Qed.

Lemma refa827_not4584 : ~ @Equation4584 Fin5 refa827_inst.
Proof. unfold Equation4584. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa827_inst, refa827_op in H. discriminate H. Qed.

Lemma refa827_not4608 : ~ @Equation4608 Fin5 refa827_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa827_inst, refa827_op in H. discriminate H. Qed.

(** ---- refa828 (Fin5) ---- *)

Definition refa828_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa828_inst : Magma Fin5 := {| magma_op := refa828_op |}.

Lemma refa828_sat433 : @Equation433 Fin5 refa828_inst.
Proof. unfold Equation433, magma_op, refa828_inst, refa828_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa828_not439 : ~ @Equation439 Fin5 refa828_inst.
Proof. unfold Equation439. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa828_inst, refa828_op in H. discriminate H. Qed.

(** ---- refa829 (Fin6) ---- *)

Definition refa829_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_0 | F6_0, F6_3 => F6_1 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_2 | F6_1, F6_1 => F6_5 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_2 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_5 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_2 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_4 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_1 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_5 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa829_inst : Magma Fin6 := {| magma_op := refa829_op |}.

Lemma refa829_sat433 : @Equation433 Fin6 refa829_inst.
Proof. unfold Equation433, magma_op, refa829_inst, refa829_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa829_not818 : ~ @Equation818 Fin6 refa829_inst.
Proof. unfold Equation818. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa829_inst, refa829_op in H. discriminate H. Qed.

Lemma refa829_not833 : ~ @Equation833 Fin6 refa829_inst.
Proof. unfold Equation833. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa829_inst, refa829_op in H. discriminate H. Qed.

Lemma refa829_not836 : ~ @Equation836 Fin6 refa829_inst.
Proof. unfold Equation836. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa829_inst, refa829_op in H. discriminate H. Qed.

Lemma refa829_not1249 : ~ @Equation1249 Fin6 refa829_inst.
Proof. unfold Equation1249. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa829_inst, refa829_op in H. discriminate H. Qed.

Lemma refa829_not3315 : ~ @Equation3315 Fin6 refa829_inst.
Proof. unfold Equation3315. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa829_inst, refa829_op in H. discriminate H. Qed.

Lemma refa829_not3864 : ~ @Equation3864 Fin6 refa829_inst.
Proof. unfold Equation3864. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa829_inst, refa829_op in H. discriminate H. Qed.

Lemma refa829_not3870 : ~ @Equation3870 Fin6 refa829_inst.
Proof. unfold Equation3870. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa829_inst, refa829_op in H. discriminate H. Qed.

Lemma refa829_not4631 : ~ @Equation4631 Fin6 refa829_inst.
Proof. unfold Equation4631. intro H. specialize (H F6_0 F6_0 F6_4). unfold magma_op, refa829_inst, refa829_op in H. discriminate H. Qed.

(** ---- refa83 (Fin3) ---- *)

Definition refa83_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa83_inst : Magma Fin3 := {| magma_op := refa83_op |}.

Lemma refa83_sat11 : @Equation11 Fin3 refa83_inst.
Proof. unfold Equation11, magma_op, refa83_inst, refa83_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa83_sat105 : @Equation105 Fin3 refa83_inst.
Proof. unfold Equation105, magma_op, refa83_inst, refa83_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa83_sat427 : @Equation427 Fin3 refa83_inst.
Proof. unfold Equation427, magma_op, refa83_inst, refa83_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa83_sat1045 : @Equation1045 Fin3 refa83_inst.
Proof. unfold Equation1045, magma_op, refa83_inst, refa83_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa83_sat1647 : @Equation1647 Fin3 refa83_inst.
Proof. unfold Equation1647, magma_op, refa83_inst, refa83_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa83_sat1840 : @Equation1840 Fin3 refa83_inst.
Proof. unfold Equation1840, magma_op, refa83_inst, refa83_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa83_sat3282 : @Equation3282 Fin3 refa83_inst.
Proof. unfold Equation3282, magma_op, refa83_inst, refa83_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa83_sat3891 : @Equation3891 Fin3 refa83_inst.
Proof. unfold Equation3891, magma_op, refa83_inst, refa83_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa83_sat3962 : @Equation3962 Fin3 refa83_inst.
Proof. unfold Equation3962, magma_op, refa83_inst, refa83_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa83_not108 : ~ @Equation108 Fin3 refa83_inst.
Proof. unfold Equation108. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not1023 : ~ @Equation1023 Fin3 refa83_inst.
Proof. unfold Equation1023. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not1025 : ~ @Equation1025 Fin3 refa83_inst.
Proof. unfold Equation1025. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not1038 : ~ @Equation1038 Fin3 refa83_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not1048 : ~ @Equation1048 Fin3 refa83_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not1224 : ~ @Equation1224 Fin3 refa83_inst.
Proof. unfold Equation1224. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not1226 : ~ @Equation1226 Fin3 refa83_inst.
Proof. unfold Equation1226. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not1229 : ~ @Equation1229 Fin3 refa83_inst.
Proof. unfold Equation1229. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not1231 : ~ @Equation1231 Fin3 refa83_inst.
Proof. unfold Equation1231. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not1238 : ~ @Equation1238 Fin3 refa83_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not1242 : ~ @Equation1242 Fin3 refa83_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not1251 : ~ @Equation1251 Fin3 refa83_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not1252 : ~ @Equation1252 Fin3 refa83_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not3279 : ~ @Equation3279 Fin3 refa83_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not3685 : ~ @Equation3685 Fin3 refa83_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not3687 : ~ @Equation3687 Fin3 refa83_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not3881 : ~ @Equation3881 Fin3 refa83_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_1 F3_0). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not3888 : ~ @Equation3888 Fin3 refa83_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not3895 : ~ @Equation3895 Fin3 refa83_inst.
Proof. unfold Equation3895. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not4065 : ~ @Equation4065 Fin3 refa83_inst.
Proof. unfold Equation4065. intro H. specialize (H F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not4269 : ~ @Equation4269 Fin3 refa83_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not4314 : ~ @Equation4314 Fin3 refa83_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not4591 : ~ @Equation4591 Fin3 refa83_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not4598 : ~ @Equation4598 Fin3 refa83_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not4606 : ~ @Equation4606 Fin3 refa83_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not4608 : ~ @Equation4608 Fin3 refa83_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not4631 : ~ @Equation4631 Fin3 refa83_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

Lemma refa83_not4647 : ~ @Equation4647 Fin3 refa83_inst.
Proof. unfold Equation4647. intro H. specialize (H F3_0 F3_1 F3_2). unfold magma_op, refa83_inst, refa83_op in H. discriminate H. Qed.

(** ---- refa830 (Fin6) ---- *)

Definition refa830_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_4 | F6_0, F6_2 => F6_0 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_1 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_5 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_2 | F6_2, F6_2 => F6_5 | F6_2, F6_3 => F6_4 | F6_2, F6_4 => F6_2 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_3 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_4 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_5 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa830_inst : Magma Fin6 := {| magma_op := refa830_op |}.

Lemma refa830_sat433 : @Equation433 Fin6 refa830_inst.
Proof. unfold Equation433, magma_op, refa830_inst, refa830_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa830_not820 : ~ @Equation820 Fin6 refa830_inst.
Proof. unfold Equation820. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa830_inst, refa830_op in H. discriminate H. Qed.

(** ---- refa831 (Fin5) ---- *)

Definition refa831_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_4 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_4 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa831_inst : Magma Fin5 := {| magma_op := refa831_op |}.

Lemma refa831_sat434 : @Equation434 Fin5 refa831_inst.
Proof. unfold Equation434, magma_op, refa831_inst, refa831_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa831_not1023 : ~ @Equation1023 Fin5 refa831_inst.
Proof. unfold Equation1023. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa831_inst, refa831_op in H. discriminate H. Qed.

(** ---- refa832 (Fin8) ---- *)

Definition refa832_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_1 | F8_0, F8_1 => F8_4 | F8_0, F8_2 => F8_1 | F8_0, F8_3 => F8_3 | F8_0, F8_4 => F8_5 | F8_0, F8_5 => F8_3 | F8_0, F8_6 => F8_4 | F8_0, F8_7 => F8_5
  | F8_1, F8_0 => F8_7 | F8_1, F8_1 => F8_5 | F8_1, F8_2 => F8_3 | F8_1, F8_3 => F8_3 | F8_1, F8_4 => F8_3 | F8_1, F8_5 => F8_3 | F8_1, F8_6 => F8_3 | F8_1, F8_7 => F8_3
  | F8_2, F8_0 => F8_6 | F8_2, F8_1 => F8_4 | F8_2, F8_2 => F8_6 | F8_2, F8_3 => F8_3 | F8_2, F8_4 => F8_3 | F8_2, F8_5 => F8_3 | F8_2, F8_6 => F8_4 | F8_2, F8_7 => F8_5
  | F8_3, F8_0 => F8_5 | F8_3, F8_1 => F8_3 | F8_3, F8_2 => F8_5 | F8_3, F8_3 => F8_3 | F8_3, F8_4 => F8_3 | F8_3, F8_5 => F8_3 | F8_3, F8_6 => F8_3 | F8_3, F8_7 => F8_3
  | F8_4, F8_0 => F8_5 | F8_4, F8_1 => F8_3 | F8_4, F8_2 => F8_5 | F8_4, F8_3 => F8_3 | F8_4, F8_4 => F8_3 | F8_4, F8_5 => F8_3 | F8_4, F8_6 => F8_3 | F8_4, F8_7 => F8_3
  | F8_5, F8_0 => F8_5 | F8_5, F8_1 => F8_3 | F8_5, F8_2 => F8_5 | F8_5, F8_3 => F8_3 | F8_5, F8_4 => F8_3 | F8_5, F8_5 => F8_3 | F8_5, F8_6 => F8_3 | F8_5, F8_7 => F8_3
  | F8_6, F8_0 => F8_7 | F8_6, F8_1 => F8_5 | F8_6, F8_2 => F8_3 | F8_6, F8_3 => F8_3 | F8_6, F8_4 => F8_3 | F8_6, F8_5 => F8_3 | F8_6, F8_6 => F8_3 | F8_6, F8_7 => F8_3
  | F8_7, F8_0 => F8_5 | F8_7, F8_1 => F8_3 | F8_7, F8_2 => F8_5 | F8_7, F8_3 => F8_3 | F8_7, F8_4 => F8_3 | F8_7, F8_5 => F8_3 | F8_7, F8_6 => F8_3 | F8_7, F8_7 => F8_3
  end.

#[local] Instance refa832_inst : Magma Fin8 := {| magma_op := refa832_op |}.

Lemma refa832_sat4364 : @Equation4364 Fin8 refa832_inst.
Proof. unfold Equation4364, magma_op, refa832_inst, refa832_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa832_not4358 : ~ @Equation4358 Fin8 refa832_inst.
Proof. unfold Equation4358. intro H. specialize (H F8_0 F8_1 F8_2). unfold magma_op, refa832_inst, refa832_op in H. discriminate H. Qed.

Lemma refa832_not4362 : ~ @Equation4362 Fin8 refa832_inst.
Proof. unfold Equation4362. intro H. specialize (H F8_0 F8_1 F8_2). unfold magma_op, refa832_inst, refa832_op in H. discriminate H. Qed.

Lemma refa832_not4369 : ~ @Equation4369 Fin8 refa832_inst.
Proof. unfold Equation4369. intro H. specialize (H F8_0 F8_1 F8_2). unfold magma_op, refa832_inst, refa832_op in H. discriminate H. Qed.

Lemma refa832_not4380 : ~ @Equation4380 Fin8 refa832_inst.
Proof. unfold Equation4380. intro H. specialize (H F8_0). unfold magma_op, refa832_inst, refa832_op in H. discriminate H. Qed.

Lemma refa832_not4598 : ~ @Equation4598 Fin8 refa832_inst.
Proof. unfold Equation4598. intro H. specialize (H F8_0 F8_2). unfold magma_op, refa832_inst, refa832_op in H. discriminate H. Qed.

(** ---- refa833 (Fin5) ---- *)

Definition refa833_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_3 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_3
  end.

#[local] Instance refa833_inst : Magma Fin5 := {| magma_op := refa833_op |}.

Lemma refa833_sat4418 : @Equation4418 Fin5 refa833_inst.
Proof. unfold Equation4418, magma_op, refa833_inst, refa833_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa833_not4269 : ~ @Equation4269 Fin5 refa833_inst.
Proof. unfold Equation4269. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa833_inst, refa833_op in H. discriminate H. Qed.

Lemma refa833_not4273 : ~ @Equation4273 Fin5 refa833_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa833_inst, refa833_op in H. discriminate H. Qed.

Lemma refa833_not4283 : ~ @Equation4283 Fin5 refa833_inst.
Proof. unfold Equation4283. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa833_inst, refa833_op in H. discriminate H. Qed.

Lemma refa833_not4291 : ~ @Equation4291 Fin5 refa833_inst.
Proof. unfold Equation4291. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa833_inst, refa833_op in H. discriminate H. Qed.

Lemma refa833_not4314 : ~ @Equation4314 Fin5 refa833_inst.
Proof. unfold Equation4314. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa833_inst, refa833_op in H. discriminate H. Qed.

Lemma refa833_not4320 : ~ @Equation4320 Fin5 refa833_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa833_inst, refa833_op in H. discriminate H. Qed.

Lemma refa833_not4321 : ~ @Equation4321 Fin5 refa833_inst.
Proof. unfold Equation4321. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa833_inst, refa833_op in H. discriminate H. Qed.

Lemma refa833_not4433 : ~ @Equation4433 Fin5 refa833_inst.
Proof. unfold Equation4433. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa833_inst, refa833_op in H. discriminate H. Qed.

Lemma refa833_not4435 : ~ @Equation4435 Fin5 refa833_inst.
Proof. unfold Equation4435. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa833_inst, refa833_op in H. discriminate H. Qed.

Lemma refa833_not4436 : ~ @Equation4436 Fin5 refa833_inst.
Proof. unfold Equation4436. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa833_inst, refa833_op in H. discriminate H. Qed.

Lemma refa833_not4442 : ~ @Equation4442 Fin5 refa833_inst.
Proof. unfold Equation4442. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa833_inst, refa833_op in H. discriminate H. Qed.

Lemma refa833_not4443 : ~ @Equation4443 Fin5 refa833_inst.
Proof. unfold Equation4443. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa833_inst, refa833_op in H. discriminate H. Qed.

Lemma refa833_not4445 : ~ @Equation4445 Fin5 refa833_inst.
Proof. unfold Equation4445. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa833_inst, refa833_op in H. discriminate H. Qed.

(** ---- refa834 (Fin5) ---- *)

Definition refa834_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_3 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_3
  end.

#[local] Instance refa834_inst : Magma Fin5 := {| magma_op := refa834_op |}.

Lemma refa834_sat4418 : @Equation4418 Fin5 refa834_inst.
Proof. unfold Equation4418, magma_op, refa834_inst, refa834_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa834_not4270 : ~ @Equation4270 Fin5 refa834_inst.
Proof. unfold Equation4270. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa834_inst, refa834_op in H. discriminate H. Qed.

Lemma refa834_not4272 : ~ @Equation4272 Fin5 refa834_inst.
Proof. unfold Equation4272. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa834_inst, refa834_op in H. discriminate H. Qed.

Lemma refa834_not4284 : ~ @Equation4284 Fin5 refa834_inst.
Proof. unfold Equation4284. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa834_inst, refa834_op in H. discriminate H. Qed.

Lemma refa834_not4290 : ~ @Equation4290 Fin5 refa834_inst.
Proof. unfold Equation4290. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa834_inst, refa834_op in H. discriminate H. Qed.

Lemma refa834_not4343 : ~ @Equation4343 Fin5 refa834_inst.
Proof. unfold Equation4343. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa834_inst, refa834_op in H. discriminate H. Qed.

Lemma refa834_not4470 : ~ @Equation4470 Fin5 refa834_inst.
Proof. unfold Equation4470. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa834_inst, refa834_op in H. discriminate H. Qed.

Lemma refa834_not4472 : ~ @Equation4472 Fin5 refa834_inst.
Proof. unfold Equation4472. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa834_inst, refa834_op in H. discriminate H. Qed.

Lemma refa834_not4473 : ~ @Equation4473 Fin5 refa834_inst.
Proof. unfold Equation4473. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa834_inst, refa834_op in H. discriminate H. Qed.

Lemma refa834_not4479 : ~ @Equation4479 Fin5 refa834_inst.
Proof. unfold Equation4479. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa834_inst, refa834_op in H. discriminate H. Qed.

Lemma refa834_not4480 : ~ @Equation4480 Fin5 refa834_inst.
Proof. unfold Equation4480. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa834_inst, refa834_op in H. discriminate H. Qed.

Lemma refa834_not4482 : ~ @Equation4482 Fin5 refa834_inst.
Proof. unfold Equation4482. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa834_inst, refa834_op in H. discriminate H. Qed.

(** ---- refa835 (Fin5) ---- *)

Definition refa835_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa835_inst : Magma Fin5 := {| magma_op := refa835_op |}.

Lemma refa835_sat443 : @Equation443 Fin5 refa835_inst.
Proof. unfold Equation443, magma_op, refa835_inst, refa835_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa835_not3862 : ~ @Equation3862 Fin5 refa835_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_0). unfold magma_op, refa835_inst, refa835_op in H. discriminate H. Qed.

(** ---- refa836 (Fin5) ---- *)

Definition refa836_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_0 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa836_inst : Magma Fin5 := {| magma_op := refa836_op |}.

Lemma refa836_sat443 : @Equation443 Fin5 refa836_inst.
Proof. unfold Equation443, magma_op, refa836_inst, refa836_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa836_not817 : ~ @Equation817 Fin5 refa836_inst.
Proof. unfold Equation817. intro H. specialize (H F5_0). unfold magma_op, refa836_inst, refa836_op in H. discriminate H. Qed.

(** ---- refa837 (Fin5) ---- *)

Definition refa837_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_4 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_4 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_3 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_3
  end.

#[local] Instance refa837_inst : Magma Fin5 := {| magma_op := refa837_op |}.

Lemma refa837_sat4545 : @Equation4545 Fin5 refa837_inst.
Proof. unfold Equation4545, magma_op, refa837_inst, refa837_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa837_not4396 : ~ @Equation4396 Fin5 refa837_inst.
Proof. unfold Equation4396. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4398 : ~ @Equation4398 Fin5 refa837_inst.
Proof. unfold Equation4398. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4406 : ~ @Equation4406 Fin5 refa837_inst.
Proof. unfold Equation4406. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4408 : ~ @Equation4408 Fin5 refa837_inst.
Proof. unfold Equation4408. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4433 : ~ @Equation4433 Fin5 refa837_inst.
Proof. unfold Equation4433. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4435 : ~ @Equation4435 Fin5 refa837_inst.
Proof. unfold Equation4435. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4443 : ~ @Equation4443 Fin5 refa837_inst.
Proof. unfold Equation4443. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4445 : ~ @Equation4445 Fin5 refa837_inst.
Proof. unfold Equation4445. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4470 : ~ @Equation4470 Fin5 refa837_inst.
Proof. unfold Equation4470. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4472 : ~ @Equation4472 Fin5 refa837_inst.
Proof. unfold Equation4472. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4480 : ~ @Equation4480 Fin5 refa837_inst.
Proof. unfold Equation4480. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4482 : ~ @Equation4482 Fin5 refa837_inst.
Proof. unfold Equation4482. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4583 : ~ @Equation4583 Fin5 refa837_inst.
Proof. unfold Equation4583. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4598 : ~ @Equation4598 Fin5 refa837_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4599 : ~ @Equation4599 Fin5 refa837_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4605 : ~ @Equation4605 Fin5 refa837_inst.
Proof. unfold Equation4605. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4606 : ~ @Equation4606 Fin5 refa837_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4608 : ~ @Equation4608 Fin5 refa837_inst.
Proof. unfold Equation4608. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4622 : ~ @Equation4622 Fin5 refa837_inst.
Proof. unfold Equation4622. intro H. specialize (H F5_0 F5_1 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4629 : ~ @Equation4629 Fin5 refa837_inst.
Proof. unfold Equation4629. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4631 : ~ @Equation4631 Fin5 refa837_inst.
Proof. unfold Equation4631. intro H. specialize (H F5_0 F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4635 : ~ @Equation4635 Fin5 refa837_inst.
Proof. unfold Equation4635. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4636 : ~ @Equation4636 Fin5 refa837_inst.
Proof. unfold Equation4636. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

Lemma refa837_not4647 : ~ @Equation4647 Fin5 refa837_inst.
Proof. unfold Equation4647. intro H. specialize (H F5_0 F5_0 F5_1). unfold magma_op, refa837_inst, refa837_op in H. discriminate H. Qed.

(** ---- refa838 (Fin6) ---- *)

Definition refa838_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_3 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_4 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_5 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_5
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_5 | F6_2, F6_2 => F6_5 | F6_2, F6_3 => F6_5 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_5
  | F6_3, F6_0 => F6_5 | F6_3, F6_1 => F6_5 | F6_3, F6_2 => F6_5 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_5
  | F6_4, F6_0 => F6_3 | F6_4, F6_1 => F6_5 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_5
  | F6_5, F6_0 => F6_5 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa838_inst : Magma Fin6 := {| magma_op := refa838_op |}.

Lemma refa838_sat4541 : @Equation4541 Fin6 refa838_inst.
Proof. unfold Equation4541, magma_op, refa838_inst, refa838_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa838_not4283 : ~ @Equation4283 Fin6 refa838_inst.
Proof. unfold Equation4283. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa838_inst, refa838_op in H. discriminate H. Qed.

Lemma refa838_not4290 : ~ @Equation4290 Fin6 refa838_inst.
Proof. unfold Equation4290. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa838_inst, refa838_op in H. discriminate H. Qed.

Lemma refa838_not4396 : ~ @Equation4396 Fin6 refa838_inst.
Proof. unfold Equation4396. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa838_inst, refa838_op in H. discriminate H. Qed.

Lemma refa838_not4398 : ~ @Equation4398 Fin6 refa838_inst.
Proof. unfold Equation4398. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa838_inst, refa838_op in H. discriminate H. Qed.

Lemma refa838_not4442 : ~ @Equation4442 Fin6 refa838_inst.
Proof. unfold Equation4442. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa838_inst, refa838_op in H. discriminate H. Qed.

Lemma refa838_not4473 : ~ @Equation4473 Fin6 refa838_inst.
Proof. unfold Equation4473. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa838_inst, refa838_op in H. discriminate H. Qed.

Lemma refa838_not4605 : ~ @Equation4605 Fin6 refa838_inst.
Proof. unfold Equation4605. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa838_inst, refa838_op in H. discriminate H. Qed.

Lemma refa838_not4635 : ~ @Equation4635 Fin6 refa838_inst.
Proof. unfold Equation4635. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa838_inst, refa838_op in H. discriminate H. Qed.

(** ---- refa839 (Fin6) ---- *)

Definition refa839_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_4 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_3 | F6_0, F6_3 => F6_3 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_3
  | F6_1, F6_0 => F6_3 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_3 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_3
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_3 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_3
  | F6_3, F6_0 => F6_3 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_3 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_3 | F6_4, F6_5 => F6_3
  | F6_5, F6_0 => F6_3 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_3 | F6_5, F6_3 => F6_3 | F6_5, F6_4 => F6_3 | F6_5, F6_5 => F6_3
  end.

#[local] Instance refa839_inst : Magma Fin6 := {| magma_op := refa839_op |}.

Lemma refa839_sat4541 : @Equation4541 Fin6 refa839_inst.
Proof. unfold Equation4541, magma_op, refa839_inst, refa839_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa839_not4320 : ~ @Equation4320 Fin6 refa839_inst.
Proof. unfold Equation4320. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa839_inst, refa839_op in H. discriminate H. Qed.

Lemma refa839_not4435 : ~ @Equation4435 Fin6 refa839_inst.
Proof. unfold Equation4435. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa839_inst, refa839_op in H. discriminate H. Qed.

Lemma refa839_not4482 : ~ @Equation4482 Fin6 refa839_inst.
Proof. unfold Equation4482. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa839_inst, refa839_op in H. discriminate H. Qed.

Lemma refa839_not4598 : ~ @Equation4598 Fin6 refa839_inst.
Proof. unfold Equation4598. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa839_inst, refa839_op in H. discriminate H. Qed.

(** ---- refa84 (Fin3) ---- *)

Definition refa84_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_0 | F3_0, F3_2 => F3_0
  | F3_1, F3_0 => F3_1 | F3_1, F3_1 => F3_1 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_2 | F3_2, F3_1 => F3_2 | F3_2, F3_2 => F3_2
  end.

#[local] Instance refa84_inst : Magma Fin3 := {| magma_op := refa84_op |}.

Lemma refa84_sat1237 : @Equation1237 Fin3 refa84_inst.
Proof. unfold Equation1237, magma_op, refa84_inst, refa84_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa84_sat3716 : @Equation3716 Fin3 refa84_inst.
Proof. unfold Equation3716, magma_op, refa84_inst, refa84_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa84_sat3726 : @Equation3726 Fin3 refa84_inst.
Proof. unfold Equation3726, magma_op, refa84_inst, refa84_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa84_sat3930 : @Equation3930 Fin3 refa84_inst.
Proof. unfold Equation3930, magma_op, refa84_inst, refa84_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa84_sat3931 : @Equation3931 Fin3 refa84_inst.
Proof. unfold Equation3931, magma_op, refa84_inst, refa84_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa84_sat4120 : @Equation4120 Fin3 refa84_inst.
Proof. unfold Equation4120, magma_op, refa84_inst, refa84_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa84_sat4511 : @Equation4511 Fin3 refa84_inst.
Proof. unfold Equation4511, magma_op, refa84_inst, refa84_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa84_not55 : ~ @Equation55 Fin3 refa84_inst.
Proof. unfold Equation55. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not56 : ~ @Equation56 Fin3 refa84_inst.
Proof. unfold Equation56. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not105 : ~ @Equation105 Fin3 refa84_inst.
Proof. unfold Equation105. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not107 : ~ @Equation107 Fin3 refa84_inst.
Proof. unfold Equation107. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not108 : ~ @Equation108 Fin3 refa84_inst.
Proof. unfold Equation108. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not159 : ~ @Equation159 Fin3 refa84_inst.
Proof. unfold Equation159. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not160 : ~ @Equation160 Fin3 refa84_inst.
Proof. unfold Equation160. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not206 : ~ @Equation206 Fin3 refa84_inst.
Proof. unfold Equation206. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not209 : ~ @Equation209 Fin3 refa84_inst.
Proof. unfold Equation209. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not211 : ~ @Equation211 Fin3 refa84_inst.
Proof. unfold Equation211. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not261 : ~ @Equation261 Fin3 refa84_inst.
Proof. unfold Equation261. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not263 : ~ @Equation263 Fin3 refa84_inst.
Proof. unfold Equation263. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not264 : ~ @Equation264 Fin3 refa84_inst.
Proof. unfold Equation264. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not426 : ~ @Equation426 Fin3 refa84_inst.
Proof. unfold Equation426. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not427 : ~ @Equation427 Fin3 refa84_inst.
Proof. unfold Equation427. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not429 : ~ @Equation429 Fin3 refa84_inst.
Proof. unfold Equation429. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not430 : ~ @Equation430 Fin3 refa84_inst.
Proof. unfold Equation430. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not436 : ~ @Equation436 Fin3 refa84_inst.
Proof. unfold Equation436. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not437 : ~ @Equation437 Fin3 refa84_inst.
Proof. unfold Equation437. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not439 : ~ @Equation439 Fin3 refa84_inst.
Proof. unfold Equation439. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not440 : ~ @Equation440 Fin3 refa84_inst.
Proof. unfold Equation440. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not464 : ~ @Equation464 Fin3 refa84_inst.
Proof. unfold Equation464. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not466 : ~ @Equation466 Fin3 refa84_inst.
Proof. unfold Equation466. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not473 : ~ @Equation473 Fin3 refa84_inst.
Proof. unfold Equation473. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not477 : ~ @Equation477 Fin3 refa84_inst.
Proof. unfold Equation477. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not504 : ~ @Equation504 Fin3 refa84_inst.
Proof. unfold Equation504. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not511 : ~ @Equation511 Fin3 refa84_inst.
Proof. unfold Equation511. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not513 : ~ @Equation513 Fin3 refa84_inst.
Proof. unfold Equation513. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not629 : ~ @Equation629 Fin3 refa84_inst.
Proof. unfold Equation629. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not630 : ~ @Equation630 Fin3 refa84_inst.
Proof. unfold Equation630. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not632 : ~ @Equation632 Fin3 refa84_inst.
Proof. unfold Equation632. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not633 : ~ @Equation633 Fin3 refa84_inst.
Proof. unfold Equation633. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not639 : ~ @Equation639 Fin3 refa84_inst.
Proof. unfold Equation639. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not640 : ~ @Equation640 Fin3 refa84_inst.
Proof. unfold Equation640. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not642 : ~ @Equation642 Fin3 refa84_inst.
Proof. unfold Equation642. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not643 : ~ @Equation643 Fin3 refa84_inst.
Proof. unfold Equation643. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not667 : ~ @Equation667 Fin3 refa84_inst.
Proof. unfold Equation667. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not669 : ~ @Equation669 Fin3 refa84_inst.
Proof. unfold Equation669. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not676 : ~ @Equation676 Fin3 refa84_inst.
Proof. unfold Equation676. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not680 : ~ @Equation680 Fin3 refa84_inst.
Proof. unfold Equation680. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not707 : ~ @Equation707 Fin3 refa84_inst.
Proof. unfold Equation707. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not716 : ~ @Equation716 Fin3 refa84_inst.
Proof. unfold Equation716. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not832 : ~ @Equation832 Fin3 refa84_inst.
Proof. unfold Equation832. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not833 : ~ @Equation833 Fin3 refa84_inst.
Proof. unfold Equation833. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not835 : ~ @Equation835 Fin3 refa84_inst.
Proof. unfold Equation835. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not836 : ~ @Equation836 Fin3 refa84_inst.
Proof. unfold Equation836. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not842 : ~ @Equation842 Fin3 refa84_inst.
Proof. unfold Equation842. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not843 : ~ @Equation843 Fin3 refa84_inst.
Proof. unfold Equation843. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not845 : ~ @Equation845 Fin3 refa84_inst.
Proof. unfold Equation845. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not846 : ~ @Equation846 Fin3 refa84_inst.
Proof. unfold Equation846. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not870 : ~ @Equation870 Fin3 refa84_inst.
Proof. unfold Equation870. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not872 : ~ @Equation872 Fin3 refa84_inst.
Proof. unfold Equation872. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not879 : ~ @Equation879 Fin3 refa84_inst.
Proof. unfold Equation879. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not883 : ~ @Equation883 Fin3 refa84_inst.
Proof. unfold Equation883. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not906 : ~ @Equation906 Fin3 refa84_inst.
Proof. unfold Equation906. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not917 : ~ @Equation917 Fin3 refa84_inst.
Proof. unfold Equation917. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1035 : ~ @Equation1035 Fin3 refa84_inst.
Proof. unfold Equation1035. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1036 : ~ @Equation1036 Fin3 refa84_inst.
Proof. unfold Equation1036. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1038 : ~ @Equation1038 Fin3 refa84_inst.
Proof. unfold Equation1038. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1039 : ~ @Equation1039 Fin3 refa84_inst.
Proof. unfold Equation1039. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1045 : ~ @Equation1045 Fin3 refa84_inst.
Proof. unfold Equation1045. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1046 : ~ @Equation1046 Fin3 refa84_inst.
Proof. unfold Equation1046. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1048 : ~ @Equation1048 Fin3 refa84_inst.
Proof. unfold Equation1048. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1049 : ~ @Equation1049 Fin3 refa84_inst.
Proof. unfold Equation1049. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1086 : ~ @Equation1086 Fin3 refa84_inst.
Proof. unfold Equation1086. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1113 : ~ @Equation1113 Fin3 refa84_inst.
Proof. unfold Equation1113. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1238 : ~ @Equation1238 Fin3 refa84_inst.
Proof. unfold Equation1238. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1239 : ~ @Equation1239 Fin3 refa84_inst.
Proof. unfold Equation1239. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1241 : ~ @Equation1241 Fin3 refa84_inst.
Proof. unfold Equation1241. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1242 : ~ @Equation1242 Fin3 refa84_inst.
Proof. unfold Equation1242. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1248 : ~ @Equation1248 Fin3 refa84_inst.
Proof. unfold Equation1248. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1249 : ~ @Equation1249 Fin3 refa84_inst.
Proof. unfold Equation1249. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1251 : ~ @Equation1251 Fin3 refa84_inst.
Proof. unfold Equation1251. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1252 : ~ @Equation1252 Fin3 refa84_inst.
Proof. unfold Equation1252. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1276 : ~ @Equation1276 Fin3 refa84_inst.
Proof. unfold Equation1276. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1289 : ~ @Equation1289 Fin3 refa84_inst.
Proof. unfold Equation1289. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1431 : ~ @Equation1431 Fin3 refa84_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1432 : ~ @Equation1432 Fin3 refa84_inst.
Proof. unfold Equation1432. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1434 : ~ @Equation1434 Fin3 refa84_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1435 : ~ @Equation1435 Fin3 refa84_inst.
Proof. unfold Equation1435. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1441 : ~ @Equation1441 Fin3 refa84_inst.
Proof. unfold Equation1441. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1444 : ~ @Equation1444 Fin3 refa84_inst.
Proof. unfold Equation1444. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1445 : ~ @Equation1445 Fin3 refa84_inst.
Proof. unfold Equation1445. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1451 : ~ @Equation1451 Fin3 refa84_inst.
Proof. unfold Equation1451. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1454 : ~ @Equation1454 Fin3 refa84_inst.
Proof. unfold Equation1454. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1455 : ~ @Equation1455 Fin3 refa84_inst.
Proof. unfold Equation1455. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1519 : ~ @Equation1519 Fin3 refa84_inst.
Proof. unfold Equation1519. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1634 : ~ @Equation1634 Fin3 refa84_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1635 : ~ @Equation1635 Fin3 refa84_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1637 : ~ @Equation1637 Fin3 refa84_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1638 : ~ @Equation1638 Fin3 refa84_inst.
Proof. unfold Equation1638. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1644 : ~ @Equation1644 Fin3 refa84_inst.
Proof. unfold Equation1644. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1645 : ~ @Equation1645 Fin3 refa84_inst.
Proof. unfold Equation1645. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1648 : ~ @Equation1648 Fin3 refa84_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1654 : ~ @Equation1654 Fin3 refa84_inst.
Proof. unfold Equation1654. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1655 : ~ @Equation1655 Fin3 refa84_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1657 : ~ @Equation1657 Fin3 refa84_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1658 : ~ @Equation1658 Fin3 refa84_inst.
Proof. unfold Equation1658. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1682 : ~ @Equation1682 Fin3 refa84_inst.
Proof. unfold Equation1682. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1722 : ~ @Equation1722 Fin3 refa84_inst.
Proof. unfold Equation1722. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1834 : ~ @Equation1834 Fin3 refa84_inst.
Proof. unfold Equation1834. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1840 : ~ @Equation1840 Fin3 refa84_inst.
Proof. unfold Equation1840. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1841 : ~ @Equation1841 Fin3 refa84_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1847 : ~ @Equation1847 Fin3 refa84_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1848 : ~ @Equation1848 Fin3 refa84_inst.
Proof. unfold Equation1848. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1850 : ~ @Equation1850 Fin3 refa84_inst.
Proof. unfold Equation1850. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1851 : ~ @Equation1851 Fin3 refa84_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1857 : ~ @Equation1857 Fin3 refa84_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1858 : ~ @Equation1858 Fin3 refa84_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1860 : ~ @Equation1860 Fin3 refa84_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1861 : ~ @Equation1861 Fin3 refa84_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1885 : ~ @Equation1885 Fin3 refa84_inst.
Proof. unfold Equation1885. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not1925 : ~ @Equation1925 Fin3 refa84_inst.
Proof. unfold Equation1925. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2037 : ~ @Equation2037 Fin3 refa84_inst.
Proof. unfold Equation2037. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2038 : ~ @Equation2038 Fin3 refa84_inst.
Proof. unfold Equation2038. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2040 : ~ @Equation2040 Fin3 refa84_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2041 : ~ @Equation2041 Fin3 refa84_inst.
Proof. unfold Equation2041. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2043 : ~ @Equation2043 Fin3 refa84_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2044 : ~ @Equation2044 Fin3 refa84_inst.
Proof. unfold Equation2044. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2050 : ~ @Equation2050 Fin3 refa84_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2053 : ~ @Equation2053 Fin3 refa84_inst.
Proof. unfold Equation2053. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2054 : ~ @Equation2054 Fin3 refa84_inst.
Proof. unfold Equation2054. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2060 : ~ @Equation2060 Fin3 refa84_inst.
Proof. unfold Equation2060. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2061 : ~ @Equation2061 Fin3 refa84_inst.
Proof. unfold Equation2061. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2063 : ~ @Equation2063 Fin3 refa84_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2064 : ~ @Equation2064 Fin3 refa84_inst.
Proof. unfold Equation2064. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2088 : ~ @Equation2088 Fin3 refa84_inst.
Proof. unfold Equation2088. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2101 : ~ @Equation2101 Fin3 refa84_inst.
Proof. unfold Equation2101. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2128 : ~ @Equation2128 Fin3 refa84_inst.
Proof. unfold Equation2128. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2241 : ~ @Equation2241 Fin3 refa84_inst.
Proof. unfold Equation2241. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2244 : ~ @Equation2244 Fin3 refa84_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2247 : ~ @Equation2247 Fin3 refa84_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2253 : ~ @Equation2253 Fin3 refa84_inst.
Proof. unfold Equation2253. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2254 : ~ @Equation2254 Fin3 refa84_inst.
Proof. unfold Equation2254. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2256 : ~ @Equation2256 Fin3 refa84_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2257 : ~ @Equation2257 Fin3 refa84_inst.
Proof. unfold Equation2257. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2263 : ~ @Equation2263 Fin3 refa84_inst.
Proof. unfold Equation2263. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2264 : ~ @Equation2264 Fin3 refa84_inst.
Proof. unfold Equation2264. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2266 : ~ @Equation2266 Fin3 refa84_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2291 : ~ @Equation2291 Fin3 refa84_inst.
Proof. unfold Equation2291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2338 : ~ @Equation2338 Fin3 refa84_inst.
Proof. unfold Equation2338. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2444 : ~ @Equation2444 Fin3 refa84_inst.
Proof. unfold Equation2444. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2447 : ~ @Equation2447 Fin3 refa84_inst.
Proof. unfold Equation2447. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2450 : ~ @Equation2450 Fin3 refa84_inst.
Proof. unfold Equation2450. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2456 : ~ @Equation2456 Fin3 refa84_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2457 : ~ @Equation2457 Fin3 refa84_inst.
Proof. unfold Equation2457. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2459 : ~ @Equation2459 Fin3 refa84_inst.
Proof. unfold Equation2459. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2460 : ~ @Equation2460 Fin3 refa84_inst.
Proof. unfold Equation2460. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2466 : ~ @Equation2466 Fin3 refa84_inst.
Proof. unfold Equation2466. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2467 : ~ @Equation2467 Fin3 refa84_inst.
Proof. unfold Equation2467. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2469 : ~ @Equation2469 Fin3 refa84_inst.
Proof. unfold Equation2469. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2530 : ~ @Equation2530 Fin3 refa84_inst.
Proof. unfold Equation2530. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2534 : ~ @Equation2534 Fin3 refa84_inst.
Proof. unfold Equation2534. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2541 : ~ @Equation2541 Fin3 refa84_inst.
Proof. unfold Equation2541. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2647 : ~ @Equation2647 Fin3 refa84_inst.
Proof. unfold Equation2647. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2649 : ~ @Equation2649 Fin3 refa84_inst.
Proof. unfold Equation2649. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2650 : ~ @Equation2650 Fin3 refa84_inst.
Proof. unfold Equation2650. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2652 : ~ @Equation2652 Fin3 refa84_inst.
Proof. unfold Equation2652. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2659 : ~ @Equation2659 Fin3 refa84_inst.
Proof. unfold Equation2659. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2660 : ~ @Equation2660 Fin3 refa84_inst.
Proof. unfold Equation2660. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2662 : ~ @Equation2662 Fin3 refa84_inst.
Proof. unfold Equation2662. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2669 : ~ @Equation2669 Fin3 refa84_inst.
Proof. unfold Equation2669. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2670 : ~ @Equation2670 Fin3 refa84_inst.
Proof. unfold Equation2670. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2672 : ~ @Equation2672 Fin3 refa84_inst.
Proof. unfold Equation2672. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2706 : ~ @Equation2706 Fin3 refa84_inst.
Proof. unfold Equation2706. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2710 : ~ @Equation2710 Fin3 refa84_inst.
Proof. unfold Equation2710. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2733 : ~ @Equation2733 Fin3 refa84_inst.
Proof. unfold Equation2733. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2849 : ~ @Equation2849 Fin3 refa84_inst.
Proof. unfold Equation2849. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2853 : ~ @Equation2853 Fin3 refa84_inst.
Proof. unfold Equation2853. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2855 : ~ @Equation2855 Fin3 refa84_inst.
Proof. unfold Equation2855. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2856 : ~ @Equation2856 Fin3 refa84_inst.
Proof. unfold Equation2856. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2862 : ~ @Equation2862 Fin3 refa84_inst.
Proof. unfold Equation2862. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2863 : ~ @Equation2863 Fin3 refa84_inst.
Proof. unfold Equation2863. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2865 : ~ @Equation2865 Fin3 refa84_inst.
Proof. unfold Equation2865. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2866 : ~ @Equation2866 Fin3 refa84_inst.
Proof. unfold Equation2866. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2872 : ~ @Equation2872 Fin3 refa84_inst.
Proof. unfold Equation2872. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2873 : ~ @Equation2873 Fin3 refa84_inst.
Proof. unfold Equation2873. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2875 : ~ @Equation2875 Fin3 refa84_inst.
Proof. unfold Equation2875. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2940 : ~ @Equation2940 Fin3 refa84_inst.
Proof. unfold Equation2940. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not2947 : ~ @Equation2947 Fin3 refa84_inst.
Proof. unfold Equation2947. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3052 : ~ @Equation3052 Fin3 refa84_inst.
Proof. unfold Equation3052. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3055 : ~ @Equation3055 Fin3 refa84_inst.
Proof. unfold Equation3055. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3056 : ~ @Equation3056 Fin3 refa84_inst.
Proof. unfold Equation3056. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3058 : ~ @Equation3058 Fin3 refa84_inst.
Proof. unfold Equation3058. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3065 : ~ @Equation3065 Fin3 refa84_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3066 : ~ @Equation3066 Fin3 refa84_inst.
Proof. unfold Equation3066. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3068 : ~ @Equation3068 Fin3 refa84_inst.
Proof. unfold Equation3068. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3069 : ~ @Equation3069 Fin3 refa84_inst.
Proof. unfold Equation3069. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3075 : ~ @Equation3075 Fin3 refa84_inst.
Proof. unfold Equation3075. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3076 : ~ @Equation3076 Fin3 refa84_inst.
Proof. unfold Equation3076. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3078 : ~ @Equation3078 Fin3 refa84_inst.
Proof. unfold Equation3078. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3079 : ~ @Equation3079 Fin3 refa84_inst.
Proof. unfold Equation3079. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3103 : ~ @Equation3103 Fin3 refa84_inst.
Proof. unfold Equation3103. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3116 : ~ @Equation3116 Fin3 refa84_inst.
Proof. unfold Equation3116. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3139 : ~ @Equation3139 Fin3 refa84_inst.
Proof. unfold Equation3139. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3143 : ~ @Equation3143 Fin3 refa84_inst.
Proof. unfold Equation3143. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3150 : ~ @Equation3150 Fin3 refa84_inst.
Proof. unfold Equation3150. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3258 : ~ @Equation3258 Fin3 refa84_inst.
Proof. unfold Equation3258. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3259 : ~ @Equation3259 Fin3 refa84_inst.
Proof. unfold Equation3259. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3261 : ~ @Equation3261 Fin3 refa84_inst.
Proof. unfold Equation3261. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3262 : ~ @Equation3262 Fin3 refa84_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3269 : ~ @Equation3269 Fin3 refa84_inst.
Proof. unfold Equation3269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3278 : ~ @Equation3278 Fin3 refa84_inst.
Proof. unfold Equation3278. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3279 : ~ @Equation3279 Fin3 refa84_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3306 : ~ @Equation3306 Fin3 refa84_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3308 : ~ @Equation3308 Fin3 refa84_inst.
Proof. unfold Equation3308. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3309 : ~ @Equation3309 Fin3 refa84_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3342 : ~ @Equation3342 Fin3 refa84_inst.
Proof. unfold Equation3342. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3355 : ~ @Equation3355 Fin3 refa84_inst.
Proof. unfold Equation3355. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3461 : ~ @Equation3461 Fin3 refa84_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3462 : ~ @Equation3462 Fin3 refa84_inst.
Proof. unfold Equation3462. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3464 : ~ @Equation3464 Fin3 refa84_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3465 : ~ @Equation3465 Fin3 refa84_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3472 : ~ @Equation3472 Fin3 refa84_inst.
Proof. unfold Equation3472. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3509 : ~ @Equation3509 Fin3 refa84_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3511 : ~ @Equation3511 Fin3 refa84_inst.
Proof. unfold Equation3511. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3512 : ~ @Equation3512 Fin3 refa84_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3545 : ~ @Equation3545 Fin3 refa84_inst.
Proof. unfold Equation3545. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3558 : ~ @Equation3558 Fin3 refa84_inst.
Proof. unfold Equation3558. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3661 : ~ @Equation3661 Fin3 refa84_inst.
Proof. unfold Equation3661. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3662 : ~ @Equation3662 Fin3 refa84_inst.
Proof. unfold Equation3662. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3664 : ~ @Equation3664 Fin3 refa84_inst.
Proof. unfold Equation3664. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3665 : ~ @Equation3665 Fin3 refa84_inst.
Proof. unfold Equation3665. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3667 : ~ @Equation3667 Fin3 refa84_inst.
Proof. unfold Equation3667. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3668 : ~ @Equation3668 Fin3 refa84_inst.
Proof. unfold Equation3668. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3675 : ~ @Equation3675 Fin3 refa84_inst.
Proof. unfold Equation3675. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3677 : ~ @Equation3677 Fin3 refa84_inst.
Proof. unfold Equation3677. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3684 : ~ @Equation3684 Fin3 refa84_inst.
Proof. unfold Equation3684. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3685 : ~ @Equation3685 Fin3 refa84_inst.
Proof. unfold Equation3685. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3687 : ~ @Equation3687 Fin3 refa84_inst.
Proof. unfold Equation3687. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3712 : ~ @Equation3712 Fin3 refa84_inst.
Proof. unfold Equation3712. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3748 : ~ @Equation3748 Fin3 refa84_inst.
Proof. unfold Equation3748. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3761 : ~ @Equation3761 Fin3 refa84_inst.
Proof. unfold Equation3761. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3865 : ~ @Equation3865 Fin3 refa84_inst.
Proof. unfold Equation3865. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3867 : ~ @Equation3867 Fin3 refa84_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3868 : ~ @Equation3868 Fin3 refa84_inst.
Proof. unfold Equation3868. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3870 : ~ @Equation3870 Fin3 refa84_inst.
Proof. unfold Equation3870. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3871 : ~ @Equation3871 Fin3 refa84_inst.
Proof. unfold Equation3871. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3878 : ~ @Equation3878 Fin3 refa84_inst.
Proof. unfold Equation3878. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3881 : ~ @Equation3881 Fin3 refa84_inst.
Proof. unfold Equation3881. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3887 : ~ @Equation3887 Fin3 refa84_inst.
Proof. unfold Equation3887. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3888 : ~ @Equation3888 Fin3 refa84_inst.
Proof. unfold Equation3888. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3917 : ~ @Equation3917 Fin3 refa84_inst.
Proof. unfold Equation3917. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3951 : ~ @Equation3951 Fin3 refa84_inst.
Proof. unfold Equation3951. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3962 : ~ @Equation3962 Fin3 refa84_inst.
Proof. unfold Equation3962. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not3964 : ~ @Equation3964 Fin3 refa84_inst.
Proof. unfold Equation3964. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4066 : ~ @Equation4066 Fin3 refa84_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4067 : ~ @Equation4067 Fin3 refa84_inst.
Proof. unfold Equation4067. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4068 : ~ @Equation4068 Fin3 refa84_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4070 : ~ @Equation4070 Fin3 refa84_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4071 : ~ @Equation4071 Fin3 refa84_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4073 : ~ @Equation4073 Fin3 refa84_inst.
Proof. unfold Equation4073. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4074 : ~ @Equation4074 Fin3 refa84_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4081 : ~ @Equation4081 Fin3 refa84_inst.
Proof. unfold Equation4081. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4083 : ~ @Equation4083 Fin3 refa84_inst.
Proof. unfold Equation4083. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4084 : ~ @Equation4084 Fin3 refa84_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4090 : ~ @Equation4090 Fin3 refa84_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4091 : ~ @Equation4091 Fin3 refa84_inst.
Proof. unfold Equation4091. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4093 : ~ @Equation4093 Fin3 refa84_inst.
Proof. unfold Equation4093. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4167 : ~ @Equation4167 Fin3 refa84_inst.
Proof. unfold Equation4167. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4269 : ~ @Equation4269 Fin3 refa84_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4270 : ~ @Equation4270 Fin3 refa84_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4273 : ~ @Equation4273 Fin3 refa84_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4275 : ~ @Equation4275 Fin3 refa84_inst.
Proof. unfold Equation4275. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4283 : ~ @Equation4283 Fin3 refa84_inst.
Proof. unfold Equation4283. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4284 : ~ @Equation4284 Fin3 refa84_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4290 : ~ @Equation4290 Fin3 refa84_inst.
Proof. unfold Equation4290. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4293 : ~ @Equation4293 Fin3 refa84_inst.
Proof. unfold Equation4293. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4320 : ~ @Equation4320 Fin3 refa84_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4396 : ~ @Equation4396 Fin3 refa84_inst.
Proof. unfold Equation4396. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4398 : ~ @Equation4398 Fin3 refa84_inst.
Proof. unfold Equation4398. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4399 : ~ @Equation4399 Fin3 refa84_inst.
Proof. unfold Equation4399. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4405 : ~ @Equation4405 Fin3 refa84_inst.
Proof. unfold Equation4405. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4480 : ~ @Equation4480 Fin3 refa84_inst.
Proof. unfold Equation4480. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4482 : ~ @Equation4482 Fin3 refa84_inst.
Proof. unfold Equation4482. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4583 : ~ @Equation4583 Fin3 refa84_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4584 : ~ @Equation4584 Fin3 refa84_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4585 : ~ @Equation4585 Fin3 refa84_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4588 : ~ @Equation4588 Fin3 refa84_inst.
Proof. unfold Equation4588. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4590 : ~ @Equation4590 Fin3 refa84_inst.
Proof. unfold Equation4590. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4591 : ~ @Equation4591 Fin3 refa84_inst.
Proof. unfold Equation4591. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4605 : ~ @Equation4605 Fin3 refa84_inst.
Proof. unfold Equation4605. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4606 : ~ @Equation4606 Fin3 refa84_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4608 : ~ @Equation4608 Fin3 refa84_inst.
Proof. unfold Equation4608. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

Lemma refa84_not4636 : ~ @Equation4636 Fin3 refa84_inst.
Proof. unfold Equation4636. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa84_inst, refa84_op in H. discriminate H. Qed.

(** ---- refa840 (Fin5) ---- *)

Definition refa840_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa840_inst : Magma Fin5 := {| magma_op := refa840_op |}.

Lemma refa840_sat454 : @Equation454 Fin5 refa840_inst.
Proof. unfold Equation454, magma_op, refa840_inst, refa840_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa840_not3862 : ~ @Equation3862 Fin5 refa840_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_0). unfold magma_op, refa840_inst, refa840_op in H. discriminate H. Qed.

(** ---- refa841 (Fin6) ---- *)

Definition refa841_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_2 | F6_0, F6_1 => F6_3 | F6_0, F6_2 => F6_4 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_1 | F6_1, F6_1 => F6_4 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_0
  | F6_2, F6_0 => F6_2 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_4 | F6_2, F6_3 => F6_5 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_1 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_5 | F6_3, F6_5 => F6_0
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_5 | F6_4, F6_5 => F6_0
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_4 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_0
  end.

#[local] Instance refa841_inst : Magma Fin6 := {| magma_op := refa841_op |}.

Lemma refa841_sat454 : @Equation454 Fin6 refa841_inst.
Proof. unfold Equation454, magma_op, refa841_inst, refa841_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa841_not4316 : ~ @Equation4316 Fin6 refa841_inst.
Proof. unfold Equation4316. intro H. specialize (H F6_0 F6_0 F6_1). unfold magma_op, refa841_inst, refa841_op in H. discriminate H. Qed.

(** ---- refa842 (Fin8) ---- *)

Definition refa842_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_7 | F8_0, F8_1 => F8_3 | F8_0, F8_2 => F8_1 | F8_0, F8_3 => F8_3 | F8_0, F8_4 => F8_4 | F8_0, F8_5 => F8_3 | F8_0, F8_6 => F8_3 | F8_0, F8_7 => F8_3
  | F8_1, F8_0 => F8_5 | F8_1, F8_1 => F8_3 | F8_1, F8_2 => F8_5 | F8_1, F8_3 => F8_4 | F8_1, F8_4 => F8_4 | F8_1, F8_5 => F8_4 | F8_1, F8_6 => F8_4 | F8_1, F8_7 => F8_3
  | F8_2, F8_0 => F8_7 | F8_2, F8_1 => F8_6 | F8_2, F8_2 => F8_1 | F8_2, F8_3 => F8_4 | F8_2, F8_4 => F8_4 | F8_2, F8_5 => F8_3 | F8_2, F8_6 => F8_3 | F8_2, F8_7 => F8_6
  | F8_3, F8_0 => F8_4 | F8_3, F8_1 => F8_4 | F8_3, F8_2 => F8_4 | F8_3, F8_3 => F8_4 | F8_3, F8_4 => F8_4 | F8_3, F8_5 => F8_4 | F8_3, F8_6 => F8_4 | F8_3, F8_7 => F8_4
  | F8_4, F8_0 => F8_4 | F8_4, F8_1 => F8_4 | F8_4, F8_2 => F8_4 | F8_4, F8_3 => F8_4 | F8_4, F8_4 => F8_4 | F8_4, F8_5 => F8_4 | F8_4, F8_6 => F8_4 | F8_4, F8_7 => F8_4
  | F8_5, F8_0 => F8_4 | F8_5, F8_1 => F8_4 | F8_5, F8_2 => F8_3 | F8_5, F8_3 => F8_4 | F8_5, F8_4 => F8_4 | F8_5, F8_5 => F8_4 | F8_5, F8_6 => F8_4 | F8_5, F8_7 => F8_4
  | F8_6, F8_0 => F8_3 | F8_6, F8_1 => F8_4 | F8_6, F8_2 => F8_3 | F8_6, F8_3 => F8_4 | F8_6, F8_4 => F8_4 | F8_6, F8_5 => F8_4 | F8_6, F8_6 => F8_4 | F8_6, F8_7 => F8_4
  | F8_7, F8_0 => F8_5 | F8_7, F8_1 => F8_4 | F8_7, F8_2 => F8_5 | F8_7, F8_3 => F8_4 | F8_7, F8_4 => F8_4 | F8_7, F8_5 => F8_4 | F8_7, F8_6 => F8_4 | F8_7, F8_7 => F8_4
  end.

#[local] Instance refa842_inst : Magma Fin8 := {| magma_op := refa842_op |}.

Lemma refa842_sat4679 : @Equation4679 Fin8 refa842_inst.
Proof. unfold Equation4679, magma_op, refa842_inst, refa842_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa842_not4673 : ~ @Equation4673 Fin8 refa842_inst.
Proof. unfold Equation4673. intro H. specialize (H F8_0 F8_1 F8_2). unfold magma_op, refa842_inst, refa842_op in H. discriminate H. Qed.

Lemma refa842_not4677 : ~ @Equation4677 Fin8 refa842_inst.
Proof. unfold Equation4677. intro H. specialize (H F8_0 F8_1 F8_2). unfold magma_op, refa842_inst, refa842_op in H. discriminate H. Qed.

Lemma refa842_not4684 : ~ @Equation4684 Fin8 refa842_inst.
Proof. unfold Equation4684. intro H. specialize (H F8_0 F8_1 F8_2). unfold magma_op, refa842_inst, refa842_op in H. discriminate H. Qed.

(** ---- refa843 (Fin7) ---- *)

Definition refa843_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_2 | F7_0, F7_1 => F7_1 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_5 | F7_0, F7_4 => F7_4 | F7_0, F7_5 => F7_0 | F7_0, F7_6 => F7_6
  | F7_1, F7_0 => F7_2 | F7_1, F7_1 => F7_1 | F7_1, F7_2 => F7_3 | F7_1, F7_3 => F7_5 | F7_1, F7_4 => F7_4 | F7_1, F7_5 => F7_0 | F7_1, F7_6 => F7_6
  | F7_2, F7_0 => F7_2 | F7_2, F7_1 => F7_1 | F7_2, F7_2 => F7_3 | F7_2, F7_3 => F7_5 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_0 | F7_2, F7_6 => F7_6
  | F7_3, F7_0 => F7_2 | F7_3, F7_1 => F7_4 | F7_3, F7_2 => F7_3 | F7_3, F7_3 => F7_5 | F7_3, F7_4 => F7_6 | F7_3, F7_5 => F7_0 | F7_3, F7_6 => F7_1
  | F7_4, F7_0 => F7_2 | F7_4, F7_1 => F7_1 | F7_4, F7_2 => F7_3 | F7_4, F7_3 => F7_5 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_0 | F7_4, F7_6 => F7_6
  | F7_5, F7_0 => F7_2 | F7_5, F7_1 => F7_4 | F7_5, F7_2 => F7_3 | F7_5, F7_3 => F7_5 | F7_5, F7_4 => F7_6 | F7_5, F7_5 => F7_0 | F7_5, F7_6 => F7_1
  | F7_6, F7_0 => F7_2 | F7_6, F7_1 => F7_1 | F7_6, F7_2 => F7_3 | F7_6, F7_3 => F7_5 | F7_6, F7_4 => F7_4 | F7_6, F7_5 => F7_0 | F7_6, F7_6 => F7_6
  end.

#[local] Instance refa843_inst : Magma Fin7 := {| magma_op := refa843_op |}.

Lemma refa843_sat476 : @Equation476 Fin7 refa843_inst.
Proof. unfold Equation476, magma_op, refa843_inst, refa843_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa843_sat503 : @Equation503 Fin7 refa843_inst.
Proof. unfold Equation503, magma_op, refa843_inst, refa843_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa843_sat510 : @Equation510 Fin7 refa843_inst.
Proof. unfold Equation510, magma_op, refa843_inst, refa843_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa843_not3915 : ~ @Equation3915 Fin7 refa843_inst.
Proof. unfold Equation3915. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa843_inst, refa843_op in H. discriminate H. Qed.

Lemma refa843_not3955 : ~ @Equation3955 Fin7 refa843_inst.
Proof. unfold Equation3955. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa843_inst, refa843_op in H. discriminate H. Qed.

Lemma refa843_not4083 : ~ @Equation4083 Fin7 refa843_inst.
Proof. unfold Equation4083. intro H. specialize (H F7_1 F7_2). unfold magma_op, refa843_inst, refa843_op in H. discriminate H. Qed.

Lemma refa843_not4118 : ~ @Equation4118 Fin7 refa843_inst.
Proof. unfold Equation4118. intro H. specialize (H F7_2 F7_1). unfold magma_op, refa843_inst, refa843_op in H. discriminate H. Qed.

Lemma refa843_not4158 : ~ @Equation4158 Fin7 refa843_inst.
Proof. unfold Equation4158. intro H. specialize (H F7_3 F7_1). unfold magma_op, refa843_inst, refa843_op in H. discriminate H. Qed.

(** ---- refa844 (Fin5) ---- *)

Definition refa844_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_3 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_0 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_0 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa844_inst : Magma Fin5 := {| magma_op := refa844_op |}.

Lemma refa844_sat476 : @Equation476 Fin5 refa844_inst.
Proof. unfold Equation476, magma_op, refa844_inst, refa844_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa844_sat503 : @Equation503 Fin5 refa844_inst.
Proof. unfold Equation503, magma_op, refa844_inst, refa844_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa844_sat510 : @Equation510 Fin5 refa844_inst.
Proof. unfold Equation510, magma_op, refa844_inst, refa844_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa844_not375 : ~ @Equation375 Fin5 refa844_inst.
Proof. unfold Equation375. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa844_inst, refa844_op in H. discriminate H. Qed.

Lemma refa844_not466 : ~ @Equation466 Fin5 refa844_inst.
Proof. unfold Equation466. intro H. specialize (H F5_1 F5_2). unfold magma_op, refa844_inst, refa844_op in H. discriminate H. Qed.

Lemma refa844_not3880 : ~ @Equation3880 Fin5 refa844_inst.
Proof. unfold Equation3880. intro H. specialize (H F5_1 F5_2). unfold magma_op, refa844_inst, refa844_op in H. discriminate H. Qed.

(** ---- refa845 (Fin5) ---- *)

Definition refa845_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa845_inst : Magma Fin5 := {| magma_op := refa845_op |}.

Lemma refa845_sat621 : @Equation621 Fin5 refa845_inst.
Proof. unfold Equation621, magma_op, refa845_inst, refa845_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa845_not3659 : ~ @Equation3659 Fin5 refa845_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_0). unfold magma_op, refa845_inst, refa845_op in H. discriminate H. Qed.

(** ---- refa846 (Fin5) ---- *)

Definition refa846_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_0 | F5_0, F5_2 => F5_1 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_4 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_3
  end.

#[local] Instance refa846_inst : Magma Fin5 := {| magma_op := refa846_op |}.

Lemma refa846_sat626 : @Equation626 Fin5 refa846_inst.
Proof. unfold Equation626, magma_op, refa846_inst, refa846_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa846_not3660 : ~ @Equation3660 Fin5 refa846_inst.
Proof. unfold Equation3660. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa846_inst, refa846_op in H. discriminate H. Qed.

Lemma refa846_not3661 : ~ @Equation3661 Fin5 refa846_inst.
Proof. unfold Equation3661. intro H. specialize (H F5_1 F5_0). unfold magma_op, refa846_inst, refa846_op in H. discriminate H. Qed.

Lemma refa846_not3862 : ~ @Equation3862 Fin5 refa846_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_0). unfold magma_op, refa846_inst, refa846_op in H. discriminate H. Qed.

Lemma refa846_not4065 : ~ @Equation4065 Fin5 refa846_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_4). unfold magma_op, refa846_inst, refa846_op in H. discriminate H. Qed.

Lemma refa846_not4598 : ~ @Equation4598 Fin5 refa846_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa846_inst, refa846_op in H. discriminate H. Qed.

(** ---- refa847 (Fin5) ---- *)

Definition refa847_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_1 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_4
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_1
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_1 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_1 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa847_inst : Magma Fin5 := {| magma_op := refa847_op |}.

Lemma refa847_sat633 : @Equation633 Fin5 refa847_inst.
Proof. unfold Equation633, magma_op, refa847_inst, refa847_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa847_not203 : ~ @Equation203 Fin5 refa847_inst.
Proof. unfold Equation203. intro H. specialize (H F5_0). unfold magma_op, refa847_inst, refa847_op in H. discriminate H. Qed.

Lemma refa847_not255 : ~ @Equation255 Fin5 refa847_inst.
Proof. unfold Equation255. intro H. specialize (H F5_0). unfold magma_op, refa847_inst, refa847_op in H. discriminate H. Qed.

Lemma refa847_not1426 : ~ @Equation1426 Fin5 refa847_inst.
Proof. unfold Equation1426. intro H. specialize (H F5_0). unfold magma_op, refa847_inst, refa847_op in H. discriminate H. Qed.

Lemma refa847_not1629 : ~ @Equation1629 Fin5 refa847_inst.
Proof. unfold Equation1629. intro H. specialize (H F5_0). unfold magma_op, refa847_inst, refa847_op in H. discriminate H. Qed.

(** ---- refa848 (Fin5) ---- *)

Definition refa848_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_4 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_1 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_4 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_0 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_1 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa848_inst : Magma Fin5 := {| magma_op := refa848_op |}.

Lemma refa848_sat633 : @Equation633 Fin5 refa848_inst.
Proof. unfold Equation633, magma_op, refa848_inst, refa848_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa848_not411 : ~ @Equation411 Fin5 refa848_inst.
Proof. unfold Equation411. intro H. specialize (H F5_0). unfold magma_op, refa848_inst, refa848_op in H. discriminate H. Qed.

Lemma refa848_not4380 : ~ @Equation4380 Fin5 refa848_inst.
Proof. unfold Equation4380. intro H. specialize (H F5_0). unfold magma_op, refa848_inst, refa848_op in H. discriminate H. Qed.

(** ---- refa849 (Fin6) ---- *)

Definition refa849_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_5 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_0 | F6_0, F6_5 => F6_5
  | F6_1, F6_0 => F6_4 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_2 | F6_1, F6_3 => F6_1 | F6_1, F6_4 => F6_4 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_4 | F6_2, F6_1 => F6_3 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_3 | F6_2, F6_4 => F6_4 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_2 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_4 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_4 | F6_4, F6_1 => F6_3 | F6_4, F6_2 => F6_2 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_0 | F6_5, F6_1 => F6_5 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa849_inst : Magma Fin6 := {| magma_op := refa849_op |}.

Lemma refa849_sat645 : @Equation645 Fin6 refa849_inst.
Proof. unfold Equation645, magma_op, refa849_inst, refa849_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa849_not629 : ~ @Equation629 Fin6 refa849_inst.
Proof. unfold Equation629. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa849_inst, refa849_op in H. discriminate H. Qed.

Lemma refa849_not835 : ~ @Equation835 Fin6 refa849_inst.
Proof. unfold Equation835. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa849_inst, refa849_op in H. discriminate H. Qed.

Lemma refa849_not842 : ~ @Equation842 Fin6 refa849_inst.
Proof. unfold Equation842. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa849_inst, refa849_op in H. discriminate H. Qed.

Lemma refa849_not3867 : ~ @Equation3867 Fin6 refa849_inst.
Proof. unfold Equation3867. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa849_inst, refa849_op in H. discriminate H. Qed.

Lemma refa849_not3928 : ~ @Equation3928 Fin6 refa849_inst.
Proof. unfold Equation3928. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa849_inst, refa849_op in H. discriminate H. Qed.

Lemma refa849_not4131 : ~ @Equation4131 Fin6 refa849_inst.
Proof. unfold Equation4131. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa849_inst, refa849_op in H. discriminate H. Qed.

(** ---- refa85 (Fin3) ---- *)

Definition refa85_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_0 | F3_0, F3_1 => F3_1 | F3_0, F3_2 => F3_2
  | F3_1, F3_0 => F3_0 | F3_1, F3_1 => F3_0 | F3_1, F3_2 => F3_1
  | F3_2, F3_0 => F3_0 | F3_2, F3_1 => F3_1 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa85_inst : Magma Fin3 := {| magma_op := refa85_op |}.

Lemma refa85_sat316 : @Equation316 Fin3 refa85_inst.
Proof. unfold Equation316, magma_op, refa85_inst, refa85_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa85_sat2389 : @Equation2389 Fin3 refa85_inst.
Proof. unfold Equation2389, magma_op, refa85_inst, refa85_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa85_sat2558 : @Equation2558 Fin3 refa85_inst.
Proof. unfold Equation2558, magma_op, refa85_inst, refa85_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa85_sat2836 : @Equation2836 Fin3 refa85_inst.
Proof. unfold Equation2836, magma_op, refa85_inst, refa85_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa85_not221 : ~ @Equation221 Fin3 refa85_inst.
Proof. unfold Equation221. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not2243 : ~ @Equation2243 Fin3 refa85_inst.
Proof. unfold Equation2243. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not2330 : ~ @Equation2330 Fin3 refa85_inst.
Proof. unfold Equation2330. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not2446 : ~ @Equation2446 Fin3 refa85_inst.
Proof. unfold Equation2446. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not2456 : ~ @Equation2456 Fin3 refa85_inst.
Proof. unfold Equation2456. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not2506 : ~ @Equation2506 Fin3 refa85_inst.
Proof. unfold Equation2506. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not2533 : ~ @Equation2533 Fin3 refa85_inst.
Proof. unfold Equation2533. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not3065 : ~ @Equation3065 Fin3 refa85_inst.
Proof. unfold Equation3065. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not3115 : ~ @Equation3115 Fin3 refa85_inst.
Proof. unfold Equation3115. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not3255 : ~ @Equation3255 Fin3 refa85_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not3279 : ~ @Equation3279 Fin3 refa85_inst.
Proof. unfold Equation3279. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not3306 : ~ @Equation3306 Fin3 refa85_inst.
Proof. unfold Equation3306. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not3458 : ~ @Equation3458 Fin3 refa85_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not3461 : ~ @Equation3461 Fin3 refa85_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not3475 : ~ @Equation3475 Fin3 refa85_inst.
Proof. unfold Equation3475. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not3482 : ~ @Equation3482 Fin3 refa85_inst.
Proof. unfold Equation3482. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not3519 : ~ @Equation3519 Fin3 refa85_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not3749 : ~ @Equation3749 Fin3 refa85_inst.
Proof. unfold Equation3749. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not4070 : ~ @Equation4070 Fin3 refa85_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not4084 : ~ @Equation4084 Fin3 refa85_inst.
Proof. unfold Equation4084. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not4128 : ~ @Equation4128 Fin3 refa85_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not4155 : ~ @Equation4155 Fin3 refa85_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not4269 : ~ @Equation4269 Fin3 refa85_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not4273 : ~ @Equation4273 Fin3 refa85_inst.
Proof. unfold Equation4273. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not4314 : ~ @Equation4314 Fin3 refa85_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not4320 : ~ @Equation4320 Fin3 refa85_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_2 F3_1). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not4321 : ~ @Equation4321 Fin3 refa85_inst.
Proof. unfold Equation4321. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not4606 : ~ @Equation4606 Fin3 refa85_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not4631 : ~ @Equation4631 Fin3 refa85_inst.
Proof. unfold Equation4631. intro H. specialize (H F3_1 F3_0 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

Lemma refa85_not4658 : ~ @Equation4658 Fin3 refa85_inst.
Proof. unfold Equation4658. intro H. specialize (H F3_1 F3_2). unfold magma_op, refa85_inst, refa85_op in H. discriminate H. Qed.

(** ---- refa850 (Fin8) ---- *)

Definition refa850_op (x y : Fin8) : Fin8 :=
  match x, y with
  | F8_0, F8_0 => F8_0 | F8_0, F8_1 => F8_4 | F8_0, F8_2 => F8_4 | F8_0, F8_3 => F8_4 | F8_0, F8_4 => F8_4 | F8_0, F8_5 => F8_0 | F8_0, F8_6 => F8_0 | F8_0, F8_7 => F8_0
  | F8_1, F8_0 => F8_2 | F8_1, F8_1 => F8_1 | F8_1, F8_2 => F8_5 | F8_1, F8_3 => F8_7 | F8_1, F8_4 => F8_1 | F8_1, F8_5 => F8_5 | F8_1, F8_6 => F8_1 | F8_1, F8_7 => F8_7
  | F8_2, F8_0 => F8_3 | F8_2, F8_1 => F8_6 | F8_2, F8_2 => F8_2 | F8_2, F8_3 => F8_7 | F8_2, F8_4 => F8_2 | F8_2, F8_5 => F8_2 | F8_2, F8_6 => F8_6 | F8_2, F8_7 => F8_7
  | F8_3, F8_0 => F8_6 | F8_3, F8_1 => F8_6 | F8_3, F8_2 => F8_5 | F8_3, F8_3 => F8_3 | F8_3, F8_4 => F8_3 | F8_3, F8_5 => F8_5 | F8_3, F8_6 => F8_6 | F8_3, F8_7 => F8_3
  | F8_4, F8_0 => F8_0 | F8_4, F8_1 => F8_4 | F8_4, F8_2 => F8_4 | F8_4, F8_3 => F8_4 | F8_4, F8_4 => F8_4 | F8_4, F8_5 => F8_4 | F8_4, F8_6 => F8_4 | F8_4, F8_7 => F8_4
  | F8_5, F8_0 => F8_5 | F8_5, F8_1 => F8_6 | F8_5, F8_2 => F8_5 | F8_5, F8_3 => F8_3 | F8_5, F8_4 => F8_5 | F8_5, F8_5 => F8_5 | F8_5, F8_6 => F8_6 | F8_5, F8_7 => F8_3
  | F8_6, F8_0 => F8_6 | F8_6, F8_1 => F8_6 | F8_6, F8_2 => F8_2 | F8_6, F8_3 => F8_7 | F8_6, F8_4 => F8_6 | F8_6, F8_5 => F8_5 | F8_6, F8_6 => F8_6 | F8_6, F8_7 => F8_7
  | F8_7, F8_0 => F8_7 | F8_7, F8_1 => F8_6 | F8_7, F8_2 => F8_2 | F8_7, F8_3 => F8_7 | F8_7, F8_4 => F8_7 | F8_7, F8_5 => F8_2 | F8_7, F8_6 => F8_6 | F8_7, F8_7 => F8_7
  end.

#[local] Instance refa850_inst : Magma Fin8 := {| magma_op := refa850_op |}.

Lemma refa850_sat645 : @Equation645 Fin8 refa850_inst.
Proof. unfold Equation645, magma_op, refa850_inst, refa850_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa850_not832 : ~ @Equation832 Fin8 refa850_inst.
Proof. unfold Equation832. intro H. specialize (H F8_0 F8_1). unfold magma_op, refa850_inst, refa850_op in H. discriminate H. Qed.

(** ---- refa851 (Fin7) ---- *)

Definition refa851_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_0 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_5 | F7_0, F7_3 => F7_0 | F7_0, F7_4 => F7_4 | F7_0, F7_5 => F7_6 | F7_0, F7_6 => F7_2
  | F7_1, F7_0 => F7_3 | F7_1, F7_1 => F7_2 | F7_1, F7_2 => F7_5 | F7_1, F7_3 => F7_3 | F7_1, F7_4 => F7_4 | F7_1, F7_5 => F7_1 | F7_1, F7_6 => F7_2
  | F7_2, F7_0 => F7_0 | F7_2, F7_1 => F7_2 | F7_2, F7_2 => F7_5 | F7_2, F7_3 => F7_4 | F7_2, F7_4 => F7_4 | F7_2, F7_5 => F7_6 | F7_2, F7_6 => F7_2
  | F7_3, F7_0 => F7_3 | F7_3, F7_1 => F7_2 | F7_3, F7_2 => F7_5 | F7_3, F7_3 => F7_3 | F7_3, F7_4 => F7_3 | F7_3, F7_5 => F7_6 | F7_3, F7_6 => F7_2
  | F7_4, F7_0 => F7_0 | F7_4, F7_1 => F7_2 | F7_4, F7_2 => F7_5 | F7_4, F7_3 => F7_4 | F7_4, F7_4 => F7_4 | F7_4, F7_5 => F7_6 | F7_4, F7_6 => F7_2
  | F7_5, F7_0 => F7_0 | F7_5, F7_1 => F7_2 | F7_5, F7_2 => F7_5 | F7_5, F7_3 => F7_0 | F7_5, F7_4 => F7_4 | F7_5, F7_5 => F7_1 | F7_5, F7_6 => F7_2
  | F7_6, F7_0 => F7_0 | F7_6, F7_1 => F7_2 | F7_6, F7_2 => F7_5 | F7_6, F7_3 => F7_4 | F7_6, F7_4 => F7_4 | F7_6, F7_5 => F7_6 | F7_6, F7_6 => F7_2
  end.

#[local] Instance refa851_inst : Magma Fin7 := {| magma_op := refa851_op |}.

Lemma refa851_sat645 : @Equation645 Fin7 refa851_inst.
Proof. unfold Equation645, magma_op, refa851_inst, refa851_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa851_not845 : ~ @Equation845 Fin7 refa851_inst.
Proof. unfold Equation845. intro H. specialize (H F7_0 F7_1). unfold magma_op, refa851_inst, refa851_op in H. discriminate H. Qed.

Lemma refa851_not1426 : ~ @Equation1426 Fin7 refa851_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_1). unfold magma_op, refa851_inst, refa851_op in H. discriminate H. Qed.

Lemma refa851_not3862 : ~ @Equation3862 Fin7 refa851_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_5). unfold magma_op, refa851_inst, refa851_op in H. discriminate H. Qed.

(** ---- refa852 (Fin6) ---- *)

Definition refa852_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_0 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_1 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_1 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_1 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_5 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_1 | F6_2, F6_1 => F6_2 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_5 | F6_2, F6_4 => F6_1 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_5 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_0 | F6_3, F6_4 => F6_0 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_2 | F6_4, F6_1 => F6_2 | F6_4, F6_2 => F6_4 | F6_4, F6_3 => F6_3 | F6_4, F6_4 => F6_0 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_5 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_0 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa852_inst : Magma Fin6 := {| magma_op := refa852_op |}.

Lemma refa852_sat646 : @Equation646 Fin6 refa852_inst.
Proof. unfold Equation646, magma_op, refa852_inst, refa852_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa852_not99 : ~ @Equation99 Fin6 refa852_inst.
Proof. unfold Equation99. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not151 : ~ @Equation151 Fin6 refa852_inst.
Proof. unfold Equation151. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not203 : ~ @Equation203 Fin6 refa852_inst.
Proof. unfold Equation203. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not255 : ~ @Equation255 Fin6 refa852_inst.
Proof. unfold Equation255. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not411 : ~ @Equation411 Fin6 refa852_inst.
Proof. unfold Equation411. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not615 : ~ @Equation615 Fin6 refa852_inst.
Proof. unfold Equation615. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not619 : ~ @Equation619 Fin6 refa852_inst.
Proof. unfold Equation619. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not620 : ~ @Equation620 Fin6 refa852_inst.
Proof. unfold Equation620. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not622 : ~ @Equation622 Fin6 refa852_inst.
Proof. unfold Equation622. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not623 : ~ @Equation623 Fin6 refa852_inst.
Proof. unfold Equation623. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not629 : ~ @Equation629 Fin6 refa852_inst.
Proof. unfold Equation629. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not630 : ~ @Equation630 Fin6 refa852_inst.
Proof. unfold Equation630. intro H. specialize (H F6_0 F6_4). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not632 : ~ @Equation632 Fin6 refa852_inst.
Proof. unfold Equation632. intro H. specialize (H F6_0 F6_5). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not633 : ~ @Equation633 Fin6 refa852_inst.
Proof. unfold Equation633. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not639 : ~ @Equation639 Fin6 refa852_inst.
Proof. unfold Equation639. intro H. specialize (H F6_1 F6_4). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not642 : ~ @Equation642 Fin6 refa852_inst.
Proof. unfold Equation642. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not817 : ~ @Equation817 Fin6 refa852_inst.
Proof. unfold Equation817. intro H. specialize (H F6_4). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not1020 : ~ @Equation1020 Fin6 refa852_inst.
Proof. unfold Equation1020. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not1223 : ~ @Equation1223 Fin6 refa852_inst.
Proof. unfold Equation1223. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not1426 : ~ @Equation1426 Fin6 refa852_inst.
Proof. unfold Equation1426. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not1629 : ~ @Equation1629 Fin6 refa852_inst.
Proof. unfold Equation1629. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not1832 : ~ @Equation1832 Fin6 refa852_inst.
Proof. unfold Equation1832. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not2035 : ~ @Equation2035 Fin6 refa852_inst.
Proof. unfold Equation2035. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not2238 : ~ @Equation2238 Fin6 refa852_inst.
Proof. unfold Equation2238. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not2441 : ~ @Equation2441 Fin6 refa852_inst.
Proof. unfold Equation2441. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not2644 : ~ @Equation2644 Fin6 refa852_inst.
Proof. unfold Equation2644. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not2847 : ~ @Equation2847 Fin6 refa852_inst.
Proof. unfold Equation2847. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not3050 : ~ @Equation3050 Fin6 refa852_inst.
Proof. unfold Equation3050. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not3253 : ~ @Equation3253 Fin6 refa852_inst.
Proof. unfold Equation3253. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not3456 : ~ @Equation3456 Fin6 refa852_inst.
Proof. unfold Equation3456. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not3659 : ~ @Equation3659 Fin6 refa852_inst.
Proof. unfold Equation3659. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not3862 : ~ @Equation3862 Fin6 refa852_inst.
Proof. unfold Equation3862. intro H. specialize (H F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4065 : ~ @Equation4065 Fin6 refa852_inst.
Proof. unfold Equation4065. intro H. specialize (H F6_4). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4268 : ~ @Equation4268 Fin6 refa852_inst.
Proof. unfold Equation4268. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4269 : ~ @Equation4269 Fin6 refa852_inst.
Proof. unfold Equation4269. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4270 : ~ @Equation4270 Fin6 refa852_inst.
Proof. unfold Equation4270. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4283 : ~ @Equation4283 Fin6 refa852_inst.
Proof. unfold Equation4283. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4284 : ~ @Equation4284 Fin6 refa852_inst.
Proof. unfold Equation4284. intro H. specialize (H F6_0 F6_2). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4314 : ~ @Equation4314 Fin6 refa852_inst.
Proof. unfold Equation4314. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4380 : ~ @Equation4380 Fin6 refa852_inst.
Proof. unfold Equation4380. intro H. specialize (H F6_0). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4583 : ~ @Equation4583 Fin6 refa852_inst.
Proof. unfold Equation4583. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4584 : ~ @Equation4584 Fin6 refa852_inst.
Proof. unfold Equation4584. intro H. specialize (H F6_1 F6_3). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4585 : ~ @Equation4585 Fin6 refa852_inst.
Proof. unfold Equation4585. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4598 : ~ @Equation4598 Fin6 refa852_inst.
Proof. unfold Equation4598. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4599 : ~ @Equation4599 Fin6 refa852_inst.
Proof. unfold Equation4599. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

Lemma refa852_not4629 : ~ @Equation4629 Fin6 refa852_inst.
Proof. unfold Equation4629. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa852_inst, refa852_op in H. discriminate H. Qed.

(** ---- refa853 (Fin7) ---- *)

Definition refa853_op (x y : Fin7) : Fin7 :=
  match x, y with
  | F7_0, F7_0 => F7_1 | F7_0, F7_1 => F7_2 | F7_0, F7_2 => F7_3 | F7_0, F7_3 => F7_5 | F7_0, F7_4 => F7_5 | F7_0, F7_5 => F7_0 | F7_0, F7_6 => F7_1
  | F7_1, F7_0 => F7_4 | F7_1, F7_1 => F7_2 | F7_1, F7_2 => F7_3 | F7_1, F7_3 => F7_1 | F7_1, F7_4 => F7_5 | F7_1, F7_5 => F7_6 | F7_1, F7_6 => F7_1
  | F7_2, F7_0 => F7_4 | F7_2, F7_1 => F7_2 | F7_2, F7_2 => F7_3 | F7_2, F7_3 => F7_5 | F7_2, F7_4 => F7_5 | F7_2, F7_5 => F7_2 | F7_2, F7_6 => F7_1
  | F7_3, F7_0 => F7_4 | F7_3, F7_1 => F7_2 | F7_3, F7_2 => F7_3 | F7_3, F7_3 => F7_5 | F7_3, F7_4 => F7_5 | F7_3, F7_5 => F7_6 | F7_3, F7_6 => F7_3
  | F7_4, F7_0 => F7_4 | F7_4, F7_1 => F7_2 | F7_4, F7_2 => F7_4 | F7_4, F7_3 => F7_1 | F7_4, F7_4 => F7_5 | F7_4, F7_5 => F7_6 | F7_4, F7_6 => F7_4
  | F7_5, F7_0 => F7_4 | F7_5, F7_1 => F7_5 | F7_5, F7_2 => F7_3 | F7_5, F7_3 => F7_5 | F7_5, F7_4 => F7_5 | F7_5, F7_5 => F7_6 | F7_5, F7_6 => F7_1
  | F7_6, F7_0 => F7_4 | F7_6, F7_1 => F7_2 | F7_6, F7_2 => F7_6 | F7_6, F7_3 => F7_5 | F7_6, F7_4 => F7_5 | F7_6, F7_5 => F7_6 | F7_6, F7_6 => F7_1
  end.

#[local] Instance refa853_inst : Magma Fin7 := {| magma_op := refa853_op |}.

Lemma refa853_sat653 : @Equation653 Fin7 refa853_inst.
Proof. unfold Equation653, magma_op, refa853_inst, refa853_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa853_not47 : ~ @Equation47 Fin7 refa853_inst.
Proof. unfold Equation47. intro H. specialize (H F7_0). unfold magma_op, refa853_inst, refa853_op in H. discriminate H. Qed.

Lemma refa853_not817 : ~ @Equation817 Fin7 refa853_inst.
Proof. unfold Equation817. intro H. specialize (H F7_0). unfold magma_op, refa853_inst, refa853_op in H. discriminate H. Qed.

Lemma refa853_not1426 : ~ @Equation1426 Fin7 refa853_inst.
Proof. unfold Equation1426. intro H. specialize (H F7_0). unfold magma_op, refa853_inst, refa853_op in H. discriminate H. Qed.

Lemma refa853_not3862 : ~ @Equation3862 Fin7 refa853_inst.
Proof. unfold Equation3862. intro H. specialize (H F7_0). unfold magma_op, refa853_inst, refa853_op in H. discriminate H. Qed.

Lemma refa853_not4065 : ~ @Equation4065 Fin7 refa853_inst.
Proof. unfold Equation4065. intro H. specialize (H F7_0). unfold magma_op, refa853_inst, refa853_op in H. discriminate H. Qed.

(** ---- refa854 (Fin5) ---- *)

Definition refa854_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_4 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_2 | F5_0, F5_4 => F5_3
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_2 | F5_1, F5_2 => F5_0 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_2 | F5_2, F5_4 => F5_3
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_4 | F5_3, F5_3 => F5_2 | F5_3, F5_4 => F5_3
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_3
  end.

#[local] Instance refa854_inst : Magma Fin5 := {| magma_op := refa854_op |}.

Lemma refa854_sat657 : @Equation657 Fin5 refa854_inst.
Proof. unfold Equation657, magma_op, refa854_inst, refa854_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa854_not619 : ~ @Equation619 Fin5 refa854_inst.
Proof. unfold Equation619. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa854_inst, refa854_op in H. discriminate H. Qed.

(** ---- refa855 (Fin5) ---- *)

Definition refa855_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_1 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_0 | F5_1, F5_4 => F5_0
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_4 | F5_2, F5_2 => F5_4 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_0
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_0
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_4 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_0
  end.

#[local] Instance refa855_inst : Magma Fin5 := {| magma_op := refa855_op |}.

Lemma refa855_sat864 : @Equation864 Fin5 refa855_inst.
Proof. unfold Equation864, magma_op, refa855_inst, refa855_op. intros x y z w. destruct x, y, z, w; reflexivity. Qed.

Lemma refa855_not4316 : ~ @Equation4316 Fin5 refa855_inst.
Proof. unfold Equation4316. intro H. specialize (H F5_0 F5_0 F5_2). unfold magma_op, refa855_inst, refa855_op in H. discriminate H. Qed.

(** ---- refa856 (Fin6) ---- *)

Definition refa856_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_0 | F6_0, F6_3 => F6_5 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_1 | F6_1, F6_1 => F6_4 | F6_1, F6_2 => F6_3 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_0 | F6_1, F6_5 => F6_2
  | F6_2, F6_0 => F6_5 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_0 | F6_2, F6_3 => F6_1 | F6_2, F6_4 => F6_3 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_1 | F6_3, F6_1 => F6_2 | F6_3, F6_2 => F6_0 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_4
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_4 | F6_4, F6_2 => F6_0 | F6_4, F6_3 => F6_1 | F6_4, F6_4 => F6_3 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_1 | F6_5, F6_1 => F6_4 | F6_5, F6_2 => F6_3 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_0 | F6_5, F6_5 => F6_2
  end.

#[local] Instance refa856_inst : Magma Fin6 := {| magma_op := refa856_op |}.

Lemma refa856_sat690 : @Equation690 Fin6 refa856_inst.
Proof. unfold Equation690, magma_op, refa856_inst, refa856_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa856_not1426 : ~ @Equation1426 Fin6 refa856_inst.
Proof. unfold Equation1426. intro H. specialize (H F6_0). unfold magma_op, refa856_inst, refa856_op in H. discriminate H. Qed.

Lemma refa856_not3862 : ~ @Equation3862 Fin6 refa856_inst.
Proof. unfold Equation3862. intro H. specialize (H F6_0). unfold magma_op, refa856_inst, refa856_op in H. discriminate H. Qed.

(** ---- refa857 (Fin5) ---- *)

Definition refa857_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_2 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_2 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_3 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_0 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_1 | F5_4, F5_1 => F5_0 | F5_4, F5_2 => F5_2 | F5_4, F5_3 => F5_3 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa857_inst : Magma Fin5 := {| magma_op := refa857_op |}.

Lemma refa857_sat1506 : @Equation1506 Fin5 refa857_inst.
Proof. unfold Equation1506, magma_op, refa857_inst, refa857_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa857_sat1518 : @Equation1518 Fin5 refa857_inst.
Proof. unfold Equation1518, magma_op, refa857_inst, refa857_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa857_not1444 : ~ @Equation1444 Fin5 refa857_inst.
Proof. unfold Equation1444. intro H. specialize (H F5_1 F5_3). unfold magma_op, refa857_inst, refa857_op in H. discriminate H. Qed.

Lemma refa857_not1451 : ~ @Equation1451 Fin5 refa857_inst.
Proof. unfold Equation1451. intro H. specialize (H F5_1 F5_3). unfold magma_op, refa857_inst, refa857_op in H. discriminate H. Qed.

Lemma refa857_not3897 : ~ @Equation3897 Fin5 refa857_inst.
Proof. unfold Equation3897. intro H. specialize (H F5_0 F5_1 F5_2). unfold magma_op, refa857_inst, refa857_op in H. discriminate H. Qed.

Lemma refa857_not3925 : ~ @Equation3925 Fin5 refa857_inst.
Proof. unfold Equation3925. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa857_inst, refa857_op in H. discriminate H. Qed.

Lemma refa857_not3952 : ~ @Equation3952 Fin5 refa857_inst.
Proof. unfold Equation3952. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa857_inst, refa857_op in H. discriminate H. Qed.

Lemma refa857_not4128 : ~ @Equation4128 Fin5 refa857_inst.
Proof. unfold Equation4128. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa857_inst, refa857_op in H. discriminate H. Qed.

Lemma refa857_not4165 : ~ @Equation4165 Fin5 refa857_inst.
Proof. unfold Equation4165. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa857_inst, refa857_op in H. discriminate H. Qed.

Lemma refa857_not4362 : ~ @Equation4362 Fin5 refa857_inst.
Proof. unfold Equation4362. intro H. specialize (H F5_1 F5_2 F5_0). unfold magma_op, refa857_inst, refa857_op in H. discriminate H. Qed.

Lemma refa857_not4606 : ~ @Equation4606 Fin5 refa857_inst.
Proof. unfold Equation4606. intro H. specialize (H F5_0 F5_4). unfold magma_op, refa857_inst, refa857_op in H. discriminate H. Qed.

(** ---- refa858 (Fin9) ---- *)

Definition refa858_op (x y : Fin9) : Fin9 :=
  match x, y with
  | F9_0, F9_0 => F9_1 | F9_0, F9_1 => F9_2 | F9_0, F9_2 => F9_4 | F9_0, F9_3 => F9_8 | F9_0, F9_4 => F9_3 | F9_0, F9_5 => F9_0 | F9_0, F9_6 => F9_7 | F9_0, F9_7 => F9_5 | F9_0, F9_8 => F9_6
  | F9_1, F9_0 => F9_7 | F9_1, F9_1 => F9_5 | F9_1, F9_2 => F9_0 | F9_1, F9_3 => F9_2 | F9_1, F9_4 => F9_1 | F9_1, F9_5 => F9_6 | F9_1, F9_6 => F9_3 | F9_1, F9_7 => F9_8 | F9_1, F9_8 => F9_4
  | F9_2, F9_0 => F9_3 | F9_2, F9_1 => F9_8 | F9_2, F9_2 => F9_6 | F9_2, F9_3 => F9_5 | F9_2, F9_4 => F9_7 | F9_2, F9_5 => F9_4 | F9_2, F9_6 => F9_1 | F9_2, F9_7 => F9_2 | F9_2, F9_8 => F9_0
  | F9_3, F9_0 => F9_7 | F9_3, F9_1 => F9_5 | F9_3, F9_2 => F9_0 | F9_3, F9_3 => F9_2 | F9_3, F9_4 => F9_1 | F9_3, F9_5 => F9_6 | F9_3, F9_6 => F9_3 | F9_3, F9_7 => F9_8 | F9_3, F9_8 => F9_4
  | F9_4, F9_0 => F9_1 | F9_4, F9_1 => F9_2 | F9_4, F9_2 => F9_4 | F9_4, F9_3 => F9_8 | F9_4, F9_4 => F9_3 | F9_4, F9_5 => F9_0 | F9_4, F9_6 => F9_7 | F9_4, F9_7 => F9_5 | F9_4, F9_8 => F9_6
  | F9_5, F9_0 => F9_3 | F9_5, F9_1 => F9_8 | F9_5, F9_2 => F9_6 | F9_5, F9_3 => F9_5 | F9_5, F9_4 => F9_7 | F9_5, F9_5 => F9_4 | F9_5, F9_6 => F9_1 | F9_5, F9_7 => F9_2 | F9_5, F9_8 => F9_0
  | F9_6, F9_0 => F9_1 | F9_6, F9_1 => F9_2 | F9_6, F9_2 => F9_4 | F9_6, F9_3 => F9_8 | F9_6, F9_4 => F9_3 | F9_6, F9_5 => F9_0 | F9_6, F9_6 => F9_7 | F9_6, F9_7 => F9_5 | F9_6, F9_8 => F9_6
  | F9_7, F9_0 => F9_7 | F9_7, F9_1 => F9_5 | F9_7, F9_2 => F9_0 | F9_7, F9_3 => F9_2 | F9_7, F9_4 => F9_1 | F9_7, F9_5 => F9_6 | F9_7, F9_6 => F9_3 | F9_7, F9_7 => F9_8 | F9_7, F9_8 => F9_4
  | F9_8, F9_0 => F9_3 | F9_8, F9_1 => F9_8 | F9_8, F9_2 => F9_6 | F9_8, F9_3 => F9_5 | F9_8, F9_4 => F9_7 | F9_8, F9_5 => F9_4 | F9_8, F9_6 => F9_1 | F9_8, F9_7 => F9_2 | F9_8, F9_8 => F9_0
  end.

#[local] Instance refa858_inst : Magma Fin9 := {| magma_op := refa858_op |}.

Lemma refa858_sat964 : @Equation964 Fin9 refa858_inst.
Proof. unfold Equation964, magma_op, refa858_inst, refa858_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa858_not47 : ~ @Equation47 Fin9 refa858_inst.
Proof. unfold Equation47. intro H. specialize (H F9_0). unfold magma_op, refa858_inst, refa858_op in H. discriminate H. Qed.

Lemma refa858_not3862 : ~ @Equation3862 Fin9 refa858_inst.
Proof. unfold Equation3862. intro H. specialize (H F9_0). unfold magma_op, refa858_inst, refa858_op in H. discriminate H. Qed.

Lemma refa858_not4065 : ~ @Equation4065 Fin9 refa858_inst.
Proof. unfold Equation4065. intro H. specialize (H F9_0). unfold magma_op, refa858_inst, refa858_op in H. discriminate H. Qed.

(** ---- refa859 (Fin5) ---- *)

Definition refa859_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_2 | F5_0, F5_1 => F5_1 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_4
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_1 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_0 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_2 | F5_3, F5_1 => F5_1 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_4
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_0 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa859_inst : Magma Fin5 := {| magma_op := refa859_op |}.

Lemma refa859_sat1594 : @Equation1594 Fin5 refa859_inst.
Proof. unfold Equation1594, magma_op, refa859_inst, refa859_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa859_not4320 : ~ @Equation4320 Fin5 refa859_inst.
Proof. unfold Equation4320. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa859_inst, refa859_op in H. discriminate H. Qed.

(** ---- refa86 (Fin3) ---- *)

Definition refa86_op (x y : Fin3) : Fin3 :=
  match x, y with
  | F3_0, F3_0 => F3_1 | F3_0, F3_1 => F3_2 | F3_0, F3_2 => F3_1
  | F3_1, F3_0 => F3_2 | F3_1, F3_1 => F3_2 | F3_1, F3_2 => F3_0
  | F3_2, F3_0 => F3_1 | F3_2, F3_1 => F3_0 | F3_2, F3_2 => F3_0
  end.

#[local] Instance refa86_inst : Magma Fin3 := {| magma_op := refa86_op |}.

Lemma refa86_sat1441 : @Equation1441 Fin3 refa86_inst.
Proof. unfold Equation1441, magma_op, refa86_inst, refa86_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa86_sat1478 : @Equation1478 Fin3 refa86_inst.
Proof. unfold Equation1478, magma_op, refa86_inst, refa86_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa86_sat1681 : @Equation1681 Fin3 refa86_inst.
Proof. unfold Equation1681, magma_op, refa86_inst, refa86_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa86_sat1684 : @Equation1684 Fin3 refa86_inst.
Proof. unfold Equation1684, magma_op, refa86_inst, refa86_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa86_sat1691 : @Equation1691 Fin3 refa86_inst.
Proof. unfold Equation1691, magma_op, refa86_inst, refa86_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa86_sat1833 : @Equation1833 Fin3 refa86_inst.
Proof. unfold Equation1833, magma_op, refa86_inst, refa86_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa86_sat1834 : @Equation1834 Fin3 refa86_inst.
Proof. unfold Equation1834, magma_op, refa86_inst, refa86_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa86_sat1840 : @Equation1840 Fin3 refa86_inst.
Proof. unfold Equation1840, magma_op, refa86_inst, refa86_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa86_sat2036 : @Equation2036 Fin3 refa86_inst.
Proof. unfold Equation2036, magma_op, refa86_inst, refa86_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa86_sat2037 : @Equation2037 Fin3 refa86_inst.
Proof. unfold Equation2037, magma_op, refa86_inst, refa86_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa86_sat3457 : @Equation3457 Fin3 refa86_inst.
Proof. unfold Equation3457, magma_op, refa86_inst, refa86_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa86_not47 : ~ @Equation47 Fin3 refa86_inst.
Proof. unfold Equation47. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not99 : ~ @Equation99 Fin3 refa86_inst.
Proof. unfold Equation99. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not151 : ~ @Equation151 Fin3 refa86_inst.
Proof. unfold Equation151. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not203 : ~ @Equation203 Fin3 refa86_inst.
Proof. unfold Equation203. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not255 : ~ @Equation255 Fin3 refa86_inst.
Proof. unfold Equation255. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not307 : ~ @Equation307 Fin3 refa86_inst.
Proof. unfold Equation307. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not359 : ~ @Equation359 Fin3 refa86_inst.
Proof. unfold Equation359. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not411 : ~ @Equation411 Fin3 refa86_inst.
Proof. unfold Equation411. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not614 : ~ @Equation614 Fin3 refa86_inst.
Proof. unfold Equation614. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not817 : ~ @Equation817 Fin3 refa86_inst.
Proof. unfold Equation817. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1020 : ~ @Equation1020 Fin3 refa86_inst.
Proof. unfold Equation1020. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1223 : ~ @Equation1223 Fin3 refa86_inst.
Proof. unfold Equation1223. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1431 : ~ @Equation1431 Fin3 refa86_inst.
Proof. unfold Equation1431. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1434 : ~ @Equation1434 Fin3 refa86_inst.
Proof. unfold Equation1434. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1443 : ~ @Equation1443 Fin3 refa86_inst.
Proof. unfold Equation1443. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1447 : ~ @Equation1447 Fin3 refa86_inst.
Proof. unfold Equation1447. intro H. specialize (H F3_0 F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1631 : ~ @Equation1631 Fin3 refa86_inst.
Proof. unfold Equation1631. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1632 : ~ @Equation1632 Fin3 refa86_inst.
Proof. unfold Equation1632. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1634 : ~ @Equation1634 Fin3 refa86_inst.
Proof. unfold Equation1634. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1635 : ~ @Equation1635 Fin3 refa86_inst.
Proof. unfold Equation1635. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1637 : ~ @Equation1637 Fin3 refa86_inst.
Proof. unfold Equation1637. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1648 : ~ @Equation1648 Fin3 refa86_inst.
Proof. unfold Equation1648. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1655 : ~ @Equation1655 Fin3 refa86_inst.
Proof. unfold Equation1655. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1657 : ~ @Equation1657 Fin3 refa86_inst.
Proof. unfold Equation1657. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1837 : ~ @Equation1837 Fin3 refa86_inst.
Proof. unfold Equation1837. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1841 : ~ @Equation1841 Fin3 refa86_inst.
Proof. unfold Equation1841. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1847 : ~ @Equation1847 Fin3 refa86_inst.
Proof. unfold Equation1847. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1851 : ~ @Equation1851 Fin3 refa86_inst.
Proof. unfold Equation1851. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1857 : ~ @Equation1857 Fin3 refa86_inst.
Proof. unfold Equation1857. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1858 : ~ @Equation1858 Fin3 refa86_inst.
Proof. unfold Equation1858. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1860 : ~ @Equation1860 Fin3 refa86_inst.
Proof. unfold Equation1860. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1861 : ~ @Equation1861 Fin3 refa86_inst.
Proof. unfold Equation1861. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not1921 : ~ @Equation1921 Fin3 refa86_inst.
Proof. unfold Equation1921. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not2040 : ~ @Equation2040 Fin3 refa86_inst.
Proof. unfold Equation2040. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not2043 : ~ @Equation2043 Fin3 refa86_inst.
Proof. unfold Equation2043. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not2050 : ~ @Equation2050 Fin3 refa86_inst.
Proof. unfold Equation2050. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not2063 : ~ @Equation2063 Fin3 refa86_inst.
Proof. unfold Equation2063. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not2087 : ~ @Equation2087 Fin3 refa86_inst.
Proof. unfold Equation2087. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not2124 : ~ @Equation2124 Fin3 refa86_inst.
Proof. unfold Equation2124. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not2244 : ~ @Equation2244 Fin3 refa86_inst.
Proof. unfold Equation2244. intro H. specialize (H F3_0 F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not2247 : ~ @Equation2247 Fin3 refa86_inst.
Proof. unfold Equation2247. intro H. specialize (H F3_0 F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not2256 : ~ @Equation2256 Fin3 refa86_inst.
Proof. unfold Equation2256. intro H. specialize (H F3_0 F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not2266 : ~ @Equation2266 Fin3 refa86_inst.
Proof. unfold Equation2266. intro H. specialize (H F3_0 F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not2441 : ~ @Equation2441 Fin3 refa86_inst.
Proof. unfold Equation2441. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not2644 : ~ @Equation2644 Fin3 refa86_inst.
Proof. unfold Equation2644. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not2847 : ~ @Equation2847 Fin3 refa86_inst.
Proof. unfold Equation2847. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3050 : ~ @Equation3050 Fin3 refa86_inst.
Proof. unfold Equation3050. intro H. specialize (H F3_0). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3255 : ~ @Equation3255 Fin3 refa86_inst.
Proof. unfold Equation3255. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3256 : ~ @Equation3256 Fin3 refa86_inst.
Proof. unfold Equation3256. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3262 : ~ @Equation3262 Fin3 refa86_inst.
Proof. unfold Equation3262. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3309 : ~ @Equation3309 Fin3 refa86_inst.
Proof. unfold Equation3309. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3315 : ~ @Equation3315 Fin3 refa86_inst.
Proof. unfold Equation3315. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3316 : ~ @Equation3316 Fin3 refa86_inst.
Proof. unfold Equation3316. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3318 : ~ @Equation3318 Fin3 refa86_inst.
Proof. unfold Equation3318. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3319 : ~ @Equation3319 Fin3 refa86_inst.
Proof. unfold Equation3319. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3343 : ~ @Equation3343 Fin3 refa86_inst.
Proof. unfold Equation3343. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3346 : ~ @Equation3346 Fin3 refa86_inst.
Proof. unfold Equation3346. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3458 : ~ @Equation3458 Fin3 refa86_inst.
Proof. unfold Equation3458. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3461 : ~ @Equation3461 Fin3 refa86_inst.
Proof. unfold Equation3461. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3464 : ~ @Equation3464 Fin3 refa86_inst.
Proof. unfold Equation3464. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3465 : ~ @Equation3465 Fin3 refa86_inst.
Proof. unfold Equation3465. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3509 : ~ @Equation3509 Fin3 refa86_inst.
Proof. unfold Equation3509. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3512 : ~ @Equation3512 Fin3 refa86_inst.
Proof. unfold Equation3512. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3519 : ~ @Equation3519 Fin3 refa86_inst.
Proof. unfold Equation3519. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3521 : ~ @Equation3521 Fin3 refa86_inst.
Proof. unfold Equation3521. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3522 : ~ @Equation3522 Fin3 refa86_inst.
Proof. unfold Equation3522. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3867 : ~ @Equation3867 Fin3 refa86_inst.
Proof. unfold Equation3867. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3915 : ~ @Equation3915 Fin3 refa86_inst.
Proof. unfold Equation3915. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3925 : ~ @Equation3925 Fin3 refa86_inst.
Proof. unfold Equation3925. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not3952 : ~ @Equation3952 Fin3 refa86_inst.
Proof. unfold Equation3952. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4066 : ~ @Equation4066 Fin3 refa86_inst.
Proof. unfold Equation4066. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4068 : ~ @Equation4068 Fin3 refa86_inst.
Proof. unfold Equation4068. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4070 : ~ @Equation4070 Fin3 refa86_inst.
Proof. unfold Equation4070. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4071 : ~ @Equation4071 Fin3 refa86_inst.
Proof. unfold Equation4071. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4074 : ~ @Equation4074 Fin3 refa86_inst.
Proof. unfold Equation4074. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4090 : ~ @Equation4090 Fin3 refa86_inst.
Proof. unfold Equation4090. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4118 : ~ @Equation4118 Fin3 refa86_inst.
Proof. unfold Equation4118. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4120 : ~ @Equation4120 Fin3 refa86_inst.
Proof. unfold Equation4120. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4121 : ~ @Equation4121 Fin3 refa86_inst.
Proof. unfold Equation4121. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4128 : ~ @Equation4128 Fin3 refa86_inst.
Proof. unfold Equation4128. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4130 : ~ @Equation4130 Fin3 refa86_inst.
Proof. unfold Equation4130. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4155 : ~ @Equation4155 Fin3 refa86_inst.
Proof. unfold Equation4155. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4165 : ~ @Equation4165 Fin3 refa86_inst.
Proof. unfold Equation4165. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4268 : ~ @Equation4268 Fin3 refa86_inst.
Proof. unfold Equation4268. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4269 : ~ @Equation4269 Fin3 refa86_inst.
Proof. unfold Equation4269. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4270 : ~ @Equation4270 Fin3 refa86_inst.
Proof. unfold Equation4270. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4284 : ~ @Equation4284 Fin3 refa86_inst.
Proof. unfold Equation4284. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4291 : ~ @Equation4291 Fin3 refa86_inst.
Proof. unfold Equation4291. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4314 : ~ @Equation4314 Fin3 refa86_inst.
Proof. unfold Equation4314. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4320 : ~ @Equation4320 Fin3 refa86_inst.
Proof. unfold Equation4320. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4472 : ~ @Equation4472 Fin3 refa86_inst.
Proof. unfold Equation4472. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4583 : ~ @Equation4583 Fin3 refa86_inst.
Proof. unfold Equation4583. intro H. specialize (H F3_0 F3_2). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4584 : ~ @Equation4584 Fin3 refa86_inst.
Proof. unfold Equation4584. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4585 : ~ @Equation4585 Fin3 refa86_inst.
Proof. unfold Equation4585. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4587 : ~ @Equation4587 Fin3 refa86_inst.
Proof. unfold Equation4587. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4598 : ~ @Equation4598 Fin3 refa86_inst.
Proof. unfold Equation4598. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4599 : ~ @Equation4599 Fin3 refa86_inst.
Proof. unfold Equation4599. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4606 : ~ @Equation4606 Fin3 refa86_inst.
Proof. unfold Equation4606. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

Lemma refa86_not4629 : ~ @Equation4629 Fin3 refa86_inst.
Proof. unfold Equation4629. intro H. specialize (H F3_0 F3_1). unfold magma_op, refa86_inst, refa86_op in H. discriminate H. Qed.

(** ---- refa860 (Fin6) ---- *)

Definition refa860_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_1 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_5 | F6_0, F6_3 => F6_0 | F6_0, F6_4 => F6_3 | F6_0, F6_5 => F6_4
  | F6_1, F6_0 => F6_4 | F6_1, F6_1 => F6_3 | F6_1, F6_2 => F6_0 | F6_1, F6_3 => F6_5 | F6_1, F6_4 => F6_2 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_4 | F6_2, F6_2 => F6_1 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_0
  | F6_3, F6_0 => F6_4 | F6_3, F6_1 => F6_3 | F6_3, F6_2 => F6_0 | F6_3, F6_3 => F6_5 | F6_3, F6_4 => F6_2 | F6_3, F6_5 => F6_1
  | F6_4, F6_0 => F6_5 | F6_4, F6_1 => F6_0 | F6_4, F6_2 => F6_3 | F6_4, F6_3 => F6_4 | F6_4, F6_4 => F6_1 | F6_4, F6_5 => F6_2
  | F6_5, F6_0 => F6_4 | F6_5, F6_1 => F6_3 | F6_5, F6_2 => F6_0 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_2 | F6_5, F6_5 => F6_1
  end.

#[local] Instance refa860_inst : Magma Fin6 := {| magma_op := refa860_op |}.

Lemma refa860_sat1543 : @Equation1543 Fin6 refa860_inst.
Proof. unfold Equation1543, magma_op, refa860_inst, refa860_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa860_not3862 : ~ @Equation3862 Fin6 refa860_inst.
Proof. unfold Equation3862. intro H. specialize (H F6_0). unfold magma_op, refa860_inst, refa860_op in H. discriminate H. Qed.

Lemma refa860_not4065 : ~ @Equation4065 Fin6 refa860_inst.
Proof. unfold Equation4065. intro H. specialize (H F6_0). unfold magma_op, refa860_inst, refa860_op in H. discriminate H. Qed.

(** ---- refa861 (Fin5) ---- *)

Definition refa861_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_4 | F5_0, F5_3 => F5_3 | F5_0, F5_4 => F5_0
  | F5_1, F5_0 => F5_0 | F5_1, F5_1 => F5_4 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_2 | F5_1, F5_4 => F5_3
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_0 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_1 | F5_2, F5_4 => F5_4
  | F5_3, F5_0 => F5_4 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_2 | F5_3, F5_3 => F5_0 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_3 | F5_4, F5_1 => F5_1 | F5_4, F5_2 => F5_0 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa861_inst : Magma Fin5 := {| magma_op := refa861_op |}.

Lemma refa861_sat546 : @Equation546 Fin5 refa861_inst.
Proof. unfold Equation546, magma_op, refa861_inst, refa861_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa861_sat826 : @Equation826 Fin5 refa861_inst.
Proof. unfold Equation826, magma_op, refa861_inst, refa861_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa861_sat3113 : @Equation3113 Fin5 refa861_inst.
Proof. unfold Equation3113, magma_op, refa861_inst, refa861_op. intros x y. destruct x, y; reflexivity. Qed.

Lemma refa861_not47 : ~ @Equation47 Fin5 refa861_inst.
Proof. unfold Equation47. intro H. specialize (H F5_0). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not255 : ~ @Equation255 Fin5 refa861_inst.
Proof. unfold Equation255. intro H. specialize (H F5_0). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not417 : ~ @Equation417 Fin5 refa861_inst.
Proof. unfold Equation417. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not440 : ~ @Equation440 Fin5 refa861_inst.
Proof. unfold Equation440. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not614 : ~ @Equation614 Fin5 refa861_inst.
Proof. unfold Equation614. intro H. specialize (H F5_0). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not825 : ~ @Equation825 Fin5 refa861_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not846 : ~ @Equation846 Fin5 refa861_inst.
Proof. unfold Equation846. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not1020 : ~ @Equation1020 Fin5 refa861_inst.
Proof. unfold Equation1020. intro H. specialize (H F5_0). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not1637 : ~ @Equation1637 Fin5 refa861_inst.
Proof. unfold Equation1637. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not1645 : ~ @Equation1645 Fin5 refa861_inst.
Proof. unfold Equation1645. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not1684 : ~ @Equation1684 Fin5 refa861_inst.
Proof. unfold Equation1684. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not1692 : ~ @Equation1692 Fin5 refa861_inst.
Proof. unfold Equation1692. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not1722 : ~ @Equation1722 Fin5 refa861_inst.
Proof. unfold Equation1722. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not1731 : ~ @Equation1731 Fin5 refa861_inst.
Proof. unfold Equation1731. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not1857 : ~ @Equation1857 Fin5 refa861_inst.
Proof. unfold Equation1857. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not1894 : ~ @Equation1894 Fin5 refa861_inst.
Proof. unfold Equation1894. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not1922 : ~ @Equation1922 Fin5 refa861_inst.
Proof. unfold Equation1922. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not2444 : ~ @Equation2444 Fin5 refa861_inst.
Proof. unfold Equation2444. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not2466 : ~ @Equation2466 Fin5 refa861_inst.
Proof. unfold Equation2466. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not2496 : ~ @Equation2496 Fin5 refa861_inst.
Proof. unfold Equation2496. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not2504 : ~ @Equation2504 Fin5 refa861_inst.
Proof. unfold Equation2504. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not2530 : ~ @Equation2530 Fin5 refa861_inst.
Proof. unfold Equation2530. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not2534 : ~ @Equation2534 Fin5 refa861_inst.
Proof. unfold Equation2534. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not2543 : ~ @Equation2543 Fin5 refa861_inst.
Proof. unfold Equation2543. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not2644 : ~ @Equation2644 Fin5 refa861_inst.
Proof. unfold Equation2644. intro H. specialize (H F5_0). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not2847 : ~ @Equation2847 Fin5 refa861_inst.
Proof. unfold Equation2847. intro H. specialize (H F5_0). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not3056 : ~ @Equation3056 Fin5 refa861_inst.
Proof. unfold Equation3056. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not3068 : ~ @Equation3068 Fin5 refa861_inst.
Proof. unfold Equation3068. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not3253 : ~ @Equation3253 Fin5 refa861_inst.
Proof. unfold Equation3253. intro H. specialize (H F5_0). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not3472 : ~ @Equation3472 Fin5 refa861_inst.
Proof. unfold Equation3472. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not3556 : ~ @Equation3556 Fin5 refa861_inst.
Proof. unfold Equation3556. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not3659 : ~ @Equation3659 Fin5 refa861_inst.
Proof. unfold Equation3659. intro H. specialize (H F5_0). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not4071 : ~ @Equation4071 Fin5 refa861_inst.
Proof. unfold Equation4071. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not4120 : ~ @Equation4120 Fin5 refa861_inst.
Proof. unfold Equation4120. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not4273 : ~ @Equation4273 Fin5 refa861_inst.
Proof. unfold Equation4273. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not4293 : ~ @Equation4293 Fin5 refa861_inst.
Proof. unfold Equation4293. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

Lemma refa861_not4598 : ~ @Equation4598 Fin5 refa861_inst.
Proof. unfold Equation4598. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa861_inst, refa861_op in H. discriminate H. Qed.

(** ---- refa862 (Fin6) ---- *)

Definition refa862_op (x y : Fin6) : Fin6 :=
  match x, y with
  | F6_0, F6_0 => F6_0 | F6_0, F6_1 => F6_2 | F6_0, F6_2 => F6_5 | F6_0, F6_3 => F6_4 | F6_0, F6_4 => F6_5 | F6_0, F6_5 => F6_0
  | F6_1, F6_0 => F6_4 | F6_1, F6_1 => F6_1 | F6_1, F6_2 => F6_4 | F6_1, F6_3 => F6_4 | F6_1, F6_4 => F6_1 | F6_1, F6_5 => F6_1
  | F6_2, F6_0 => F6_3 | F6_2, F6_1 => F6_5 | F6_2, F6_2 => F6_2 | F6_2, F6_3 => F6_2 | F6_2, F6_4 => F6_5 | F6_2, F6_5 => F6_2
  | F6_3, F6_0 => F6_2 | F6_3, F6_1 => F6_2 | F6_3, F6_2 => F6_3 | F6_3, F6_3 => F6_3 | F6_3, F6_4 => F6_3 | F6_3, F6_5 => F6_3
  | F6_4, F6_0 => F6_4 | F6_4, F6_1 => F6_2 | F6_4, F6_2 => F6_5 | F6_4, F6_3 => F6_5 | F6_4, F6_4 => F6_4 | F6_4, F6_5 => F6_4
  | F6_5, F6_0 => F6_2 | F6_5, F6_1 => F6_2 | F6_5, F6_2 => F6_5 | F6_5, F6_3 => F6_5 | F6_5, F6_4 => F6_5 | F6_5, F6_5 => F6_5
  end.

#[local] Instance refa862_inst : Magma Fin6 := {| magma_op := refa862_op |}.

Lemma refa862_sat827 : @Equation827 Fin6 refa862_inst.
Proof. unfold Equation827, magma_op, refa862_inst, refa862_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa862_not616 : ~ @Equation616 Fin6 refa862_inst.
Proof. unfold Equation616. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa862_inst, refa862_op in H. discriminate H. Qed.

Lemma refa862_not1026 : ~ @Equation1026 Fin6 refa862_inst.
Proof. unfold Equation1026. intro H. specialize (H F6_0 F6_1). unfold magma_op, refa862_inst, refa862_op in H. discriminate H. Qed.

Lemma refa862_not3318 : ~ @Equation3318 Fin6 refa862_inst.
Proof. unfold Equation3318. intro H. specialize (H F6_1 F6_0). unfold magma_op, refa862_inst, refa862_op in H. discriminate H. Qed.

Lemma refa862_not3918 : ~ @Equation3918 Fin6 refa862_inst.
Proof. unfold Equation3918. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa862_inst, refa862_op in H. discriminate H. Qed.

Lemma refa862_not4131 : ~ @Equation4131 Fin6 refa862_inst.
Proof. unfold Equation4131. intro H. specialize (H F6_0 F6_3). unfold magma_op, refa862_inst, refa862_op in H. discriminate H. Qed.

(** ---- refa863 (Fin5) ---- *)

Definition refa863_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_1 | F5_0, F5_1 => F5_3 | F5_0, F5_2 => F5_3 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_2 | F5_1, F5_1 => F5_3 | F5_1, F5_2 => F5_3 | F5_1, F5_3 => F5_4 | F5_1, F5_4 => F5_1
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_3 | F5_2, F5_2 => F5_3 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_1 | F5_3, F5_1 => F5_3 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_4 | F5_3, F5_4 => F5_1
  | F5_4, F5_0 => F5_2 | F5_4, F5_1 => F5_3 | F5_4, F5_2 => F5_3 | F5_4, F5_3 => F5_4 | F5_4, F5_4 => F5_2
  end.

#[local] Instance refa863_inst : Magma Fin5 := {| magma_op := refa863_op |}.

Lemma refa863_sat828 : @Equation828 Fin5 refa863_inst.
Proof. unfold Equation828, magma_op, refa863_inst, refa863_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa863_sat838 : @Equation838 Fin5 refa863_inst.
Proof. unfold Equation838, magma_op, refa863_inst, refa863_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa863_not1426 : ~ @Equation1426 Fin5 refa863_inst.
Proof. unfold Equation1426. intro H. specialize (H F5_0). unfold magma_op, refa863_inst, refa863_op in H. discriminate H. Qed.

Lemma refa863_not3862 : ~ @Equation3862 Fin5 refa863_inst.
Proof. unfold Equation3862. intro H. specialize (H F5_4). unfold magma_op, refa863_inst, refa863_op in H. discriminate H. Qed.

Lemma refa863_not4065 : ~ @Equation4065 Fin5 refa863_inst.
Proof. unfold Equation4065. intro H. specialize (H F5_0). unfold magma_op, refa863_inst, refa863_op in H. discriminate H. Qed.

Lemma refa863_not4599 : ~ @Equation4599 Fin5 refa863_inst.
Proof. unfold Equation4599. intro H. specialize (H F5_0 F5_3). unfold magma_op, refa863_inst, refa863_op in H. discriminate H. Qed.

(** ---- refa864 (Fin5) ---- *)

Definition refa864_op (x y : Fin5) : Fin5 :=
  match x, y with
  | F5_0, F5_0 => F5_0 | F5_0, F5_1 => F5_2 | F5_0, F5_2 => F5_0 | F5_0, F5_3 => F5_0 | F5_0, F5_4 => F5_2
  | F5_1, F5_0 => F5_3 | F5_1, F5_1 => F5_1 | F5_1, F5_2 => F5_1 | F5_1, F5_3 => F5_1 | F5_1, F5_4 => F5_2
  | F5_2, F5_0 => F5_2 | F5_2, F5_1 => F5_2 | F5_2, F5_2 => F5_2 | F5_2, F5_3 => F5_4 | F5_2, F5_4 => F5_2
  | F5_3, F5_0 => F5_3 | F5_3, F5_1 => F5_2 | F5_3, F5_2 => F5_3 | F5_3, F5_3 => F5_3 | F5_3, F5_4 => F5_2
  | F5_4, F5_0 => F5_4 | F5_4, F5_1 => F5_2 | F5_4, F5_2 => F5_4 | F5_4, F5_3 => F5_2 | F5_4, F5_4 => F5_4
  end.

#[local] Instance refa864_inst : Magma Fin5 := {| magma_op := refa864_op |}.

Lemma refa864_sat829 : @Equation829 Fin5 refa864_inst.
Proof. unfold Equation829, magma_op, refa864_inst, refa864_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa864_sat1236 : @Equation1236 Fin5 refa864_inst.
Proof. unfold Equation1236, magma_op, refa864_inst, refa864_op. intros x y z. destruct x, y, z; reflexivity. Qed.

Lemma refa864_not825 : ~ @Equation825 Fin5 refa864_inst.
Proof. unfold Equation825. intro H. specialize (H F5_0 F5_1). unfold magma_op, refa864_inst, refa864_op in H. discriminate H. Qed.
