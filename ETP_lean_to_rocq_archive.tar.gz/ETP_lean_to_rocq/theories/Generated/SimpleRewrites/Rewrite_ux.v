(** * SimpleRewrites/Rewrite_ux

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation358_implies_Equation354
  (G : Type) `{Magma G} (h : Equation358 G) : Equation354 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation410_implies_Equation406
  (G : Type) `{Magma G} (h : Equation410 G) : Equation406 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation1217_implies_Equation1197
  (G : Type) `{Magma G} (h : Equation1217 G) : Equation1197 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation1477_implies_Equation1473
  (G : Type) `{Magma G} (h : Equation1477 G) : Equation1473 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation1624_implies_Equation1604
  (G : Type) `{Magma G} (h : Equation1624 G) : Equation1604 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation1883_implies_Equation1879
  (G : Type) `{Magma G} (h : Equation1883 G) : Equation1879 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation2436_implies_Equation2416
  (G : Type) `{Magma G} (h : Equation2436 G) : Equation2416 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation2438_implies_Equation2418
  (G : Type) `{Magma G} (h : Equation2438 G) : Equation2418 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3304_implies_Equation3300
  (G : Type) `{Magma G} (h : Equation3304 G) : Equation3300 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3341_implies_Equation3337
  (G : Type) `{Magma G} (h : Equation3341 G) : Equation3337 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3378_implies_Equation3374
  (G : Type) `{Magma G} (h : Equation3378 G) : Equation3374 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3395_implies_Equation3391
  (G : Type) `{Magma G} (h : Equation3395 G) : Equation3391 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3412_implies_Equation3408
  (G : Type) `{Magma G} (h : Equation3412 G) : Equation3408 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3429_implies_Equation3425
  (G : Type) `{Magma G} (h : Equation3429 G) : Equation3425 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3439_implies_Equation3435
  (G : Type) `{Magma G} (h : Equation3439 G) : Equation3435 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3444_implies_Equation3440
  (G : Type) `{Magma G} (h : Equation3444 G) : Equation3440 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3449_implies_Equation3445
  (G : Type) `{Magma G} (h : Equation3449 G) : Equation3445 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3452_implies_Equation3432
  (G : Type) `{Magma G} (h : Equation3452 G) : Equation3432 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3453_implies_Equation3433
  (G : Type) `{Magma G} (h : Equation3453 G) : Equation3433 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3507_implies_Equation3503
  (G : Type) `{Magma G} (h : Equation3507 G) : Equation3503 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3598_implies_Equation3594
  (G : Type) `{Magma G} (h : Equation3598 G) : Equation3594 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3615_implies_Equation3611
  (G : Type) `{Magma G} (h : Equation3615 G) : Equation3611 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3632_implies_Equation3628
  (G : Type) `{Magma G} (h : Equation3632 G) : Equation3628 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3637_implies_Equation3633
  (G : Type) `{Magma G} (h : Equation3637 G) : Equation3633 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3642_implies_Equation3638
  (G : Type) `{Magma G} (h : Equation3642 G) : Equation3638 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3647_implies_Equation3643
  (G : Type) `{Magma G} (h : Equation3647 G) : Equation3643 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3652_implies_Equation3648
  (G : Type) `{Magma G} (h : Equation3652 G) : Equation3648 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3653_implies_Equation3633
  (G : Type) `{Magma G} (h : Equation3653 G) : Equation3633 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3654_implies_Equation3634
  (G : Type) `{Magma G} (h : Equation3654 G) : Equation3634 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3655_implies_Equation3635
  (G : Type) `{Magma G} (h : Equation3655 G) : Equation3635 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3656_implies_Equation3636
  (G : Type) `{Magma G} (h : Equation3656 G) : Equation3636 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3657_implies_Equation3633
  (G : Type) `{Magma G} (h : Equation3657 G) : Equation3633 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3710_implies_Equation3706
  (G : Type) `{Magma G} (h : Equation3710 G) : Equation3706 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3784_implies_Equation3780
  (G : Type) `{Magma G} (h : Equation3784 G) : Equation3780 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3835_implies_Equation3831
  (G : Type) `{Magma G} (h : Equation3835 G) : Equation3831 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3913_implies_Equation3909
  (G : Type) `{Magma G} (h : Equation3913 G) : Equation3909 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation3987_implies_Equation3983
  (G : Type) `{Magma G} (h : Equation3987 G) : Equation3983 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4004_implies_Equation4000
  (G : Type) `{Magma G} (h : Equation4004 G) : Equation4000 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4021_implies_Equation4017
  (G : Type) `{Magma G} (h : Equation4021 G) : Equation4017 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4038_implies_Equation4034
  (G : Type) `{Magma G} (h : Equation4038 G) : Equation4034 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4043_implies_Equation4039
  (G : Type) `{Magma G} (h : Equation4043 G) : Equation4039 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4053_implies_Equation4049
  (G : Type) `{Magma G} (h : Equation4053 G) : Equation4049 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4058_implies_Equation4054
  (G : Type) `{Magma G} (h : Equation4058 G) : Equation4054 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4059_implies_Equation4039
  (G : Type) `{Magma G} (h : Equation4059 G) : Equation4039 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4061_implies_Equation4041
  (G : Type) `{Magma G} (h : Equation4061 G) : Equation4041 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4062_implies_Equation4042
  (G : Type) `{Magma G} (h : Equation4062 G) : Equation4042 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4063_implies_Equation4039
  (G : Type) `{Magma G} (h : Equation4063 G) : Equation4039 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4256_implies_Equation4252
  (G : Type) `{Magma G} (h : Equation4256 G) : Equation4252 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4263_implies_Equation4243
  (G : Type) `{Magma G} (h : Equation4263 G) : Equation4243 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4264_implies_Equation4244
  (G : Type) `{Magma G} (h : Equation4264 G) : Equation4244 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4265_implies_Equation4245
  (G : Type) `{Magma G} (h : Equation4265 G) : Equation4245 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4356_implies_Equation4353
  (G : Type) `{Magma G} (h : Equation4356 G) : Equation4353 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4368_implies_Equation4366
  (G : Type) `{Magma G} (h : Equation4368 G) : Equation4366 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4373_implies_Equation4371
  (G : Type) `{Magma G} (h : Equation4373 G) : Equation4371 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4566_implies_Equation4562
  (G : Type) `{Magma G} (h : Equation4566 G) : Equation4562 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4577_implies_Equation4557
  (G : Type) `{Magma G} (h : Equation4577 G) : Equation4557 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4628_implies_Equation4624
  (G : Type) `{Magma G} (h : Equation4628 G) : Equation4624 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4683_implies_Equation4681
  (G : Type) `{Magma G} (h : Equation4683 G) : Equation4681 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

Theorem Equation4688_implies_Equation4686
  (G : Type) `{Magma G} (h : Equation4688 G) : Equation4686 G.
Proof. intros x y z w. exact (h x y z w x). Qed.

