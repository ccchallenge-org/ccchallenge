(** * SimpleRewrites/Rewrite_uy_vu

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation816_implies_Equation800
  (G : Type) `{Magma G} (h : Equation816 G) : Equation800 G.
Proof. intros x y z w u. exact (h x y z w y u). Qed.

Theorem Equation1019_implies_Equation1003
  (G : Type) `{Magma G} (h : Equation1019 G) : Equation1003 G.
Proof. intros x y z w u. exact (h x y z w y u). Qed.

Theorem Equation1222_implies_Equation1206
  (G : Type) `{Magma G} (h : Equation1222 G) : Equation1206 G.
Proof. intros x y z w u. exact (h x y z w y u). Qed.

Theorem Equation1628_implies_Equation1612
  (G : Type) `{Magma G} (h : Equation1628 G) : Equation1612 G.
Proof. intros x y z w u. exact (h x y z w y u). Qed.

Theorem Equation2034_implies_Equation2018
  (G : Type) `{Magma G} (h : Equation2034 G) : Equation2018 G.
Proof. intros x y z w u. exact (h x y z w y u). Qed.

Theorem Equation2237_implies_Equation2221
  (G : Type) `{Magma G} (h : Equation2237 G) : Equation2221 G.
Proof. intros x y z w u. exact (h x y z w y u). Qed.

Theorem Equation2643_implies_Equation2627
  (G : Type) `{Magma G} (h : Equation2643 G) : Equation2627 G.
Proof. intros x y z w u. exact (h x y z w y u). Qed.

Theorem Equation3049_implies_Equation3033
  (G : Type) `{Magma G} (h : Equation3049 G) : Equation3033 G.
Proof. intros x y z w u. exact (h x y z w y u). Qed.

Theorem Equation3658_implies_Equation3642
  (G : Type) `{Magma G} (h : Equation3658 G) : Equation3642 G.
Proof. intros x y z w u. exact (h x y z w y u). Qed.

Theorem Equation4064_implies_Equation4048
  (G : Type) `{Magma G} (h : Equation4064 G) : Equation4048 G.
Proof. intros x y z w u. exact (h x y z w y u). Qed.

