(** * SimpleRewrites/Rewrite_uw_wy

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation150_implies_Equation141
  (G : Type) `{Magma G} (h : Equation150 G) : Equation141 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation202_implies_Equation193
  (G : Type) `{Magma G} (h : Equation202 G) : Equation193 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation254_implies_Equation245
  (G : Type) `{Magma G} (h : Equation254 G) : Equation245 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation358_implies_Equation349
  (G : Type) `{Magma G} (h : Equation358 G) : Equation349 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation410_implies_Equation401
  (G : Type) `{Magma G} (h : Equation410 G) : Equation401 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation462_implies_Equation453
  (G : Type) `{Magma G} (h : Equation462 G) : Equation453 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation536_implies_Equation527
  (G : Type) `{Magma G} (h : Equation536 G) : Equation527 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation592_implies_Equation557
  (G : Type) `{Magma G} (h : Equation592 G) : Equation557 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation608_implies_Equation566
  (G : Type) `{Magma G} (h : Equation608 G) : Equation566 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation665_implies_Equation656
  (G : Type) `{Magma G} (h : Equation665 G) : Equation656 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation773_implies_Equation764
  (G : Type) `{Magma G} (h : Equation773 G) : Equation764 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation811_implies_Equation769
  (G : Type) `{Magma G} (h : Equation811 G) : Equation769 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation868_implies_Equation859
  (G : Type) `{Magma G} (h : Equation868 G) : Equation859 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation942_implies_Equation933
  (G : Type) `{Magma G} (h : Equation942 G) : Equation933 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation959_implies_Equation950
  (G : Type) `{Magma G} (h : Equation959 G) : Equation950 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation998_implies_Equation963
  (G : Type) `{Magma G} (h : Equation998 G) : Equation963 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1008_implies_Equation971
  (G : Type) `{Magma G} (h : Equation1008 G) : Equation971 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1018_implies_Equation975
  (G : Type) `{Magma G} (h : Equation1018 G) : Equation975 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1071_implies_Equation1062
  (G : Type) `{Magma G} (h : Equation1071 G) : Equation1062 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1108_implies_Equation1099
  (G : Type) `{Magma G} (h : Equation1108 G) : Equation1099 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1145_implies_Equation1136
  (G : Type) `{Magma G} (h : Equation1145 G) : Equation1136 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1162_implies_Equation1153
  (G : Type) `{Magma G} (h : Equation1162 G) : Equation1153 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1179_implies_Equation1170
  (G : Type) `{Magma G} (h : Equation1179 G) : Equation1170 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1196_implies_Equation1187
  (G : Type) `{Magma G} (h : Equation1196 G) : Equation1187 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1201_implies_Equation1166
  (G : Type) `{Magma G} (h : Equation1201 G) : Equation1166 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1348_implies_Equation1339
  (G : Type) `{Magma G} (h : Equation1348 G) : Equation1339 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1382_implies_Equation1373
  (G : Type) `{Magma G} (h : Equation1382 G) : Equation1373 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1399_implies_Equation1390
  (G : Type) `{Magma G} (h : Equation1399 G) : Equation1390 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1551_implies_Equation1542
  (G : Type) `{Magma G} (h : Equation1551 G) : Equation1542 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1568_implies_Equation1559
  (G : Type) `{Magma G} (h : Equation1568 G) : Equation1559 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1585_implies_Equation1576
  (G : Type) `{Magma G} (h : Equation1585 G) : Equation1576 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1602_implies_Equation1593
  (G : Type) `{Magma G} (h : Equation1602 G) : Equation1593 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1607_implies_Equation1572
  (G : Type) `{Magma G} (h : Equation1607 G) : Equation1572 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1623_implies_Equation1581
  (G : Type) `{Magma G} (h : Equation1623 G) : Equation1581 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1680_implies_Equation1671
  (G : Type) `{Magma G} (h : Equation1680 G) : Equation1671 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1771_implies_Equation1762
  (G : Type) `{Magma G} (h : Equation1771 G) : Equation1762 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1826_implies_Equation1784
  (G : Type) `{Magma G} (h : Equation1826 G) : Equation1784 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1920_implies_Equation1911
  (G : Type) `{Magma G} (h : Equation1920 G) : Equation1911 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1957_implies_Equation1948
  (G : Type) `{Magma G} (h : Equation1957 G) : Equation1948 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation1974_implies_Equation1965
  (G : Type) `{Magma G} (h : Equation1974 G) : Equation1965 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2013_implies_Equation1978
  (G : Type) `{Magma G} (h : Equation2013 G) : Equation1978 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2029_implies_Equation1987
  (G : Type) `{Magma G} (h : Equation2029 G) : Equation1987 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2086_implies_Equation2077
  (G : Type) `{Magma G} (h : Equation2086 G) : Equation2077 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2123_implies_Equation2114
  (G : Type) `{Magma G} (h : Equation2123 G) : Equation2114 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2160_implies_Equation2151
  (G : Type) `{Magma G} (h : Equation2160 G) : Equation2151 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2177_implies_Equation2168
  (G : Type) `{Magma G} (h : Equation2177 G) : Equation2168 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2194_implies_Equation2185
  (G : Type) `{Magma G} (h : Equation2194 G) : Equation2185 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2211_implies_Equation2202
  (G : Type) `{Magma G} (h : Equation2211 G) : Equation2202 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2216_implies_Equation2181
  (G : Type) `{Magma G} (h : Equation2216 G) : Equation2181 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2232_implies_Equation2190
  (G : Type) `{Magma G} (h : Equation2232 G) : Equation2190 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2289_implies_Equation2280
  (G : Type) `{Magma G} (h : Equation2289 G) : Equation2280 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2326_implies_Equation2317
  (G : Type) `{Magma G} (h : Equation2326 G) : Equation2317 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2380_implies_Equation2371
  (G : Type) `{Magma G} (h : Equation2380 G) : Equation2371 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2429_implies_Equation2392
  (G : Type) `{Magma G} (h : Equation2429 G) : Equation2392 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2435_implies_Equation2393
  (G : Type) `{Magma G} (h : Equation2435 G) : Equation2393 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2492_implies_Equation2483
  (G : Type) `{Magma G} (h : Equation2492 G) : Equation2483 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2529_implies_Equation2520
  (G : Type) `{Magma G} (h : Equation2529 G) : Equation2520 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2566_implies_Equation2557
  (G : Type) `{Magma G} (h : Equation2566 G) : Equation2557 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2583_implies_Equation2574
  (G : Type) `{Magma G} (h : Equation2583 G) : Equation2574 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2600_implies_Equation2591
  (G : Type) `{Magma G} (h : Equation2600 G) : Equation2591 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2617_implies_Equation2608
  (G : Type) `{Magma G} (h : Equation2617 G) : Equation2608 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2622_implies_Equation2587
  (G : Type) `{Magma G} (h : Equation2622 G) : Equation2587 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2638_implies_Equation2596
  (G : Type) `{Magma G} (h : Equation2638 G) : Equation2596 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2695_implies_Equation2686
  (G : Type) `{Magma G} (h : Equation2695 G) : Equation2686 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2732_implies_Equation2723
  (G : Type) `{Magma G} (h : Equation2732 G) : Equation2723 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2786_implies_Equation2777
  (G : Type) `{Magma G} (h : Equation2786 G) : Equation2777 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2803_implies_Equation2794
  (G : Type) `{Magma G} (h : Equation2803 G) : Equation2794 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2825_implies_Equation2790
  (G : Type) `{Magma G} (h : Equation2825 G) : Equation2790 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2841_implies_Equation2799
  (G : Type) `{Magma G} (h : Equation2841 G) : Equation2799 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2898_implies_Equation2889
  (G : Type) `{Magma G} (h : Equation2898 G) : Equation2889 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2935_implies_Equation2926
  (G : Type) `{Magma G} (h : Equation2935 G) : Equation2926 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2972_implies_Equation2963
  (G : Type) `{Magma G} (h : Equation2972 G) : Equation2963 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation2989_implies_Equation2980
  (G : Type) `{Magma G} (h : Equation2989 G) : Equation2980 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3023_implies_Equation3014
  (G : Type) `{Magma G} (h : Equation3023 G) : Equation3014 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3028_implies_Equation2993
  (G : Type) `{Magma G} (h : Equation3028 G) : Equation2993 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3044_implies_Equation3002
  (G : Type) `{Magma G} (h : Equation3044 G) : Equation3002 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3101_implies_Equation3092
  (G : Type) `{Magma G} (h : Equation3101 G) : Equation3092 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3138_implies_Equation3129
  (G : Type) `{Magma G} (h : Equation3138 G) : Equation3129 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3175_implies_Equation3166
  (G : Type) `{Magma G} (h : Equation3175 G) : Equation3166 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3247_implies_Equation3205
  (G : Type) `{Magma G} (h : Equation3247 G) : Equation3205 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3395_implies_Equation3386
  (G : Type) `{Magma G} (h : Equation3395 G) : Equation3386 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3412_implies_Equation3403
  (G : Type) `{Magma G} (h : Equation3412 G) : Equation3403 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3450_implies_Equation3408
  (G : Type) `{Magma G} (h : Equation3450 G) : Equation3408 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3454_implies_Equation3411
  (G : Type) `{Magma G} (h : Equation3454 G) : Equation3411 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3507_implies_Equation3498
  (G : Type) `{Magma G} (h : Equation3507 G) : Equation3498 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3544_implies_Equation3535
  (G : Type) `{Magma G} (h : Equation3544 G) : Equation3535 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3581_implies_Equation3572
  (G : Type) `{Magma G} (h : Equation3581 G) : Equation3572 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3632_implies_Equation3623
  (G : Type) `{Magma G} (h : Equation3632 G) : Equation3623 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3647_implies_Equation3610
  (G : Type) `{Magma G} (h : Equation3647 G) : Equation3610 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3655_implies_Equation3613
  (G : Type) `{Magma G} (h : Equation3655 G) : Equation3613 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3657_implies_Equation3614
  (G : Type) `{Magma G} (h : Equation3657 G) : Equation3614 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3747_implies_Equation3738
  (G : Type) `{Magma G} (h : Equation3747 G) : Equation3738 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3784_implies_Equation3775
  (G : Type) `{Magma G} (h : Equation3784 G) : Equation3775 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3835_implies_Equation3826
  (G : Type) `{Magma G} (h : Equation3835 G) : Equation3826 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3840_implies_Equation3805
  (G : Type) `{Magma G} (h : Equation3840 G) : Equation3805 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3845_implies_Equation3809
  (G : Type) `{Magma G} (h : Equation3845 G) : Equation3809 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3850_implies_Equation3813
  (G : Type) `{Magma G} (h : Equation3850 G) : Equation3813 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3856_implies_Equation3814
  (G : Type) `{Magma G} (h : Equation3856 G) : Equation3814 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3857_implies_Equation3815
  (G : Type) `{Magma G} (h : Equation3857 G) : Equation3815 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3860_implies_Equation3817
  (G : Type) `{Magma G} (h : Equation3860 G) : Equation3817 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3950_implies_Equation3941
  (G : Type) `{Magma G} (h : Equation3950 G) : Equation3941 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation3987_implies_Equation3978
  (G : Type) `{Magma G} (h : Equation3987 G) : Equation3978 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4004_implies_Equation3995
  (G : Type) `{Magma G} (h : Equation4004 G) : Equation3995 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4038_implies_Equation4029
  (G : Type) `{Magma G} (h : Equation4038 G) : Equation4029 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4053_implies_Equation4016
  (G : Type) `{Magma G} (h : Equation4053 G) : Equation4016 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4058_implies_Equation4012
  (G : Type) `{Magma G} (h : Equation4058 G) : Equation4012 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4059_implies_Equation4017
  (G : Type) `{Magma G} (h : Equation4059 G) : Equation4017 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4060_implies_Equation4018
  (G : Type) `{Magma G} (h : Equation4060 G) : Equation4018 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4061_implies_Equation4019
  (G : Type) `{Magma G} (h : Equation4061 G) : Equation4019 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4063_implies_Equation4020
  (G : Type) `{Magma G} (h : Equation4063 G) : Equation4020 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4116_implies_Equation4107
  (G : Type) `{Magma G} (h : Equation4116 G) : Equation4107 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4153_implies_Equation4144
  (G : Type) `{Magma G} (h : Equation4153 G) : Equation4144 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4190_implies_Equation4181
  (G : Type) `{Magma G} (h : Equation4190 G) : Equation4181 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4207_implies_Equation4198
  (G : Type) `{Magma G} (h : Equation4207 G) : Equation4198 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4241_implies_Equation4232
  (G : Type) `{Magma G} (h : Equation4241 G) : Equation4232 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4246_implies_Equation4211
  (G : Type) `{Magma G} (h : Equation4246 G) : Equation4211 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4256_implies_Equation4219
  (G : Type) `{Magma G} (h : Equation4256 G) : Equation4219 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4261_implies_Equation4215
  (G : Type) `{Magma G} (h : Equation4261 G) : Equation4215 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4263_implies_Equation4221
  (G : Type) `{Magma G} (h : Equation4263 G) : Equation4221 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4264_implies_Equation4222
  (G : Type) `{Magma G} (h : Equation4264 G) : Equation4222 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4266_implies_Equation4223
  (G : Type) `{Magma G} (h : Equation4266 G) : Equation4223 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4373_implies_Equation4370
  (G : Type) `{Magma G} (h : Equation4373 G) : Equation4370 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4378_implies_Equation4367
  (G : Type) `{Magma G} (h : Equation4378 G) : Equation4367 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4505_implies_Equation4496
  (G : Type) `{Magma G} (h : Equation4505 G) : Equation4496 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4556_implies_Equation4547
  (G : Type) `{Magma G} (h : Equation4556 G) : Equation4547 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4571_implies_Equation4534
  (G : Type) `{Magma G} (h : Equation4571 G) : Equation4534 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4576_implies_Equation4530
  (G : Type) `{Magma G} (h : Equation4576 G) : Equation4530 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4577_implies_Equation4535
  (G : Type) `{Magma G} (h : Equation4577 G) : Equation4535 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4578_implies_Equation4536
  (G : Type) `{Magma G} (h : Equation4578 G) : Equation4536 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4579_implies_Equation4537
  (G : Type) `{Magma G} (h : Equation4579 G) : Equation4537 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4580_implies_Equation4536
  (G : Type) `{Magma G} (h : Equation4580 G) : Equation4536 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4628_implies_Equation4621
  (G : Type) `{Magma G} (h : Equation4628 G) : Equation4621 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

Theorem Equation4693_implies_Equation4682
  (G : Type) `{Magma G} (h : Equation4693 G) : Equation4682 G.
Proof. intros x y z w. exact (h x y z y w). Qed.

