(** * SimpleRewrites/Rewrite_vz

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation613_implies_Equation610
  (G : Type) `{Magma G} (h : Equation613 G) : Equation610 G.
Proof. intros x y z w u. exact (h x y z w u z). Qed.

Theorem Equation816_implies_Equation813
  (G : Type) `{Magma G} (h : Equation816 G) : Equation813 G.
Proof. intros x y z w u. exact (h x y z w u z). Qed.

Theorem Equation1019_implies_Equation1016
  (G : Type) `{Magma G} (h : Equation1019 G) : Equation1016 G.
Proof. intros x y z w u. exact (h x y z w u z). Qed.

Theorem Equation1222_implies_Equation1219
  (G : Type) `{Magma G} (h : Equation1222 G) : Equation1219 G.
Proof. intros x y z w u. exact (h x y z w u z). Qed.

Theorem Equation1425_implies_Equation1422
  (G : Type) `{Magma G} (h : Equation1425 G) : Equation1422 G.
Proof. intros x y z w u. exact (h x y z w u z). Qed.

Theorem Equation1628_implies_Equation1625
  (G : Type) `{Magma G} (h : Equation1628 G) : Equation1625 G.
Proof. intros x y z w u. exact (h x y z w u z). Qed.

Theorem Equation2034_implies_Equation2031
  (G : Type) `{Magma G} (h : Equation2034 G) : Equation2031 G.
Proof. intros x y z w u. exact (h x y z w u z). Qed.

Theorem Equation2237_implies_Equation2234
  (G : Type) `{Magma G} (h : Equation2237 G) : Equation2234 G.
Proof. intros x y z w u. exact (h x y z w u z). Qed.

Theorem Equation2643_implies_Equation2640
  (G : Type) `{Magma G} (h : Equation2643 G) : Equation2640 G.
Proof. intros x y z w u. exact (h x y z w u z). Qed.

Theorem Equation2846_implies_Equation2843
  (G : Type) `{Magma G} (h : Equation2846 G) : Equation2843 G.
Proof. intros x y z w u. exact (h x y z w u z). Qed.

Theorem Equation3049_implies_Equation3046
  (G : Type) `{Magma G} (h : Equation3049 G) : Equation3046 G.
Proof. intros x y z w u. exact (h x y z w u z). Qed.

Theorem Equation3252_implies_Equation3249
  (G : Type) `{Magma G} (h : Equation3252 G) : Equation3249 G.
Proof. intros x y z w u. exact (h x y z w u z). Qed.

Theorem Equation3861_implies_Equation3858
  (G : Type) `{Magma G} (h : Equation3861 G) : Equation3858 G.
Proof. intros x y z w u. exact (h x y z w u z). Qed.

