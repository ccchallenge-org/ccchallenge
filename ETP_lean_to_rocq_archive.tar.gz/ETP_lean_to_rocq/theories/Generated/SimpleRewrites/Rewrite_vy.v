(** * SimpleRewrites/Rewrite_vy

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation613_implies_Equation609
  (G : Type) `{Magma G} (h : Equation613 G) : Equation609 G.
Proof. intros x y z w u. exact (h x y z w u y). Qed.

Theorem Equation816_implies_Equation812
  (G : Type) `{Magma G} (h : Equation816 G) : Equation812 G.
Proof. intros x y z w u. exact (h x y z w u y). Qed.

Theorem Equation1019_implies_Equation1015
  (G : Type) `{Magma G} (h : Equation1019 G) : Equation1015 G.
Proof. intros x y z w u. exact (h x y z w u y). Qed.

Theorem Equation1222_implies_Equation1218
  (G : Type) `{Magma G} (h : Equation1222 G) : Equation1218 G.
Proof. intros x y z w u. exact (h x y z w u y). Qed.

Theorem Equation1425_implies_Equation1421
  (G : Type) `{Magma G} (h : Equation1425 G) : Equation1421 G.
Proof. intros x y z w u. exact (h x y z w u y). Qed.

Theorem Equation1628_implies_Equation1624
  (G : Type) `{Magma G} (h : Equation1628 G) : Equation1624 G.
Proof. intros x y z w u. exact (h x y z w u y). Qed.

Theorem Equation2034_implies_Equation2030
  (G : Type) `{Magma G} (h : Equation2034 G) : Equation2030 G.
Proof. intros x y z w u. exact (h x y z w u y). Qed.

Theorem Equation2237_implies_Equation2233
  (G : Type) `{Magma G} (h : Equation2237 G) : Equation2233 G.
Proof. intros x y z w u. exact (h x y z w u y). Qed.

Theorem Equation2643_implies_Equation2639
  (G : Type) `{Magma G} (h : Equation2643 G) : Equation2639 G.
Proof. intros x y z w u. exact (h x y z w u y). Qed.

Theorem Equation2846_implies_Equation2842
  (G : Type) `{Magma G} (h : Equation2846 G) : Equation2842 G.
Proof. intros x y z w u. exact (h x y z w u y). Qed.

Theorem Equation3049_implies_Equation3045
  (G : Type) `{Magma G} (h : Equation3049 G) : Equation3045 G.
Proof. intros x y z w u. exact (h x y z w u y). Qed.

Theorem Equation3252_implies_Equation3248
  (G : Type) `{Magma G} (h : Equation3252 G) : Equation3248 G.
Proof. intros x y z w u. exact (h x y z w u y). Qed.

