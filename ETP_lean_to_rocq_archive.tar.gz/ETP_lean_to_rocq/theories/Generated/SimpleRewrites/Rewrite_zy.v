(** * SimpleRewrites/Rewrite_zy

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation18_implies_Equation17
  (G : Type) `{Magma G} (h : Equation18 G) : Equation17 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation20_implies_Equation17
  (G : Type) `{Magma G} (h : Equation20 G) : Equation17 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation33_implies_Equation32
  (G : Type) `{Magma G} (h : Equation33 G) : Equation32 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation34_implies_Equation31
  (G : Type) `{Magma G} (h : Equation34 G) : Equation31 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation41_implies_Equation40
  (G : Type) `{Magma G} (h : Equation41 G) : Equation40 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation86_implies_Equation75
  (G : Type) `{Magma G} (h : Equation86 G) : Equation75 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation88_implies_Equation76
  (G : Type) `{Magma G} (h : Equation88 G) : Equation76 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation92_implies_Equation76
  (G : Type) `{Magma G} (h : Equation92 G) : Equation76 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation129_implies_Equation128
  (G : Type) `{Magma G} (h : Equation129 G) : Equation128 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation131_implies_Equation128
  (G : Type) `{Magma G} (h : Equation131 G) : Equation128 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation132_implies_Equation128
  (G : Type) `{Magma G} (h : Equation132 G) : Equation128 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation134_implies_Equation124
  (G : Type) `{Magma G} (h : Equation134 G) : Equation124 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation136_implies_Equation125
  (G : Type) `{Magma G} (h : Equation136 G) : Equation125 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation162_implies_Equation159
  (G : Type) `{Magma G} (h : Equation162 G) : Equation159 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation168_implies_Equation167
  (G : Type) `{Magma G} (h : Equation168 G) : Equation167 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation172_implies_Equation169
  (G : Type) `{Magma G} (h : Equation172 G) : Equation169 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation181_implies_Equation180
  (G : Type) `{Magma G} (h : Equation181 G) : Equation180 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation186_implies_Equation176
  (G : Type) `{Magma G} (h : Equation186 G) : Equation176 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation194_implies_Equation179
  (G : Type) `{Magma G} (h : Equation194 G) : Equation179 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation207_implies_Equation206
  (G : Type) `{Magma G} (h : Equation207 G) : Equation206 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation215_implies_Equation212
  (G : Type) `{Magma G} (h : Equation215 G) : Equation212 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation233_implies_Equation232
  (G : Type) `{Magma G} (h : Equation233 G) : Equation232 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation244_implies_Equation232
  (G : Type) `{Magma G} (h : Equation244 G) : Equation232 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation247_implies_Equation232
  (G : Type) `{Magma G} (h : Equation247 G) : Equation232 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation248_implies_Equation232
  (G : Type) `{Magma G} (h : Equation248 G) : Equation232 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation265_implies_Equation264
  (G : Type) `{Magma G} (h : Equation265 G) : Equation264 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation288_implies_Equation284
  (G : Type) `{Magma G} (h : Equation288 G) : Equation284 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation318_implies_Equation315
  (G : Type) `{Magma G} (h : Equation318 G) : Equation315 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation320_implies_Equation316
  (G : Type) `{Magma G} (h : Equation320 G) : Equation316 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation327_implies_Equation326
  (G : Type) `{Magma G} (h : Equation327 G) : Equation326 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation329_implies_Equation326
  (G : Type) `{Magma G} (h : Equation329 G) : Equation326 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation343_implies_Equation333
  (G : Type) `{Magma G} (h : Equation343 G) : Equation333 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation350_implies_Equation335
  (G : Type) `{Magma G} (h : Equation350 G) : Equation335 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation351_implies_Equation336
  (G : Type) `{Magma G} (h : Equation351 G) : Equation336 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation363_implies_Equation362
  (G : Type) `{Magma G} (h : Equation363 G) : Equation362 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation369_implies_Equation368
  (G : Type) `{Magma G} (h : Equation369 G) : Equation368 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation372_implies_Equation368
  (G : Type) `{Magma G} (h : Equation372 G) : Equation368 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation379_implies_Equation378
  (G : Type) `{Magma G} (h : Equation379 G) : Equation378 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation381_implies_Equation378
  (G : Type) `{Magma G} (h : Equation381 G) : Equation378 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation390_implies_Equation387
  (G : Type) `{Magma G} (h : Equation390 G) : Equation387 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation391_implies_Equation388
  (G : Type) `{Magma G} (h : Equation391 G) : Equation388 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation394_implies_Equation384
  (G : Type) `{Magma G} (h : Equation394 G) : Equation384 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation399_implies_Equation388
  (G : Type) `{Magma G} (h : Equation399 G) : Equation388 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation403_implies_Equation388
  (G : Type) `{Magma G} (h : Equation403 G) : Equation388 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation415_implies_Equation414
  (G : Type) `{Magma G} (h : Equation415 G) : Equation414 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation418_implies_Equation417
  (G : Type) `{Magma G} (h : Equation418 G) : Equation417 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation421_implies_Equation420
  (G : Type) `{Magma G} (h : Equation421 G) : Equation420 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation422_implies_Equation419
  (G : Type) `{Magma G} (h : Equation422 G) : Equation419 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation428_implies_Equation427
  (G : Type) `{Magma G} (h : Equation428 G) : Equation427 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation432_implies_Equation429
  (G : Type) `{Magma G} (h : Equation432 G) : Equation429 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation434_implies_Equation430
  (G : Type) `{Magma G} (h : Equation434 G) : Equation430 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation442_implies_Equation439
  (G : Type) `{Magma G} (h : Equation442 G) : Equation439 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation443_implies_Equation440
  (G : Type) `{Magma G} (h : Equation443 G) : Equation440 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation444_implies_Equation440
  (G : Type) `{Magma G} (h : Equation444 G) : Equation440 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation450_implies_Equation439
  (G : Type) `{Magma G} (h : Equation450 G) : Equation439 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation452_implies_Equation440
  (G : Type) `{Magma G} (h : Equation452 G) : Equation440 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation475_implies_Equation474
  (G : Type) `{Magma G} (h : Equation475 G) : Equation474 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation479_implies_Equation476
  (G : Type) `{Magma G} (h : Equation479 G) : Equation476 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation481_implies_Equation477
  (G : Type) `{Magma G} (h : Equation481 G) : Equation477 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation525_implies_Equation514
  (G : Type) `{Magma G} (h : Equation525 G) : Equation514 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation528_implies_Equation513
  (G : Type) `{Magma G} (h : Equation528 G) : Equation513 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation554_implies_Equation510
  (G : Type) `{Magma G} (h : Equation554 G) : Equation510 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation562_implies_Equation513
  (G : Type) `{Magma G} (h : Equation562 G) : Equation513 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation581_implies_Equation514
  (G : Type) `{Magma G} (h : Equation581 G) : Equation514 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation618_implies_Equation617
  (G : Type) `{Magma G} (h : Equation618 G) : Equation617 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation621_implies_Equation620
  (G : Type) `{Magma G} (h : Equation621 G) : Equation620 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation624_implies_Equation623
  (G : Type) `{Magma G} (h : Equation624 G) : Equation623 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation625_implies_Equation622
  (G : Type) `{Magma G} (h : Equation625 G) : Equation622 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation634_implies_Equation633
  (G : Type) `{Magma G} (h : Equation634 G) : Equation633 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation635_implies_Equation632
  (G : Type) `{Magma G} (h : Equation635 G) : Equation632 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation645_implies_Equation642
  (G : Type) `{Magma G} (h : Equation645 G) : Equation642 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation646_implies_Equation643
  (G : Type) `{Magma G} (h : Equation646 G) : Equation643 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation647_implies_Equation643
  (G : Type) `{Magma G} (h : Equation647 G) : Equation643 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation653_implies_Equation642
  (G : Type) `{Magma G} (h : Equation653 G) : Equation642 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation657_implies_Equation642
  (G : Type) `{Magma G} (h : Equation657 G) : Equation642 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation658_implies_Equation643
  (G : Type) `{Magma G} (h : Equation658 G) : Equation643 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation690_implies_Equation679
  (G : Type) `{Magma G} (h : Equation690 G) : Equation679 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation718_implies_Equation717
  (G : Type) `{Magma G} (h : Equation718 G) : Equation717 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation723_implies_Equation713
  (G : Type) `{Magma G} (h : Equation723 G) : Equation713 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation725_implies_Equation714
  (G : Type) `{Magma G} (h : Equation725 G) : Equation714 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation731_implies_Equation716
  (G : Type) `{Magma G} (h : Equation731 G) : Equation716 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation733_implies_Equation717
  (G : Type) `{Magma G} (h : Equation733 G) : Equation717 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation775_implies_Equation714
  (G : Type) `{Magma G} (h : Equation775 G) : Equation714 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation776_implies_Equation714
  (G : Type) `{Magma G} (h : Equation776 G) : Equation714 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation821_implies_Equation820
  (G : Type) `{Magma G} (h : Equation821 G) : Equation820 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation828_implies_Equation825
  (G : Type) `{Magma G} (h : Equation828 G) : Equation825 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation834_implies_Equation833
  (G : Type) `{Magma G} (h : Equation834 G) : Equation833 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation837_implies_Equation836
  (G : Type) `{Magma G} (h : Equation837 G) : Equation836 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation838_implies_Equation835
  (G : Type) `{Magma G} (h : Equation838 G) : Equation835 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation839_implies_Equation836
  (G : Type) `{Magma G} (h : Equation839 G) : Equation836 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation840_implies_Equation836
  (G : Type) `{Magma G} (h : Equation840 G) : Equation836 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation844_implies_Equation843
  (G : Type) `{Magma G} (h : Equation844 G) : Equation843 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation847_implies_Equation846
  (G : Type) `{Magma G} (h : Equation847 G) : Equation846 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation848_implies_Equation845
  (G : Type) `{Magma G} (h : Equation848 G) : Equation845 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation850_implies_Equation846
  (G : Type) `{Magma G} (h : Equation850 G) : Equation846 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation852_implies_Equation842
  (G : Type) `{Magma G} (h : Equation852 G) : Equation842 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation854_implies_Equation843
  (G : Type) `{Magma G} (h : Equation854 G) : Equation843 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation856_implies_Equation845
  (G : Type) `{Magma G} (h : Equation856 G) : Equation845 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation860_implies_Equation845
  (G : Type) `{Magma G} (h : Equation860 G) : Equation845 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation861_implies_Equation846
  (G : Type) `{Magma G} (h : Equation861 G) : Equation846 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation887_implies_Equation883
  (G : Type) `{Magma G} (h : Equation887 G) : Equation883 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation891_implies_Equation880
  (G : Type) `{Magma G} (h : Equation891 G) : Equation880 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation898_implies_Equation883
  (G : Type) `{Magma G} (h : Equation898 G) : Equation883 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation914_implies_Equation910
  (G : Type) `{Magma G} (h : Equation914 G) : Equation910 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation921_implies_Equation920
  (G : Type) `{Magma G} (h : Equation921 G) : Equation920 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation934_implies_Equation919
  (G : Type) `{Magma G} (h : Equation934 G) : Equation919 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation949_implies_Equation910
  (G : Type) `{Magma G} (h : Equation949 G) : Equation910 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation960_implies_Equation916
  (G : Type) `{Magma G} (h : Equation960 G) : Equation916 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation962_implies_Equation917
  (G : Type) `{Magma G} (h : Equation962 G) : Equation917 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation978_implies_Equation917
  (G : Type) `{Magma G} (h : Equation978 G) : Equation917 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1027_implies_Equation1026
  (G : Type) `{Magma G} (h : Equation1027 G) : Equation1026 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1031_implies_Equation1028
  (G : Type) `{Magma G} (h : Equation1031 G) : Equation1028 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1041_implies_Equation1038
  (G : Type) `{Magma G} (h : Equation1041 G) : Equation1038 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1042_implies_Equation1039
  (G : Type) `{Magma G} (h : Equation1042 G) : Equation1039 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1050_implies_Equation1049
  (G : Type) `{Magma G} (h : Equation1050 G) : Equation1049 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1051_implies_Equation1048
  (G : Type) `{Magma G} (h : Equation1051 G) : Equation1048 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1052_implies_Equation1049
  (G : Type) `{Magma G} (h : Equation1052 G) : Equation1049 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1055_implies_Equation1045
  (G : Type) `{Magma G} (h : Equation1055 G) : Equation1045 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1056_implies_Equation1046
  (G : Type) `{Magma G} (h : Equation1056 G) : Equation1046 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1061_implies_Equation1049
  (G : Type) `{Magma G} (h : Equation1061 G) : Equation1049 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1063_implies_Equation1048
  (G : Type) `{Magma G} (h : Equation1063 G) : Equation1048 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1064_implies_Equation1049
  (G : Type) `{Magma G} (h : Equation1064 G) : Equation1049 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1117_implies_Equation1113
  (G : Type) `{Magma G} (h : Equation1117 G) : Equation1113 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1152_implies_Equation1113
  (G : Type) `{Magma G} (h : Equation1152 G) : Equation1113 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1155_implies_Equation1113
  (G : Type) `{Magma G} (h : Equation1155 G) : Equation1113 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1163_implies_Equation1119
  (G : Type) `{Magma G} (h : Equation1163 G) : Equation1119 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1184_implies_Equation1122
  (G : Type) `{Magma G} (h : Equation1184 G) : Equation1122 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1227_implies_Equation1226
  (G : Type) `{Magma G} (h : Equation1227 G) : Equation1226 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1230_implies_Equation1229
  (G : Type) `{Magma G} (h : Equation1230 G) : Equation1229 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1233_implies_Equation1232
  (G : Type) `{Magma G} (h : Equation1233 G) : Equation1232 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1234_implies_Equation1231
  (G : Type) `{Magma G} (h : Equation1234 G) : Equation1231 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1235_implies_Equation1232
  (G : Type) `{Magma G} (h : Equation1235 G) : Equation1232 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1236_implies_Equation1232
  (G : Type) `{Magma G} (h : Equation1236 G) : Equation1232 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1240_implies_Equation1239
  (G : Type) `{Magma G} (h : Equation1240 G) : Equation1239 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1243_implies_Equation1242
  (G : Type) `{Magma G} (h : Equation1243 G) : Equation1242 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1244_implies_Equation1241
  (G : Type) `{Magma G} (h : Equation1244 G) : Equation1241 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1245_implies_Equation1242
  (G : Type) `{Magma G} (h : Equation1245 G) : Equation1242 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1250_implies_Equation1249
  (G : Type) `{Magma G} (h : Equation1250 G) : Equation1249 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1253_implies_Equation1252
  (G : Type) `{Magma G} (h : Equation1253 G) : Equation1252 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1254_implies_Equation1251
  (G : Type) `{Magma G} (h : Equation1254 G) : Equation1251 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1256_implies_Equation1252
  (G : Type) `{Magma G} (h : Equation1256 G) : Equation1252 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1258_implies_Equation1248
  (G : Type) `{Magma G} (h : Equation1258 G) : Equation1248 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1259_implies_Equation1249
  (G : Type) `{Magma G} (h : Equation1259 G) : Equation1249 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1262_implies_Equation1251
  (G : Type) `{Magma G} (h : Equation1262 G) : Equation1251 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1327_implies_Equation1326
  (G : Type) `{Magma G} (h : Equation1327 G) : Equation1326 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1329_implies_Equation1326
  (G : Type) `{Magma G} (h : Equation1329 G) : Equation1326 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1340_implies_Equation1325
  (G : Type) `{Magma G} (h : Equation1340 G) : Equation1325 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1353_implies_Equation1315
  (G : Type) `{Magma G} (h : Equation1353 G) : Equation1315 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1368_implies_Equation1323
  (G : Type) `{Magma G} (h : Equation1368 G) : Equation1323 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1384_implies_Equation1323
  (G : Type) `{Magma G} (h : Equation1384 G) : Equation1323 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1430_implies_Equation1429
  (G : Type) `{Magma G} (h : Equation1430 G) : Equation1429 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1437_implies_Equation1434
  (G : Type) `{Magma G} (h : Equation1437 G) : Equation1434 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1443_implies_Equation1442
  (G : Type) `{Magma G} (h : Equation1443 G) : Equation1442 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1447_implies_Equation1444
  (G : Type) `{Magma G} (h : Equation1447 G) : Equation1444 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1453_implies_Equation1452
  (G : Type) `{Magma G} (h : Equation1453 G) : Equation1452 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1457_implies_Equation1454
  (G : Type) `{Magma G} (h : Equation1457 G) : Equation1454 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1459_implies_Equation1455
  (G : Type) `{Magma G} (h : Equation1459 G) : Equation1455 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1461_implies_Equation1451
  (G : Type) `{Magma G} (h : Equation1461 G) : Equation1451 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1469_implies_Equation1454
  (G : Type) `{Magma G} (h : Equation1469 G) : Equation1454 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1480_implies_Equation1479
  (G : Type) `{Magma G} (h : Equation1480 G) : Equation1479 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1483_implies_Equation1482
  (G : Type) `{Magma G} (h : Equation1483 G) : Equation1482 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1484_implies_Equation1481
  (G : Type) `{Magma G} (h : Equation1484 G) : Equation1481 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1486_implies_Equation1482
  (G : Type) `{Magma G} (h : Equation1486 G) : Equation1482 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1496_implies_Equation1492
  (G : Type) `{Magma G} (h : Equation1496 G) : Equation1492 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1504_implies_Equation1492
  (G : Type) `{Magma G} (h : Equation1504 G) : Equation1492 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1506_implies_Equation1491
  (G : Type) `{Magma G} (h : Equation1506 G) : Equation1491 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1523_implies_Equation1519
  (G : Type) `{Magma G} (h : Equation1523 G) : Equation1519 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1560_implies_Equation1518
  (G : Type) `{Magma G} (h : Equation1560 G) : Equation1518 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1586_implies_Equation1525
  (G : Type) `{Magma G} (h : Equation1586 G) : Equation1525 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1594_implies_Equation1528
  (G : Type) `{Magma G} (h : Equation1594 G) : Equation1528 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1596_implies_Equation1529
  (G : Type) `{Magma G} (h : Equation1596 G) : Equation1529 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1633_implies_Equation1632
  (G : Type) `{Magma G} (h : Equation1633 G) : Equation1632 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1640_implies_Equation1637
  (G : Type) `{Magma G} (h : Equation1640 G) : Equation1637 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1641_implies_Equation1638
  (G : Type) `{Magma G} (h : Equation1641 G) : Equation1638 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1650_implies_Equation1647
  (G : Type) `{Magma G} (h : Equation1650 G) : Equation1647 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1652_implies_Equation1648
  (G : Type) `{Magma G} (h : Equation1652 G) : Equation1648 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1662_implies_Equation1658
  (G : Type) `{Magma G} (h : Equation1662 G) : Equation1658 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1664_implies_Equation1654
  (G : Type) `{Magma G} (h : Equation1664 G) : Equation1654 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1668_implies_Equation1657
  (G : Type) `{Magma G} (h : Equation1668 G) : Equation1657 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1672_implies_Equation1657
  (G : Type) `{Magma G} (h : Equation1672 G) : Equation1657 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1673_implies_Equation1658
  (G : Type) `{Magma G} (h : Equation1673 G) : Equation1658 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1687_implies_Equation1684
  (G : Type) `{Magma G} (h : Equation1687 G) : Equation1684 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1701_implies_Equation1691
  (G : Type) `{Magma G} (h : Equation1701 G) : Equation1691 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1703_implies_Equation1692
  (G : Type) `{Magma G} (h : Equation1703 G) : Equation1692 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1705_implies_Equation1694
  (G : Type) `{Magma G} (h : Equation1705 G) : Equation1694 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1707_implies_Equation1695
  (G : Type) `{Magma G} (h : Equation1707 G) : Equation1695 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1724_implies_Equation1721
  (G : Type) `{Magma G} (h : Equation1724 G) : Equation1721 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1735_implies_Equation1732
  (G : Type) `{Magma G} (h : Equation1735 G) : Equation1732 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1738_implies_Equation1728
  (G : Type) `{Magma G} (h : Equation1738 G) : Equation1728 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1746_implies_Equation1731
  (G : Type) `{Magma G} (h : Equation1746 G) : Equation1731 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1763_implies_Equation1721
  (G : Type) `{Magma G} (h : Equation1763 G) : Equation1721 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1780_implies_Equation1731
  (G : Type) `{Magma G} (h : Equation1780 G) : Equation1731 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1790_implies_Equation1729
  (G : Type) `{Magma G} (h : Equation1790 G) : Equation1729 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1793_implies_Equation1731
  (G : Type) `{Magma G} (h : Equation1793 G) : Equation1731 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1839_implies_Equation1838
  (G : Type) `{Magma G} (h : Equation1839 G) : Equation1838 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1843_implies_Equation1840
  (G : Type) `{Magma G} (h : Equation1843 G) : Equation1840 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1845_implies_Equation1841
  (G : Type) `{Magma G} (h : Equation1845 G) : Equation1841 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1849_implies_Equation1848
  (G : Type) `{Magma G} (h : Equation1849 G) : Equation1848 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1853_implies_Equation1850
  (G : Type) `{Magma G} (h : Equation1853 G) : Equation1850 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1855_implies_Equation1851
  (G : Type) `{Magma G} (h : Equation1855 G) : Equation1851 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1863_implies_Equation1860
  (G : Type) `{Magma G} (h : Equation1863 G) : Equation1860 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1865_implies_Equation1861
  (G : Type) `{Magma G} (h : Equation1865 G) : Equation1861 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1867_implies_Equation1857
  (G : Type) `{Magma G} (h : Equation1867 G) : Equation1857 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1868_implies_Equation1858
  (G : Type) `{Magma G} (h : Equation1868 G) : Equation1858 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1871_implies_Equation1860
  (G : Type) `{Magma G} (h : Equation1871 G) : Equation1860 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1873_implies_Equation1861
  (G : Type) `{Magma G} (h : Equation1873 G) : Equation1861 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1875_implies_Equation1860
  (G : Type) `{Magma G} (h : Equation1875 G) : Equation1860 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1876_implies_Equation1861
  (G : Type) `{Magma G} (h : Equation1876 G) : Equation1861 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1902_implies_Equation1898
  (G : Type) `{Magma G} (h : Equation1902 G) : Equation1898 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1913_implies_Equation1898
  (G : Type) `{Magma G} (h : Equation1913 G) : Equation1898 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1958_implies_Equation1921
  (G : Type) `{Magma G} (h : Equation1958 G) : Equation1921 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1966_implies_Equation1924
  (G : Type) `{Magma G} (h : Equation1966 G) : Equation1924 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1975_implies_Equation1931
  (G : Type) `{Magma G} (h : Equation1975 G) : Equation1931 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1983_implies_Equation1934
  (G : Type) `{Magma G} (h : Equation1983 G) : Equation1934 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1993_implies_Equation1932
  (G : Type) `{Magma G} (h : Equation1993 G) : Equation1932 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1996_implies_Equation1934
  (G : Type) `{Magma G} (h : Equation1996 G) : Equation1934 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation1998_implies_Equation1935
  (G : Type) `{Magma G} (h : Equation1998 G) : Equation1935 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2045_implies_Equation2044
  (G : Type) `{Magma G} (h : Equation2045 G) : Equation2044 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2046_implies_Equation2043
  (G : Type) `{Magma G} (h : Equation2046 G) : Equation2043 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2052_implies_Equation2051
  (G : Type) `{Magma G} (h : Equation2052 G) : Equation2051 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2055_implies_Equation2054
  (G : Type) `{Magma G} (h : Equation2055 G) : Equation2054 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2056_implies_Equation2053
  (G : Type) `{Magma G} (h : Equation2056 G) : Equation2053 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2062_implies_Equation2061
  (G : Type) `{Magma G} (h : Equation2062 G) : Equation2061 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2065_implies_Equation2064
  (G : Type) `{Magma G} (h : Equation2065 G) : Equation2064 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2066_implies_Equation2063
  (G : Type) `{Magma G} (h : Equation2066 G) : Equation2063 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2070_implies_Equation2060
  (G : Type) `{Magma G} (h : Equation2070 G) : Equation2060 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2078_implies_Equation2063
  (G : Type) `{Magma G} (h : Equation2078 G) : Equation2063 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2079_implies_Equation2064
  (G : Type) `{Magma G} (h : Equation2079 G) : Equation2064 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2089_implies_Equation2088
  (G : Type) `{Magma G} (h : Equation2089 G) : Equation2088 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2093_implies_Equation2090
  (G : Type) `{Magma G} (h : Equation2093 G) : Equation2090 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2113_implies_Equation2101
  (G : Type) `{Magma G} (h : Equation2113 G) : Equation2101 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2115_implies_Equation2100
  (G : Type) `{Magma G} (h : Equation2115 G) : Equation2100 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2126_implies_Equation2125
  (G : Type) `{Magma G} (h : Equation2126 G) : Equation2125 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2132_implies_Equation2128
  (G : Type) `{Magma G} (h : Equation2132 G) : Equation2128 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2139_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2139 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2141_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2141 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2142_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2142 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2149_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2149 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2150_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2150 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2152_implies_Equation2137
  (G : Type) `{Magma G} (h : Equation2152 G) : Equation2137 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2153_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2153 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2154_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2154 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2161_implies_Equation2124
  (G : Type) `{Magma G} (h : Equation2161 G) : Equation2124 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2162_implies_Equation2125
  (G : Type) `{Magma G} (h : Equation2162 G) : Equation2125 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2163_implies_Equation2125
  (G : Type) `{Magma G} (h : Equation2163 G) : Equation2125 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2183_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2183 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2184_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2184 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2187_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2187 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2188_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2188 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2201_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2201 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2203_implies_Equation2137
  (G : Type) `{Magma G} (h : Equation2203 G) : Equation2137 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2204_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2204 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2205_implies_Equation2138
  (G : Type) `{Magma G} (h : Equation2205 G) : Equation2138 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2249_implies_Equation2246
  (G : Type) `{Magma G} (h : Equation2249 G) : Equation2246 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2251_implies_Equation2247
  (G : Type) `{Magma G} (h : Equation2251 G) : Equation2247 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2259_implies_Equation2256
  (G : Type) `{Magma G} (h : Equation2259 G) : Equation2256 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2260_implies_Equation2257
  (G : Type) `{Magma G} (h : Equation2260 G) : Equation2257 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2270_implies_Equation2267
  (G : Type) `{Magma G} (h : Equation2270 G) : Equation2267 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2271_implies_Equation2267
  (G : Type) `{Magma G} (h : Equation2271 G) : Equation2267 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2273_implies_Equation2263
  (G : Type) `{Magma G} (h : Equation2273 G) : Equation2263 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2277_implies_Equation2266
  (G : Type) `{Magma G} (h : Equation2277 G) : Equation2266 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2281_implies_Equation2266
  (G : Type) `{Magma G} (h : Equation2281 G) : Equation2266 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2296_implies_Equation2293
  (G : Type) `{Magma G} (h : Equation2296 G) : Equation2293 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2310_implies_Equation2300
  (G : Type) `{Magma G} (h : Equation2310 G) : Equation2300 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2314_implies_Equation2303
  (G : Type) `{Magma G} (h : Equation2314 G) : Equation2303 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2316_implies_Equation2304
  (G : Type) `{Magma G} (h : Equation2316 G) : Equation2304 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2318_implies_Equation2303
  (G : Type) `{Magma G} (h : Equation2318 G) : Equation2303 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2319_implies_Equation2304
  (G : Type) `{Magma G} (h : Equation2319 G) : Equation2304 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2342_implies_Equation2341
  (G : Type) `{Magma G} (h : Equation2342 G) : Equation2341 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2347_implies_Equation2337
  (G : Type) `{Magma G} (h : Equation2347 G) : Equation2337 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2355_implies_Equation2340
  (G : Type) `{Magma G} (h : Equation2355 G) : Equation2340 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2364_implies_Equation2327
  (G : Type) `{Magma G} (h : Equation2364 G) : Equation2327 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2366_implies_Equation2328
  (G : Type) `{Magma G} (h : Equation2366 G) : Equation2328 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2368_implies_Equation2330
  (G : Type) `{Magma G} (h : Equation2368 G) : Equation2330 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2370_implies_Equation2331
  (G : Type) `{Magma G} (h : Equation2370 G) : Equation2331 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2372_implies_Equation2330
  (G : Type) `{Magma G} (h : Equation2372 G) : Equation2330 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2373_implies_Equation2331
  (G : Type) `{Magma G} (h : Equation2373 G) : Equation2331 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2381_implies_Equation2337
  (G : Type) `{Magma G} (h : Equation2381 G) : Equation2337 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2398_implies_Equation2337
  (G : Type) `{Magma G} (h : Equation2398 G) : Equation2337 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2406_implies_Equation2340
  (G : Type) `{Magma G} (h : Equation2406 G) : Equation2340 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2451_implies_Equation2450
  (G : Type) `{Magma G} (h : Equation2451 G) : Equation2450 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2452_implies_Equation2449
  (G : Type) `{Magma G} (h : Equation2452 G) : Equation2449 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2462_implies_Equation2459
  (G : Type) `{Magma G} (h : Equation2462 G) : Equation2459 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2472_implies_Equation2469
  (G : Type) `{Magma G} (h : Equation2472 G) : Equation2469 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2476_implies_Equation2466
  (G : Type) `{Magma G} (h : Equation2476 G) : Equation2466 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2482_implies_Equation2470
  (G : Type) `{Magma G} (h : Equation2482 G) : Equation2470 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2484_implies_Equation2469
  (G : Type) `{Magma G} (h : Equation2484 G) : Equation2469 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2511_implies_Equation2507
  (G : Type) `{Magma G} (h : Equation2511 G) : Equation2507 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2513_implies_Equation2503
  (G : Type) `{Magma G} (h : Equation2513 G) : Equation2503 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2517_implies_Equation2506
  (G : Type) `{Magma G} (h : Equation2517 G) : Equation2506 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2522_implies_Equation2507
  (G : Type) `{Magma G} (h : Equation2522 G) : Equation2507 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2538_implies_Equation2534
  (G : Type) `{Magma G} (h : Equation2538 G) : Equation2534 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2545_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2545 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2547_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2547 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2548_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2548 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2555_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2555 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2556_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2556 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2559_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2559 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2560_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2560 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2567_implies_Equation2530
  (G : Type) `{Magma G} (h : Equation2567 G) : Equation2530 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2571_implies_Equation2533
  (G : Type) `{Magma G} (h : Equation2571 G) : Equation2533 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2573_implies_Equation2534
  (G : Type) `{Magma G} (h : Equation2573 G) : Equation2534 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2576_implies_Equation2534
  (G : Type) `{Magma G} (h : Equation2576 G) : Equation2534 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2588_implies_Equation2543
  (G : Type) `{Magma G} (h : Equation2588 G) : Equation2543 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2589_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2589 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2590_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2590 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2592_implies_Equation2543
  (G : Type) `{Magma G} (h : Equation2592 G) : Equation2543 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2593_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2593 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2594_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2594 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2605_implies_Equation2543
  (G : Type) `{Magma G} (h : Equation2605 G) : Equation2543 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2606_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2606 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2607_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2607 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2609_implies_Equation2543
  (G : Type) `{Magma G} (h : Equation2609 G) : Equation2543 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2610_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2610 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2611_implies_Equation2544
  (G : Type) `{Magma G} (h : Equation2611 G) : Equation2544 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2655_implies_Equation2652
  (G : Type) `{Magma G} (h : Equation2655 G) : Equation2652 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2656_implies_Equation2653
  (G : Type) `{Magma G} (h : Equation2656 G) : Equation2653 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2665_implies_Equation2662
  (G : Type) `{Magma G} (h : Equation2665 G) : Equation2662 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2675_implies_Equation2672
  (G : Type) `{Magma G} (h : Equation2675 G) : Equation2672 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2679_implies_Equation2669
  (G : Type) `{Magma G} (h : Equation2679 G) : Equation2669 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2683_implies_Equation2672
  (G : Type) `{Magma G} (h : Equation2683 G) : Equation2672 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2687_implies_Equation2672
  (G : Type) `{Magma G} (h : Equation2687 G) : Equation2672 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2702_implies_Equation2699
  (G : Type) `{Magma G} (h : Equation2702 G) : Equation2699 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2712_implies_Equation2709
  (G : Type) `{Magma G} (h : Equation2712 G) : Equation2709 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2722_implies_Equation2710
  (G : Type) `{Magma G} (h : Equation2722 G) : Equation2710 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2724_implies_Equation2709
  (G : Type) `{Magma G} (h : Equation2724 G) : Equation2709 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2739_implies_Equation2736
  (G : Type) `{Magma G} (h : Equation2739 G) : Equation2736 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2741_implies_Equation2737
  (G : Type) `{Magma G} (h : Equation2741 G) : Equation2737 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2748_implies_Equation2747
  (G : Type) `{Magma G} (h : Equation2748 G) : Equation2747 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2750_implies_Equation2747
  (G : Type) `{Magma G} (h : Equation2750 G) : Equation2747 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2751_implies_Equation2747
  (G : Type) `{Magma G} (h : Equation2751 G) : Equation2747 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2755_implies_Equation2744
  (G : Type) `{Magma G} (h : Equation2755 G) : Equation2744 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2759_implies_Equation2747
  (G : Type) `{Magma G} (h : Equation2759 G) : Equation2747 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2763_implies_Equation2747
  (G : Type) `{Magma G} (h : Equation2763 G) : Equation2747 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2770_implies_Equation2733
  (G : Type) `{Magma G} (h : Equation2770 G) : Equation2733 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2774_implies_Equation2736
  (G : Type) `{Magma G} (h : Equation2774 G) : Equation2736 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2776_implies_Equation2737
  (G : Type) `{Magma G} (h : Equation2776 G) : Equation2737 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2778_implies_Equation2736
  (G : Type) `{Magma G} (h : Equation2778 G) : Equation2736 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2792_implies_Equation2747
  (G : Type) `{Magma G} (h : Equation2792 G) : Equation2747 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2793_implies_Equation2747
  (G : Type) `{Magma G} (h : Equation2793 G) : Equation2747 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2795_implies_Equation2746
  (G : Type) `{Magma G} (h : Equation2795 G) : Equation2746 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2796_implies_Equation2747
  (G : Type) `{Magma G} (h : Equation2796 G) : Equation2747 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2797_implies_Equation2747
  (G : Type) `{Magma G} (h : Equation2797 G) : Equation2747 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2805_implies_Equation2744
  (G : Type) `{Magma G} (h : Equation2805 G) : Equation2744 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2808_implies_Equation2746
  (G : Type) `{Magma G} (h : Equation2808 G) : Equation2746 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2810_implies_Equation2747
  (G : Type) `{Magma G} (h : Equation2810 G) : Equation2747 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2812_implies_Equation2746
  (G : Type) `{Magma G} (h : Equation2812 G) : Equation2746 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2860_implies_Equation2856
  (G : Type) `{Magma G} (h : Equation2860 G) : Equation2856 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2868_implies_Equation2865
  (G : Type) `{Magma G} (h : Equation2868 G) : Equation2865 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2878_implies_Equation2875
  (G : Type) `{Magma G} (h : Equation2878 G) : Equation2875 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2880_implies_Equation2876
  (G : Type) `{Magma G} (h : Equation2880 G) : Equation2876 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2882_implies_Equation2872
  (G : Type) `{Magma G} (h : Equation2882 G) : Equation2872 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2883_implies_Equation2873
  (G : Type) `{Magma G} (h : Equation2883 G) : Equation2873 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2886_implies_Equation2875
  (G : Type) `{Magma G} (h : Equation2886 G) : Equation2875 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2890_implies_Equation2875
  (G : Type) `{Magma G} (h : Equation2890 G) : Equation2875 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2919_implies_Equation2909
  (G : Type) `{Magma G} (h : Equation2919 G) : Equation2909 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2951_implies_Equation2950
  (G : Type) `{Magma G} (h : Equation2951 G) : Equation2950 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2953_implies_Equation2950
  (G : Type) `{Magma G} (h : Equation2953 G) : Equation2950 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2954_implies_Equation2950
  (G : Type) `{Magma G} (h : Equation2954 G) : Equation2950 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2961_implies_Equation2950
  (G : Type) `{Magma G} (h : Equation2961 G) : Equation2950 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2962_implies_Equation2950
  (G : Type) `{Magma G} (h : Equation2962 G) : Equation2950 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2964_implies_Equation2949
  (G : Type) `{Magma G} (h : Equation2964 G) : Equation2949 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2965_implies_Equation2950
  (G : Type) `{Magma G} (h : Equation2965 G) : Equation2950 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2966_implies_Equation2950
  (G : Type) `{Magma G} (h : Equation2966 G) : Equation2950 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2973_implies_Equation2936
  (G : Type) `{Magma G} (h : Equation2973 G) : Equation2936 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2981_implies_Equation2939
  (G : Type) `{Magma G} (h : Equation2981 G) : Equation2939 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2994_implies_Equation2949
  (G : Type) `{Magma G} (h : Equation2994 G) : Equation2949 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation2999_implies_Equation2950
  (G : Type) `{Magma G} (h : Equation2999 G) : Equation2950 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3007_implies_Equation2946
  (G : Type) `{Magma G} (h : Equation3007 G) : Equation2946 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3011_implies_Equation2949
  (G : Type) `{Magma G} (h : Equation3011 G) : Equation2949 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3071_implies_Equation3068
  (G : Type) `{Magma G} (h : Equation3071 G) : Equation3068 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3073_implies_Equation3069
  (G : Type) `{Magma G} (h : Equation3073 G) : Equation3069 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3083_implies_Equation3079
  (G : Type) `{Magma G} (h : Equation3083 G) : Equation3079 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3085_implies_Equation3075
  (G : Type) `{Magma G} (h : Equation3085 G) : Equation3075 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3086_implies_Equation3076
  (G : Type) `{Magma G} (h : Equation3086 G) : Equation3076 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3089_implies_Equation3078
  (G : Type) `{Magma G} (h : Equation3089 G) : Equation3078 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3091_implies_Equation3079
  (G : Type) `{Magma G} (h : Equation3091 G) : Equation3079 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3093_implies_Equation3078
  (G : Type) `{Magma G} (h : Equation3093 G) : Equation3078 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3108_implies_Equation3105
  (G : Type) `{Magma G} (h : Equation3108 G) : Equation3105 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3122_implies_Equation3112
  (G : Type) `{Magma G} (h : Equation3122 G) : Equation3112 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3145_implies_Equation3142
  (G : Type) `{Magma G} (h : Equation3145 G) : Equation3142 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3161_implies_Equation3150
  (G : Type) `{Magma G} (h : Equation3161 G) : Equation3150 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3167_implies_Equation3152
  (G : Type) `{Magma G} (h : Equation3167 G) : Equation3152 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3176_implies_Equation3139
  (G : Type) `{Magma G} (h : Equation3176 G) : Equation3139 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3197_implies_Equation3152
  (G : Type) `{Magma G} (h : Equation3197 G) : Equation3152 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3199_implies_Equation3153
  (G : Type) `{Magma G} (h : Equation3199 G) : Equation3153 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3201_implies_Equation3152
  (G : Type) `{Magma G} (h : Equation3201 G) : Equation3152 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3210_implies_Equation3149
  (G : Type) `{Magma G} (h : Equation3210 G) : Equation3149 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3216_implies_Equation3153
  (G : Type) `{Magma G} (h : Equation3216 G) : Equation3153 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3257_implies_Equation3256
  (G : Type) `{Magma G} (h : Equation3257 G) : Equation3256 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3260_implies_Equation3259
  (G : Type) `{Magma G} (h : Equation3260 G) : Equation3259 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3264_implies_Equation3261
  (G : Type) `{Magma G} (h : Equation3264 G) : Equation3261 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3265_implies_Equation3262
  (G : Type) `{Magma G} (h : Equation3265 G) : Equation3262 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3266_implies_Equation3262
  (G : Type) `{Magma G} (h : Equation3266 G) : Equation3262 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3274_implies_Equation3271
  (G : Type) `{Magma G} (h : Equation3274 G) : Equation3271 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3284_implies_Equation3281
  (G : Type) `{Magma G} (h : Equation3284 G) : Equation3281 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3285_implies_Equation3282
  (G : Type) `{Magma G} (h : Equation3285 G) : Equation3282 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3286_implies_Equation3282
  (G : Type) `{Magma G} (h : Equation3286 G) : Equation3282 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3288_implies_Equation3278
  (G : Type) `{Magma G} (h : Equation3288 G) : Equation3278 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3292_implies_Equation3281
  (G : Type) `{Magma G} (h : Equation3292 G) : Equation3281 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3293_implies_Equation3282
  (G : Type) `{Magma G} (h : Equation3293 G) : Equation3282 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3294_implies_Equation3282
  (G : Type) `{Magma G} (h : Equation3294 G) : Equation3282 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3296_implies_Equation3281
  (G : Type) `{Magma G} (h : Equation3296 G) : Equation3281 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3297_implies_Equation3282
  (G : Type) `{Magma G} (h : Equation3297 G) : Equation3282 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3310_implies_Equation3309
  (G : Type) `{Magma G} (h : Equation3310 G) : Equation3309 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3312_implies_Equation3309
  (G : Type) `{Magma G} (h : Equation3312 G) : Equation3309 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3321_implies_Equation3318
  (G : Type) `{Magma G} (h : Equation3321 G) : Equation3318 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3322_implies_Equation3319
  (G : Type) `{Magma G} (h : Equation3322 G) : Equation3319 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3323_implies_Equation3319
  (G : Type) `{Magma G} (h : Equation3323 G) : Equation3319 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3326_implies_Equation3316
  (G : Type) `{Magma G} (h : Equation3326 G) : Equation3316 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3331_implies_Equation3319
  (G : Type) `{Magma G} (h : Equation3331 G) : Equation3319 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3334_implies_Equation3319
  (G : Type) `{Magma G} (h : Equation3334 G) : Equation3319 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3350_implies_Equation3346
  (G : Type) `{Magma G} (h : Equation3350 G) : Equation3346 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3359_implies_Equation3356
  (G : Type) `{Magma G} (h : Equation3359 G) : Equation3356 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3364_implies_Equation3353
  (G : Type) `{Magma G} (h : Equation3364 G) : Equation3353 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3370_implies_Equation3355
  (G : Type) `{Magma G} (h : Equation3370 G) : Equation3355 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3380_implies_Equation3343
  (G : Type) `{Magma G} (h : Equation3380 G) : Equation3343 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3387_implies_Equation3345
  (G : Type) `{Magma G} (h : Equation3387 G) : Equation3345 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3388_implies_Equation3346
  (G : Type) `{Magma G} (h : Equation3388 G) : Equation3346 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3401_implies_Equation3356
  (G : Type) `{Magma G} (h : Equation3401 G) : Equation3356 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3405_implies_Equation3356
  (G : Type) `{Magma G} (h : Equation3405 G) : Equation3356 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3413_implies_Equation3352
  (G : Type) `{Magma G} (h : Equation3413 G) : Equation3352 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3414_implies_Equation3353
  (G : Type) `{Magma G} (h : Equation3414 G) : Equation3353 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3460_implies_Equation3459
  (G : Type) `{Magma G} (h : Equation3460 G) : Equation3459 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3463_implies_Equation3462
  (G : Type) `{Magma G} (h : Equation3463 G) : Equation3462 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3466_implies_Equation3465
  (G : Type) `{Magma G} (h : Equation3466 G) : Equation3465 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3467_implies_Equation3464
  (G : Type) `{Magma G} (h : Equation3467 G) : Equation3464 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3468_implies_Equation3465
  (G : Type) `{Magma G} (h : Equation3468 G) : Equation3465 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3469_implies_Equation3465
  (G : Type) `{Magma G} (h : Equation3469 G) : Equation3465 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3477_implies_Equation3474
  (G : Type) `{Magma G} (h : Equation3477 G) : Equation3474 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3488_implies_Equation3485
  (G : Type) `{Magma G} (h : Equation3488 G) : Equation3485 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3489_implies_Equation3485
  (G : Type) `{Magma G} (h : Equation3489 G) : Equation3485 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3491_implies_Equation3481
  (G : Type) `{Magma G} (h : Equation3491 G) : Equation3481 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3495_implies_Equation3484
  (G : Type) `{Magma G} (h : Equation3495 G) : Equation3484 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3496_implies_Equation3485
  (G : Type) `{Magma G} (h : Equation3496 G) : Equation3485 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3497_implies_Equation3485
  (G : Type) `{Magma G} (h : Equation3497 G) : Equation3485 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3499_implies_Equation3484
  (G : Type) `{Magma G} (h : Equation3499 G) : Equation3484 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3500_implies_Equation3485
  (G : Type) `{Magma G} (h : Equation3500 G) : Equation3485 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3501_implies_Equation3485
  (G : Type) `{Magma G} (h : Equation3501 G) : Equation3485 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3513_implies_Equation3512
  (G : Type) `{Magma G} (h : Equation3513 G) : Equation3512 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3515_implies_Equation3512
  (G : Type) `{Magma G} (h : Equation3515 G) : Equation3512 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3520_implies_Equation3519
  (G : Type) `{Magma G} (h : Equation3520 G) : Equation3519 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3523_implies_Equation3522
  (G : Type) `{Magma G} (h : Equation3523 G) : Equation3522 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3524_implies_Equation3521
  (G : Type) `{Magma G} (h : Equation3524 G) : Equation3521 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3525_implies_Equation3522
  (G : Type) `{Magma G} (h : Equation3525 G) : Equation3522 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3526_implies_Equation3522
  (G : Type) `{Magma G} (h : Equation3526 G) : Equation3522 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3529_implies_Equation3519
  (G : Type) `{Magma G} (h : Equation3529 G) : Equation3519 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3533_implies_Equation3522
  (G : Type) `{Magma G} (h : Equation3533 G) : Equation3522 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3534_implies_Equation3522
  (G : Type) `{Magma G} (h : Equation3534 G) : Equation3522 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3537_implies_Equation3522
  (G : Type) `{Magma G} (h : Equation3537 G) : Equation3522 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3553_implies_Equation3549
  (G : Type) `{Magma G} (h : Equation3553 G) : Equation3549 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3566_implies_Equation3556
  (G : Type) `{Magma G} (h : Equation3566 G) : Equation3556 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3567_implies_Equation3556
  (G : Type) `{Magma G} (h : Equation3567 G) : Equation3556 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3573_implies_Equation3558
  (G : Type) `{Magma G} (h : Equation3573 G) : Equation3558 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3574_implies_Equation3559
  (G : Type) `{Magma G} (h : Equation3574 G) : Equation3559 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3583_implies_Equation3546
  (G : Type) `{Magma G} (h : Equation3583 G) : Equation3546 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3587_implies_Equation3549
  (G : Type) `{Magma G} (h : Equation3587 G) : Equation3549 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3588_implies_Equation3549
  (G : Type) `{Magma G} (h : Equation3588 G) : Equation3549 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3590_implies_Equation3548
  (G : Type) `{Magma G} (h : Equation3590 G) : Equation3548 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3591_implies_Equation3549
  (G : Type) `{Magma G} (h : Equation3591 G) : Equation3549 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3600_implies_Equation3556
  (G : Type) `{Magma G} (h : Equation3600 G) : Equation3556 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3601_implies_Equation3556
  (G : Type) `{Magma G} (h : Equation3601 G) : Equation3556 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3604_implies_Equation3559
  (G : Type) `{Magma G} (h : Equation3604 G) : Equation3559 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3607_implies_Equation3558
  (G : Type) `{Magma G} (h : Equation3607 G) : Equation3558 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3608_implies_Equation3559
  (G : Type) `{Magma G} (h : Equation3608 G) : Equation3559 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3616_implies_Equation3555
  (G : Type) `{Magma G} (h : Equation3616 G) : Equation3555 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3617_implies_Equation3556
  (G : Type) `{Magma G} (h : Equation3617 G) : Equation3556 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3620_implies_Equation3558
  (G : Type) `{Magma G} (h : Equation3620 G) : Equation3558 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3621_implies_Equation3559
  (G : Type) `{Magma G} (h : Equation3621 G) : Equation3559 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3625_implies_Equation3559
  (G : Type) `{Magma G} (h : Equation3625 G) : Equation3559 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3663_implies_Equation3662
  (G : Type) `{Magma G} (h : Equation3663 G) : Equation3662 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3666_implies_Equation3665
  (G : Type) `{Magma G} (h : Equation3666 G) : Equation3665 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3669_implies_Equation3668
  (G : Type) `{Magma G} (h : Equation3669 G) : Equation3668 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3670_implies_Equation3667
  (G : Type) `{Magma G} (h : Equation3670 G) : Equation3667 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3671_implies_Equation3668
  (G : Type) `{Magma G} (h : Equation3671 G) : Equation3668 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3672_implies_Equation3668
  (G : Type) `{Magma G} (h : Equation3672 G) : Equation3668 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3680_implies_Equation3677
  (G : Type) `{Magma G} (h : Equation3680 G) : Equation3677 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3690_implies_Equation3687
  (G : Type) `{Magma G} (h : Equation3690 G) : Equation3687 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3692_implies_Equation3688
  (G : Type) `{Magma G} (h : Equation3692 G) : Equation3688 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3694_implies_Equation3684
  (G : Type) `{Magma G} (h : Equation3694 G) : Equation3684 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3698_implies_Equation3687
  (G : Type) `{Magma G} (h : Equation3698 G) : Equation3687 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3700_implies_Equation3688
  (G : Type) `{Magma G} (h : Equation3700 G) : Equation3688 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3702_implies_Equation3687
  (G : Type) `{Magma G} (h : Equation3702 G) : Equation3687 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3716_implies_Equation3715
  (G : Type) `{Magma G} (h : Equation3716 G) : Equation3715 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3718_implies_Equation3715
  (G : Type) `{Magma G} (h : Equation3718 G) : Equation3715 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3723_implies_Equation3722
  (G : Type) `{Magma G} (h : Equation3723 G) : Equation3722 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3726_implies_Equation3725
  (G : Type) `{Magma G} (h : Equation3726 G) : Equation3725 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3728_implies_Equation3725
  (G : Type) `{Magma G} (h : Equation3728 G) : Equation3725 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3729_implies_Equation3725
  (G : Type) `{Magma G} (h : Equation3729 G) : Equation3725 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3732_implies_Equation3722
  (G : Type) `{Magma G} (h : Equation3732 G) : Equation3722 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3736_implies_Equation3725
  (G : Type) `{Magma G} (h : Equation3736 G) : Equation3725 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3737_implies_Equation3725
  (G : Type) `{Magma G} (h : Equation3737 G) : Equation3725 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3740_implies_Equation3725
  (G : Type) `{Magma G} (h : Equation3740 G) : Equation3725 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3756_implies_Equation3752
  (G : Type) `{Magma G} (h : Equation3756 G) : Equation3752 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3765_implies_Equation3762
  (G : Type) `{Magma G} (h : Equation3765 G) : Equation3762 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3769_implies_Equation3759
  (G : Type) `{Magma G} (h : Equation3769 G) : Equation3759 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3773_implies_Equation3762
  (G : Type) `{Magma G} (h : Equation3773 G) : Equation3762 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3776_implies_Equation3761
  (G : Type) `{Magma G} (h : Equation3776 G) : Equation3761 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3777_implies_Equation3762
  (G : Type) `{Magma G} (h : Equation3777 G) : Equation3762 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3786_implies_Equation3749
  (G : Type) `{Magma G} (h : Equation3786 G) : Equation3749 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3790_implies_Equation3752
  (G : Type) `{Magma G} (h : Equation3790 G) : Equation3752 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3793_implies_Equation3751
  (G : Type) `{Magma G} (h : Equation3793 G) : Equation3751 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3794_implies_Equation3752
  (G : Type) `{Magma G} (h : Equation3794 G) : Equation3752 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3803_implies_Equation3759
  (G : Type) `{Magma G} (h : Equation3803 G) : Equation3759 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3807_implies_Equation3762
  (G : Type) `{Magma G} (h : Equation3807 G) : Equation3762 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3820_implies_Equation3759
  (G : Type) `{Magma G} (h : Equation3820 G) : Equation3759 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3823_implies_Equation3761
  (G : Type) `{Magma G} (h : Equation3823 G) : Equation3761 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3824_implies_Equation3762
  (G : Type) `{Magma G} (h : Equation3824 G) : Equation3762 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3828_implies_Equation3762
  (G : Type) `{Magma G} (h : Equation3828 G) : Equation3762 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3866_implies_Equation3865
  (G : Type) `{Magma G} (h : Equation3866 G) : Equation3865 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3869_implies_Equation3868
  (G : Type) `{Magma G} (h : Equation3869 G) : Equation3868 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3872_implies_Equation3871
  (G : Type) `{Magma G} (h : Equation3872 G) : Equation3871 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3873_implies_Equation3870
  (G : Type) `{Magma G} (h : Equation3873 G) : Equation3870 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3874_implies_Equation3871
  (G : Type) `{Magma G} (h : Equation3874 G) : Equation3871 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3883_implies_Equation3880
  (G : Type) `{Magma G} (h : Equation3883 G) : Equation3880 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3893_implies_Equation3890
  (G : Type) `{Magma G} (h : Equation3893 G) : Equation3890 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3894_implies_Equation3891
  (G : Type) `{Magma G} (h : Equation3894 G) : Equation3891 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3895_implies_Equation3891
  (G : Type) `{Magma G} (h : Equation3895 G) : Equation3891 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3897_implies_Equation3887
  (G : Type) `{Magma G} (h : Equation3897 G) : Equation3887 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3901_implies_Equation3890
  (G : Type) `{Magma G} (h : Equation3901 G) : Equation3890 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3902_implies_Equation3891
  (G : Type) `{Magma G} (h : Equation3902 G) : Equation3891 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3903_implies_Equation3891
  (G : Type) `{Magma G} (h : Equation3903 G) : Equation3891 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3905_implies_Equation3890
  (G : Type) `{Magma G} (h : Equation3905 G) : Equation3890 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3906_implies_Equation3891
  (G : Type) `{Magma G} (h : Equation3906 G) : Equation3891 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3907_implies_Equation3891
  (G : Type) `{Magma G} (h : Equation3907 G) : Equation3891 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3919_implies_Equation3918
  (G : Type) `{Magma G} (h : Equation3919 G) : Equation3918 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3921_implies_Equation3918
  (G : Type) `{Magma G} (h : Equation3921 G) : Equation3918 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3926_implies_Equation3925
  (G : Type) `{Magma G} (h : Equation3926 G) : Equation3925 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3929_implies_Equation3928
  (G : Type) `{Magma G} (h : Equation3929 G) : Equation3928 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3930_implies_Equation3927
  (G : Type) `{Magma G} (h : Equation3930 G) : Equation3927 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3931_implies_Equation3928
  (G : Type) `{Magma G} (h : Equation3931 G) : Equation3928 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3932_implies_Equation3928
  (G : Type) `{Magma G} (h : Equation3932 G) : Equation3928 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3935_implies_Equation3925
  (G : Type) `{Magma G} (h : Equation3935 G) : Equation3925 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3939_implies_Equation3928
  (G : Type) `{Magma G} (h : Equation3939 G) : Equation3928 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3943_implies_Equation3928
  (G : Type) `{Magma G} (h : Equation3943 G) : Equation3928 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3968_implies_Equation3965
  (G : Type) `{Magma G} (h : Equation3968 G) : Equation3965 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3972_implies_Equation3962
  (G : Type) `{Magma G} (h : Equation3972 G) : Equation3962 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3979_implies_Equation3964
  (G : Type) `{Magma G} (h : Equation3979 G) : Equation3964 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3989_implies_Equation3952
  (G : Type) `{Magma G} (h : Equation3989 G) : Equation3952 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3993_implies_Equation3955
  (G : Type) `{Magma G} (h : Equation3993 G) : Equation3955 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3994_implies_Equation3955
  (G : Type) `{Magma G} (h : Equation3994 G) : Equation3955 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3996_implies_Equation3954
  (G : Type) `{Magma G} (h : Equation3996 G) : Equation3954 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation3997_implies_Equation3955
  (G : Type) `{Magma G} (h : Equation3997 G) : Equation3955 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4005_implies_Equation3961
  (G : Type) `{Magma G} (h : Equation4005 G) : Equation3961 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4006_implies_Equation3962
  (G : Type) `{Magma G} (h : Equation4006 G) : Equation3962 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4007_implies_Equation3962
  (G : Type) `{Magma G} (h : Equation4007 G) : Equation3962 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4023_implies_Equation3962
  (G : Type) `{Magma G} (h : Equation4023 G) : Equation3962 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4026_implies_Equation3964
  (G : Type) `{Magma G} (h : Equation4026 G) : Equation3964 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4069_implies_Equation4068
  (G : Type) `{Magma G} (h : Equation4069 G) : Equation4068 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4072_implies_Equation4071
  (G : Type) `{Magma G} (h : Equation4072 G) : Equation4071 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4075_implies_Equation4074
  (G : Type) `{Magma G} (h : Equation4075 G) : Equation4074 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4076_implies_Equation4073
  (G : Type) `{Magma G} (h : Equation4076 G) : Equation4073 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4077_implies_Equation4074
  (G : Type) `{Magma G} (h : Equation4077 G) : Equation4074 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4078_implies_Equation4074
  (G : Type) `{Magma G} (h : Equation4078 G) : Equation4074 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4086_implies_Equation4083
  (G : Type) `{Magma G} (h : Equation4086 G) : Equation4083 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4096_implies_Equation4093
  (G : Type) `{Magma G} (h : Equation4096 G) : Equation4093 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4097_implies_Equation4094
  (G : Type) `{Magma G} (h : Equation4097 G) : Equation4094 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4098_implies_Equation4094
  (G : Type) `{Magma G} (h : Equation4098 G) : Equation4094 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4100_implies_Equation4090
  (G : Type) `{Magma G} (h : Equation4100 G) : Equation4090 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4104_implies_Equation4093
  (G : Type) `{Magma G} (h : Equation4104 G) : Equation4093 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4105_implies_Equation4094
  (G : Type) `{Magma G} (h : Equation4105 G) : Equation4094 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4106_implies_Equation4094
  (G : Type) `{Magma G} (h : Equation4106 G) : Equation4094 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4109_implies_Equation4094
  (G : Type) `{Magma G} (h : Equation4109 G) : Equation4094 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4133_implies_Equation4130
  (G : Type) `{Magma G} (h : Equation4133 G) : Equation4130 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4134_implies_Equation4131
  (G : Type) `{Magma G} (h : Equation4134 G) : Equation4131 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4135_implies_Equation4131
  (G : Type) `{Magma G} (h : Equation4135 G) : Equation4131 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4138_implies_Equation4128
  (G : Type) `{Magma G} (h : Equation4138 G) : Equation4128 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4146_implies_Equation4131
  (G : Type) `{Magma G} (h : Equation4146 G) : Equation4131 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4162_implies_Equation4158
  (G : Type) `{Magma G} (h : Equation4162 G) : Equation4158 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4171_implies_Equation4168
  (G : Type) `{Magma G} (h : Equation4171 G) : Equation4168 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4175_implies_Equation4165
  (G : Type) `{Magma G} (h : Equation4175 G) : Equation4165 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4182_implies_Equation4167
  (G : Type) `{Magma G} (h : Equation4182 G) : Equation4167 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4192_implies_Equation4155
  (G : Type) `{Magma G} (h : Equation4192 G) : Equation4155 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4199_implies_Equation4157
  (G : Type) `{Magma G} (h : Equation4199 G) : Equation4157 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4200_implies_Equation4158
  (G : Type) `{Magma G} (h : Equation4200 G) : Equation4158 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4208_implies_Equation4164
  (G : Type) `{Magma G} (h : Equation4208 G) : Equation4164 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4209_implies_Equation4165
  (G : Type) `{Magma G} (h : Equation4209 G) : Equation4165 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4226_implies_Equation4165
  (G : Type) `{Magma G} (h : Equation4226 G) : Equation4165 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4229_implies_Equation4167
  (G : Type) `{Magma G} (h : Equation4229 G) : Equation4167 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4277_implies_Equation4276
  (G : Type) `{Magma G} (h : Equation4277 G) : Equation4276 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4279_implies_Equation4276
  (G : Type) `{Magma G} (h : Equation4279 G) : Equation4276 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4280_implies_Equation4276
  (G : Type) `{Magma G} (h : Equation4280 G) : Equation4276 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4286_implies_Equation4283
  (G : Type) `{Magma G} (h : Equation4286 G) : Equation4283 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4288_implies_Equation4284
  (G : Type) `{Magma G} (h : Equation4288 G) : Equation4284 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4315_implies_Equation4314
  (G : Type) `{Magma G} (h : Equation4315 G) : Equation4314 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4318_implies_Equation4314
  (G : Type) `{Magma G} (h : Equation4318 G) : Equation4314 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4327_implies_Equation4320
  (G : Type) `{Magma G} (h : Equation4327 G) : Equation4320 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4328_implies_Equation4321
  (G : Type) `{Magma G} (h : Equation4328 G) : Equation4321 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4384_implies_Equation4383
  (G : Type) `{Magma G} (h : Equation4384 G) : Equation4383 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4390_implies_Equation4389
  (G : Type) `{Magma G} (h : Equation4390 G) : Equation4389 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4391_implies_Equation4388
  (G : Type) `{Magma G} (h : Equation4391 G) : Equation4388 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4392_implies_Equation4389
  (G : Type) `{Magma G} (h : Equation4392 G) : Equation4389 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4393_implies_Equation4389
  (G : Type) `{Magma G} (h : Equation4393 G) : Equation4389 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4397_implies_Equation4396
  (G : Type) `{Magma G} (h : Equation4397 G) : Equation4396 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4400_implies_Equation4399
  (G : Type) `{Magma G} (h : Equation4400 G) : Equation4399 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4401_implies_Equation4398
  (G : Type) `{Magma G} (h : Equation4401 G) : Equation4398 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4402_implies_Equation4399
  (G : Type) `{Magma G} (h : Equation4402 G) : Equation4399 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4403_implies_Equation4399
  (G : Type) `{Magma G} (h : Equation4403 G) : Equation4399 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4412_implies_Equation4409
  (G : Type) `{Magma G} (h : Equation4412 G) : Equation4409 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4413_implies_Equation4409
  (G : Type) `{Magma G} (h : Equation4413 G) : Equation4409 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4415_implies_Equation4405
  (G : Type) `{Magma G} (h : Equation4415 G) : Equation4405 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4416_implies_Equation4406
  (G : Type) `{Magma G} (h : Equation4416 G) : Equation4406 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4420_implies_Equation4409
  (G : Type) `{Magma G} (h : Equation4420 G) : Equation4409 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4421_implies_Equation4409
  (G : Type) `{Magma G} (h : Equation4421 G) : Equation4409 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4423_implies_Equation4408
  (G : Type) `{Magma G} (h : Equation4423 G) : Equation4408 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4424_implies_Equation4409
  (G : Type) `{Magma G} (h : Equation4424 G) : Equation4409 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4425_implies_Equation4409
  (G : Type) `{Magma G} (h : Equation4425 G) : Equation4409 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4434_implies_Equation4433
  (G : Type) `{Magma G} (h : Equation4434 G) : Equation4433 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4437_implies_Equation4436
  (G : Type) `{Magma G} (h : Equation4437 G) : Equation4436 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4438_implies_Equation4435
  (G : Type) `{Magma G} (h : Equation4438 G) : Equation4435 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4439_implies_Equation4436
  (G : Type) `{Magma G} (h : Equation4439 G) : Equation4436 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4440_implies_Equation4436
  (G : Type) `{Magma G} (h : Equation4440 G) : Equation4436 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4450_implies_Equation4446
  (G : Type) `{Magma G} (h : Equation4450 G) : Equation4446 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4452_implies_Equation4442
  (G : Type) `{Magma G} (h : Equation4452 G) : Equation4442 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4454_implies_Equation4443
  (G : Type) `{Magma G} (h : Equation4454 G) : Equation4443 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4456_implies_Equation4445
  (G : Type) `{Magma G} (h : Equation4456 G) : Equation4445 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4458_implies_Equation4446
  (G : Type) `{Magma G} (h : Equation4458 G) : Equation4446 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4460_implies_Equation4445
  (G : Type) `{Magma G} (h : Equation4460 G) : Equation4445 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4461_implies_Equation4446
  (G : Type) `{Magma G} (h : Equation4461 G) : Equation4446 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4462_implies_Equation4446
  (G : Type) `{Magma G} (h : Equation4462 G) : Equation4446 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4471_implies_Equation4470
  (G : Type) `{Magma G} (h : Equation4471 G) : Equation4470 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4474_implies_Equation4473
  (G : Type) `{Magma G} (h : Equation4474 G) : Equation4473 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4475_implies_Equation4472
  (G : Type) `{Magma G} (h : Equation4475 G) : Equation4472 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4476_implies_Equation4473
  (G : Type) `{Magma G} (h : Equation4476 G) : Equation4473 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4477_implies_Equation4473
  (G : Type) `{Magma G} (h : Equation4477 G) : Equation4473 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4486_implies_Equation4483
  (G : Type) `{Magma G} (h : Equation4486 G) : Equation4483 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4489_implies_Equation4479
  (G : Type) `{Magma G} (h : Equation4489 G) : Equation4479 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4490_implies_Equation4480
  (G : Type) `{Magma G} (h : Equation4490 G) : Equation4480 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4491_implies_Equation4480
  (G : Type) `{Magma G} (h : Equation4491 G) : Equation4480 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4494_implies_Equation4483
  (G : Type) `{Magma G} (h : Equation4494 G) : Equation4483 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4497_implies_Equation4482
  (G : Type) `{Magma G} (h : Equation4497 G) : Equation4482 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4498_implies_Equation4483
  (G : Type) `{Magma G} (h : Equation4498 G) : Equation4483 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4499_implies_Equation4483
  (G : Type) `{Magma G} (h : Equation4499 G) : Equation4483 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4506_implies_Equation4469
  (G : Type) `{Magma G} (h : Equation4506 G) : Equation4469 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4507_implies_Equation4470
  (G : Type) `{Magma G} (h : Equation4507 G) : Equation4470 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4508_implies_Equation4470
  (G : Type) `{Magma G} (h : Equation4508 G) : Equation4470 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4510_implies_Equation4472
  (G : Type) `{Magma G} (h : Equation4510 G) : Equation4472 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4511_implies_Equation4473
  (G : Type) `{Magma G} (h : Equation4511 G) : Equation4473 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4512_implies_Equation4473
  (G : Type) `{Magma G} (h : Equation4512 G) : Equation4473 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4515_implies_Equation4473
  (G : Type) `{Magma G} (h : Equation4515 G) : Equation4473 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4516_implies_Equation4473
  (G : Type) `{Magma G} (h : Equation4516 G) : Equation4473 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4525_implies_Equation4480
  (G : Type) `{Magma G} (h : Equation4525 G) : Equation4480 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4529_implies_Equation4483
  (G : Type) `{Magma G} (h : Equation4529 G) : Equation4483 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4531_implies_Equation4482
  (G : Type) `{Magma G} (h : Equation4531 G) : Equation4482 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4533_implies_Equation4483
  (G : Type) `{Magma G} (h : Equation4533 G) : Equation4483 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4541_implies_Equation4480
  (G : Type) `{Magma G} (h : Equation4541 G) : Equation4480 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4542_implies_Equation4480
  (G : Type) `{Magma G} (h : Equation4542 G) : Equation4480 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4544_implies_Equation4482
  (G : Type) `{Magma G} (h : Equation4544 G) : Equation4482 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4546_implies_Equation4483
  (G : Type) `{Magma G} (h : Equation4546 G) : Equation4483 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4550_implies_Equation4483
  (G : Type) `{Magma G} (h : Equation4550 G) : Equation4483 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4592_implies_Equation4591
  (G : Type) `{Magma G} (h : Equation4592 G) : Equation4591 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4594_implies_Equation4591
  (G : Type) `{Magma G} (h : Equation4594 G) : Equation4591 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4595_implies_Equation4591
  (G : Type) `{Magma G} (h : Equation4595 G) : Equation4591 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4601_implies_Equation4598
  (G : Type) `{Magma G} (h : Equation4601 G) : Equation4598 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4602_implies_Equation4599
  (G : Type) `{Magma G} (h : Equation4602 G) : Equation4599 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4603_implies_Equation4599
  (G : Type) `{Magma G} (h : Equation4603 G) : Equation4599 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4610_implies_Equation4608
  (G : Type) `{Magma G} (h : Equation4610 G) : Equation4608 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4630_implies_Equation4629
  (G : Type) `{Magma G} (h : Equation4630 G) : Equation4629 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4632_implies_Equation4629
  (G : Type) `{Magma G} (h : Equation4632 G) : Equation4629 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4633_implies_Equation4629
  (G : Type) `{Magma G} (h : Equation4633 G) : Equation4629 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4637_implies_Equation4636
  (G : Type) `{Magma G} (h : Equation4637 G) : Equation4636 G.
Proof. intros x y. exact (h x y y). Qed.

Theorem Equation4642_implies_Equation4635
  (G : Type) `{Magma G} (h : Equation4642 G) : Equation4635 G.
Proof. intros x y. exact (h x y y). Qed.

