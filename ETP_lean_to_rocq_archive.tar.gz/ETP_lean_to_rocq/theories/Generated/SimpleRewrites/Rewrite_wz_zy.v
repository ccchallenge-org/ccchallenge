(** * SimpleRewrites/Rewrite_wz_zy

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation37_implies_Equation33
  (G : Type) `{Magma G} (h : Equation37 G) : Equation33 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation46_implies_Equation44
  (G : Type) `{Magma G} (h : Equation46 G) : Equation44 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation85_implies_Equation74
  (G : Type) `{Magma G} (h : Equation85 G) : Equation74 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation96_implies_Equation79
  (G : Type) `{Magma G} (h : Equation96 G) : Equation79 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation123_implies_Equation119
  (G : Type) `{Magma G} (h : Equation123 G) : Equation119 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation133_implies_Equation129
  (G : Type) `{Magma G} (h : Equation133 G) : Equation129 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation193_implies_Equation181
  (G : Type) `{Magma G} (h : Equation193 G) : Equation181 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation200_implies_Equation183
  (G : Type) `{Magma G} (h : Equation200 G) : Equation183 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation217_implies_Equation213
  (G : Type) `{Magma G} (h : Equation217 G) : Equation213 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation237_implies_Equation233
  (G : Type) `{Magma G} (h : Equation237 G) : Equation233 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation250_implies_Equation234
  (G : Type) `{Magma G} (h : Equation250 G) : Equation234 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation269_implies_Equation265
  (G : Type) `{Magma G} (h : Equation269 G) : Equation265 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation279_implies_Equation275
  (G : Type) `{Magma G} (h : Equation279 G) : Equation275 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation289_implies_Equation285
  (G : Type) `{Magma G} (h : Equation289 G) : Equation285 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation297_implies_Equation285
  (G : Type) `{Magma G} (h : Equation297 G) : Equation285 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation301_implies_Equation285
  (G : Type) `{Magma G} (h : Equation301 G) : Equation285 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation302_implies_Equation286
  (G : Type) `{Magma G} (h : Equation302 G) : Equation286 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation305_implies_Equation288
  (G : Type) `{Magma G} (h : Equation305 G) : Equation288 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation331_implies_Equation327
  (G : Type) `{Magma G} (h : Equation331 G) : Equation327 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation341_implies_Equation337
  (G : Type) `{Magma G} (h : Equation341 G) : Equation337 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation354_implies_Equation338
  (G : Type) `{Magma G} (h : Equation354 G) : Equation338 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation425_implies_Equation421
  (G : Type) `{Magma G} (h : Equation425 G) : Equation421 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation435_implies_Equation431
  (G : Type) `{Magma G} (h : Equation435 G) : Equation431 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation445_implies_Equation441
  (G : Type) `{Magma G} (h : Equation445 G) : Equation441 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation486_implies_Equation475
  (G : Type) `{Magma G} (h : Equation486 G) : Equation475 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation494_implies_Equation478
  (G : Type) `{Magma G} (h : Equation494 G) : Equation478 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation495_implies_Equation479
  (G : Type) `{Magma G} (h : Equation495 G) : Equation479 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation496_implies_Equation480
  (G : Type) `{Magma G} (h : Equation496 G) : Equation480 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation497_implies_Equation480
  (G : Type) `{Magma G} (h : Equation497 G) : Equation480 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation509_implies_Equation505
  (G : Type) `{Magma G} (h : Equation509 G) : Equation505 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation519_implies_Equation515
  (G : Type) `{Magma G} (h : Equation519 G) : Equation515 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation523_implies_Equation512
  (G : Type) `{Magma G} (h : Equation523 G) : Equation512 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation550_implies_Equation507
  (G : Type) `{Magma G} (h : Equation550 G) : Equation507 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation583_implies_Equation516
  (G : Type) `{Magma G} (h : Equation583 G) : Equation516 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation589_implies_Equation521
  (G : Type) `{Magma G} (h : Equation589 G) : Equation521 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation590_implies_Equation521
  (G : Type) `{Magma G} (h : Equation590 G) : Equation521 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation599_implies_Equation525
  (G : Type) `{Magma G} (h : Equation599 G) : Equation525 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation638_implies_Equation634
  (G : Type) `{Magma G} (h : Equation638 G) : Equation634 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation648_implies_Equation644
  (G : Type) `{Magma G} (h : Equation648 G) : Equation644 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation661_implies_Equation645
  (G : Type) `{Magma G} (h : Equation661 G) : Equation645 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation663_implies_Equation646
  (G : Type) `{Magma G} (h : Equation663 G) : Equation646 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation664_implies_Equation647
  (G : Type) `{Magma G} (h : Equation664 G) : Equation647 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation689_implies_Equation678
  (G : Type) `{Magma G} (h : Equation689 G) : Equation678 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation693_implies_Equation681
  (G : Type) `{Magma G} (h : Equation693 G) : Equation681 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation698_implies_Equation682
  (G : Type) `{Magma G} (h : Equation698 G) : Equation682 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation699_implies_Equation683
  (G : Type) `{Magma G} (h : Equation699 G) : Equation683 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation700_implies_Equation683
  (G : Type) `{Magma G} (h : Equation700 G) : Equation683 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation712_implies_Equation708
  (G : Type) `{Magma G} (h : Equation712 G) : Equation708 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation722_implies_Equation718
  (G : Type) `{Magma G} (h : Equation722 G) : Equation718 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation735_implies_Equation719
  (G : Type) `{Magma G} (h : Equation735 G) : Equation719 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation747_implies_Equation708
  (G : Type) `{Magma G} (h : Equation747 G) : Equation708 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation789_implies_Equation721
  (G : Type) `{Magma G} (h : Equation789 G) : Equation721 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation796_implies_Equation727
  (G : Type) `{Magma G} (h : Equation796 G) : Equation727 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation851_implies_Equation847
  (G : Type) `{Magma G} (h : Equation851 G) : Equation847 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation900_implies_Equation884
  (G : Type) `{Magma G} (h : Equation900 G) : Equation884 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation901_implies_Equation885
  (G : Type) `{Magma G} (h : Equation901 G) : Equation885 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation915_implies_Equation911
  (G : Type) `{Magma G} (h : Equation915 G) : Equation911 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation929_implies_Equation918
  (G : Type) `{Magma G} (h : Equation929 G) : Equation918 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation963_implies_Equation918
  (G : Type) `{Magma G} (h : Equation963 G) : Equation918 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation967_implies_Equation921
  (G : Type) `{Magma G} (h : Equation967 G) : Equation921 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation980_implies_Equation918
  (G : Type) `{Magma G} (h : Equation980 G) : Equation918 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation989_implies_Equation922
  (G : Type) `{Magma G} (h : Equation989 G) : Equation922 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation996_implies_Equation927
  (G : Type) `{Magma G} (h : Equation996 G) : Equation927 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1000_implies_Equation931
  (G : Type) `{Magma G} (h : Equation1000 G) : Equation931 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1004_implies_Equation930
  (G : Type) `{Magma G} (h : Equation1004 G) : Equation930 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1034_implies_Equation1030
  (G : Type) `{Magma G} (h : Equation1034 G) : Equation1030 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1044_implies_Equation1040
  (G : Type) `{Magma G} (h : Equation1044 G) : Equation1040 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1066_implies_Equation1050
  (G : Type) `{Magma G} (h : Equation1066 G) : Equation1050 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1067_implies_Equation1051
  (G : Type) `{Magma G} (h : Equation1067 G) : Equation1051 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1068_implies_Equation1052
  (G : Type) `{Magma G} (h : Equation1068 G) : Equation1052 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1081_implies_Equation1077
  (G : Type) `{Magma G} (h : Equation1081 G) : Equation1077 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1091_implies_Equation1087
  (G : Type) `{Magma G} (h : Equation1091 G) : Equation1087 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1095_implies_Equation1084
  (G : Type) `{Magma G} (h : Equation1095 G) : Equation1084 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1099_implies_Equation1087
  (G : Type) `{Magma G} (h : Equation1099 G) : Equation1087 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1103_implies_Equation1087
  (G : Type) `{Magma G} (h : Equation1103 G) : Equation1087 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1118_implies_Equation1114
  (G : Type) `{Magma G} (h : Equation1118 G) : Equation1114 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1128_implies_Equation1124
  (G : Type) `{Magma G} (h : Equation1128 G) : Equation1124 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1132_implies_Equation1121
  (G : Type) `{Magma G} (h : Equation1132 G) : Equation1121 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1175_implies_Equation1125
  (G : Type) `{Magma G} (h : Equation1175 G) : Equation1125 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1197_implies_Equation1129
  (G : Type) `{Magma G} (h : Equation1197 G) : Equation1129 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1212_implies_Equation1137
  (G : Type) `{Magma G} (h : Equation1212 G) : Equation1137 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1237_implies_Equation1233
  (G : Type) `{Magma G} (h : Equation1237 G) : Equation1233 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1247_implies_Equation1243
  (G : Type) `{Magma G} (h : Equation1247 G) : Equation1243 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1261_implies_Equation1250
  (G : Type) `{Magma G} (h : Equation1261 G) : Equation1250 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1270_implies_Equation1254
  (G : Type) `{Magma G} (h : Equation1270 G) : Equation1254 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1335_implies_Equation1324
  (G : Type) `{Magma G} (h : Equation1335 G) : Equation1324 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1369_implies_Equation1324
  (G : Type) `{Magma G} (h : Equation1369 G) : Equation1324 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1378_implies_Equation1328
  (G : Type) `{Magma G} (h : Equation1378 G) : Equation1328 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1386_implies_Equation1324
  (G : Type) `{Magma G} (h : Equation1386 G) : Equation1324 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1401_implies_Equation1333
  (G : Type) `{Magma G} (h : Equation1401 G) : Equation1333 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1473_implies_Equation1457
  (G : Type) `{Magma G} (h : Equation1473 G) : Equation1457 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1475_implies_Equation1458
  (G : Type) `{Magma G} (h : Equation1475 G) : Equation1458 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1497_implies_Equation1493
  (G : Type) `{Magma G} (h : Equation1497 G) : Equation1493 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1501_implies_Equation1490
  (G : Type) `{Magma G} (h : Equation1501 G) : Equation1490 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1524_implies_Equation1520
  (G : Type) `{Magma G} (h : Equation1524 G) : Equation1520 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1534_implies_Equation1530
  (G : Type) `{Magma G} (h : Equation1534 G) : Equation1530 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1555_implies_Equation1517
  (G : Type) `{Magma G} (h : Equation1555 G) : Equation1517 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1565_implies_Equation1522
  (G : Type) `{Magma G} (h : Equation1565 G) : Equation1522 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1589_implies_Equation1527
  (G : Type) `{Magma G} (h : Equation1589 G) : Equation1527 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1598_implies_Equation1531
  (G : Type) `{Magma G} (h : Equation1598 G) : Equation1531 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1605_implies_Equation1536
  (G : Type) `{Magma G} (h : Equation1605 G) : Equation1536 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1606_implies_Equation1537
  (G : Type) `{Magma G} (h : Equation1606 G) : Equation1537 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1643_implies_Equation1639
  (G : Type) `{Magma G} (h : Equation1643 G) : Equation1639 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1653_implies_Equation1649
  (G : Type) `{Magma G} (h : Equation1653 G) : Equation1649 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1690_implies_Equation1686
  (G : Type) `{Magma G} (h : Equation1690 G) : Equation1686 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1700_implies_Equation1696
  (G : Type) `{Magma G} (h : Equation1700 G) : Equation1696 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1708_implies_Equation1696
  (G : Type) `{Magma G} (h : Equation1708 G) : Equation1696 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1712_implies_Equation1696
  (G : Type) `{Magma G} (h : Equation1712 G) : Equation1696 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1714_implies_Equation1698
  (G : Type) `{Magma G} (h : Equation1714 G) : Equation1698 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1727_implies_Equation1723
  (G : Type) `{Magma G} (h : Equation1727 G) : Equation1723 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1741_implies_Equation1730
  (G : Type) `{Magma G} (h : Equation1741 G) : Equation1730 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1750_implies_Equation1734
  (G : Type) `{Magma G} (h : Equation1750 G) : Equation1734 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1751_implies_Equation1735
  (G : Type) `{Magma G} (h : Equation1751 G) : Equation1735 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1758_implies_Equation1720
  (G : Type) `{Magma G} (h : Equation1758 G) : Equation1720 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1767_implies_Equation1724
  (G : Type) `{Magma G} (h : Equation1767 G) : Equation1724 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1806_implies_Equation1738
  (G : Type) `{Magma G} (h : Equation1806 G) : Equation1738 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1807_implies_Equation1739
  (G : Type) `{Magma G} (h : Equation1807 G) : Equation1739 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1816_implies_Equation1742
  (G : Type) `{Magma G} (h : Equation1816 G) : Equation1742 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1846_implies_Equation1842
  (G : Type) `{Magma G} (h : Equation1846 G) : Equation1842 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1874_implies_Equation1862
  (G : Type) `{Magma G} (h : Equation1874 G) : Equation1862 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1879_implies_Equation1863
  (G : Type) `{Magma G} (h : Equation1879 G) : Equation1863 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1880_implies_Equation1864
  (G : Type) `{Magma G} (h : Equation1880 G) : Equation1864 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1881_implies_Equation1864
  (G : Type) `{Magma G} (h : Equation1881 G) : Equation1864 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1903_implies_Equation1899
  (G : Type) `{Magma G} (h : Equation1903 G) : Equation1899 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1917_implies_Equation1901
  (G : Type) `{Magma G} (h : Equation1917 G) : Equation1901 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1940_implies_Equation1936
  (G : Type) `{Magma G} (h : Equation1940 G) : Equation1936 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1944_implies_Equation1933
  (G : Type) `{Magma G} (h : Equation1944 G) : Equation1933 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1953_implies_Equation1937
  (G : Type) `{Magma G} (h : Equation1953 G) : Equation1937 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1965_implies_Equation1926
  (G : Type) `{Magma G} (h : Equation1965 G) : Equation1926 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1972_implies_Equation1928
  (G : Type) `{Magma G} (h : Equation1972 G) : Equation1928 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1978_implies_Equation1933
  (G : Type) `{Magma G} (h : Equation1978 G) : Equation1933 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1987_implies_Equation1937
  (G : Type) `{Magma G} (h : Equation1987 G) : Equation1937 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation1995_implies_Equation1933
  (G : Type) `{Magma G} (h : Equation1995 G) : Equation1933 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2004_implies_Equation1937
  (G : Type) `{Magma G} (h : Equation2004 G) : Equation1937 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2010_implies_Equation1942
  (G : Type) `{Magma G} (h : Equation2010 G) : Equation1942 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2081_implies_Equation2065
  (G : Type) `{Magma G} (h : Equation2081 G) : Equation2065 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2082_implies_Equation2066
  (G : Type) `{Magma G} (h : Equation2082 G) : Equation2066 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2096_implies_Equation2092
  (G : Type) `{Magma G} (h : Equation2096 G) : Equation2092 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2106_implies_Equation2102
  (G : Type) `{Magma G} (h : Equation2106 G) : Equation2102 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2119_implies_Equation2103
  (G : Type) `{Magma G} (h : Equation2119 G) : Equation2103 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2133_implies_Equation2129
  (G : Type) `{Magma G} (h : Equation2133 G) : Equation2129 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2143_implies_Equation2139
  (G : Type) `{Magma G} (h : Equation2143 G) : Equation2139 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2147_implies_Equation2136
  (G : Type) `{Magma G} (h : Equation2147 G) : Equation2136 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2164_implies_Equation2126
  (G : Type) `{Magma G} (h : Equation2164 G) : Equation2126 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2172_implies_Equation2129
  (G : Type) `{Magma G} (h : Equation2172 G) : Equation2129 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2173_implies_Equation2130
  (G : Type) `{Magma G} (h : Equation2173 G) : Equation2130 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2175_implies_Equation2131
  (G : Type) `{Magma G} (h : Equation2175 G) : Equation2131 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2198_implies_Equation2136
  (G : Type) `{Magma G} (h : Equation2198 G) : Equation2136 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2207_implies_Equation2140
  (G : Type) `{Magma G} (h : Equation2207 G) : Equation2140 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2212_implies_Equation2144
  (G : Type) `{Magma G} (h : Equation2212 G) : Equation2144 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2214_implies_Equation2145
  (G : Type) `{Magma G} (h : Equation2214 G) : Equation2145 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2215_implies_Equation2146
  (G : Type) `{Magma G} (h : Equation2215 G) : Equation2146 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2227_implies_Equation2152
  (G : Type) `{Magma G} (h : Equation2227 G) : Equation2152 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2252_implies_Equation2248
  (G : Type) `{Magma G} (h : Equation2252 G) : Equation2248 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2262_implies_Equation2258
  (G : Type) `{Magma G} (h : Equation2262 G) : Equation2258 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2272_implies_Equation2268
  (G : Type) `{Magma G} (h : Equation2272 G) : Equation2268 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2276_implies_Equation2265
  (G : Type) `{Magma G} (h : Equation2276 G) : Equation2265 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2280_implies_Equation2268
  (G : Type) `{Magma G} (h : Equation2280 G) : Equation2268 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2284_implies_Equation2268
  (G : Type) `{Magma G} (h : Equation2284 G) : Equation2268 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2285_implies_Equation2269
  (G : Type) `{Magma G} (h : Equation2285 G) : Equation2269 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2286_implies_Equation2270
  (G : Type) `{Magma G} (h : Equation2286 G) : Equation2270 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2299_implies_Equation2295
  (G : Type) `{Magma G} (h : Equation2299 G) : Equation2295 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2317_implies_Equation2305
  (G : Type) `{Magma G} (h : Equation2317 G) : Equation2305 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2336_implies_Equation2332
  (G : Type) `{Magma G} (h : Equation2336 G) : Equation2332 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2346_implies_Equation2342
  (G : Type) `{Magma G} (h : Equation2346 G) : Equation2342 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2350_implies_Equation2339
  (G : Type) `{Magma G} (h : Equation2350 G) : Equation2339 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2359_implies_Equation2343
  (G : Type) `{Magma G} (h : Equation2359 G) : Equation2343 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2367_implies_Equation2329
  (G : Type) `{Magma G} (h : Equation2367 G) : Equation2329 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2371_implies_Equation2332
  (G : Type) `{Magma G} (h : Equation2371 G) : Equation2332 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2375_implies_Equation2332
  (G : Type) `{Magma G} (h : Equation2375 G) : Equation2332 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2378_implies_Equation2334
  (G : Type) `{Magma G} (h : Equation2378 G) : Equation2334 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2384_implies_Equation2339
  (G : Type) `{Magma G} (h : Equation2384 G) : Equation2339 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2393_implies_Equation2343
  (G : Type) `{Magma G} (h : Equation2393 G) : Equation2343 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2401_implies_Equation2339
  (G : Type) `{Magma G} (h : Equation2401 G) : Equation2339 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2410_implies_Equation2343
  (G : Type) `{Magma G} (h : Equation2410 G) : Equation2343 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2415_implies_Equation2347
  (G : Type) `{Magma G} (h : Equation2415 G) : Equation2347 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2417_implies_Equation2348
  (G : Type) `{Magma G} (h : Equation2417 G) : Equation2348 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2425_implies_Equation2351
  (G : Type) `{Magma G} (h : Equation2425 G) : Equation2351 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2430_implies_Equation2355
  (G : Type) `{Magma G} (h : Equation2430 G) : Equation2355 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2455_implies_Equation2451
  (G : Type) `{Magma G} (h : Equation2455 G) : Equation2451 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2465_implies_Equation2461
  (G : Type) `{Magma G} (h : Equation2465 G) : Equation2461 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2475_implies_Equation2471
  (G : Type) `{Magma G} (h : Equation2475 G) : Equation2471 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2479_implies_Equation2468
  (G : Type) `{Magma G} (h : Equation2479 G) : Equation2468 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2483_implies_Equation2471
  (G : Type) `{Magma G} (h : Equation2483 G) : Equation2471 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2487_implies_Equation2471
  (G : Type) `{Magma G} (h : Equation2487 G) : Equation2471 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2488_implies_Equation2472
  (G : Type) `{Magma G} (h : Equation2488 G) : Equation2472 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2489_implies_Equation2473
  (G : Type) `{Magma G} (h : Equation2489 G) : Equation2473 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2502_implies_Equation2498
  (G : Type) `{Magma G} (h : Equation2502 G) : Equation2498 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2512_implies_Equation2508
  (G : Type) `{Magma G} (h : Equation2512 G) : Equation2508 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2525_implies_Equation2509
  (G : Type) `{Magma G} (h : Equation2525 G) : Equation2509 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2527_implies_Equation2510
  (G : Type) `{Magma G} (h : Equation2527 G) : Equation2510 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2539_implies_Equation2535
  (G : Type) `{Magma G} (h : Equation2539 G) : Equation2535 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2549_implies_Equation2545
  (G : Type) `{Magma G} (h : Equation2549 G) : Equation2545 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2553_implies_Equation2542
  (G : Type) `{Magma G} (h : Equation2553 G) : Equation2542 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2562_implies_Equation2546
  (G : Type) `{Magma G} (h : Equation2562 G) : Equation2546 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2570_implies_Equation2532
  (G : Type) `{Magma G} (h : Equation2570 G) : Equation2532 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2574_implies_Equation2535
  (G : Type) `{Magma G} (h : Equation2574 G) : Equation2535 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2578_implies_Equation2535
  (G : Type) `{Magma G} (h : Equation2578 G) : Equation2535 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2581_implies_Equation2537
  (G : Type) `{Magma G} (h : Equation2581 G) : Equation2537 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2587_implies_Equation2542
  (G : Type) `{Magma G} (h : Equation2587 G) : Equation2542 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2596_implies_Equation2546
  (G : Type) `{Magma G} (h : Equation2596 G) : Equation2546 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2604_implies_Equation2542
  (G : Type) `{Magma G} (h : Equation2604 G) : Equation2542 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2613_implies_Equation2546
  (G : Type) `{Magma G} (h : Equation2613 G) : Equation2546 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2618_implies_Equation2550
  (G : Type) `{Magma G} (h : Equation2618 G) : Equation2550 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2620_implies_Equation2551
  (G : Type) `{Magma G} (h : Equation2620 G) : Equation2551 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2623_implies_Equation2554
  (G : Type) `{Magma G} (h : Equation2623 G) : Equation2554 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2678_implies_Equation2674
  (G : Type) `{Magma G} (h : Equation2678 G) : Equation2674 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2682_implies_Equation2671
  (G : Type) `{Magma G} (h : Equation2682 G) : Equation2671 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2691_implies_Equation2675
  (G : Type) `{Magma G} (h : Equation2691 G) : Equation2675 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2715_implies_Equation2711
  (G : Type) `{Magma G} (h : Equation2715 G) : Equation2711 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2723_implies_Equation2711
  (G : Type) `{Magma G} (h : Equation2723 G) : Equation2711 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2742_implies_Equation2738
  (G : Type) `{Magma G} (h : Equation2742 G) : Equation2738 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2756_implies_Equation2745
  (G : Type) `{Magma G} (h : Equation2756 G) : Equation2745 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2760_implies_Equation2748
  (G : Type) `{Magma G} (h : Equation2760 G) : Equation2748 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2765_implies_Equation2749
  (G : Type) `{Magma G} (h : Equation2765 G) : Equation2749 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2773_implies_Equation2735
  (G : Type) `{Magma G} (h : Equation2773 G) : Equation2735 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2777_implies_Equation2738
  (G : Type) `{Magma G} (h : Equation2777 G) : Equation2738 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2781_implies_Equation2738
  (G : Type) `{Magma G} (h : Equation2781 G) : Equation2738 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2782_implies_Equation2739
  (G : Type) `{Magma G} (h : Equation2782 G) : Equation2739 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2790_implies_Equation2745
  (G : Type) `{Magma G} (h : Equation2790 G) : Equation2745 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2799_implies_Equation2749
  (G : Type) `{Magma G} (h : Equation2799 G) : Equation2749 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2807_implies_Equation2745
  (G : Type) `{Magma G} (h : Equation2807 G) : Equation2745 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2816_implies_Equation2749
  (G : Type) `{Magma G} (h : Equation2816 G) : Equation2749 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2821_implies_Equation2753
  (G : Type) `{Magma G} (h : Equation2821 G) : Equation2753 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2826_implies_Equation2757
  (G : Type) `{Magma G} (h : Equation2826 G) : Equation2757 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2831_implies_Equation2757
  (G : Type) `{Magma G} (h : Equation2831 G) : Equation2757 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2839_implies_Equation2763
  (G : Type) `{Magma G} (h : Equation2839 G) : Equation2763 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2861_implies_Equation2857
  (G : Type) `{Magma G} (h : Equation2861 G) : Equation2857 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2871_implies_Equation2867
  (G : Type) `{Magma G} (h : Equation2871 G) : Equation2867 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2881_implies_Equation2877
  (G : Type) `{Magma G} (h : Equation2881 G) : Equation2877 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2885_implies_Equation2874
  (G : Type) `{Magma G} (h : Equation2885 G) : Equation2874 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2893_implies_Equation2877
  (G : Type) `{Magma G} (h : Equation2893 G) : Equation2877 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2894_implies_Equation2878
  (G : Type) `{Magma G} (h : Equation2894 G) : Equation2878 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2908_implies_Equation2904
  (G : Type) `{Magma G} (h : Equation2908 G) : Equation2904 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2918_implies_Equation2914
  (G : Type) `{Magma G} (h : Equation2918 G) : Equation2914 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2930_implies_Equation2914
  (G : Type) `{Magma G} (h : Equation2930 G) : Equation2914 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2931_implies_Equation2915
  (G : Type) `{Magma G} (h : Equation2931 G) : Equation2915 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2945_implies_Equation2941
  (G : Type) `{Magma G} (h : Equation2945 G) : Equation2941 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2968_implies_Equation2952
  (G : Type) `{Magma G} (h : Equation2968 G) : Equation2952 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2976_implies_Equation2938
  (G : Type) `{Magma G} (h : Equation2976 G) : Equation2938 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2986_implies_Equation2943
  (G : Type) `{Magma G} (h : Equation2986 G) : Equation2943 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation2997_implies_Equation2951
  (G : Type) `{Magma G} (h : Equation2997 G) : Equation2951 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3002_implies_Equation2952
  (G : Type) `{Magma G} (h : Equation3002 G) : Equation2952 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3019_implies_Equation2952
  (G : Type) `{Magma G} (h : Equation3019 G) : Equation2952 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3024_implies_Equation2956
  (G : Type) `{Magma G} (h : Equation3024 G) : Equation2956 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3026_implies_Equation2957
  (G : Type) `{Magma G} (h : Equation3026 G) : Equation2957 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3029_implies_Equation2960
  (G : Type) `{Magma G} (h : Equation3029 G) : Equation2960 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3039_implies_Equation2964
  (G : Type) `{Magma G} (h : Equation3039 G) : Equation2964 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3074_implies_Equation3070
  (G : Type) `{Magma G} (h : Equation3074 G) : Equation3070 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3097_implies_Equation3081
  (G : Type) `{Magma G} (h : Equation3097 G) : Equation3081 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3100_implies_Equation3083
  (G : Type) `{Magma G} (h : Equation3100 G) : Equation3083 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3111_implies_Equation3107
  (G : Type) `{Magma G} (h : Equation3111 G) : Equation3107 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3121_implies_Equation3117
  (G : Type) `{Magma G} (h : Equation3121 G) : Equation3117 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3133_implies_Equation3117
  (G : Type) `{Magma G} (h : Equation3133 G) : Equation3117 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3134_implies_Equation3118
  (G : Type) `{Magma G} (h : Equation3134 G) : Equation3118 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3136_implies_Equation3119
  (G : Type) `{Magma G} (h : Equation3136 G) : Equation3119 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3158_implies_Equation3154
  (G : Type) `{Magma G} (h : Equation3158 G) : Equation3154 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3171_implies_Equation3155
  (G : Type) `{Magma G} (h : Equation3171 G) : Equation3155 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3179_implies_Equation3141
  (G : Type) `{Magma G} (h : Equation3179 G) : Equation3141 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3183_implies_Equation3144
  (G : Type) `{Magma G} (h : Equation3183 G) : Equation3144 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3189_implies_Equation3146
  (G : Type) `{Magma G} (h : Equation3189 G) : Equation3146 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3205_implies_Equation3155
  (G : Type) `{Magma G} (h : Equation3205 G) : Equation3155 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3222_implies_Equation3155
  (G : Type) `{Magma G} (h : Equation3222 G) : Equation3155 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3228_implies_Equation3160
  (G : Type) `{Magma G} (h : Equation3228 G) : Equation3160 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3229_implies_Equation3160
  (G : Type) `{Magma G} (h : Equation3229 G) : Equation3160 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3237_implies_Equation3163
  (G : Type) `{Magma G} (h : Equation3237 G) : Equation3163 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3240_implies_Equation3165
  (G : Type) `{Magma G} (h : Equation3240 G) : Equation3165 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3267_implies_Equation3263
  (G : Type) `{Magma G} (h : Equation3267 G) : Equation3263 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3295_implies_Equation3283
  (G : Type) `{Magma G} (h : Equation3295 G) : Equation3283 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3299_implies_Equation3283
  (G : Type) `{Magma G} (h : Equation3299 G) : Equation3283 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3300_implies_Equation3284
  (G : Type) `{Magma G} (h : Equation3300 G) : Equation3284 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3301_implies_Equation3285
  (G : Type) `{Magma G} (h : Equation3301 G) : Equation3285 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3302_implies_Equation3285
  (G : Type) `{Magma G} (h : Equation3302 G) : Equation3285 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3324_implies_Equation3320
  (G : Type) `{Magma G} (h : Equation3324 G) : Equation3320 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3338_implies_Equation3322
  (G : Type) `{Magma G} (h : Equation3338 G) : Equation3322 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3361_implies_Equation3357
  (G : Type) `{Magma G} (h : Equation3361 G) : Equation3357 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3365_implies_Equation3354
  (G : Type) `{Magma G} (h : Equation3365 G) : Equation3354 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3375_implies_Equation3359
  (G : Type) `{Magma G} (h : Equation3375 G) : Equation3359 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3392_implies_Equation3349
  (G : Type) `{Magma G} (h : Equation3392 G) : Equation3349 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3426_implies_Equation3359
  (G : Type) `{Magma G} (h : Equation3426 G) : Equation3359 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3431_implies_Equation3363
  (G : Type) `{Magma G} (h : Equation3431 G) : Equation3363 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3443_implies_Equation3368
  (G : Type) `{Magma G} (h : Equation3443 G) : Equation3368 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3446_implies_Equation3371
  (G : Type) `{Magma G} (h : Equation3446 G) : Equation3371 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3448_implies_Equation3372
  (G : Type) `{Magma G} (h : Equation3448 G) : Equation3372 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3470_implies_Equation3466
  (G : Type) `{Magma G} (h : Equation3470 G) : Equation3466 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3490_implies_Equation3486
  (G : Type) `{Magma G} (h : Equation3490 G) : Equation3486 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3498_implies_Equation3486
  (G : Type) `{Magma G} (h : Equation3498 G) : Equation3486 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3503_implies_Equation3487
  (G : Type) `{Magma G} (h : Equation3503 G) : Equation3487 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3504_implies_Equation3488
  (G : Type) `{Magma G} (h : Equation3504 G) : Equation3488 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3505_implies_Equation3488
  (G : Type) `{Magma G} (h : Equation3505 G) : Equation3488 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3506_implies_Equation3489
  (G : Type) `{Magma G} (h : Equation3506 G) : Equation3489 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3527_implies_Equation3523
  (G : Type) `{Magma G} (h : Equation3527 G) : Equation3523 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3535_implies_Equation3523
  (G : Type) `{Magma G} (h : Equation3535 G) : Equation3523 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3541_implies_Equation3525
  (G : Type) `{Magma G} (h : Equation3541 G) : Equation3525 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3580_implies_Equation3563
  (G : Type) `{Magma G} (h : Equation3580 G) : Equation3563 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3589_implies_Equation3550
  (G : Type) `{Magma G} (h : Equation3589 G) : Equation3550 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3595_implies_Equation3552
  (G : Type) `{Magma G} (h : Equation3595 G) : Equation3552 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3631_implies_Equation3563
  (G : Type) `{Magma G} (h : Equation3631 G) : Equation3563 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3634_implies_Equation3566
  (G : Type) `{Magma G} (h : Equation3634 G) : Equation3566 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3646_implies_Equation3571
  (G : Type) `{Magma G} (h : Equation3646 G) : Equation3571 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3649_implies_Equation3574
  (G : Type) `{Magma G} (h : Equation3649 G) : Equation3574 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3673_implies_Equation3669
  (G : Type) `{Magma G} (h : Equation3673 G) : Equation3669 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3683_implies_Equation3679
  (G : Type) `{Magma G} (h : Equation3683 G) : Equation3679 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3693_implies_Equation3689
  (G : Type) `{Magma G} (h : Equation3693 G) : Equation3689 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3701_implies_Equation3689
  (G : Type) `{Magma G} (h : Equation3701 G) : Equation3689 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3705_implies_Equation3689
  (G : Type) `{Magma G} (h : Equation3705 G) : Equation3689 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3706_implies_Equation3690
  (G : Type) `{Magma G} (h : Equation3706 G) : Equation3690 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3707_implies_Equation3691
  (G : Type) `{Magma G} (h : Equation3707 G) : Equation3691 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3708_implies_Equation3691
  (G : Type) `{Magma G} (h : Equation3708 G) : Equation3691 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3709_implies_Equation3692
  (G : Type) `{Magma G} (h : Equation3709 G) : Equation3692 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3738_implies_Equation3726
  (G : Type) `{Magma G} (h : Equation3738 G) : Equation3726 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3744_implies_Equation3728
  (G : Type) `{Magma G} (h : Equation3744 G) : Equation3728 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3757_implies_Equation3753
  (G : Type) `{Magma G} (h : Equation3757 G) : Equation3753 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3767_implies_Equation3763
  (G : Type) `{Magma G} (h : Equation3767 G) : Equation3763 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3771_implies_Equation3760
  (G : Type) `{Magma G} (h : Equation3771 G) : Equation3760 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3779_implies_Equation3763
  (G : Type) `{Magma G} (h : Equation3779 G) : Equation3763 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3781_implies_Equation3765
  (G : Type) `{Magma G} (h : Equation3781 G) : Equation3765 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3792_implies_Equation3753
  (G : Type) `{Magma G} (h : Equation3792 G) : Equation3753 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3798_implies_Equation3755
  (G : Type) `{Magma G} (h : Equation3798 G) : Equation3755 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3809_implies_Equation3763
  (G : Type) `{Magma G} (h : Equation3809 G) : Equation3763 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3813_implies_Equation3763
  (G : Type) `{Magma G} (h : Equation3813 G) : Equation3763 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3814_implies_Equation3764
  (G : Type) `{Magma G} (h : Equation3814 G) : Equation3764 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3830_implies_Equation3763
  (G : Type) `{Magma G} (h : Equation3830 G) : Equation3763 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3831_implies_Equation3764
  (G : Type) `{Magma G} (h : Equation3831 G) : Equation3764 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3834_implies_Equation3766
  (G : Type) `{Magma G} (h : Equation3834 G) : Equation3766 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3837_implies_Equation3769
  (G : Type) `{Magma G} (h : Equation3837 G) : Equation3769 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3841_implies_Equation3772
  (G : Type) `{Magma G} (h : Equation3841 G) : Equation3772 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3842_implies_Equation3773
  (G : Type) `{Magma G} (h : Equation3842 G) : Equation3773 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3844_implies_Equation3774
  (G : Type) `{Magma G} (h : Equation3844 G) : Equation3774 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3852_implies_Equation3777
  (G : Type) `{Magma G} (h : Equation3852 G) : Equation3777 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3854_implies_Equation3778
  (G : Type) `{Magma G} (h : Equation3854 G) : Equation3778 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3886_implies_Equation3882
  (G : Type) `{Magma G} (h : Equation3886 G) : Equation3882 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3904_implies_Equation3892
  (G : Type) `{Magma G} (h : Equation3904 G) : Equation3892 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3908_implies_Equation3892
  (G : Type) `{Magma G} (h : Equation3908 G) : Equation3892 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3909_implies_Equation3893
  (G : Type) `{Magma G} (h : Equation3909 G) : Equation3893 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3911_implies_Equation3894
  (G : Type) `{Magma G} (h : Equation3911 G) : Equation3894 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3912_implies_Equation3895
  (G : Type) `{Magma G} (h : Equation3912 G) : Equation3895 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3933_implies_Equation3929
  (G : Type) `{Magma G} (h : Equation3933 G) : Equation3929 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3947_implies_Equation3931
  (G : Type) `{Magma G} (h : Equation3947 G) : Equation3931 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3970_implies_Equation3966
  (G : Type) `{Magma G} (h : Equation3970 G) : Equation3966 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation3983_implies_Equation3967
  (G : Type) `{Magma G} (h : Equation3983 G) : Equation3967 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4000_implies_Equation3957
  (G : Type) `{Magma G} (h : Equation4000 G) : Equation3957 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4001_implies_Equation3958
  (G : Type) `{Magma G} (h : Equation4001 G) : Equation3958 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4017_implies_Equation3967
  (G : Type) `{Magma G} (h : Equation4017 G) : Equation3967 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4034_implies_Equation3967
  (G : Type) `{Magma G} (h : Equation4034 G) : Equation3967 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4039_implies_Equation3971
  (G : Type) `{Magma G} (h : Equation4039 G) : Equation3971 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4040_implies_Equation3972
  (G : Type) `{Magma G} (h : Equation4040 G) : Equation3972 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4044_implies_Equation3975
  (G : Type) `{Magma G} (h : Equation4044 G) : Equation3975 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4049_implies_Equation3975
  (G : Type) `{Magma G} (h : Equation4049 G) : Equation3975 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4079_implies_Equation4075
  (G : Type) `{Magma G} (h : Equation4079 G) : Equation4075 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4113_implies_Equation4097
  (G : Type) `{Magma G} (h : Equation4113 G) : Equation4097 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4126_implies_Equation4122
  (G : Type) `{Magma G} (h : Equation4126 G) : Equation4122 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4136_implies_Equation4132
  (G : Type) `{Magma G} (h : Equation4136 G) : Equation4132 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4140_implies_Equation4129
  (G : Type) `{Magma G} (h : Equation4140 G) : Equation4129 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4144_implies_Equation4132
  (G : Type) `{Magma G} (h : Equation4144 G) : Equation4132 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4148_implies_Equation4132
  (G : Type) `{Magma G} (h : Equation4148 G) : Equation4132 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4150_implies_Equation4134
  (G : Type) `{Magma G} (h : Equation4150 G) : Equation4134 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4151_implies_Equation4134
  (G : Type) `{Magma G} (h : Equation4151 G) : Equation4134 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4152_implies_Equation4135
  (G : Type) `{Magma G} (h : Equation4152 G) : Equation4135 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4163_implies_Equation4159
  (G : Type) `{Magma G} (h : Equation4163 G) : Equation4159 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4186_implies_Equation4170
  (G : Type) `{Magma G} (h : Equation4186 G) : Equation4170 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4187_implies_Equation4171
  (G : Type) `{Magma G} (h : Equation4187 G) : Equation4171 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4204_implies_Equation4161
  (G : Type) `{Magma G} (h : Equation4204 G) : Equation4161 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4236_implies_Equation4169
  (G : Type) `{Magma G} (h : Equation4236 G) : Equation4169 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4240_implies_Equation4172
  (G : Type) `{Magma G} (h : Equation4240 G) : Equation4172 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4243_implies_Equation4175
  (G : Type) `{Magma G} (h : Equation4243 G) : Equation4175 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4247_implies_Equation4178
  (G : Type) `{Magma G} (h : Equation4247 G) : Equation4178 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4250_implies_Equation4180
  (G : Type) `{Magma G} (h : Equation4250 G) : Equation4180 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4281_implies_Equation4277
  (G : Type) `{Magma G} (h : Equation4281 G) : Equation4277 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4302_implies_Equation4292
  (G : Type) `{Magma G} (h : Equation4302 G) : Equation4292 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4308_implies_Equation4294
  (G : Type) `{Magma G} (h : Equation4308 G) : Equation4294 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4311_implies_Equation4296
  (G : Type) `{Magma G} (h : Equation4311 G) : Equation4296 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4329_implies_Equation4322
  (G : Type) `{Magma G} (h : Equation4329 G) : Equation4322 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4334_implies_Equation4323
  (G : Type) `{Magma G} (h : Equation4334 G) : Equation4323 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4336_implies_Equation4324
  (G : Type) `{Magma G} (h : Equation4336 G) : Equation4324 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4337_implies_Equation4325
  (G : Type) `{Magma G} (h : Equation4337 G) : Equation4325 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4355_implies_Equation4346
  (G : Type) `{Magma G} (h : Equation4355 G) : Equation4346 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4357_implies_Equation4339
  (G : Type) `{Magma G} (h : Equation4357 G) : Equation4339 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4359_implies_Equation4339
  (G : Type) `{Magma G} (h : Equation4359 G) : Equation4339 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4363_implies_Equation4344
  (G : Type) `{Magma G} (h : Equation4363 G) : Equation4344 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4371_implies_Equation4345
  (G : Type) `{Magma G} (h : Equation4371 G) : Equation4345 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4404_implies_Equation4400
  (G : Type) `{Magma G} (h : Equation4404 G) : Equation4400 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4418_implies_Equation4407
  (G : Type) `{Magma G} (h : Equation4418 G) : Equation4407 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4422_implies_Equation4410
  (G : Type) `{Magma G} (h : Equation4422 G) : Equation4410 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4426_implies_Equation4410
  (G : Type) `{Magma G} (h : Equation4426 G) : Equation4410 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4427_implies_Equation4411
  (G : Type) `{Magma G} (h : Equation4427 G) : Equation4411 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4428_implies_Equation4412
  (G : Type) `{Magma G} (h : Equation4428 G) : Equation4412 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4429_implies_Equation4412
  (G : Type) `{Magma G} (h : Equation4429 G) : Equation4412 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4430_implies_Equation4413
  (G : Type) `{Magma G} (h : Equation4430 G) : Equation4413 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4441_implies_Equation4437
  (G : Type) `{Magma G} (h : Equation4441 G) : Equation4437 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4455_implies_Equation4444
  (G : Type) `{Magma G} (h : Equation4455 G) : Equation4444 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4459_implies_Equation4447
  (G : Type) `{Magma G} (h : Equation4459 G) : Equation4447 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4463_implies_Equation4447
  (G : Type) `{Magma G} (h : Equation4463 G) : Equation4447 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4464_implies_Equation4448
  (G : Type) `{Magma G} (h : Equation4464 G) : Equation4448 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4466_implies_Equation4449
  (G : Type) `{Magma G} (h : Equation4466 G) : Equation4449 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4467_implies_Equation4450
  (G : Type) `{Magma G} (h : Equation4467 G) : Equation4450 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4478_implies_Equation4474
  (G : Type) `{Magma G} (h : Equation4478 G) : Equation4474 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4496_implies_Equation4484
  (G : Type) `{Magma G} (h : Equation4496 G) : Equation4484 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4500_implies_Equation4484
  (G : Type) `{Magma G} (h : Equation4500 G) : Equation4484 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4502_implies_Equation4486
  (G : Type) `{Magma G} (h : Equation4502 G) : Equation4486 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4503_implies_Equation4486
  (G : Type) `{Magma G} (h : Equation4503 G) : Equation4486 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4504_implies_Equation4487
  (G : Type) `{Magma G} (h : Equation4504 G) : Equation4487 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4509_implies_Equation4471
  (G : Type) `{Magma G} (h : Equation4509 G) : Equation4471 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4513_implies_Equation4474
  (G : Type) `{Magma G} (h : Equation4513 G) : Equation4474 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4518_implies_Equation4475
  (G : Type) `{Magma G} (h : Equation4518 G) : Equation4475 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4519_implies_Equation4476
  (G : Type) `{Magma G} (h : Equation4519 G) : Equation4476 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4520_implies_Equation4476
  (G : Type) `{Magma G} (h : Equation4520 G) : Equation4476 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4521_implies_Equation4477
  (G : Type) `{Magma G} (h : Equation4521 G) : Equation4477 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4551_implies_Equation4484
  (G : Type) `{Magma G} (h : Equation4551 G) : Equation4484 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4554_implies_Equation4486
  (G : Type) `{Magma G} (h : Equation4554 G) : Equation4486 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4557_implies_Equation4489
  (G : Type) `{Magma G} (h : Equation4557 G) : Equation4489 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4559_implies_Equation4490
  (G : Type) `{Magma G} (h : Equation4559 G) : Equation4490 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4564_implies_Equation4494
  (G : Type) `{Magma G} (h : Equation4564 G) : Equation4494 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4569_implies_Equation4494
  (G : Type) `{Magma G} (h : Equation4569 G) : Equation4494 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4570_implies_Equation4495
  (G : Type) `{Magma G} (h : Equation4570 G) : Equation4495 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4572_implies_Equation4497
  (G : Type) `{Magma G} (h : Equation4572 G) : Equation4497 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4574_implies_Equation4498
  (G : Type) `{Magma G} (h : Equation4574 G) : Equation4498 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4575_implies_Equation4499
  (G : Type) `{Magma G} (h : Equation4575 G) : Equation4499 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4623_implies_Equation4609
  (G : Type) `{Magma G} (h : Equation4623 G) : Equation4609 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4626_implies_Equation4611
  (G : Type) `{Magma G} (h : Equation4626 G) : Equation4611 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4627_implies_Equation4612
  (G : Type) `{Magma G} (h : Equation4627 G) : Equation4612 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4649_implies_Equation4638
  (G : Type) `{Magma G} (h : Equation4649 G) : Equation4638 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4651_implies_Equation4639
  (G : Type) `{Magma G} (h : Equation4651 G) : Equation4639 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4652_implies_Equation4640
  (G : Type) `{Magma G} (h : Equation4652 G) : Equation4640 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4670_implies_Equation4661
  (G : Type) `{Magma G} (h : Equation4670 G) : Equation4661 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4672_implies_Equation4654
  (G : Type) `{Magma G} (h : Equation4672 G) : Equation4654 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4674_implies_Equation4654
  (G : Type) `{Magma G} (h : Equation4674 G) : Equation4654 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4675_implies_Equation4655
  (G : Type) `{Magma G} (h : Equation4675 G) : Equation4655 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4678_implies_Equation4659
  (G : Type) `{Magma G} (h : Equation4678 G) : Equation4659 G.
Proof. intros x y z. exact (h x y y z). Qed.

Theorem Equation4686_implies_Equation4660
  (G : Type) `{Magma G} (h : Equation4686 G) : Equation4660 G.
Proof. intros x y z. exact (h x y y z). Qed.

