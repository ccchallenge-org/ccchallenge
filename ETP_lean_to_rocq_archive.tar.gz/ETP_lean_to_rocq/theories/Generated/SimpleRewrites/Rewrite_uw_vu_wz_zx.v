(** * SimpleRewrites/Rewrite_uw_vu_wz_zx

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation1019_implies_Equation905
  (G : Type) `{Magma G} (h : Equation1019 G) : Equation905 G.
Proof. intros x y z w u. exact (h x y x z w u). Qed.

Theorem Equation1425_implies_Equation1311
  (G : Type) `{Magma G} (h : Equation1425 G) : Equation1311 G.
Proof. intros x y z w u. exact (h x y x z w u). Qed.

Theorem Equation1831_implies_Equation1717
  (G : Type) `{Magma G} (h : Equation1831 G) : Equation1717 G.
Proof. intros x y z w u. exact (h x y x z w u). Qed.

Theorem Equation2643_implies_Equation2529
  (G : Type) `{Magma G} (h : Equation2643 G) : Equation2529 G.
Proof. intros x y z w u. exact (h x y x z w u). Qed.

Theorem Equation3049_implies_Equation2935
  (G : Type) `{Magma G} (h : Equation3049 G) : Equation2935 G.
Proof. intros x y z w u. exact (h x y x z w u). Qed.

Theorem Equation4379_implies_Equation4338
  (G : Type) `{Magma G} (h : Equation4379 G) : Equation4338 G.
Proof. intros x y z w u. exact (h x y x z w u). Qed.

