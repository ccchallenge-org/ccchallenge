(** * SimpleRewrites/Rewrite_uw_vu_wz_zy

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation1222_implies_Equation1145
  (G : Type) `{Magma G} (h : Equation1222 G) : Equation1145 G.
Proof. intros x y z w u. exact (h x y y z w u). Qed.

Theorem Equation1628_implies_Equation1551
  (G : Type) `{Magma G} (h : Equation1628 G) : Equation1551 G.
Proof. intros x y z w u. exact (h x y y z w u). Qed.

Theorem Equation2034_implies_Equation1957
  (G : Type) `{Magma G} (h : Equation2034 G) : Equation1957 G.
Proof. intros x y z w u. exact (h x y y z w u). Qed.

Theorem Equation2237_implies_Equation2160
  (G : Type) `{Magma G} (h : Equation2237 G) : Equation2160 G.
Proof. intros x y z w u. exact (h x y y z w u). Qed.

Theorem Equation2643_implies_Equation2566
  (G : Type) `{Magma G} (h : Equation2643 G) : Equation2566 G.
Proof. intros x y z w u. exact (h x y y z w u). Qed.

Theorem Equation3658_implies_Equation3581
  (G : Type) `{Magma G} (h : Equation3658 G) : Equation3581 G.
Proof. intros x y z w u. exact (h x y y z w u). Qed.

Theorem Equation3861_implies_Equation3784
  (G : Type) `{Magma G} (h : Equation3861 G) : Equation3784 G.
Proof. intros x y z w u. exact (h x y y z w u). Qed.

Theorem Equation4064_implies_Equation3987
  (G : Type) `{Magma G} (h : Equation4064 G) : Equation3987 G.
Proof. intros x y z w u. exact (h x y y z w u). Qed.

Theorem Equation4267_implies_Equation4190
  (G : Type) `{Magma G} (h : Equation4267 G) : Equation4190 G.
Proof. intros x y z w u. exact (h x y y z w u). Qed.

