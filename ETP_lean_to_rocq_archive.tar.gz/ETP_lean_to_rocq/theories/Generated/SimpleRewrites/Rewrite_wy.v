(** * SimpleRewrites/Rewrite_wy

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation22_implies_Equation20
  (G : Type) `{Magma G} (h : Equation22 G) : Equation20 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation37_implies_Equation35
  (G : Type) `{Magma G} (h : Equation37 G) : Equation35 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation61_implies_Equation59
  (G : Type) `{Magma G} (h : Equation61 G) : Equation59 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation96_implies_Equation88
  (G : Type) `{Magma G} (h : Equation96 G) : Equation88 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation97_implies_Equation87
  (G : Type) `{Magma G} (h : Equation97 G) : Equation87 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation123_implies_Equation121
  (G : Type) `{Magma G} (h : Equation123 G) : Equation121 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation133_implies_Equation131
  (G : Type) `{Magma G} (h : Equation133 G) : Equation131 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation137_implies_Equation135
  (G : Type) `{Magma G} (h : Equation137 G) : Equation135 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation141_implies_Equation139
  (G : Type) `{Magma G} (h : Equation141 G) : Equation139 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation145_implies_Equation143
  (G : Type) `{Magma G} (h : Equation145 G) : Equation143 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation165_implies_Equation163
  (G : Type) `{Magma G} (h : Equation165 G) : Equation163 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation185_implies_Equation183
  (G : Type) `{Magma G} (h : Equation185 G) : Equation183 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation193_implies_Equation191
  (G : Type) `{Magma G} (h : Equation193 G) : Equation191 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation198_implies_Equation190
  (G : Type) `{Magma G} (h : Equation198 G) : Equation190 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation199_implies_Equation191
  (G : Type) `{Magma G} (h : Equation199 G) : Equation191 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation227_implies_Equation225
  (G : Type) `{Magma G} (h : Equation227 G) : Equation225 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation237_implies_Equation235
  (G : Type) `{Magma G} (h : Equation237 G) : Equation235 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation241_implies_Equation239
  (G : Type) `{Magma G} (h : Equation241 G) : Equation239 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation245_implies_Equation243
  (G : Type) `{Magma G} (h : Equation245 G) : Equation243 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation249_implies_Equation247
  (G : Type) `{Magma G} (h : Equation249 G) : Equation247 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation279_implies_Equation277
  (G : Type) `{Magma G} (h : Equation279 G) : Equation277 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation302_implies_Equation294
  (G : Type) `{Magma G} (h : Equation302 G) : Equation294 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation305_implies_Equation295
  (G : Type) `{Magma G} (h : Equation305 G) : Equation295 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation321_implies_Equation319
  (G : Type) `{Magma G} (h : Equation321 G) : Equation319 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation331_implies_Equation329
  (G : Type) `{Magma G} (h : Equation331 G) : Equation329 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation355_implies_Equation347
  (G : Type) `{Magma G} (h : Equation355 G) : Equation347 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation356_implies_Equation348
  (G : Type) `{Magma G} (h : Equation356 G) : Equation348 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation373_implies_Equation371
  (G : Type) `{Magma G} (h : Equation373 G) : Equation371 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation408_implies_Equation400
  (G : Type) `{Magma G} (h : Equation408 G) : Equation400 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation425_implies_Equation423
  (G : Type) `{Magma G} (h : Equation425 G) : Equation423 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation449_implies_Equation447
  (G : Type) `{Magma G} (h : Equation449 G) : Equation447 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation453_implies_Equation451
  (G : Type) `{Magma G} (h : Equation453 G) : Equation451 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation458_implies_Equation450
  (G : Type) `{Magma G} (h : Equation458 G) : Equation450 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation461_implies_Equation451
  (G : Type) `{Magma G} (h : Equation461 G) : Equation451 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation498_implies_Equation488
  (G : Type) `{Magma G} (h : Equation498 G) : Equation488 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation509_implies_Equation507
  (G : Type) `{Magma G} (h : Equation509 G) : Equation507 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation519_implies_Equation517
  (G : Type) `{Magma G} (h : Equation519 G) : Equation517 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation523_implies_Equation521
  (G : Type) `{Magma G} (h : Equation523 G) : Equation521 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation531_implies_Equation529
  (G : Type) `{Magma G} (h : Equation531 G) : Equation529 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation532_implies_Equation524
  (G : Type) `{Magma G} (h : Equation532 G) : Equation524 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation544_implies_Equation542
  (G : Type) `{Magma G} (h : Equation544 G) : Equation542 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation561_implies_Equation559
  (G : Type) `{Magma G} (h : Equation561 G) : Equation559 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation578_implies_Equation576
  (G : Type) `{Magma G} (h : Equation578 G) : Equation576 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation582_implies_Equation580
  (G : Type) `{Magma G} (h : Equation582 G) : Equation580 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation584_implies_Equation576
  (G : Type) `{Magma G} (h : Equation584 G) : Equation576 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation588_implies_Equation554
  (G : Type) `{Magma G} (h : Equation588 G) : Equation554 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation598_implies_Equation562
  (G : Type) `{Magma G} (h : Equation598 G) : Equation562 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation599_implies_Equation563
  (G : Type) `{Magma G} (h : Equation599 G) : Equation563 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation603_implies_Equation558
  (G : Type) `{Magma G} (h : Equation603 G) : Equation558 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation628_implies_Equation626
  (G : Type) `{Magma G} (h : Equation628 G) : Equation626 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation656_implies_Equation654
  (G : Type) `{Magma G} (h : Equation656 G) : Equation654 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation661_implies_Equation653
  (G : Type) `{Magma G} (h : Equation661 G) : Equation653 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation662_implies_Equation654
  (G : Type) `{Magma G} (h : Equation662 G) : Equation654 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation663_implies_Equation655
  (G : Type) `{Magma G} (h : Equation663 G) : Equation655 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation664_implies_Equation654
  (G : Type) `{Magma G} (h : Equation664 G) : Equation654 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation685_implies_Equation683
  (G : Type) `{Magma G} (h : Equation685 G) : Equation683 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation689_implies_Equation687
  (G : Type) `{Magma G} (h : Equation689 G) : Equation687 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation693_implies_Equation691
  (G : Type) `{Magma G} (h : Equation693 G) : Equation691 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation701_implies_Equation691
  (G : Type) `{Magma G} (h : Equation701 G) : Equation691 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation712_implies_Equation710
  (G : Type) `{Magma G} (h : Equation712 G) : Equation710 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation726_implies_Equation724
  (G : Type) `{Magma G} (h : Equation726 G) : Equation724 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation730_implies_Equation728
  (G : Type) `{Magma G} (h : Equation730 G) : Equation728 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation734_implies_Equation732
  (G : Type) `{Magma G} (h : Equation734 G) : Equation732 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation747_implies_Equation745
  (G : Type) `{Magma G} (h : Equation747 G) : Equation745 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation753_implies_Equation745
  (G : Type) `{Magma G} (h : Equation753 G) : Equation745 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation764_implies_Equation762
  (G : Type) `{Magma G} (h : Equation764 G) : Equation762 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation768_implies_Equation766
  (G : Type) `{Magma G} (h : Equation768 G) : Equation766 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation785_implies_Equation783
  (G : Type) `{Magma G} (h : Equation785 G) : Equation783 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation787_implies_Equation779
  (G : Type) `{Magma G} (h : Equation787 G) : Equation779 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation789_implies_Equation779
  (G : Type) `{Magma G} (h : Equation789 G) : Equation779 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation791_implies_Equation757
  (G : Type) `{Magma G} (h : Equation791 G) : Equation757 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation831_implies_Equation829
  (G : Type) `{Magma G} (h : Equation831 G) : Equation829 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation851_implies_Equation849
  (G : Type) `{Magma G} (h : Equation851 G) : Equation849 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation855_implies_Equation853
  (G : Type) `{Magma G} (h : Equation855 G) : Equation853 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation859_implies_Equation857
  (G : Type) `{Magma G} (h : Equation859 G) : Equation857 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation864_implies_Equation856
  (G : Type) `{Magma G} (h : Equation864 G) : Equation856 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation867_implies_Equation857
  (G : Type) `{Magma G} (h : Equation867 G) : Equation857 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation878_implies_Equation876
  (G : Type) `{Magma G} (h : Equation878 G) : Equation876 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation888_implies_Equation886
  (G : Type) `{Magma G} (h : Equation888 G) : Equation886 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation896_implies_Equation894
  (G : Type) `{Magma G} (h : Equation896 G) : Equation894 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation902_implies_Equation894
  (G : Type) `{Magma G} (h : Equation902 G) : Equation894 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation903_implies_Equation895
  (G : Type) `{Magma G} (h : Equation903 G) : Equation895 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation925_implies_Equation923
  (G : Type) `{Magma G} (h : Equation925 G) : Equation923 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation937_implies_Equation935
  (G : Type) `{Magma G} (h : Equation937 G) : Equation935 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation946_implies_Equation944
  (G : Type) `{Magma G} (h : Equation946 G) : Equation944 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation950_implies_Equation948
  (G : Type) `{Magma G} (h : Equation950 G) : Equation948 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation956_implies_Equation948
  (G : Type) `{Magma G} (h : Equation956 G) : Equation948 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation958_implies_Equation948
  (G : Type) `{Magma G} (h : Equation958 G) : Equation948 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation967_implies_Equation965
  (G : Type) `{Magma G} (h : Equation967 G) : Equation965 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation984_implies_Equation982
  (G : Type) `{Magma G} (h : Equation984 G) : Equation982 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation992_implies_Equation982
  (G : Type) `{Magma G} (h : Equation992 G) : Equation982 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1005_implies_Equation969
  (G : Type) `{Magma G} (h : Equation1005 G) : Equation969 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1006_implies_Equation970
  (G : Type) `{Magma G} (h : Equation1006 G) : Equation970 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1067_implies_Equation1059
  (G : Type) `{Magma G} (h : Equation1067 G) : Equation1059 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1068_implies_Equation1060
  (G : Type) `{Magma G} (h : Equation1068 G) : Equation1060 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1069_implies_Equation1061
  (G : Type) `{Magma G} (h : Equation1069 G) : Equation1061 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1081_implies_Equation1079
  (G : Type) `{Magma G} (h : Equation1081 G) : Equation1079 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1091_implies_Equation1089
  (G : Type) `{Magma G} (h : Equation1091 G) : Equation1089 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1095_implies_Equation1093
  (G : Type) `{Magma G} (h : Equation1095 G) : Equation1093 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1099_implies_Equation1097
  (G : Type) `{Magma G} (h : Equation1099 G) : Equation1097 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1105_implies_Equation1097
  (G : Type) `{Magma G} (h : Equation1105 G) : Equation1097 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1118_implies_Equation1116
  (G : Type) `{Magma G} (h : Equation1118 G) : Equation1116 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1128_implies_Equation1126
  (G : Type) `{Magma G} (h : Equation1128 G) : Equation1126 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1132_implies_Equation1130
  (G : Type) `{Magma G} (h : Equation1132 G) : Equation1130 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1136_implies_Equation1134
  (G : Type) `{Magma G} (h : Equation1136 G) : Equation1134 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1140_implies_Equation1138
  (G : Type) `{Magma G} (h : Equation1140 G) : Equation1138 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1149_implies_Equation1147
  (G : Type) `{Magma G} (h : Equation1149 G) : Equation1147 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1153_implies_Equation1151
  (G : Type) `{Magma G} (h : Equation1153 G) : Equation1151 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1158_implies_Equation1150
  (G : Type) `{Magma G} (h : Equation1158 G) : Equation1150 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1159_implies_Equation1151
  (G : Type) `{Magma G} (h : Equation1159 G) : Equation1151 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1166_implies_Equation1164
  (G : Type) `{Magma G} (h : Equation1166 G) : Equation1164 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1170_implies_Equation1168
  (G : Type) `{Magma G} (h : Equation1170 G) : Equation1168 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1174_implies_Equation1172
  (G : Type) `{Magma G} (h : Equation1174 G) : Equation1172 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1187_implies_Equation1185
  (G : Type) `{Magma G} (h : Equation1187 G) : Equation1185 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1191_implies_Equation1189
  (G : Type) `{Magma G} (h : Equation1191 G) : Equation1189 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1193_implies_Equation1185
  (G : Type) `{Magma G} (h : Equation1193 G) : Equation1185 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1195_implies_Equation1185
  (G : Type) `{Magma G} (h : Equation1195 G) : Equation1185 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1237_implies_Equation1235
  (G : Type) `{Magma G} (h : Equation1237 G) : Equation1235 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1247_implies_Equation1245
  (G : Type) `{Magma G} (h : Equation1247 G) : Equation1245 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1257_implies_Equation1255
  (G : Type) `{Magma G} (h : Equation1257 G) : Equation1255 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1261_implies_Equation1259
  (G : Type) `{Magma G} (h : Equation1261 G) : Equation1259 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1270_implies_Equation1262
  (G : Type) `{Magma G} (h : Equation1270 G) : Equation1262 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1302_implies_Equation1300
  (G : Type) `{Magma G} (h : Equation1302 G) : Equation1300 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1308_implies_Equation1300
  (G : Type) `{Magma G} (h : Equation1308 G) : Equation1300 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1321_implies_Equation1319
  (G : Type) `{Magma G} (h : Equation1321 G) : Equation1319 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1339_implies_Equation1337
  (G : Type) `{Magma G} (h : Equation1339 G) : Equation1337 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1343_implies_Equation1341
  (G : Type) `{Magma G} (h : Equation1343 G) : Equation1341 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1352_implies_Equation1350
  (G : Type) `{Magma G} (h : Equation1352 G) : Equation1350 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1356_implies_Equation1354
  (G : Type) `{Magma G} (h : Equation1356 G) : Equation1354 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1362_implies_Equation1354
  (G : Type) `{Magma G} (h : Equation1362 G) : Equation1354 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1369_implies_Equation1367
  (G : Type) `{Magma G} (h : Equation1369 G) : Equation1367 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1373_implies_Equation1371
  (G : Type) `{Magma G} (h : Equation1373 G) : Equation1371 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1377_implies_Equation1375
  (G : Type) `{Magma G} (h : Equation1377 G) : Equation1375 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1394_implies_Equation1392
  (G : Type) `{Magma G} (h : Equation1394 G) : Equation1392 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1403_implies_Equation1367
  (G : Type) `{Magma G} (h : Equation1403 G) : Equation1367 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1460_implies_Equation1458
  (G : Type) `{Magma G} (h : Equation1460 G) : Equation1458 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1464_implies_Equation1462
  (G : Type) `{Magma G} (h : Equation1464 G) : Equation1462 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1473_implies_Equation1465
  (G : Type) `{Magma G} (h : Equation1473 G) : Equation1465 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1475_implies_Equation1467
  (G : Type) `{Magma G} (h : Equation1475 G) : Equation1467 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1497_implies_Equation1495
  (G : Type) `{Magma G} (h : Equation1497 G) : Equation1495 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1505_implies_Equation1503
  (G : Type) `{Magma G} (h : Equation1505 G) : Equation1503 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1510_implies_Equation1502
  (G : Type) `{Magma G} (h : Equation1510 G) : Equation1502 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1524_implies_Equation1522
  (G : Type) `{Magma G} (h : Equation1524 G) : Equation1522 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1534_implies_Equation1532
  (G : Type) `{Magma G} (h : Equation1534 G) : Equation1532 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1538_implies_Equation1536
  (G : Type) `{Magma G} (h : Equation1538 G) : Equation1536 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1542_implies_Equation1540
  (G : Type) `{Magma G} (h : Equation1542 G) : Equation1540 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1546_implies_Equation1544
  (G : Type) `{Magma G} (h : Equation1546 G) : Equation1544 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1555_implies_Equation1553
  (G : Type) `{Magma G} (h : Equation1555 G) : Equation1553 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1559_implies_Equation1557
  (G : Type) `{Magma G} (h : Equation1559 G) : Equation1557 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1564_implies_Equation1556
  (G : Type) `{Magma G} (h : Equation1564 G) : Equation1556 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1576_implies_Equation1574
  (G : Type) `{Magma G} (h : Equation1576 G) : Equation1574 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1580_implies_Equation1578
  (G : Type) `{Magma G} (h : Equation1580 G) : Equation1578 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1581_implies_Equation1573
  (G : Type) `{Magma G} (h : Equation1581 G) : Equation1573 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1582_implies_Equation1574
  (G : Type) `{Magma G} (h : Equation1582 G) : Equation1574 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1584_implies_Equation1574
  (G : Type) `{Magma G} (h : Equation1584 G) : Equation1574 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1593_implies_Equation1591
  (G : Type) `{Magma G} (h : Equation1593 G) : Equation1591 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1597_implies_Equation1595
  (G : Type) `{Magma G} (h : Equation1597 G) : Equation1595 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1599_implies_Equation1591
  (G : Type) `{Magma G} (h : Equation1599 G) : Equation1591 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1601_implies_Equation1591
  (G : Type) `{Magma G} (h : Equation1601 G) : Equation1591 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1603_implies_Equation1569
  (G : Type) `{Magma G} (h : Equation1603 G) : Equation1569 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1606_implies_Equation1570
  (G : Type) `{Magma G} (h : Equation1606 G) : Equation1570 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1609_implies_Equation1574
  (G : Type) `{Magma G} (h : Equation1609 G) : Equation1574 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1611_implies_Equation1574
  (G : Type) `{Magma G} (h : Equation1611 G) : Equation1574 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1618_implies_Equation1573
  (G : Type) `{Magma G} (h : Equation1618 G) : Equation1573 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1619_implies_Equation1574
  (G : Type) `{Magma G} (h : Equation1619 G) : Equation1574 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1667_implies_Equation1665
  (G : Type) `{Magma G} (h : Equation1667 G) : Equation1665 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1716_implies_Equation1706
  (G : Type) `{Magma G} (h : Equation1716 G) : Equation1706 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1727_implies_Equation1725
  (G : Type) `{Magma G} (h : Equation1727 G) : Equation1725 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1751_implies_Equation1743
  (G : Type) `{Magma G} (h : Equation1751 G) : Equation1743 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1762_implies_Equation1760
  (G : Type) `{Magma G} (h : Equation1762 G) : Equation1760 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1767_implies_Equation1759
  (G : Type) `{Magma G} (h : Equation1767 G) : Equation1759 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1768_implies_Equation1760
  (G : Type) `{Magma G} (h : Equation1768 G) : Equation1760 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1770_implies_Equation1760
  (G : Type) `{Magma G} (h : Equation1770 G) : Equation1760 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1784_implies_Equation1776
  (G : Type) `{Magma G} (h : Equation1784 G) : Equation1776 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1785_implies_Equation1777
  (G : Type) `{Magma G} (h : Equation1785 G) : Equation1777 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1802_implies_Equation1794
  (G : Type) `{Magma G} (h : Equation1802 G) : Equation1794 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1806_implies_Equation1772
  (G : Type) `{Magma G} (h : Equation1806 G) : Equation1772 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1807_implies_Equation1773
  (G : Type) `{Magma G} (h : Equation1807 G) : Equation1773 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1809_implies_Equation1773
  (G : Type) `{Magma G} (h : Equation1809 G) : Equation1773 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1811_implies_Equation1776
  (G : Type) `{Magma G} (h : Equation1811 G) : Equation1776 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1821_implies_Equation1776
  (G : Type) `{Magma G} (h : Equation1821 G) : Equation1776 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1856_implies_Equation1854
  (G : Type) `{Magma G} (h : Equation1856 G) : Equation1854 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1866_implies_Equation1864
  (G : Type) `{Magma G} (h : Equation1866 G) : Equation1864 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1874_implies_Equation1872
  (G : Type) `{Magma G} (h : Equation1874 G) : Equation1872 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1879_implies_Equation1871
  (G : Type) `{Magma G} (h : Equation1879 G) : Equation1871 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1893_implies_Equation1891
  (G : Type) `{Magma G} (h : Equation1893 G) : Equation1891 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1911_implies_Equation1909
  (G : Type) `{Magma G} (h : Equation1911 G) : Equation1909 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1916_implies_Equation1908
  (G : Type) `{Magma G} (h : Equation1916 G) : Equation1908 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1917_implies_Equation1909
  (G : Type) `{Magma G} (h : Equation1917 G) : Equation1909 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1940_implies_Equation1938
  (G : Type) `{Magma G} (h : Equation1940 G) : Equation1938 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1944_implies_Equation1942
  (G : Type) `{Magma G} (h : Equation1944 G) : Equation1942 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1948_implies_Equation1946
  (G : Type) `{Magma G} (h : Equation1948 G) : Equation1946 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1952_implies_Equation1950
  (G : Type) `{Magma G} (h : Equation1952 G) : Equation1950 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1965_implies_Equation1963
  (G : Type) `{Magma G} (h : Equation1965 G) : Equation1963 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1973_implies_Equation1963
  (G : Type) `{Magma G} (h : Equation1973 G) : Equation1963 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation1986_implies_Equation1984
  (G : Type) `{Magma G} (h : Equation1986 G) : Equation1984 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2003_implies_Equation2001
  (G : Type) `{Magma G} (h : Equation2003 G) : Equation2001 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2005_implies_Equation1997
  (G : Type) `{Magma G} (h : Equation2005 G) : Equation1997 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2006_implies_Equation1998
  (G : Type) `{Magma G} (h : Equation2006 G) : Equation1998 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2012_implies_Equation1976
  (G : Type) `{Magma G} (h : Equation2012 G) : Equation1976 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2024_implies_Equation1979
  (G : Type) `{Magma G} (h : Equation2024 G) : Equation1979 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2049_implies_Equation2047
  (G : Type) `{Magma G} (h : Equation2049 G) : Equation2047 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2059_implies_Equation2057
  (G : Type) `{Magma G} (h : Equation2059 G) : Equation2057 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2073_implies_Equation2071
  (G : Type) `{Magma G} (h : Equation2073 G) : Equation2071 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2077_implies_Equation2075
  (G : Type) `{Magma G} (h : Equation2077 G) : Equation2075 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2082_implies_Equation2074
  (G : Type) `{Magma G} (h : Equation2082 G) : Equation2074 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2084_implies_Equation2076
  (G : Type) `{Magma G} (h : Equation2084 G) : Equation2076 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2085_implies_Equation2075
  (G : Type) `{Magma G} (h : Equation2085 G) : Equation2075 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2096_implies_Equation2094
  (G : Type) `{Magma G} (h : Equation2096 G) : Equation2094 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2106_implies_Equation2104
  (G : Type) `{Magma G} (h : Equation2106 G) : Equation2104 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2110_implies_Equation2108
  (G : Type) `{Magma G} (h : Equation2110 G) : Equation2108 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2114_implies_Equation2112
  (G : Type) `{Magma G} (h : Equation2114 G) : Equation2112 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2122_implies_Equation2112
  (G : Type) `{Magma G} (h : Equation2122 G) : Equation2112 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2133_implies_Equation2131
  (G : Type) `{Magma G} (h : Equation2133 G) : Equation2131 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2143_implies_Equation2141
  (G : Type) `{Magma G} (h : Equation2143 G) : Equation2141 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2147_implies_Equation2145
  (G : Type) `{Magma G} (h : Equation2147 G) : Equation2145 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2151_implies_Equation2149
  (G : Type) `{Magma G} (h : Equation2151 G) : Equation2149 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2155_implies_Equation2153
  (G : Type) `{Magma G} (h : Equation2155 G) : Equation2153 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2164_implies_Equation2162
  (G : Type) `{Magma G} (h : Equation2164 G) : Equation2162 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2168_implies_Equation2166
  (G : Type) `{Magma G} (h : Equation2168 G) : Equation2166 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2174_implies_Equation2166
  (G : Type) `{Magma G} (h : Equation2174 G) : Equation2166 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2176_implies_Equation2166
  (G : Type) `{Magma G} (h : Equation2176 G) : Equation2166 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2185_implies_Equation2183
  (G : Type) `{Magma G} (h : Equation2185 G) : Equation2183 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2189_implies_Equation2187
  (G : Type) `{Magma G} (h : Equation2189 G) : Equation2187 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2190_implies_Equation2182
  (G : Type) `{Magma G} (h : Equation2190 G) : Equation2182 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2202_implies_Equation2200
  (G : Type) `{Magma G} (h : Equation2202 G) : Equation2200 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2206_implies_Equation2204
  (G : Type) `{Magma G} (h : Equation2206 G) : Equation2204 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2215_implies_Equation2179
  (G : Type) `{Magma G} (h : Equation2215 G) : Equation2179 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2227_implies_Equation2182
  (G : Type) `{Magma G} (h : Equation2227 G) : Equation2182 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2285_implies_Equation2277
  (G : Type) `{Magma G} (h : Equation2285 G) : Equation2277 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2322_implies_Equation2314
  (G : Type) `{Magma G} (h : Equation2322 G) : Equation2314 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2323_implies_Equation2315
  (G : Type) `{Magma G} (h : Equation2323 G) : Equation2315 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2325_implies_Equation2315
  (G : Type) `{Magma G} (h : Equation2325 G) : Equation2315 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2336_implies_Equation2334
  (G : Type) `{Magma G} (h : Equation2336 G) : Equation2334 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2346_implies_Equation2344
  (G : Type) `{Magma G} (h : Equation2346 G) : Equation2344 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2350_implies_Equation2348
  (G : Type) `{Magma G} (h : Equation2350 G) : Equation2348 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2354_implies_Equation2352
  (G : Type) `{Magma G} (h : Equation2354 G) : Equation2352 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2358_implies_Equation2356
  (G : Type) `{Magma G} (h : Equation2358 G) : Equation2356 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2360_implies_Equation2352
  (G : Type) `{Magma G} (h : Equation2360 G) : Equation2352 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2362_implies_Equation2352
  (G : Type) `{Magma G} (h : Equation2362 G) : Equation2352 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2371_implies_Equation2369
  (G : Type) `{Magma G} (h : Equation2371 G) : Equation2369 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2376_implies_Equation2368
  (G : Type) `{Magma G} (h : Equation2376 G) : Equation2368 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2379_implies_Equation2369
  (G : Type) `{Magma G} (h : Equation2379 G) : Equation2369 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2388_implies_Equation2386
  (G : Type) `{Magma G} (h : Equation2388 G) : Equation2386 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2392_implies_Equation2390
  (G : Type) `{Magma G} (h : Equation2392 G) : Equation2390 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2394_implies_Equation2386
  (G : Type) `{Magma G} (h : Equation2394 G) : Equation2386 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2396_implies_Equation2386
  (G : Type) `{Magma G} (h : Equation2396 G) : Equation2386 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2405_implies_Equation2403
  (G : Type) `{Magma G} (h : Equation2405 G) : Equation2403 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2409_implies_Equation2407
  (G : Type) `{Magma G} (h : Equation2409 G) : Equation2407 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2411_implies_Equation2403
  (G : Type) `{Magma G} (h : Equation2411 G) : Equation2403 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2413_implies_Equation2403
  (G : Type) `{Magma G} (h : Equation2413 G) : Equation2403 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2415_implies_Equation2381
  (G : Type) `{Magma G} (h : Equation2415 G) : Equation2381 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2416_implies_Equation2382
  (G : Type) `{Magma G} (h : Equation2416 G) : Equation2382 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2418_implies_Equation2382
  (G : Type) `{Magma G} (h : Equation2418 G) : Equation2382 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2425_implies_Equation2389
  (G : Type) `{Magma G} (h : Equation2425 G) : Equation2389 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2430_implies_Equation2385
  (G : Type) `{Magma G} (h : Equation2430 G) : Equation2385 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2465_implies_Equation2463
  (G : Type) `{Magma G} (h : Equation2465 G) : Equation2463 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2488_implies_Equation2480
  (G : Type) `{Magma G} (h : Equation2488 G) : Equation2480 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2489_implies_Equation2481
  (G : Type) `{Magma G} (h : Equation2489 G) : Equation2481 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2512_implies_Equation2510
  (G : Type) `{Magma G} (h : Equation2512 G) : Equation2510 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2516_implies_Equation2514
  (G : Type) `{Magma G} (h : Equation2516 G) : Equation2514 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2520_implies_Equation2518
  (G : Type) `{Magma G} (h : Equation2520 G) : Equation2518 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2549_implies_Equation2547
  (G : Type) `{Magma G} (h : Equation2549 G) : Equation2547 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2553_implies_Equation2551
  (G : Type) `{Magma G} (h : Equation2553 G) : Equation2551 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2557_implies_Equation2555
  (G : Type) `{Magma G} (h : Equation2557 G) : Equation2555 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2561_implies_Equation2559
  (G : Type) `{Magma G} (h : Equation2561 G) : Equation2559 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2582_implies_Equation2572
  (G : Type) `{Magma G} (h : Equation2582 G) : Equation2572 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2591_implies_Equation2589
  (G : Type) `{Magma G} (h : Equation2591 G) : Equation2589 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2595_implies_Equation2593
  (G : Type) `{Magma G} (h : Equation2595 G) : Equation2593 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2608_implies_Equation2606
  (G : Type) `{Magma G} (h : Equation2608 G) : Equation2606 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2612_implies_Equation2610
  (G : Type) `{Magma G} (h : Equation2612 G) : Equation2610 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2619_implies_Equation2585
  (G : Type) `{Magma G} (h : Equation2619 G) : Equation2585 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2623_implies_Equation2588
  (G : Type) `{Magma G} (h : Equation2623 G) : Equation2588 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2686_implies_Equation2684
  (G : Type) `{Magma G} (h : Equation2686 G) : Equation2684 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2691_implies_Equation2683
  (G : Type) `{Magma G} (h : Equation2691 G) : Equation2683 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2705_implies_Equation2703
  (G : Type) `{Magma G} (h : Equation2705 G) : Equation2703 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2728_implies_Equation2720
  (G : Type) `{Magma G} (h : Equation2728 G) : Equation2720 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2729_implies_Equation2721
  (G : Type) `{Magma G} (h : Equation2729 G) : Equation2721 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2742_implies_Equation2740
  (G : Type) `{Magma G} (h : Equation2742 G) : Equation2740 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2752_implies_Equation2750
  (G : Type) `{Magma G} (h : Equation2752 G) : Equation2750 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2756_implies_Equation2754
  (G : Type) `{Magma G} (h : Equation2756 G) : Equation2754 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2760_implies_Equation2758
  (G : Type) `{Magma G} (h : Equation2760 G) : Equation2758 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2764_implies_Equation2762
  (G : Type) `{Magma G} (h : Equation2764 G) : Equation2762 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2765_implies_Equation2757
  (G : Type) `{Magma G} (h : Equation2765 G) : Equation2757 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2767_implies_Equation2759
  (G : Type) `{Magma G} (h : Equation2767 G) : Equation2759 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2782_implies_Equation2774
  (G : Type) `{Magma G} (h : Equation2782 G) : Equation2774 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2785_implies_Equation2775
  (G : Type) `{Magma G} (h : Equation2785 G) : Equation2775 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2798_implies_Equation2796
  (G : Type) `{Magma G} (h : Equation2798 G) : Equation2796 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2811_implies_Equation2809
  (G : Type) `{Magma G} (h : Equation2811 G) : Equation2809 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2815_implies_Equation2813
  (G : Type) `{Magma G} (h : Equation2815 G) : Equation2813 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2818_implies_Equation2810
  (G : Type) `{Magma G} (h : Equation2818 G) : Equation2810 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2821_implies_Equation2787
  (G : Type) `{Magma G} (h : Equation2821 G) : Equation2787 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2836_implies_Equation2791
  (G : Type) `{Magma G} (h : Equation2836 G) : Equation2791 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2839_implies_Equation2792
  (G : Type) `{Magma G} (h : Equation2839 G) : Equation2792 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2871_implies_Equation2869
  (G : Type) `{Magma G} (h : Equation2871 G) : Equation2869 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2881_implies_Equation2879
  (G : Type) `{Magma G} (h : Equation2881 G) : Equation2879 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2894_implies_Equation2886
  (G : Type) `{Magma G} (h : Equation2894 G) : Equation2886 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2918_implies_Equation2916
  (G : Type) `{Magma G} (h : Equation2918 G) : Equation2916 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2922_implies_Equation2920
  (G : Type) `{Magma G} (h : Equation2922 G) : Equation2920 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2934_implies_Equation2924
  (G : Type) `{Magma G} (h : Equation2934 G) : Equation2924 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2945_implies_Equation2943
  (G : Type) `{Magma G} (h : Equation2945 G) : Equation2943 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2955_implies_Equation2953
  (G : Type) `{Magma G} (h : Equation2955 G) : Equation2953 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2963_implies_Equation2961
  (G : Type) `{Magma G} (h : Equation2963 G) : Equation2961 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2967_implies_Equation2965
  (G : Type) `{Magma G} (h : Equation2967 G) : Equation2965 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2980_implies_Equation2978
  (G : Type) `{Magma G} (h : Equation2980 G) : Equation2978 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation2997_implies_Equation2995
  (G : Type) `{Magma G} (h : Equation2997 G) : Equation2995 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3001_implies_Equation2999
  (G : Type) `{Magma G} (h : Equation3001 G) : Equation2999 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3003_implies_Equation2995
  (G : Type) `{Magma G} (h : Equation3003 G) : Equation2995 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3005_implies_Equation2995
  (G : Type) `{Magma G} (h : Equation3005 G) : Equation2995 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3014_implies_Equation3012
  (G : Type) `{Magma G} (h : Equation3014 G) : Equation3012 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3018_implies_Equation3016
  (G : Type) `{Magma G} (h : Equation3018 G) : Equation3016 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3020_implies_Equation3012
  (G : Type) `{Magma G} (h : Equation3020 G) : Equation3012 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3022_implies_Equation3012
  (G : Type) `{Magma G} (h : Equation3022 G) : Equation3012 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3024_implies_Equation2990
  (G : Type) `{Magma G} (h : Equation3024 G) : Equation2990 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3034_implies_Equation2998
  (G : Type) `{Magma G} (h : Equation3034 G) : Equation2998 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3039_implies_Equation2994
  (G : Type) `{Magma G} (h : Equation3039 G) : Equation2994 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3064_implies_Equation3062
  (G : Type) `{Magma G} (h : Equation3064 G) : Equation3062 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3092_implies_Equation3090
  (G : Type) `{Magma G} (h : Equation3092 G) : Equation3090 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3097_implies_Equation3089
  (G : Type) `{Magma G} (h : Equation3097 G) : Equation3089 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3098_implies_Equation3090
  (G : Type) `{Magma G} (h : Equation3098 G) : Equation3090 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3099_implies_Equation3091
  (G : Type) `{Magma G} (h : Equation3099 G) : Equation3091 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3134_implies_Equation3126
  (G : Type) `{Magma G} (h : Equation3134 G) : Equation3126 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3148_implies_Equation3146
  (G : Type) `{Magma G} (h : Equation3148 G) : Equation3146 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3158_implies_Equation3156
  (G : Type) `{Magma G} (h : Equation3158 G) : Equation3156 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3166_implies_Equation3164
  (G : Type) `{Magma G} (h : Equation3166 G) : Equation3164 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3170_implies_Equation3168
  (G : Type) `{Magma G} (h : Equation3170 G) : Equation3168 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3196_implies_Equation3194
  (G : Type) `{Magma G} (h : Equation3196 G) : Equation3194 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3200_implies_Equation3198
  (G : Type) `{Magma G} (h : Equation3200 G) : Equation3198 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3206_implies_Equation3198
  (G : Type) `{Magma G} (h : Equation3206 G) : Equation3198 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3208_implies_Equation3198
  (G : Type) `{Magma G} (h : Equation3208 G) : Equation3198 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3217_implies_Equation3215
  (G : Type) `{Magma G} (h : Equation3217 G) : Equation3215 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3221_implies_Equation3219
  (G : Type) `{Magma G} (h : Equation3221 G) : Equation3219 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3223_implies_Equation3215
  (G : Type) `{Magma G} (h : Equation3223 G) : Equation3215 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3225_implies_Equation3215
  (G : Type) `{Magma G} (h : Equation3225 G) : Equation3215 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3227_implies_Equation3193
  (G : Type) `{Magma G} (h : Equation3227 G) : Equation3193 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3230_implies_Equation3194
  (G : Type) `{Magma G} (h : Equation3230 G) : Equation3194 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3240_implies_Equation3202
  (G : Type) `{Magma G} (h : Equation3240 G) : Equation3202 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3267_implies_Equation3265
  (G : Type) `{Magma G} (h : Equation3267 G) : Equation3265 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3277_implies_Equation3275
  (G : Type) `{Magma G} (h : Equation3277 G) : Equation3275 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3291_implies_Equation3289
  (G : Type) `{Magma G} (h : Equation3291 G) : Equation3289 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3299_implies_Equation3297
  (G : Type) `{Magma G} (h : Equation3299 G) : Equation3297 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3300_implies_Equation3292
  (G : Type) `{Magma G} (h : Equation3300 G) : Equation3292 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3302_implies_Equation3294
  (G : Type) `{Magma G} (h : Equation3302 G) : Equation3294 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3303_implies_Equation3293
  (G : Type) `{Magma G} (h : Equation3303 G) : Equation3293 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3324_implies_Equation3322
  (G : Type) `{Magma G} (h : Equation3324 G) : Equation3322 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3332_implies_Equation3330
  (G : Type) `{Magma G} (h : Equation3332 G) : Equation3330 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3338_implies_Equation3330
  (G : Type) `{Magma G} (h : Equation3338 G) : Equation3330 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3339_implies_Equation3331
  (G : Type) `{Magma G} (h : Equation3339 G) : Equation3331 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3351_implies_Equation3349
  (G : Type) `{Magma G} (h : Equation3351 G) : Equation3349 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3376_implies_Equation3368
  (G : Type) `{Magma G} (h : Equation3376 G) : Equation3368 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3386_implies_Equation3384
  (G : Type) `{Magma G} (h : Equation3386 G) : Equation3384 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3410_implies_Equation3402
  (G : Type) `{Magma G} (h : Equation3410 G) : Equation3402 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3436_implies_Equation3401
  (G : Type) `{Magma G} (h : Equation3436 G) : Equation3401 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3437_implies_Equation3402
  (G : Type) `{Magma G} (h : Equation3437 G) : Equation3402 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3441_implies_Equation3405
  (G : Type) `{Magma G} (h : Equation3441 G) : Equation3405 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3447_implies_Equation3402
  (G : Type) `{Magma G} (h : Equation3447 G) : Equation3402 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3470_implies_Equation3468
  (G : Type) `{Magma G} (h : Equation3470 G) : Equation3468 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3498_implies_Equation3496
  (G : Type) `{Magma G} (h : Equation3498 G) : Equation3496 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3503_implies_Equation3495
  (G : Type) `{Magma G} (h : Equation3503 G) : Equation3495 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3504_implies_Equation3496
  (G : Type) `{Magma G} (h : Equation3504 G) : Equation3496 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3505_implies_Equation3497
  (G : Type) `{Magma G} (h : Equation3505 G) : Equation3497 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3506_implies_Equation3496
  (G : Type) `{Magma G} (h : Equation3506 G) : Equation3496 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3527_implies_Equation3525
  (G : Type) `{Magma G} (h : Equation3527 G) : Equation3525 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3535_implies_Equation3533
  (G : Type) `{Magma G} (h : Equation3535 G) : Equation3533 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3541_implies_Equation3533
  (G : Type) `{Magma G} (h : Equation3541 G) : Equation3533 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3577_implies_Equation3569
  (G : Type) `{Magma G} (h : Equation3577 G) : Equation3569 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3579_implies_Equation3571
  (G : Type) `{Magma G} (h : Equation3579 G) : Equation3571 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3595_implies_Equation3587
  (G : Type) `{Magma G} (h : Equation3595 G) : Equation3587 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3612_implies_Equation3604
  (G : Type) `{Magma G} (h : Equation3612 G) : Equation3604 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3630_implies_Equation3622
  (G : Type) `{Magma G} (h : Equation3630 G) : Equation3622 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3634_implies_Equation3600
  (G : Type) `{Magma G} (h : Equation3634 G) : Equation3600 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3638_implies_Equation3603
  (G : Type) `{Magma G} (h : Equation3638 G) : Equation3603 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3645_implies_Equation3609
  (G : Type) `{Magma G} (h : Equation3645 G) : Equation3609 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3673_implies_Equation3671
  (G : Type) `{Magma G} (h : Equation3673 G) : Equation3671 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3683_implies_Equation3681
  (G : Type) `{Magma G} (h : Equation3683 G) : Equation3681 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3693_implies_Equation3691
  (G : Type) `{Magma G} (h : Equation3693 G) : Equation3691 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3701_implies_Equation3699
  (G : Type) `{Magma G} (h : Equation3701 G) : Equation3699 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3705_implies_Equation3703
  (G : Type) `{Magma G} (h : Equation3705 G) : Equation3703 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3706_implies_Equation3698
  (G : Type) `{Magma G} (h : Equation3706 G) : Equation3698 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3707_implies_Equation3699
  (G : Type) `{Magma G} (h : Equation3707 G) : Equation3699 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3709_implies_Equation3699
  (G : Type) `{Magma G} (h : Equation3709 G) : Equation3699 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3730_implies_Equation3728
  (G : Type) `{Magma G} (h : Equation3730 G) : Equation3728 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3738_implies_Equation3736
  (G : Type) `{Magma G} (h : Equation3738 G) : Equation3736 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3744_implies_Equation3736
  (G : Type) `{Magma G} (h : Equation3744 G) : Equation3736 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3782_implies_Equation3774
  (G : Type) `{Magma G} (h : Equation3782 G) : Equation3774 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3798_implies_Equation3790
  (G : Type) `{Magma G} (h : Equation3798 G) : Equation3790 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3816_implies_Equation3808
  (G : Type) `{Magma G} (h : Equation3816 G) : Equation3808 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3833_implies_Equation3825
  (G : Type) `{Magma G} (h : Equation3833 G) : Equation3825 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3836_implies_Equation3802
  (G : Type) `{Magma G} (h : Equation3836 G) : Equation3802 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3837_implies_Equation3803
  (G : Type) `{Magma G} (h : Equation3837 G) : Equation3803 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3841_implies_Equation3806
  (G : Type) `{Magma G} (h : Equation3841 G) : Equation3806 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3842_implies_Equation3807
  (G : Type) `{Magma G} (h : Equation3842 G) : Equation3807 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3843_implies_Equation3808
  (G : Type) `{Magma G} (h : Equation3843 G) : Equation3808 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3847_implies_Equation3811
  (G : Type) `{Magma G} (h : Equation3847 G) : Equation3811 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3851_implies_Equation3806
  (G : Type) `{Magma G} (h : Equation3851 G) : Equation3806 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3853_implies_Equation3808
  (G : Type) `{Magma G} (h : Equation3853 G) : Equation3808 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3876_implies_Equation3874
  (G : Type) `{Magma G} (h : Equation3876 G) : Equation3874 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3886_implies_Equation3884
  (G : Type) `{Magma G} (h : Equation3886 G) : Equation3884 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3896_implies_Equation3894
  (G : Type) `{Magma G} (h : Equation3896 G) : Equation3894 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3904_implies_Equation3902
  (G : Type) `{Magma G} (h : Equation3904 G) : Equation3902 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3909_implies_Equation3901
  (G : Type) `{Magma G} (h : Equation3909 G) : Equation3901 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3911_implies_Equation3903
  (G : Type) `{Magma G} (h : Equation3911 G) : Equation3903 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3912_implies_Equation3902
  (G : Type) `{Magma G} (h : Equation3912 G) : Equation3902 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3933_implies_Equation3931
  (G : Type) `{Magma G} (h : Equation3933 G) : Equation3931 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3947_implies_Equation3939
  (G : Type) `{Magma G} (h : Equation3947 G) : Equation3939 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation3948_implies_Equation3940
  (G : Type) `{Magma G} (h : Equation3948 G) : Equation3940 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4001_implies_Equation3993
  (G : Type) `{Magma G} (h : Equation4001 G) : Equation3993 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4018_implies_Equation4010
  (G : Type) `{Magma G} (h : Equation4018 G) : Equation4010 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4035_implies_Equation4027
  (G : Type) `{Magma G} (h : Equation4035 G) : Equation4027 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4036_implies_Equation4028
  (G : Type) `{Magma G} (h : Equation4036 G) : Equation4028 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4040_implies_Equation4006
  (G : Type) `{Magma G} (h : Equation4040 G) : Equation4006 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4079_implies_Equation4077
  (G : Type) `{Magma G} (h : Equation4079 G) : Equation4077 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4089_implies_Equation4087
  (G : Type) `{Magma G} (h : Equation4089 G) : Equation4087 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4099_implies_Equation4097
  (G : Type) `{Magma G} (h : Equation4099 G) : Equation4097 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4103_implies_Equation4101
  (G : Type) `{Magma G} (h : Equation4103 G) : Equation4101 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4107_implies_Equation4105
  (G : Type) `{Magma G} (h : Equation4107 G) : Equation4105 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4112_implies_Equation4104
  (G : Type) `{Magma G} (h : Equation4112 G) : Equation4104 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4113_implies_Equation4105
  (G : Type) `{Magma G} (h : Equation4113 G) : Equation4105 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4114_implies_Equation4106
  (G : Type) `{Magma G} (h : Equation4114 G) : Equation4106 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4115_implies_Equation4105
  (G : Type) `{Magma G} (h : Equation4115 G) : Equation4105 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4126_implies_Equation4124
  (G : Type) `{Magma G} (h : Equation4126 G) : Equation4124 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4144_implies_Equation4142
  (G : Type) `{Magma G} (h : Equation4144 G) : Equation4142 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4149_implies_Equation4141
  (G : Type) `{Magma G} (h : Equation4149 G) : Equation4141 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4150_implies_Equation4142
  (G : Type) `{Magma G} (h : Equation4150 G) : Equation4142 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4187_implies_Equation4179
  (G : Type) `{Magma G} (h : Equation4187 G) : Equation4179 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4203_implies_Equation4195
  (G : Type) `{Magma G} (h : Equation4203 G) : Equation4195 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4204_implies_Equation4196
  (G : Type) `{Magma G} (h : Equation4204 G) : Equation4196 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4221_implies_Equation4213
  (G : Type) `{Magma G} (h : Equation4221 G) : Equation4213 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4238_implies_Equation4230
  (G : Type) `{Magma G} (h : Equation4238 G) : Equation4230 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4242_implies_Equation4208
  (G : Type) `{Magma G} (h : Equation4242 G) : Equation4208 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4243_implies_Equation4209
  (G : Type) `{Magma G} (h : Equation4243 G) : Equation4209 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4257_implies_Equation4212
  (G : Type) `{Magma G} (h : Equation4257 G) : Equation4212 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4308_implies_Equation4307
  (G : Type) `{Magma G} (h : Equation4308 G) : Equation4307 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4311_implies_Equation4305
  (G : Type) `{Magma G} (h : Equation4311 G) : Equation4305 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4334_implies_Equation4330
  (G : Type) `{Magma G} (h : Equation4334 G) : Equation4330 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4335_implies_Equation4331
  (G : Type) `{Magma G} (h : Equation4335 G) : Equation4331 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4336_implies_Equation4332
  (G : Type) `{Magma G} (h : Equation4336 G) : Equation4332 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4337_implies_Equation4331
  (G : Type) `{Magma G} (h : Equation4337 G) : Equation4331 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4342_implies_Equation4340
  (G : Type) `{Magma G} (h : Equation4342 G) : Equation4340 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4349_implies_Equation4348
  (G : Type) `{Magma G} (h : Equation4349 G) : Equation4348 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4353_implies_Equation4350
  (G : Type) `{Magma G} (h : Equation4353 G) : Equation4350 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4355_implies_Equation4351
  (G : Type) `{Magma G} (h : Equation4355 G) : Equation4351 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4359_implies_Equation4358
  (G : Type) `{Magma G} (h : Equation4359 G) : Equation4358 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4371_implies_Equation4369
  (G : Type) `{Magma G} (h : Equation4371 G) : Equation4369 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4404_implies_Equation4402
  (G : Type) `{Magma G} (h : Equation4404 G) : Equation4402 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4426_implies_Equation4424
  (G : Type) `{Magma G} (h : Equation4426 G) : Equation4424 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4427_implies_Equation4419
  (G : Type) `{Magma G} (h : Equation4427 G) : Equation4419 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4428_implies_Equation4420
  (G : Type) `{Magma G} (h : Equation4428 G) : Equation4420 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4429_implies_Equation4421
  (G : Type) `{Magma G} (h : Equation4429 G) : Equation4421 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4430_implies_Equation4420
  (G : Type) `{Magma G} (h : Equation4430 G) : Equation4420 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4441_implies_Equation4439
  (G : Type) `{Magma G} (h : Equation4441 G) : Equation4439 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4459_implies_Equation4457
  (G : Type) `{Magma G} (h : Equation4459 G) : Equation4457 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4463_implies_Equation4461
  (G : Type) `{Magma G} (h : Equation4463 G) : Equation4461 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4466_implies_Equation4458
  (G : Type) `{Magma G} (h : Equation4466 G) : Equation4458 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4467_implies_Equation4457
  (G : Type) `{Magma G} (h : Equation4467 G) : Equation4457 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4478_implies_Equation4476
  (G : Type) `{Magma G} (h : Equation4478 G) : Equation4476 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4500_implies_Equation4498
  (G : Type) `{Magma G} (h : Equation4500 G) : Equation4498 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4501_implies_Equation4493
  (G : Type) `{Magma G} (h : Equation4501 G) : Equation4493 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4502_implies_Equation4494
  (G : Type) `{Magma G} (h : Equation4502 G) : Equation4494 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4503_implies_Equation4495
  (G : Type) `{Magma G} (h : Equation4503 G) : Equation4495 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4504_implies_Equation4494
  (G : Type) `{Magma G} (h : Equation4504 G) : Equation4494 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4509_implies_Equation4507
  (G : Type) `{Magma G} (h : Equation4509 G) : Equation4507 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4513_implies_Equation4511
  (G : Type) `{Magma G} (h : Equation4513 G) : Equation4511 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4518_implies_Equation4510
  (G : Type) `{Magma G} (h : Equation4518 G) : Equation4510 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4519_implies_Equation4511
  (G : Type) `{Magma G} (h : Equation4519 G) : Equation4511 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4520_implies_Equation4512
  (G : Type) `{Magma G} (h : Equation4520 G) : Equation4512 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4521_implies_Equation4511
  (G : Type) `{Magma G} (h : Equation4521 G) : Equation4511 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4552_implies_Equation4544
  (G : Type) `{Magma G} (h : Equation4552 G) : Equation4544 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4554_implies_Equation4546
  (G : Type) `{Magma G} (h : Equation4554 G) : Equation4546 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4557_implies_Equation4523
  (G : Type) `{Magma G} (h : Equation4557 G) : Equation4523 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4559_implies_Equation4525
  (G : Type) `{Magma G} (h : Equation4559 G) : Equation4525 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4560_implies_Equation4524
  (G : Type) `{Magma G} (h : Equation4560 G) : Equation4524 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4563_implies_Equation4528
  (G : Type) `{Magma G} (h : Equation4563 G) : Equation4528 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4564_implies_Equation4529
  (G : Type) `{Magma G} (h : Equation4564 G) : Equation4529 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4569_implies_Equation4533
  (G : Type) `{Magma G} (h : Equation4569 G) : Equation4533 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4570_implies_Equation4532
  (G : Type) `{Magma G} (h : Equation4570 G) : Equation4532 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4573_implies_Equation4528
  (G : Type) `{Magma G} (h : Equation4573 G) : Equation4528 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4574_implies_Equation4529
  (G : Type) `{Magma G} (h : Equation4574 G) : Equation4529 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4575_implies_Equation4528
  (G : Type) `{Magma G} (h : Equation4575 G) : Equation4528 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4596_implies_Equation4594
  (G : Type) `{Magma G} (h : Equation4596 G) : Equation4594 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4626_implies_Equation4620
  (G : Type) `{Magma G} (h : Equation4626 G) : Equation4620 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4627_implies_Equation4619
  (G : Type) `{Magma G} (h : Equation4627 G) : Equation4619 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4649_implies_Equation4645
  (G : Type) `{Magma G} (h : Equation4649 G) : Equation4645 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4650_implies_Equation4646
  (G : Type) `{Magma G} (h : Equation4650 G) : Equation4646 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4651_implies_Equation4647
  (G : Type) `{Magma G} (h : Equation4651 G) : Equation4647 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4652_implies_Equation4646
  (G : Type) `{Magma G} (h : Equation4652 G) : Equation4646 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4657_implies_Equation4655
  (G : Type) `{Magma G} (h : Equation4657 G) : Equation4655 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4670_implies_Equation4666
  (G : Type) `{Magma G} (h : Equation4670 G) : Equation4666 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4674_implies_Equation4673
  (G : Type) `{Magma G} (h : Equation4674 G) : Equation4673 G.
Proof. intros x y z. exact (h x y z y). Qed.

Theorem Equation4686_implies_Equation4684
  (G : Type) `{Magma G} (h : Equation4686 G) : Equation4684 G.
Proof. intros x y z. exact (h x y z y). Qed.

