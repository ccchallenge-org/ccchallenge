(** * SimpleRewrites/Rewrite_uw_wz_zx

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation150_implies_Equation123
  (G : Type) `{Magma G} (h : Equation150 G) : Equation123 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation254_implies_Equation227
  (G : Type) `{Magma G} (h : Equation254 G) : Equation227 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation306_implies_Equation279
  (G : Type) `{Magma G} (h : Equation306 G) : Equation279 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation462_implies_Equation435
  (G : Type) `{Magma G} (h : Equation462 G) : Equation435 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation536_implies_Equation509
  (G : Type) `{Magma G} (h : Equation536 G) : Equation509 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation592_implies_Equation486
  (G : Type) `{Magma G} (h : Equation592 G) : Equation486 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation608_implies_Equation495
  (G : Type) `{Magma G} (h : Equation608 G) : Equation495 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation665_implies_Equation638
  (G : Type) `{Magma G} (h : Equation665 G) : Equation638 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation739_implies_Equation712
  (G : Type) `{Magma G} (h : Equation739 G) : Equation712 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation811_implies_Equation698
  (G : Type) `{Magma G} (h : Equation811 G) : Equation698 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation959_implies_Equation878
  (G : Type) `{Magma G} (h : Equation959 G) : Equation878 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1003_implies_Equation896
  (G : Type) `{Magma G} (h : Equation1003 G) : Equation896 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1008_implies_Equation892
  (G : Type) `{Magma G} (h : Equation1008 G) : Equation892 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1013_implies_Equation900
  (G : Type) `{Magma G} (h : Equation1013 G) : Equation900 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1014_implies_Equation901
  (G : Type) `{Magma G} (h : Equation1014 G) : Equation901 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1015_implies_Equation902
  (G : Type) `{Magma G} (h : Equation1015 G) : Equation902 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1017_implies_Equation903
  (G : Type) `{Magma G} (h : Equation1017 G) : Equation903 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1018_implies_Equation904
  (G : Type) `{Magma G} (h : Equation1018 G) : Equation904 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1071_implies_Equation1044
  (G : Type) `{Magma G} (h : Equation1071 G) : Equation1044 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1108_implies_Equation1081
  (G : Type) `{Magma G} (h : Equation1108 G) : Equation1081 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1145_implies_Equation1118
  (G : Type) `{Magma G} (h : Equation1145 G) : Equation1118 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1201_implies_Equation1095
  (G : Type) `{Magma G} (h : Equation1201 G) : Equation1095 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1217_implies_Equation1104
  (G : Type) `{Magma G} (h : Equation1217 G) : Equation1104 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1348_implies_Equation1321
  (G : Type) `{Magma G} (h : Equation1348 G) : Equation1321 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1399_implies_Equation1284
  (G : Type) `{Magma G} (h : Equation1399 G) : Equation1284 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1404_implies_Equation1298
  (G : Type) `{Magma G} (h : Equation1404 G) : Equation1298 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1409_implies_Equation1302
  (G : Type) `{Magma G} (h : Equation1409 G) : Equation1302 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1420_implies_Equation1307
  (G : Type) `{Magma G} (h : Equation1420 G) : Equation1307 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1551_implies_Equation1524
  (G : Type) `{Magma G} (h : Equation1551 G) : Equation1524 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1585_implies_Equation1497
  (G : Type) `{Magma G} (h : Equation1585 G) : Equation1497 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1612_implies_Equation1505
  (G : Type) `{Magma G} (h : Equation1612 G) : Equation1505 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1622_implies_Equation1509
  (G : Type) `{Magma G} (h : Equation1622 G) : Equation1509 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1623_implies_Equation1510
  (G : Type) `{Magma G} (h : Equation1623 G) : Equation1510 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1624_implies_Equation1511
  (G : Type) `{Magma G} (h : Equation1624 G) : Equation1511 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1626_implies_Equation1512
  (G : Type) `{Magma G} (h : Equation1626 G) : Equation1512 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1627_implies_Equation1513
  (G : Type) `{Magma G} (h : Equation1627 G) : Equation1513 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1680_implies_Equation1653
  (G : Type) `{Magma G} (h : Equation1680 G) : Equation1653 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1771_implies_Equation1690
  (G : Type) `{Magma G} (h : Equation1771 G) : Equation1690 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1788_implies_Equation1700
  (G : Type) `{Magma G} (h : Equation1788 G) : Equation1700 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1815_implies_Equation1708
  (G : Type) `{Magma G} (h : Equation1815 G) : Equation1708 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1820_implies_Equation1704
  (G : Type) `{Magma G} (h : Equation1820 G) : Equation1704 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1825_implies_Equation1712
  (G : Type) `{Magma G} (h : Equation1825 G) : Equation1712 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1826_implies_Equation1713
  (G : Type) `{Magma G} (h : Equation1826 G) : Equation1713 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1829_implies_Equation1715
  (G : Type) `{Magma G} (h : Equation1829 G) : Equation1715 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1920_implies_Equation1893
  (G : Type) `{Magma G} (h : Equation1920 G) : Equation1893 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation1957_implies_Equation1930
  (G : Type) `{Magma G} (h : Equation1957 G) : Equation1930 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2013_implies_Equation1907
  (G : Type) `{Magma G} (h : Equation2013 G) : Equation1907 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2029_implies_Equation1916
  (G : Type) `{Magma G} (h : Equation2029 G) : Equation1916 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2123_implies_Equation2096
  (G : Type) `{Magma G} (h : Equation2123 G) : Equation2096 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2160_implies_Equation2133
  (G : Type) `{Magma G} (h : Equation2160 G) : Equation2133 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2232_implies_Equation2119
  (G : Type) `{Magma G} (h : Equation2232 G) : Equation2119 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2289_implies_Equation2262
  (G : Type) `{Magma G} (h : Equation2289 G) : Equation2262 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2326_implies_Equation2299
  (G : Type) `{Magma G} (h : Equation2326 G) : Equation2299 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2492_implies_Equation2465
  (G : Type) `{Magma G} (h : Equation2492 G) : Equation2465 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2529_implies_Equation2502
  (G : Type) `{Magma G} (h : Equation2529 G) : Equation2502 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2566_implies_Equation2539
  (G : Type) `{Magma G} (h : Equation2566 G) : Equation2539 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2695_implies_Equation2668
  (G : Type) `{Magma G} (h : Equation2695 G) : Equation2668 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2732_implies_Equation2705
  (G : Type) `{Magma G} (h : Equation2732 G) : Equation2705 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2898_implies_Equation2871
  (G : Type) `{Magma G} (h : Equation2898 G) : Equation2871 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2935_implies_Equation2908
  (G : Type) `{Magma G} (h : Equation2935 G) : Equation2908 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation2989_implies_Equation2908
  (G : Type) `{Magma G} (h : Equation2989 G) : Equation2908 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3044_implies_Equation2931
  (G : Type) `{Magma G} (h : Equation3044 G) : Equation2931 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3231_implies_Equation3125
  (G : Type) `{Magma G} (h : Equation3231 G) : Equation3125 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3236_implies_Equation3129
  (G : Type) `{Magma G} (h : Equation3236 G) : Equation3129 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3247_implies_Equation3134
  (G : Type) `{Magma G} (h : Equation3247 G) : Equation3134 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3304_implies_Equation3277
  (G : Type) `{Magma G} (h : Equation3304 G) : Equation3277 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3341_implies_Equation3314
  (G : Type) `{Magma G} (h : Equation3341 G) : Equation3314 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3451_implies_Equation3338
  (G : Type) `{Magma G} (h : Equation3451 G) : Equation3338 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3507_implies_Equation3480
  (G : Type) `{Magma G} (h : Equation3507 G) : Equation3480 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3544_implies_Equation3517
  (G : Type) `{Magma G} (h : Equation3544 G) : Equation3517 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3581_implies_Equation3554
  (G : Type) `{Magma G} (h : Equation3581 G) : Equation3554 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3710_implies_Equation3683
  (G : Type) `{Magma G} (h : Equation3710 G) : Equation3683 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3784_implies_Equation3757
  (G : Type) `{Magma G} (h : Equation3784 G) : Equation3757 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3913_implies_Equation3886
  (G : Type) `{Magma G} (h : Equation3913 G) : Equation3886 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3950_implies_Equation3923
  (G : Type) `{Magma G} (h : Equation3950 G) : Equation3923 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation3987_implies_Equation3960
  (G : Type) `{Magma G} (h : Equation3987 G) : Equation3960 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4116_implies_Equation4089
  (G : Type) `{Magma G} (h : Equation4116 G) : Equation4089 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4190_implies_Equation4163
  (G : Type) `{Magma G} (h : Equation4190 G) : Equation4163 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4313_implies_Equation4289
  (G : Type) `{Magma G} (h : Equation4313 G) : Equation4289 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4361_implies_Equation4319
  (G : Type) `{Magma G} (h : Equation4361 G) : Equation4319 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4373_implies_Equation4319
  (G : Type) `{Magma G} (h : Equation4373 G) : Equation4319 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4375_implies_Equation4333
  (G : Type) `{Magma G} (h : Equation4375 G) : Equation4333 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4377_implies_Equation4329
  (G : Type) `{Magma G} (h : Equation4377 G) : Equation4329 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4378_implies_Equation4334
  (G : Type) `{Magma G} (h : Equation4378 G) : Equation4334 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4431_implies_Equation4404
  (G : Type) `{Magma G} (h : Equation4431 G) : Equation4404 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4468_implies_Equation4441
  (G : Type) `{Magma G} (h : Equation4468 G) : Equation4441 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4505_implies_Equation4478
  (G : Type) `{Magma G} (h : Equation4505 G) : Equation4478 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4577_implies_Equation4464
  (G : Type) `{Magma G} (h : Equation4577 G) : Equation4464 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4578_implies_Equation4465
  (G : Type) `{Magma G} (h : Equation4578 G) : Equation4465 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4628_implies_Equation4604
  (G : Type) `{Magma G} (h : Equation4628 G) : Equation4604 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4676_implies_Equation4634
  (G : Type) `{Magma G} (h : Equation4676 G) : Equation4634 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4688_implies_Equation4634
  (G : Type) `{Magma G} (h : Equation4688 G) : Equation4634 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4690_implies_Equation4648
  (G : Type) `{Magma G} (h : Equation4690 G) : Equation4648 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4692_implies_Equation4644
  (G : Type) `{Magma G} (h : Equation4692 G) : Equation4644 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

Theorem Equation4693_implies_Equation4649
  (G : Type) `{Magma G} (h : Equation4693 G) : Equation4649 G.
Proof. intros x y z w. exact (h x y x z w). Qed.

