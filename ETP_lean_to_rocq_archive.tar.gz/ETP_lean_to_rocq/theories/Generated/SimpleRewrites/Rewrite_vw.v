(** * SimpleRewrites/Rewrite_vw

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation613_implies_Equation611
  (G : Type) `{Magma G} (h : Equation613 G) : Equation611 G.
Proof. intros x y z w u. exact (h x y z w u w). Qed.

Theorem Equation816_implies_Equation814
  (G : Type) `{Magma G} (h : Equation816 G) : Equation814 G.
Proof. intros x y z w u. exact (h x y z w u w). Qed.

Theorem Equation1019_implies_Equation1017
  (G : Type) `{Magma G} (h : Equation1019 G) : Equation1017 G.
Proof. intros x y z w u. exact (h x y z w u w). Qed.

Theorem Equation1222_implies_Equation1220
  (G : Type) `{Magma G} (h : Equation1222 G) : Equation1220 G.
Proof. intros x y z w u. exact (h x y z w u w). Qed.

Theorem Equation1425_implies_Equation1423
  (G : Type) `{Magma G} (h : Equation1425 G) : Equation1423 G.
Proof. intros x y z w u. exact (h x y z w u w). Qed.

Theorem Equation1628_implies_Equation1626
  (G : Type) `{Magma G} (h : Equation1628 G) : Equation1626 G.
Proof. intros x y z w u. exact (h x y z w u w). Qed.

Theorem Equation2034_implies_Equation2032
  (G : Type) `{Magma G} (h : Equation2034 G) : Equation2032 G.
Proof. intros x y z w u. exact (h x y z w u w). Qed.

Theorem Equation2237_implies_Equation2235
  (G : Type) `{Magma G} (h : Equation2237 G) : Equation2235 G.
Proof. intros x y z w u. exact (h x y z w u w). Qed.

Theorem Equation2643_implies_Equation2641
  (G : Type) `{Magma G} (h : Equation2643 G) : Equation2641 G.
Proof. intros x y z w u. exact (h x y z w u w). Qed.

Theorem Equation2846_implies_Equation2844
  (G : Type) `{Magma G} (h : Equation2846 G) : Equation2844 G.
Proof. intros x y z w u. exact (h x y z w u w). Qed.

Theorem Equation3049_implies_Equation3047
  (G : Type) `{Magma G} (h : Equation3049 G) : Equation3047 G.
Proof. intros x y z w u. exact (h x y z w u w). Qed.

Theorem Equation3252_implies_Equation3250
  (G : Type) `{Magma G} (h : Equation3252 G) : Equation3250 G.
Proof. intros x y z w u. exact (h x y z w u w). Qed.

Theorem Equation3861_implies_Equation3859
  (G : Type) `{Magma G} (h : Equation3861 G) : Equation3859 G.
Proof. intros x y z w u. exact (h x y z w u w). Qed.

