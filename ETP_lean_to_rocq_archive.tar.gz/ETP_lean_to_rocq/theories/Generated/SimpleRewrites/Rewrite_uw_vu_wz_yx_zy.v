(** * SimpleRewrites/Rewrite_uw_vu_wz_yx_zy

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation3455_implies_Equation3304
  (G : Type) `{Magma G} (h : Equation3455 G) : Equation3304 G.
Proof. intros x y z w u. exact (h x x y z w u). Qed.

Theorem Equation4694_implies_Equation4628
  (G : Type) `{Magma G} (h : Equation4694 G) : Equation4628 G.
Proof. intros x y z w u. exact (h x x y z w u). Qed.

