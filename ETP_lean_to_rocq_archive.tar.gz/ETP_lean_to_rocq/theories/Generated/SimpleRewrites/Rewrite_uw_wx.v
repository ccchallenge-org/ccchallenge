(** * SimpleRewrites/Rewrite_uw_wx

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation150_implies_Equation137
  (G : Type) `{Magma G} (h : Equation150 G) : Equation137 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation254_implies_Equation241
  (G : Type) `{Magma G} (h : Equation254 G) : Equation241 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation358_implies_Equation345
  (G : Type) `{Magma G} (h : Equation358 G) : Equation345 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation410_implies_Equation397
  (G : Type) `{Magma G} (h : Equation410 G) : Equation397 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation462_implies_Equation449
  (G : Type) `{Magma G} (h : Equation462 G) : Equation449 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation499_implies_Equation486
  (G : Type) `{Magma G} (h : Equation499 G) : Equation486 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation592_implies_Equation540
  (G : Type) `{Magma G} (h : Equation592 G) : Equation540 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation597_implies_Equation544
  (G : Type) `{Magma G} (h : Equation597 G) : Equation544 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation608_implies_Equation549
  (G : Type) `{Magma G} (h : Equation608 G) : Equation549 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation665_implies_Equation652
  (G : Type) `{Magma G} (h : Equation665 G) : Equation652 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation756_implies_Equation743
  (G : Type) `{Magma G} (h : Equation756 G) : Equation743 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation773_implies_Equation760
  (G : Type) `{Magma G} (h : Equation773 G) : Equation760 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation790_implies_Equation777
  (G : Type) `{Magma G} (h : Equation790 G) : Equation777 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation795_implies_Equation743
  (G : Type) `{Magma G} (h : Equation795 G) : Equation743 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation811_implies_Equation752
  (G : Type) `{Magma G} (h : Equation811 G) : Equation752 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation812_implies_Equation753
  (G : Type) `{Magma G} (h : Equation812 G) : Equation753 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation813_implies_Equation754
  (G : Type) `{Magma G} (h : Equation813 G) : Equation754 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation868_implies_Equation855
  (G : Type) `{Magma G} (h : Equation868 G) : Equation855 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation942_implies_Equation929
  (G : Type) `{Magma G} (h : Equation942 G) : Equation929 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation998_implies_Equation946
  (G : Type) `{Magma G} (h : Equation998 G) : Equation946 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1008_implies_Equation954
  (G : Type) `{Magma G} (h : Equation1008 G) : Equation954 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1071_implies_Equation1058
  (G : Type) `{Magma G} (h : Equation1071 G) : Equation1058 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1201_implies_Equation1149
  (G : Type) `{Magma G} (h : Equation1201 G) : Equation1149 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1217_implies_Equation1158
  (G : Type) `{Magma G} (h : Equation1217 G) : Equation1158 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1404_implies_Equation1352
  (G : Type) `{Magma G} (h : Equation1404 G) : Equation1352 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1409_implies_Equation1356
  (G : Type) `{Magma G} (h : Equation1409 G) : Equation1356 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1420_implies_Equation1361
  (G : Type) `{Magma G} (h : Equation1420 G) : Equation1361 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1477_implies_Equation1464
  (G : Type) `{Magma G} (h : Equation1477 G) : Equation1464 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1551_implies_Equation1538
  (G : Type) `{Magma G} (h : Equation1551 G) : Equation1538 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1585_implies_Equation1572
  (G : Type) `{Magma G} (h : Equation1585 G) : Equation1572 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1602_implies_Equation1589
  (G : Type) `{Magma G} (h : Equation1602 G) : Equation1589 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1680_implies_Equation1667
  (G : Type) `{Magma G} (h : Equation1680 G) : Equation1667 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1754_implies_Equation1741
  (G : Type) `{Magma G} (h : Equation1754 G) : Equation1741 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1771_implies_Equation1758
  (G : Type) `{Magma G} (h : Equation1771 G) : Equation1758 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1788_implies_Equation1775
  (G : Type) `{Magma G} (h : Equation1788 G) : Equation1775 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1805_implies_Equation1792
  (G : Type) `{Magma G} (h : Equation1805 G) : Equation1792 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1810_implies_Equation1758
  (G : Type) `{Magma G} (h : Equation1810 G) : Equation1758 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation1825_implies_Equation1758
  (G : Type) `{Magma G} (h : Equation1825 G) : Equation1758 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2013_implies_Equation1961
  (G : Type) `{Magma G} (h : Equation2013 G) : Equation1961 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2029_implies_Equation1970
  (G : Type) `{Magma G} (h : Equation2029 G) : Equation1970 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2086_implies_Equation2073
  (G : Type) `{Magma G} (h : Equation2086 G) : Equation2073 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2231_implies_Equation2164
  (G : Type) `{Magma G} (h : Equation2231 G) : Equation2164 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2289_implies_Equation2276
  (G : Type) `{Magma G} (h : Equation2289 G) : Equation2276 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2326_implies_Equation2313
  (G : Type) `{Magma G} (h : Equation2326 G) : Equation2313 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2363_implies_Equation2350
  (G : Type) `{Magma G} (h : Equation2363 G) : Equation2350 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2397_implies_Equation2384
  (G : Type) `{Magma G} (h : Equation2397 G) : Equation2384 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2414_implies_Equation2401
  (G : Type) `{Magma G} (h : Equation2414 G) : Equation2401 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2424_implies_Equation2371
  (G : Type) `{Magma G} (h : Equation2424 G) : Equation2371 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2429_implies_Equation2375
  (G : Type) `{Magma G} (h : Equation2429 G) : Equation2375 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2434_implies_Equation2367
  (G : Type) `{Magma G} (h : Equation2434 G) : Equation2367 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2436_implies_Equation2377
  (G : Type) `{Magma G} (h : Equation2436 G) : Equation2377 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2437_implies_Equation2378
  (G : Type) `{Magma G} (h : Equation2437 G) : Equation2378 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2439_implies_Equation2379
  (G : Type) `{Magma G} (h : Equation2439 G) : Equation2379 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2529_implies_Equation2516
  (G : Type) `{Magma G} (h : Equation2529 G) : Equation2516 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2622_implies_Equation2570
  (G : Type) `{Magma G} (h : Equation2622 G) : Equation2570 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2732_implies_Equation2719
  (G : Type) `{Magma G} (h : Equation2732 G) : Equation2719 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation2972_implies_Equation2959
  (G : Type) `{Magma G} (h : Equation2972 G) : Equation2959 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3044_implies_Equation2985
  (G : Type) `{Magma G} (h : Equation3044 G) : Equation2985 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3101_implies_Equation3088
  (G : Type) `{Magma G} (h : Equation3101 G) : Equation3088 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3138_implies_Equation3125
  (G : Type) `{Magma G} (h : Equation3138 G) : Equation3125 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3175_implies_Equation3162
  (G : Type) `{Magma G} (h : Equation3175 G) : Equation3162 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3226_implies_Equation3213
  (G : Type) `{Magma G} (h : Equation3226 G) : Equation3213 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3236_implies_Equation3183
  (G : Type) `{Magma G} (h : Equation3236 G) : Equation3183 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3250_implies_Equation3188
  (G : Type) `{Magma G} (h : Equation3250 G) : Equation3188 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3304_implies_Equation3291
  (G : Type) `{Magma G} (h : Equation3304 G) : Equation3291 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3378_implies_Equation3365
  (G : Type) `{Magma G} (h : Equation3378 G) : Equation3365 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3395_implies_Equation3382
  (G : Type) `{Magma G} (h : Equation3395 G) : Equation3382 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3412_implies_Equation3399
  (G : Type) `{Magma G} (h : Equation3412 G) : Equation3399 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3429_implies_Equation3416
  (G : Type) `{Magma G} (h : Equation3429 G) : Equation3416 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3439_implies_Equation3386
  (G : Type) `{Magma G} (h : Equation3439 G) : Equation3386 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3451_implies_Equation3392
  (G : Type) `{Magma G} (h : Equation3451 G) : Equation3392 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3454_implies_Equation3394
  (G : Type) `{Magma G} (h : Equation3454 G) : Equation3394 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3507_implies_Equation3494
  (G : Type) `{Magma G} (h : Equation3507 G) : Equation3494 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3544_implies_Equation3531
  (G : Type) `{Magma G} (h : Equation3544 G) : Equation3531 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3581_implies_Equation3568
  (G : Type) `{Magma G} (h : Equation3581 G) : Equation3568 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3615_implies_Equation3602
  (G : Type) `{Magma G} (h : Equation3615 G) : Equation3602 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3632_implies_Equation3619
  (G : Type) `{Magma G} (h : Equation3632 G) : Equation3619 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3654_implies_Equation3595
  (G : Type) `{Magma G} (h : Equation3654 G) : Equation3595 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3784_implies_Equation3771
  (G : Type) `{Magma G} (h : Equation3784 G) : Equation3771 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3835_implies_Equation3822
  (G : Type) `{Magma G} (h : Equation3835 G) : Equation3822 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3840_implies_Equation3788
  (G : Type) `{Magma G} (h : Equation3840 G) : Equation3788 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3845_implies_Equation3792
  (G : Type) `{Magma G} (h : Equation3845 G) : Equation3792 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3856_implies_Equation3797
  (G : Type) `{Magma G} (h : Equation3856 G) : Equation3797 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3860_implies_Equation3800
  (G : Type) `{Magma G} (h : Equation3860 G) : Equation3800 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3950_implies_Equation3937
  (G : Type) `{Magma G} (h : Equation3950 G) : Equation3937 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation3987_implies_Equation3974
  (G : Type) `{Magma G} (h : Equation3987 G) : Equation3974 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4059_implies_Equation4000
  (G : Type) `{Magma G} (h : Equation4059 G) : Equation4000 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4061_implies_Equation4002
  (G : Type) `{Magma G} (h : Equation4061 G) : Equation4002 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4062_implies_Equation4000
  (G : Type) `{Magma G} (h : Equation4062 G) : Equation4000 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4063_implies_Equation4003
  (G : Type) `{Magma G} (h : Equation4063 G) : Equation4003 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4116_implies_Equation4103
  (G : Type) `{Magma G} (h : Equation4116 G) : Equation4103 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4241_implies_Equation4228
  (G : Type) `{Magma G} (h : Equation4241 G) : Equation4228 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4256_implies_Equation4202
  (G : Type) `{Magma G} (h : Equation4256 G) : Equation4202 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4261_implies_Equation4194
  (G : Type) `{Magma G} (h : Equation4261 G) : Equation4194 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4262_implies_Equation4203
  (G : Type) `{Magma G} (h : Equation4262 G) : Equation4203 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4264_implies_Equation4205
  (G : Type) `{Magma G} (h : Equation4264 G) : Equation4205 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4265_implies_Equation4203
  (G : Type) `{Magma G} (h : Equation4265 G) : Equation4203 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4266_implies_Equation4206
  (G : Type) `{Magma G} (h : Equation4266 G) : Equation4206 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4356_implies_Equation4349
  (G : Type) `{Magma G} (h : Equation4356 G) : Equation4349 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4431_implies_Equation4418
  (G : Type) `{Magma G} (h : Equation4431 G) : Equation4418 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4468_implies_Equation4455
  (G : Type) `{Magma G} (h : Equation4468 G) : Equation4455 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4505_implies_Equation4492
  (G : Type) `{Magma G} (h : Equation4505 G) : Equation4492 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4539_implies_Equation4526
  (G : Type) `{Magma G} (h : Equation4539 G) : Equation4526 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4556_implies_Equation4543
  (G : Type) `{Magma G} (h : Equation4556 G) : Equation4543 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4561_implies_Equation4509
  (G : Type) `{Magma G} (h : Equation4561 G) : Equation4509 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4576_implies_Equation4509
  (G : Type) `{Magma G} (h : Equation4576 G) : Equation4509 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4577_implies_Equation4518
  (G : Type) `{Magma G} (h : Equation4577 G) : Equation4518 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4578_implies_Equation4519
  (G : Type) `{Magma G} (h : Equation4578 G) : Equation4519 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

Theorem Equation4581_implies_Equation4521
  (G : Type) `{Magma G} (h : Equation4581 G) : Equation4521 G.
Proof. intros x y z w. exact (h x y z x w). Qed.

