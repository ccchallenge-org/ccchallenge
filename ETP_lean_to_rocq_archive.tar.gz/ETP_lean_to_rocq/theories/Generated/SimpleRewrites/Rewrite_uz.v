(** * SimpleRewrites/Rewrite_uz

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation150_implies_Equation148
  (G : Type) `{Magma G} (h : Equation150 G) : Equation148 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation254_implies_Equation252
  (G : Type) `{Magma G} (h : Equation254 G) : Equation252 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation410_implies_Equation408
  (G : Type) `{Magma G} (h : Equation410 G) : Equation408 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation499_implies_Equation497
  (G : Type) `{Magma G} (h : Equation499 G) : Equation497 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation536_implies_Equation534
  (G : Type) `{Magma G} (h : Equation536 G) : Equation534 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation553_implies_Equation551
  (G : Type) `{Magma G} (h : Equation553 G) : Equation551 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation570_implies_Equation568
  (G : Type) `{Magma G} (h : Equation570 G) : Equation568 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation587_implies_Equation585
  (G : Type) `{Magma G} (h : Equation587 G) : Equation585 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation592_implies_Equation590
  (G : Type) `{Magma G} (h : Equation592 G) : Equation590 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation597_implies_Equation595
  (G : Type) `{Magma G} (h : Equation597 G) : Equation595 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation602_implies_Equation600
  (G : Type) `{Magma G} (h : Equation602 G) : Equation600 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation607_implies_Equation605
  (G : Type) `{Magma G} (h : Equation607 G) : Equation605 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation665_implies_Equation663
  (G : Type) `{Magma G} (h : Equation665 G) : Equation663 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation702_implies_Equation700
  (G : Type) `{Magma G} (h : Equation702 G) : Equation700 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation739_implies_Equation737
  (G : Type) `{Magma G} (h : Equation739 G) : Equation737 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation773_implies_Equation771
  (G : Type) `{Magma G} (h : Equation773 G) : Equation771 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation795_implies_Equation793
  (G : Type) `{Magma G} (h : Equation795 G) : Equation793 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation800_implies_Equation798
  (G : Type) `{Magma G} (h : Equation800 G) : Equation798 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation805_implies_Equation803
  (G : Type) `{Magma G} (h : Equation805 G) : Equation803 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation810_implies_Equation808
  (G : Type) `{Magma G} (h : Equation810 G) : Equation808 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation868_implies_Equation866
  (G : Type) `{Magma G} (h : Equation868 G) : Equation866 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation942_implies_Equation940
  (G : Type) `{Magma G} (h : Equation942 G) : Equation940 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation959_implies_Equation957
  (G : Type) `{Magma G} (h : Equation959 G) : Equation957 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation976_implies_Equation974
  (G : Type) `{Magma G} (h : Equation976 G) : Equation974 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1003_implies_Equation1001
  (G : Type) `{Magma G} (h : Equation1003 G) : Equation1001 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1014_implies_Equation1004
  (G : Type) `{Magma G} (h : Equation1014 G) : Equation1004 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1071_implies_Equation1069
  (G : Type) `{Magma G} (h : Equation1071 G) : Equation1069 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1108_implies_Equation1106
  (G : Type) `{Magma G} (h : Equation1108 G) : Equation1106 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1145_implies_Equation1143
  (G : Type) `{Magma G} (h : Equation1145 G) : Equation1143 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1162_implies_Equation1160
  (G : Type) `{Magma G} (h : Equation1162 G) : Equation1160 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1179_implies_Equation1177
  (G : Type) `{Magma G} (h : Equation1179 G) : Equation1177 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1196_implies_Equation1194
  (G : Type) `{Magma G} (h : Equation1196 G) : Equation1194 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1201_implies_Equation1199
  (G : Type) `{Magma G} (h : Equation1201 G) : Equation1199 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1206_implies_Equation1204
  (G : Type) `{Magma G} (h : Equation1206 G) : Equation1204 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1211_implies_Equation1209
  (G : Type) `{Magma G} (h : Equation1211 G) : Equation1209 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1216_implies_Equation1214
  (G : Type) `{Magma G} (h : Equation1216 G) : Equation1214 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1217_implies_Equation1207
  (G : Type) `{Magma G} (h : Equation1217 G) : Equation1207 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1219_implies_Equation1209
  (G : Type) `{Magma G} (h : Equation1219 G) : Equation1209 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1221_implies_Equation1209
  (G : Type) `{Magma G} (h : Equation1221 G) : Equation1209 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1274_implies_Equation1272
  (G : Type) `{Magma G} (h : Equation1274 G) : Equation1272 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1311_implies_Equation1309
  (G : Type) `{Magma G} (h : Equation1311 G) : Equation1309 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1348_implies_Equation1346
  (G : Type) `{Magma G} (h : Equation1348 G) : Equation1346 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1365_implies_Equation1363
  (G : Type) `{Magma G} (h : Equation1365 G) : Equation1363 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1382_implies_Equation1380
  (G : Type) `{Magma G} (h : Equation1382 G) : Equation1380 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1399_implies_Equation1397
  (G : Type) `{Magma G} (h : Equation1399 G) : Equation1397 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1404_implies_Equation1402
  (G : Type) `{Magma G} (h : Equation1404 G) : Equation1402 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1409_implies_Equation1407
  (G : Type) `{Magma G} (h : Equation1409 G) : Equation1407 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1414_implies_Equation1412
  (G : Type) `{Magma G} (h : Equation1414 G) : Equation1412 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1419_implies_Equation1417
  (G : Type) `{Magma G} (h : Equation1419 G) : Equation1417 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1420_implies_Equation1410
  (G : Type) `{Magma G} (h : Equation1420 G) : Equation1410 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1477_implies_Equation1475
  (G : Type) `{Magma G} (h : Equation1477 G) : Equation1475 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1514_implies_Equation1512
  (G : Type) `{Magma G} (h : Equation1514 G) : Equation1512 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1551_implies_Equation1549
  (G : Type) `{Magma G} (h : Equation1551 G) : Equation1549 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1568_implies_Equation1566
  (G : Type) `{Magma G} (h : Equation1568 G) : Equation1566 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1585_implies_Equation1583
  (G : Type) `{Magma G} (h : Equation1585 G) : Equation1583 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1602_implies_Equation1600
  (G : Type) `{Magma G} (h : Equation1602 G) : Equation1600 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1607_implies_Equation1605
  (G : Type) `{Magma G} (h : Equation1607 G) : Equation1605 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1612_implies_Equation1610
  (G : Type) `{Magma G} (h : Equation1612 G) : Equation1610 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1617_implies_Equation1615
  (G : Type) `{Magma G} (h : Equation1617 G) : Equation1615 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1622_implies_Equation1620
  (G : Type) `{Magma G} (h : Equation1622 G) : Equation1620 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1680_implies_Equation1678
  (G : Type) `{Magma G} (h : Equation1680 G) : Equation1678 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1717_implies_Equation1715
  (G : Type) `{Magma G} (h : Equation1717 G) : Equation1715 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1754_implies_Equation1752
  (G : Type) `{Magma G} (h : Equation1754 G) : Equation1752 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1771_implies_Equation1769
  (G : Type) `{Magma G} (h : Equation1771 G) : Equation1769 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1788_implies_Equation1786
  (G : Type) `{Magma G} (h : Equation1788 G) : Equation1786 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1805_implies_Equation1803
  (G : Type) `{Magma G} (h : Equation1805 G) : Equation1803 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1810_implies_Equation1808
  (G : Type) `{Magma G} (h : Equation1810 G) : Equation1808 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1815_implies_Equation1813
  (G : Type) `{Magma G} (h : Equation1815 G) : Equation1813 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1820_implies_Equation1818
  (G : Type) `{Magma G} (h : Equation1820 G) : Equation1818 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1825_implies_Equation1823
  (G : Type) `{Magma G} (h : Equation1825 G) : Equation1823 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1883_implies_Equation1881
  (G : Type) `{Magma G} (h : Equation1883 G) : Equation1881 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1920_implies_Equation1918
  (G : Type) `{Magma G} (h : Equation1920 G) : Equation1918 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1957_implies_Equation1955
  (G : Type) `{Magma G} (h : Equation1957 G) : Equation1955 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation1974_implies_Equation1972
  (G : Type) `{Magma G} (h : Equation1974 G) : Equation1972 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2008_implies_Equation2006
  (G : Type) `{Magma G} (h : Equation2008 G) : Equation2006 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2013_implies_Equation2011
  (G : Type) `{Magma G} (h : Equation2013 G) : Equation2011 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2018_implies_Equation2016
  (G : Type) `{Magma G} (h : Equation2018 G) : Equation2016 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2023_implies_Equation2021
  (G : Type) `{Magma G} (h : Equation2023 G) : Equation2021 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2028_implies_Equation2026
  (G : Type) `{Magma G} (h : Equation2028 G) : Equation2026 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2029_implies_Equation2019
  (G : Type) `{Magma G} (h : Equation2029 G) : Equation2019 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2030_implies_Equation2020
  (G : Type) `{Magma G} (h : Equation2030 G) : Equation2020 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2086_implies_Equation2084
  (G : Type) `{Magma G} (h : Equation2086 G) : Equation2084 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2123_implies_Equation2121
  (G : Type) `{Magma G} (h : Equation2123 G) : Equation2121 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2160_implies_Equation2158
  (G : Type) `{Magma G} (h : Equation2160 G) : Equation2158 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2194_implies_Equation2192
  (G : Type) `{Magma G} (h : Equation2194 G) : Equation2192 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2211_implies_Equation2209
  (G : Type) `{Magma G} (h : Equation2211 G) : Equation2209 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2216_implies_Equation2214
  (G : Type) `{Magma G} (h : Equation2216 G) : Equation2214 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2221_implies_Equation2219
  (G : Type) `{Magma G} (h : Equation2221 G) : Equation2219 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2226_implies_Equation2224
  (G : Type) `{Magma G} (h : Equation2226 G) : Equation2224 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2231_implies_Equation2229
  (G : Type) `{Magma G} (h : Equation2231 G) : Equation2229 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2363_implies_Equation2361
  (G : Type) `{Magma G} (h : Equation2363 G) : Equation2361 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2397_implies_Equation2395
  (G : Type) `{Magma G} (h : Equation2397 G) : Equation2395 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2414_implies_Equation2412
  (G : Type) `{Magma G} (h : Equation2414 G) : Equation2412 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2424_implies_Equation2422
  (G : Type) `{Magma G} (h : Equation2424 G) : Equation2422 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2429_implies_Equation2427
  (G : Type) `{Magma G} (h : Equation2429 G) : Equation2427 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2529_implies_Equation2527
  (G : Type) `{Magma G} (h : Equation2529 G) : Equation2527 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2566_implies_Equation2564
  (G : Type) `{Magma G} (h : Equation2566 G) : Equation2564 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2600_implies_Equation2598
  (G : Type) `{Magma G} (h : Equation2600 G) : Equation2598 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2617_implies_Equation2615
  (G : Type) `{Magma G} (h : Equation2617 G) : Equation2615 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2622_implies_Equation2620
  (G : Type) `{Magma G} (h : Equation2622 G) : Equation2620 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2627_implies_Equation2625
  (G : Type) `{Magma G} (h : Equation2627 G) : Equation2625 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2632_implies_Equation2630
  (G : Type) `{Magma G} (h : Equation2632 G) : Equation2630 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2637_implies_Equation2635
  (G : Type) `{Magma G} (h : Equation2637 G) : Equation2635 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2732_implies_Equation2730
  (G : Type) `{Magma G} (h : Equation2732 G) : Equation2730 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2769_implies_Equation2767
  (G : Type) `{Magma G} (h : Equation2769 G) : Equation2767 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2786_implies_Equation2784
  (G : Type) `{Magma G} (h : Equation2786 G) : Equation2784 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2803_implies_Equation2801
  (G : Type) `{Magma G} (h : Equation2803 G) : Equation2801 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2820_implies_Equation2818
  (G : Type) `{Magma G} (h : Equation2820 G) : Equation2818 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2825_implies_Equation2823
  (G : Type) `{Magma G} (h : Equation2825 G) : Equation2823 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2830_implies_Equation2828
  (G : Type) `{Magma G} (h : Equation2830 G) : Equation2828 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2835_implies_Equation2833
  (G : Type) `{Magma G} (h : Equation2835 G) : Equation2833 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2841_implies_Equation2831
  (G : Type) `{Magma G} (h : Equation2841 G) : Equation2831 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2842_implies_Equation2832
  (G : Type) `{Magma G} (h : Equation2842 G) : Equation2832 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2935_implies_Equation2933
  (G : Type) `{Magma G} (h : Equation2935 G) : Equation2933 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2972_implies_Equation2970
  (G : Type) `{Magma G} (h : Equation2972 G) : Equation2970 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation2989_implies_Equation2987
  (G : Type) `{Magma G} (h : Equation2989 G) : Equation2987 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3006_implies_Equation3004
  (G : Type) `{Magma G} (h : Equation3006 G) : Equation3004 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3023_implies_Equation3021
  (G : Type) `{Magma G} (h : Equation3023 G) : Equation3021 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3033_implies_Equation3031
  (G : Type) `{Magma G} (h : Equation3033 G) : Equation3031 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3038_implies_Equation3036
  (G : Type) `{Magma G} (h : Equation3038 G) : Equation3036 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3043_implies_Equation3041
  (G : Type) `{Magma G} (h : Equation3043 G) : Equation3041 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3044_implies_Equation3034
  (G : Type) `{Magma G} (h : Equation3044 G) : Equation3034 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3101_implies_Equation3099
  (G : Type) `{Magma G} (h : Equation3101 G) : Equation3099 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3175_implies_Equation3173
  (G : Type) `{Magma G} (h : Equation3175 G) : Equation3173 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3209_implies_Equation3207
  (G : Type) `{Magma G} (h : Equation3209 G) : Equation3207 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3226_implies_Equation3224
  (G : Type) `{Magma G} (h : Equation3226 G) : Equation3224 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3231_implies_Equation3229
  (G : Type) `{Magma G} (h : Equation3231 G) : Equation3229 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3236_implies_Equation3234
  (G : Type) `{Magma G} (h : Equation3236 G) : Equation3234 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3247_implies_Equation3237
  (G : Type) `{Magma G} (h : Equation3247 G) : Equation3237 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3304_implies_Equation3302
  (G : Type) `{Magma G} (h : Equation3304 G) : Equation3302 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3378_implies_Equation3376
  (G : Type) `{Magma G} (h : Equation3378 G) : Equation3376 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3395_implies_Equation3393
  (G : Type) `{Magma G} (h : Equation3395 G) : Equation3393 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3412_implies_Equation3410
  (G : Type) `{Magma G} (h : Equation3412 G) : Equation3410 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3439_implies_Equation3437
  (G : Type) `{Magma G} (h : Equation3439 G) : Equation3437 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3449_implies_Equation3447
  (G : Type) `{Magma G} (h : Equation3449 G) : Equation3447 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3507_implies_Equation3505
  (G : Type) `{Magma G} (h : Equation3507 G) : Equation3505 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3544_implies_Equation3542
  (G : Type) `{Magma G} (h : Equation3544 G) : Equation3542 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3581_implies_Equation3579
  (G : Type) `{Magma G} (h : Equation3581 G) : Equation3579 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3598_implies_Equation3596
  (G : Type) `{Magma G} (h : Equation3598 G) : Equation3596 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3710_implies_Equation3708
  (G : Type) `{Magma G} (h : Equation3710 G) : Equation3708 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3784_implies_Equation3782
  (G : Type) `{Magma G} (h : Equation3784 G) : Equation3782 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3801_implies_Equation3799
  (G : Type) `{Magma G} (h : Equation3801 G) : Equation3799 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3818_implies_Equation3816
  (G : Type) `{Magma G} (h : Equation3818 G) : Equation3816 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3835_implies_Equation3833
  (G : Type) `{Magma G} (h : Equation3835 G) : Equation3833 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3840_implies_Equation3838
  (G : Type) `{Magma G} (h : Equation3840 G) : Equation3838 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3845_implies_Equation3843
  (G : Type) `{Magma G} (h : Equation3845 G) : Equation3843 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3855_implies_Equation3853
  (G : Type) `{Magma G} (h : Equation3855 G) : Equation3853 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3856_implies_Equation3846
  (G : Type) `{Magma G} (h : Equation3856 G) : Equation3846 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3859_implies_Equation3849
  (G : Type) `{Magma G} (h : Equation3859 G) : Equation3849 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3860_implies_Equation3848
  (G : Type) `{Magma G} (h : Equation3860 G) : Equation3848 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3913_implies_Equation3911
  (G : Type) `{Magma G} (h : Equation3913 G) : Equation3911 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3950_implies_Equation3948
  (G : Type) `{Magma G} (h : Equation3950 G) : Equation3948 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation3987_implies_Equation3985
  (G : Type) `{Magma G} (h : Equation3987 G) : Equation3985 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation4059_implies_Equation4049
  (G : Type) `{Magma G} (h : Equation4059 G) : Equation4049 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation4060_implies_Equation4050
  (G : Type) `{Magma G} (h : Equation4060 G) : Equation4050 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation4207_implies_Equation4205
  (G : Type) `{Magma G} (h : Equation4207 G) : Equation4205 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation4246_implies_Equation4244
  (G : Type) `{Magma G} (h : Equation4246 G) : Equation4244 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation4251_implies_Equation4249
  (G : Type) `{Magma G} (h : Equation4251 G) : Equation4249 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation4262_implies_Equation4252
  (G : Type) `{Magma G} (h : Equation4262 G) : Equation4252 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation4263_implies_Equation4253
  (G : Type) `{Magma G} (h : Equation4263 G) : Equation4253 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation4576_implies_Equation4574
  (G : Type) `{Magma G} (h : Equation4576 G) : Equation4574 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation4579_implies_Equation4569
  (G : Type) `{Magma G} (h : Equation4579 G) : Equation4569 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

Theorem Equation4580_implies_Equation4570
  (G : Type) `{Magma G} (h : Equation4580 G) : Equation4570 G.
Proof. intros x y z w. exact (h x y z w z). Qed.

