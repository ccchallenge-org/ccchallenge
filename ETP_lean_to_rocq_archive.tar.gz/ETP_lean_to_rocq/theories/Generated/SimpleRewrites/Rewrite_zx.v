(** * SimpleRewrites/Rewrite_zx

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation12_implies_Equation10
  (G : Type) `{Magma G} (h : Equation12 G) : Equation10 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation19_implies_Equation13
  (G : Type) `{Magma G} (h : Equation19 G) : Equation13 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation41_implies_Equation39
  (G : Type) `{Magma G} (h : Equation41 G) : Equation39 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation59_implies_Equation53
  (G : Type) `{Magma G} (h : Equation59 G) : Equation53 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation68_implies_Equation62
  (G : Type) `{Magma G} (h : Equation68 G) : Equation62 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation82_implies_Equation62
  (G : Type) `{Magma G} (h : Equation82 G) : Equation62 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation87_implies_Equation66
  (G : Type) `{Magma G} (h : Equation87 G) : Equation66 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation91_implies_Equation63
  (G : Type) `{Magma G} (h : Equation91 G) : Equation63 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation194_implies_Equation166
  (G : Type) `{Magma G} (h : Equation194 G) : Equation166 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation243_implies_Equation222
  (G : Type) `{Magma G} (h : Equation243 G) : Equation222 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation276_implies_Equation270
  (G : Type) `{Magma G} (h : Equation276 G) : Equation270 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation278_implies_Equation270
  (G : Type) `{Magma G} (h : Equation278 G) : Equation270 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation294_implies_Equation273
  (G : Type) `{Magma G} (h : Equation294 G) : Equation273 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation299_implies_Equation271
  (G : Type) `{Magma G} (h : Equation299 G) : Equation271 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation311_implies_Equation309
  (G : Type) `{Magma G} (h : Equation311 G) : Equation309 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation317_implies_Equation315
  (G : Type) `{Magma G} (h : Equation317 G) : Equation315 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation319_implies_Equation313
  (G : Type) `{Magma G} (h : Equation319 G) : Equation313 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation324_implies_Equation322
  (G : Type) `{Magma G} (h : Equation324 G) : Equation322 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation328_implies_Equation322
  (G : Type) `{Magma G} (h : Equation328 G) : Equation322 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation329_implies_Equation323
  (G : Type) `{Magma G} (h : Equation329 G) : Equation323 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation330_implies_Equation322
  (G : Type) `{Magma G} (h : Equation330 G) : Equation322 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation337_implies_Equation335
  (G : Type) `{Magma G} (h : Equation337 G) : Equation335 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation338_implies_Equation332
  (G : Type) `{Magma G} (h : Equation338 G) : Equation332 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation343_implies_Equation323
  (G : Type) `{Magma G} (h : Equation343 G) : Equation323 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation346_implies_Equation325
  (G : Type) `{Magma G} (h : Equation346 G) : Equation325 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation363_implies_Equation361
  (G : Type) `{Magma G} (h : Equation363 G) : Equation361 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation369_implies_Equation367
  (G : Type) `{Magma G} (h : Equation369 G) : Equation367 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation370_implies_Equation364
  (G : Type) `{Magma G} (h : Equation370 G) : Equation364 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation371_implies_Equation365
  (G : Type) `{Magma G} (h : Equation371 G) : Equation365 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation372_implies_Equation364
  (G : Type) `{Magma G} (h : Equation372 G) : Equation364 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation376_implies_Equation374
  (G : Type) `{Magma G} (h : Equation376 G) : Equation374 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation379_implies_Equation377
  (G : Type) `{Magma G} (h : Equation379 G) : Equation377 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation381_implies_Equation375
  (G : Type) `{Magma G} (h : Equation381 G) : Equation375 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation382_implies_Equation374
  (G : Type) `{Magma G} (h : Equation382 G) : Equation374 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation395_implies_Equation375
  (G : Type) `{Magma G} (h : Equation395 G) : Equation375 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation415_implies_Equation413
  (G : Type) `{Magma G} (h : Equation415 G) : Equation413 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation418_implies_Equation416
  (G : Type) `{Magma G} (h : Equation418 G) : Equation416 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation422_implies_Equation416
  (G : Type) `{Magma G} (h : Equation422 G) : Equation416 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation432_implies_Equation426
  (G : Type) `{Magma G} (h : Equation432 G) : Equation426 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation433_implies_Equation427
  (G : Type) `{Magma G} (h : Equation433 G) : Equation427 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation442_implies_Equation436
  (G : Type) `{Magma G} (h : Equation442 G) : Equation436 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation443_implies_Equation437
  (G : Type) `{Magma G} (h : Equation443 G) : Equation437 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation444_implies_Equation436
  (G : Type) `{Magma G} (h : Equation444 G) : Equation436 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation452_implies_Equation429
  (G : Type) `{Magma G} (h : Equation452 G) : Equation429 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation455_implies_Equation427
  (G : Type) `{Magma G} (h : Equation455 G) : Equation427 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation481_implies_Equation473
  (G : Type) `{Magma G} (h : Equation481 G) : Equation473 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation483_implies_Equation463
  (G : Type) `{Magma G} (h : Equation483 G) : Equation463 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation489_implies_Equation466
  (G : Type) `{Magma G} (h : Equation489 G) : Equation466 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation492_implies_Equation464
  (G : Type) `{Magma G} (h : Equation492 G) : Equation464 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation524_implies_Equation503
  (G : Type) `{Magma G} (h : Equation524 G) : Equation503 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation528_implies_Equation500
  (G : Type) `{Magma G} (h : Equation528 G) : Equation500 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation529_implies_Equation501
  (G : Type) `{Magma G} (h : Equation529 G) : Equation501 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation542_implies_Equation467
  (G : Type) `{Magma G} (h : Equation542 G) : Equation467 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation546_implies_Equation464
  (G : Type) `{Magma G} (h : Equation546 G) : Equation464 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation562_implies_Equation473
  (G : Type) `{Magma G} (h : Equation562 G) : Equation473 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation563_implies_Equation474
  (G : Type) `{Magma G} (h : Equation563 G) : Equation474 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation575_implies_Equation466
  (G : Type) `{Magma G} (h : Equation575 G) : Equation466 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation618_implies_Equation616
  (G : Type) `{Magma G} (h : Equation618 G) : Equation616 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation624_implies_Equation622
  (G : Type) `{Magma G} (h : Equation624 G) : Equation622 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation625_implies_Equation619
  (G : Type) `{Magma G} (h : Equation625 G) : Equation619 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation626_implies_Equation620
  (G : Type) `{Magma G} (h : Equation626 G) : Equation620 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation645_implies_Equation639
  (G : Type) `{Magma G} (h : Equation645 G) : Equation639 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation646_implies_Equation640
  (G : Type) `{Magma G} (h : Equation646 G) : Equation640 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation647_implies_Equation639
  (G : Type) `{Magma G} (h : Equation647 G) : Equation639 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation653_implies_Equation632
  (G : Type) `{Magma G} (h : Equation653 G) : Equation632 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation655_implies_Equation632
  (G : Type) `{Magma G} (h : Equation655 G) : Equation632 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation657_implies_Equation629
  (G : Type) `{Magma G} (h : Equation657 G) : Equation629 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation658_implies_Equation630
  (G : Type) `{Magma G} (h : Equation658 G) : Equation630 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation684_implies_Equation676
  (G : Type) `{Magma G} (h : Equation684 G) : Equation676 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation686_implies_Equation666
  (G : Type) `{Magma G} (h : Equation686 G) : Equation666 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation690_implies_Equation669
  (G : Type) `{Magma G} (h : Equation690 G) : Equation669 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation694_implies_Equation666
  (G : Type) `{Magma G} (h : Equation694 G) : Equation666 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation695_implies_Equation667
  (G : Type) `{Magma G} (h : Equation695 G) : Equation667 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation711_implies_Equation703
  (G : Type) `{Magma G} (h : Equation711 G) : Equation703 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation727_implies_Equation706
  (G : Type) `{Magma G} (h : Equation727 G) : Equation706 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation731_implies_Equation703
  (G : Type) `{Magma G} (h : Equation731 G) : Equation703 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation732_implies_Equation704
  (G : Type) `{Magma G} (h : Equation732 G) : Equation704 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation740_implies_Equation666
  (G : Type) `{Magma G} (h : Equation740 G) : Equation666 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation746_implies_Equation669
  (G : Type) `{Magma G} (h : Equation746 G) : Equation669 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation765_implies_Equation676
  (G : Type) `{Magma G} (h : Equation765 G) : Equation676 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation766_implies_Equation677
  (G : Type) `{Magma G} (h : Equation766 G) : Equation677 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation775_implies_Equation667
  (G : Type) `{Magma G} (h : Equation775 G) : Equation667 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation778_implies_Equation669
  (G : Type) `{Magma G} (h : Equation778 G) : Equation669 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation779_implies_Equation670
  (G : Type) `{Magma G} (h : Equation779 G) : Equation670 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation821_implies_Equation819
  (G : Type) `{Magma G} (h : Equation821 G) : Equation819 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation824_implies_Equation822
  (G : Type) `{Magma G} (h : Equation824 G) : Equation822 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation827_implies_Equation825
  (G : Type) `{Magma G} (h : Equation827 G) : Equation825 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation828_implies_Equation822
  (G : Type) `{Magma G} (h : Equation828 G) : Equation822 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation834_implies_Equation832
  (G : Type) `{Magma G} (h : Equation834 G) : Equation832 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation837_implies_Equation835
  (G : Type) `{Magma G} (h : Equation837 G) : Equation835 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation838_implies_Equation832
  (G : Type) `{Magma G} (h : Equation838 G) : Equation832 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation839_implies_Equation833
  (G : Type) `{Magma G} (h : Equation839 G) : Equation833 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation840_implies_Equation832
  (G : Type) `{Magma G} (h : Equation840 G) : Equation832 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation847_implies_Equation845
  (G : Type) `{Magma G} (h : Equation847 G) : Equation845 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation848_implies_Equation842
  (G : Type) `{Magma G} (h : Equation848 G) : Equation842 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation850_implies_Equation842
  (G : Type) `{Magma G} (h : Equation850 G) : Equation842 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation852_implies_Equation832
  (G : Type) `{Magma G} (h : Equation852 G) : Equation832 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation854_implies_Equation832
  (G : Type) `{Magma G} (h : Equation854 G) : Equation832 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation856_implies_Equation835
  (G : Type) `{Magma G} (h : Equation856 G) : Equation835 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation858_implies_Equation835
  (G : Type) `{Magma G} (h : Equation858 G) : Equation835 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation860_implies_Equation832
  (G : Type) `{Magma G} (h : Equation860 G) : Equation832 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation861_implies_Equation833
  (G : Type) `{Magma G} (h : Equation861 G) : Equation833 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation875_implies_Equation869
  (G : Type) `{Magma G} (h : Equation875 G) : Equation869 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation887_implies_Equation879
  (G : Type) `{Magma G} (h : Equation887 G) : Equation879 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation889_implies_Equation869
  (G : Type) `{Magma G} (h : Equation889 G) : Equation869 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation897_implies_Equation869
  (G : Type) `{Magma G} (h : Equation897 G) : Equation869 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation898_implies_Equation870
  (G : Type) `{Magma G} (h : Equation898 G) : Equation870 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation914_implies_Equation906
  (G : Type) `{Magma G} (h : Equation914 G) : Equation906 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation934_implies_Equation906
  (G : Type) `{Magma G} (h : Equation934 G) : Equation906 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation935_implies_Equation907
  (G : Type) `{Magma G} (h : Equation935 G) : Equation907 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation949_implies_Equation872
  (G : Type) `{Magma G} (h : Equation949 G) : Equation872 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation960_implies_Equation879
  (G : Type) `{Magma G} (h : Equation960 G) : Equation879 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation962_implies_Equation879
  (G : Type) `{Magma G} (h : Equation962 G) : Equation879 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation968_implies_Equation879
  (G : Type) `{Magma G} (h : Equation968 G) : Equation879 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation978_implies_Equation870
  (G : Type) `{Magma G} (h : Equation978 G) : Equation870 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation981_implies_Equation872
  (G : Type) `{Magma G} (h : Equation981 G) : Equation872 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1027_implies_Equation1025
  (G : Type) `{Magma G} (h : Equation1027 G) : Equation1025 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1031_implies_Equation1025
  (G : Type) `{Magma G} (h : Equation1031 G) : Equation1025 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1032_implies_Equation1026
  (G : Type) `{Magma G} (h : Equation1032 G) : Equation1026 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1033_implies_Equation1025
  (G : Type) `{Magma G} (h : Equation1033 G) : Equation1025 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1041_implies_Equation1035
  (G : Type) `{Magma G} (h : Equation1041 G) : Equation1035 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1050_implies_Equation1048
  (G : Type) `{Magma G} (h : Equation1050 G) : Equation1048 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1051_implies_Equation1045
  (G : Type) `{Magma G} (h : Equation1051 G) : Equation1045 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1052_implies_Equation1046
  (G : Type) `{Magma G} (h : Equation1052 G) : Equation1046 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1053_implies_Equation1045
  (G : Type) `{Magma G} (h : Equation1053 G) : Equation1045 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1055_implies_Equation1035
  (G : Type) `{Magma G} (h : Equation1055 G) : Equation1035 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1060_implies_Equation1039
  (G : Type) `{Magma G} (h : Equation1060 G) : Equation1039 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1061_implies_Equation1038
  (G : Type) `{Magma G} (h : Equation1061 G) : Equation1038 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1063_implies_Equation1035
  (G : Type) `{Magma G} (h : Equation1063 G) : Equation1035 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1064_implies_Equation1036
  (G : Type) `{Magma G} (h : Equation1064 G) : Equation1036 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1078_implies_Equation1072
  (G : Type) `{Magma G} (h : Equation1078 G) : Equation1072 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1092_implies_Equation1072
  (G : Type) `{Magma G} (h : Equation1092 G) : Equation1072 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1100_implies_Equation1072
  (G : Type) `{Magma G} (h : Equation1100 G) : Equation1072 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1101_implies_Equation1073
  (G : Type) `{Magma G} (h : Equation1101 G) : Equation1073 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1117_implies_Equation1109
  (G : Type) `{Magma G} (h : Equation1117 G) : Equation1109 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1133_implies_Equation1112
  (G : Type) `{Magma G} (h : Equation1133 G) : Equation1112 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1137_implies_Equation1109
  (G : Type) `{Magma G} (h : Equation1137 G) : Equation1109 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1138_implies_Equation1110
  (G : Type) `{Magma G} (h : Equation1138 G) : Equation1110 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1146_implies_Equation1072
  (G : Type) `{Magma G} (h : Equation1146 G) : Equation1072 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1152_implies_Equation1075
  (G : Type) `{Magma G} (h : Equation1152 G) : Equation1075 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1154_implies_Equation1072
  (G : Type) `{Magma G} (h : Equation1154 G) : Equation1072 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1155_implies_Equation1073
  (G : Type) `{Magma G} (h : Equation1155 G) : Equation1073 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1172_implies_Equation1083
  (G : Type) `{Magma G} (h : Equation1172 G) : Equation1083 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1180_implies_Equation1072
  (G : Type) `{Magma G} (h : Equation1180 G) : Equation1072 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1184_implies_Equation1075
  (G : Type) `{Magma G} (h : Equation1184 G) : Equation1075 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1185_implies_Equation1076
  (G : Type) `{Magma G} (h : Equation1185 G) : Equation1076 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1188_implies_Equation1072
  (G : Type) `{Magma G} (h : Equation1188 G) : Equation1072 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1227_implies_Equation1225
  (G : Type) `{Magma G} (h : Equation1227 G) : Equation1225 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1230_implies_Equation1228
  (G : Type) `{Magma G} (h : Equation1230 G) : Equation1228 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1233_implies_Equation1231
  (G : Type) `{Magma G} (h : Equation1233 G) : Equation1231 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1234_implies_Equation1228
  (G : Type) `{Magma G} (h : Equation1234 G) : Equation1228 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1235_implies_Equation1229
  (G : Type) `{Magma G} (h : Equation1235 G) : Equation1229 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1236_implies_Equation1228
  (G : Type) `{Magma G} (h : Equation1236 G) : Equation1228 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1243_implies_Equation1241
  (G : Type) `{Magma G} (h : Equation1243 G) : Equation1241 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1245_implies_Equation1239
  (G : Type) `{Magma G} (h : Equation1245 G) : Equation1239 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1250_implies_Equation1248
  (G : Type) `{Magma G} (h : Equation1250 G) : Equation1248 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1253_implies_Equation1251
  (G : Type) `{Magma G} (h : Equation1253 G) : Equation1251 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1254_implies_Equation1248
  (G : Type) `{Magma G} (h : Equation1254 G) : Equation1248 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1255_implies_Equation1249
  (G : Type) `{Magma G} (h : Equation1255 G) : Equation1249 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1256_implies_Equation1248
  (G : Type) `{Magma G} (h : Equation1256 G) : Equation1248 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1258_implies_Equation1238
  (G : Type) `{Magma G} (h : Equation1258 G) : Equation1238 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1259_implies_Equation1239
  (G : Type) `{Magma G} (h : Equation1259 G) : Equation1239 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1262_implies_Equation1241
  (G : Type) `{Magma G} (h : Equation1262 G) : Equation1241 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1263_implies_Equation1242
  (G : Type) `{Magma G} (h : Equation1263 G) : Equation1242 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1264_implies_Equation1241
  (G : Type) `{Magma G} (h : Equation1264 G) : Equation1241 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1267_implies_Equation1239
  (G : Type) `{Magma G} (h : Equation1267 G) : Equation1239 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1281_implies_Equation1275
  (G : Type) `{Magma G} (h : Equation1281 G) : Equation1275 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1295_implies_Equation1275
  (G : Type) `{Magma G} (h : Equation1295 G) : Equation1275 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1301_implies_Equation1278
  (G : Type) `{Magma G} (h : Equation1301 G) : Equation1278 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1303_implies_Equation1275
  (G : Type) `{Magma G} (h : Equation1303 G) : Equation1275 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1328_implies_Equation1322
  (G : Type) `{Magma G} (h : Equation1328 G) : Equation1322 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1340_implies_Equation1312
  (G : Type) `{Magma G} (h : Equation1340 G) : Equation1312 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1341_implies_Equation1313
  (G : Type) `{Magma G} (h : Equation1341 G) : Equation1313 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1349_implies_Equation1275
  (G : Type) `{Magma G} (h : Equation1349 G) : Equation1275 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1353_implies_Equation1278
  (G : Type) `{Magma G} (h : Equation1353 G) : Equation1278 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1354_implies_Equation1279
  (G : Type) `{Magma G} (h : Equation1354 G) : Equation1279 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1357_implies_Equation1275
  (G : Type) `{Magma G} (h : Equation1357 G) : Equation1275 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1358_implies_Equation1276
  (G : Type) `{Magma G} (h : Equation1358 G) : Equation1276 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1368_implies_Equation1285
  (G : Type) `{Magma G} (h : Equation1368 G) : Equation1285 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1370_implies_Equation1288
  (G : Type) `{Magma G} (h : Equation1370 G) : Equation1288 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1374_implies_Equation1285
  (G : Type) `{Magma G} (h : Equation1374 G) : Equation1285 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1375_implies_Equation1286
  (G : Type) `{Magma G} (h : Equation1375 G) : Equation1286 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1383_implies_Equation1275
  (G : Type) `{Magma G} (h : Equation1383 G) : Equation1275 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1387_implies_Equation1278
  (G : Type) `{Magma G} (h : Equation1387 G) : Equation1278 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1391_implies_Equation1275
  (G : Type) `{Magma G} (h : Equation1391 G) : Equation1275 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1430_implies_Equation1428
  (G : Type) `{Magma G} (h : Equation1430 G) : Equation1428 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1437_implies_Equation1431
  (G : Type) `{Magma G} (h : Equation1437 G) : Equation1431 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1443_implies_Equation1441
  (G : Type) `{Magma G} (h : Equation1443 G) : Equation1441 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1446_implies_Equation1444
  (G : Type) `{Magma G} (h : Equation1446 G) : Equation1444 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1447_implies_Equation1441
  (G : Type) `{Magma G} (h : Equation1447 G) : Equation1441 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1453_implies_Equation1451
  (G : Type) `{Magma G} (h : Equation1453 G) : Equation1451 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1457_implies_Equation1451
  (G : Type) `{Magma G} (h : Equation1457 G) : Equation1451 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1459_implies_Equation1451
  (G : Type) `{Magma G} (h : Equation1459 G) : Equation1451 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1467_implies_Equation1444
  (G : Type) `{Magma G} (h : Equation1467 G) : Equation1444 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1469_implies_Equation1441
  (G : Type) `{Magma G} (h : Equation1469 G) : Equation1441 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1470_implies_Equation1442
  (G : Type) `{Magma G} (h : Equation1470 G) : Equation1442 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1480_implies_Equation1478
  (G : Type) `{Magma G} (h : Equation1480 G) : Equation1478 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1483_implies_Equation1481
  (G : Type) `{Magma G} (h : Equation1483 G) : Equation1481 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1484_implies_Equation1478
  (G : Type) `{Magma G} (h : Equation1484 G) : Equation1478 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1486_implies_Equation1478
  (G : Type) `{Magma G} (h : Equation1486 G) : Equation1478 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1493_implies_Equation1491
  (G : Type) `{Magma G} (h : Equation1493 G) : Equation1491 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1496_implies_Equation1488
  (G : Type) `{Magma G} (h : Equation1496 G) : Equation1488 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1504_implies_Equation1481
  (G : Type) `{Magma G} (h : Equation1504 G) : Equation1481 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1523_implies_Equation1515
  (G : Type) `{Magma G} (h : Equation1523 G) : Equation1515 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1543_implies_Equation1515
  (G : Type) `{Magma G} (h : Equation1543 G) : Equation1515 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1544_implies_Equation1516
  (G : Type) `{Magma G} (h : Equation1544 G) : Equation1516 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1561_implies_Equation1479
  (G : Type) `{Magma G} (h : Equation1561 G) : Equation1479 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1577_implies_Equation1488
  (G : Type) `{Magma G} (h : Equation1577 G) : Equation1488 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1578_implies_Equation1489
  (G : Type) `{Magma G} (h : Equation1578 G) : Equation1489 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1586_implies_Equation1478
  (G : Type) `{Magma G} (h : Equation1586 G) : Equation1478 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1587_implies_Equation1479
  (G : Type) `{Magma G} (h : Equation1587 G) : Equation1479 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1590_implies_Equation1481
  (G : Type) `{Magma G} (h : Equation1590 G) : Equation1481 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1594_implies_Equation1478
  (G : Type) `{Magma G} (h : Equation1594 G) : Equation1478 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1633_implies_Equation1631
  (G : Type) `{Magma G} (h : Equation1633 G) : Equation1631 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1636_implies_Equation1634
  (G : Type) `{Magma G} (h : Equation1636 G) : Equation1634 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1640_implies_Equation1634
  (G : Type) `{Magma G} (h : Equation1640 G) : Equation1634 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1641_implies_Equation1635
  (G : Type) `{Magma G} (h : Equation1641 G) : Equation1635 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1650_implies_Equation1644
  (G : Type) `{Magma G} (h : Equation1650 G) : Equation1644 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1662_implies_Equation1654
  (G : Type) `{Magma G} (h : Equation1662 G) : Equation1654 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1664_implies_Equation1644
  (G : Type) `{Magma G} (h : Equation1664 G) : Equation1644 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1668_implies_Equation1647
  (G : Type) `{Magma G} (h : Equation1668 G) : Equation1647 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1670_implies_Equation1647
  (G : Type) `{Magma G} (h : Equation1670 G) : Equation1647 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1672_implies_Equation1644
  (G : Type) `{Magma G} (h : Equation1672 G) : Equation1644 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1673_implies_Equation1645
  (G : Type) `{Magma G} (h : Equation1673 G) : Equation1645 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1687_implies_Equation1681
  (G : Type) `{Magma G} (h : Equation1687 G) : Equation1681 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1701_implies_Equation1681
  (G : Type) `{Magma G} (h : Equation1701 G) : Equation1681 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1705_implies_Equation1684
  (G : Type) `{Magma G} (h : Equation1705 G) : Equation1684 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1707_implies_Equation1684
  (G : Type) `{Magma G} (h : Equation1707 G) : Equation1684 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1710_implies_Equation1682
  (G : Type) `{Magma G} (h : Equation1710 G) : Equation1682 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1724_implies_Equation1718
  (G : Type) `{Magma G} (h : Equation1724 G) : Equation1718 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1738_implies_Equation1718
  (G : Type) `{Magma G} (h : Equation1738 G) : Equation1718 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1746_implies_Equation1718
  (G : Type) `{Magma G} (h : Equation1746 G) : Equation1718 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1747_implies_Equation1719
  (G : Type) `{Magma G} (h : Equation1747 G) : Equation1719 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1764_implies_Equation1682
  (G : Type) `{Magma G} (h : Equation1764 G) : Equation1682 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1780_implies_Equation1691
  (G : Type) `{Magma G} (h : Equation1780 G) : Equation1691 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1790_implies_Equation1682
  (G : Type) `{Magma G} (h : Equation1790 G) : Equation1682 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1793_implies_Equation1684
  (G : Type) `{Magma G} (h : Equation1793 G) : Equation1684 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1839_implies_Equation1837
  (G : Type) `{Magma G} (h : Equation1839 G) : Equation1837 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1843_implies_Equation1837
  (G : Type) `{Magma G} (h : Equation1843 G) : Equation1837 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1845_implies_Equation1837
  (G : Type) `{Magma G} (h : Equation1845 G) : Equation1837 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1849_implies_Equation1847
  (G : Type) `{Magma G} (h : Equation1849 G) : Equation1847 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1853_implies_Equation1847
  (G : Type) `{Magma G} (h : Equation1853 G) : Equation1847 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1855_implies_Equation1847
  (G : Type) `{Magma G} (h : Equation1855 G) : Equation1847 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1863_implies_Equation1857
  (G : Type) `{Magma G} (h : Equation1863 G) : Equation1857 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1865_implies_Equation1857
  (G : Type) `{Magma G} (h : Equation1865 G) : Equation1857 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1867_implies_Equation1847
  (G : Type) `{Magma G} (h : Equation1867 G) : Equation1847 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1868_implies_Equation1848
  (G : Type) `{Magma G} (h : Equation1868 G) : Equation1848 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1871_implies_Equation1850
  (G : Type) `{Magma G} (h : Equation1871 G) : Equation1850 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1872_implies_Equation1851
  (G : Type) `{Magma G} (h : Equation1872 G) : Equation1851 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1873_implies_Equation1850
  (G : Type) `{Magma G} (h : Equation1873 G) : Equation1850 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1875_implies_Equation1847
  (G : Type) `{Magma G} (h : Equation1875 G) : Equation1847 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1876_implies_Equation1848
  (G : Type) `{Magma G} (h : Equation1876 G) : Equation1848 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1902_implies_Equation1894
  (G : Type) `{Magma G} (h : Equation1902 G) : Equation1894 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1913_implies_Equation1885
  (G : Type) `{Magma G} (h : Equation1913 G) : Equation1885 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1949_implies_Equation1921
  (G : Type) `{Magma G} (h : Equation1949 G) : Equation1921 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1958_implies_Equation1884
  (G : Type) `{Magma G} (h : Equation1958 G) : Equation1884 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1967_implies_Equation1885
  (G : Type) `{Magma G} (h : Equation1967 G) : Equation1885 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1975_implies_Equation1894
  (G : Type) `{Magma G} (h : Equation1975 G) : Equation1894 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1977_implies_Equation1894
  (G : Type) `{Magma G} (h : Equation1977 G) : Equation1894 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1979_implies_Equation1897
  (G : Type) `{Magma G} (h : Equation1979 G) : Equation1897 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1983_implies_Equation1894
  (G : Type) `{Magma G} (h : Equation1983 G) : Equation1894 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1984_implies_Equation1895
  (G : Type) `{Magma G} (h : Equation1984 G) : Equation1895 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1985_implies_Equation1894
  (G : Type) `{Magma G} (h : Equation1985 G) : Equation1894 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1993_implies_Equation1885
  (G : Type) `{Magma G} (h : Equation1993 G) : Equation1885 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1996_implies_Equation1887
  (G : Type) `{Magma G} (h : Equation1996 G) : Equation1887 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation1997_implies_Equation1888
  (G : Type) `{Magma G} (h : Equation1997 G) : Equation1888 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2000_implies_Equation1884
  (G : Type) `{Magma G} (h : Equation2000 G) : Equation1884 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2045_implies_Equation2043
  (G : Type) `{Magma G} (h : Equation2045 G) : Equation2043 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2046_implies_Equation2040
  (G : Type) `{Magma G} (h : Equation2046 G) : Equation2040 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2052_implies_Equation2050
  (G : Type) `{Magma G} (h : Equation2052 G) : Equation2050 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2055_implies_Equation2053
  (G : Type) `{Magma G} (h : Equation2055 G) : Equation2053 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2056_implies_Equation2050
  (G : Type) `{Magma G} (h : Equation2056 G) : Equation2050 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2065_implies_Equation2063
  (G : Type) `{Magma G} (h : Equation2065 G) : Equation2063 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2066_implies_Equation2060
  (G : Type) `{Magma G} (h : Equation2066 G) : Equation2060 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2070_implies_Equation2050
  (G : Type) `{Magma G} (h : Equation2070 G) : Equation2050 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2076_implies_Equation2053
  (G : Type) `{Magma G} (h : Equation2076 G) : Equation2053 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2078_implies_Equation2050
  (G : Type) `{Magma G} (h : Equation2078 G) : Equation2050 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2079_implies_Equation2051
  (G : Type) `{Magma G} (h : Equation2079 G) : Equation2051 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2089_implies_Equation2087
  (G : Type) `{Magma G} (h : Equation2089 G) : Equation2087 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2093_implies_Equation2087
  (G : Type) `{Magma G} (h : Equation2093 G) : Equation2087 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2115_implies_Equation2087
  (G : Type) `{Magma G} (h : Equation2115 G) : Equation2087 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2116_implies_Equation2088
  (G : Type) `{Magma G} (h : Equation2116 G) : Equation2088 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2126_implies_Equation2124
  (G : Type) `{Magma G} (h : Equation2126 G) : Equation2124 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2132_implies_Equation2124
  (G : Type) `{Magma G} (h : Equation2132 G) : Equation2124 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2152_implies_Equation2124
  (G : Type) `{Magma G} (h : Equation2152 G) : Equation2124 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2161_implies_Equation2087
  (G : Type) `{Magma G} (h : Equation2161 G) : Equation2087 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2162_implies_Equation2088
  (G : Type) `{Magma G} (h : Equation2162 G) : Equation2088 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2163_implies_Equation2087
  (G : Type) `{Magma G} (h : Equation2163 G) : Equation2087 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2167_implies_Equation2090
  (G : Type) `{Magma G} (h : Equation2167 G) : Equation2090 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2180_implies_Equation2097
  (G : Type) `{Magma G} (h : Equation2180 G) : Equation2097 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2186_implies_Equation2097
  (G : Type) `{Magma G} (h : Equation2186 G) : Equation2097 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2187_implies_Equation2098
  (G : Type) `{Magma G} (h : Equation2187 G) : Equation2098 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2196_implies_Equation2088
  (G : Type) `{Magma G} (h : Equation2196 G) : Equation2088 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2199_implies_Equation2090
  (G : Type) `{Magma G} (h : Equation2199 G) : Equation2090 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2200_implies_Equation2091
  (G : Type) `{Magma G} (h : Equation2200 G) : Equation2091 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2203_implies_Equation2087
  (G : Type) `{Magma G} (h : Equation2203 G) : Equation2087 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2249_implies_Equation2243
  (G : Type) `{Magma G} (h : Equation2249 G) : Equation2243 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2259_implies_Equation2253
  (G : Type) `{Magma G} (h : Equation2259 G) : Equation2253 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2260_implies_Equation2254
  (G : Type) `{Magma G} (h : Equation2260 G) : Equation2254 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2270_implies_Equation2264
  (G : Type) `{Magma G} (h : Equation2270 G) : Equation2264 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2271_implies_Equation2263
  (G : Type) `{Magma G} (h : Equation2271 G) : Equation2263 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2273_implies_Equation2253
  (G : Type) `{Magma G} (h : Equation2273 G) : Equation2253 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2277_implies_Equation2256
  (G : Type) `{Magma G} (h : Equation2277 G) : Equation2256 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2279_implies_Equation2256
  (G : Type) `{Magma G} (h : Equation2279 G) : Equation2256 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2281_implies_Equation2253
  (G : Type) `{Magma G} (h : Equation2281 G) : Equation2253 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2282_implies_Equation2254
  (G : Type) `{Magma G} (h : Equation2282 G) : Equation2254 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2296_implies_Equation2290
  (G : Type) `{Magma G} (h : Equation2296 G) : Equation2290 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2310_implies_Equation2290
  (G : Type) `{Magma G} (h : Equation2310 G) : Equation2290 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2314_implies_Equation2293
  (G : Type) `{Magma G} (h : Equation2314 G) : Equation2293 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2316_implies_Equation2293
  (G : Type) `{Magma G} (h : Equation2316 G) : Equation2293 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2318_implies_Equation2290
  (G : Type) `{Magma G} (h : Equation2318 G) : Equation2290 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2335_implies_Equation2327
  (G : Type) `{Magma G} (h : Equation2335 G) : Equation2327 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2351_implies_Equation2330
  (G : Type) `{Magma G} (h : Equation2351 G) : Equation2330 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2355_implies_Equation2327
  (G : Type) `{Magma G} (h : Equation2355 G) : Equation2327 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2364_implies_Equation2290
  (G : Type) `{Magma G} (h : Equation2364 G) : Equation2290 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2368_implies_Equation2293
  (G : Type) `{Magma G} (h : Equation2368 G) : Equation2293 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2369_implies_Equation2294
  (G : Type) `{Magma G} (h : Equation2369 G) : Equation2294 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2370_implies_Equation2293
  (G : Type) `{Magma G} (h : Equation2370 G) : Equation2293 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2372_implies_Equation2290
  (G : Type) `{Magma G} (h : Equation2372 G) : Equation2290 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2373_implies_Equation2291
  (G : Type) `{Magma G} (h : Equation2373 G) : Equation2291 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2381_implies_Equation2300
  (G : Type) `{Magma G} (h : Equation2381 G) : Equation2300 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2383_implies_Equation2300
  (G : Type) `{Magma G} (h : Equation2383 G) : Equation2300 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2385_implies_Equation2303
  (G : Type) `{Magma G} (h : Equation2385 G) : Equation2303 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2389_implies_Equation2300
  (G : Type) `{Magma G} (h : Equation2389 G) : Equation2300 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2390_implies_Equation2301
  (G : Type) `{Magma G} (h : Equation2390 G) : Equation2301 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2402_implies_Equation2293
  (G : Type) `{Magma G} (h : Equation2402 G) : Equation2293 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2406_implies_Equation2290
  (G : Type) `{Magma G} (h : Equation2406 G) : Equation2290 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2452_implies_Equation2446
  (G : Type) `{Magma G} (h : Equation2452 G) : Equation2446 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2462_implies_Equation2456
  (G : Type) `{Magma G} (h : Equation2462 G) : Equation2456 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2472_implies_Equation2466
  (G : Type) `{Magma G} (h : Equation2472 G) : Equation2466 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2473_implies_Equation2467
  (G : Type) `{Magma G} (h : Equation2473 G) : Equation2467 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2474_implies_Equation2466
  (G : Type) `{Magma G} (h : Equation2474 G) : Equation2466 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2476_implies_Equation2456
  (G : Type) `{Magma G} (h : Equation2476 G) : Equation2456 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2481_implies_Equation2460
  (G : Type) `{Magma G} (h : Equation2481 G) : Equation2460 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2482_implies_Equation2459
  (G : Type) `{Magma G} (h : Equation2482 G) : Equation2459 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2484_implies_Equation2456
  (G : Type) `{Magma G} (h : Equation2484 G) : Equation2456 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2485_implies_Equation2457
  (G : Type) `{Magma G} (h : Equation2485 G) : Equation2457 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2511_implies_Equation2503
  (G : Type) `{Magma G} (h : Equation2511 G) : Equation2503 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2538_implies_Equation2530
  (G : Type) `{Magma G} (h : Equation2538 G) : Equation2530 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2554_implies_Equation2533
  (G : Type) `{Magma G} (h : Equation2554 G) : Equation2533 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2558_implies_Equation2530
  (G : Type) `{Magma G} (h : Equation2558 G) : Equation2530 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2559_implies_Equation2531
  (G : Type) `{Magma G} (h : Equation2559 G) : Equation2531 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2567_implies_Equation2493
  (G : Type) `{Magma G} (h : Equation2567 G) : Equation2493 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2573_implies_Equation2496
  (G : Type) `{Magma G} (h : Equation2573 G) : Equation2496 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2576_implies_Equation2494
  (G : Type) `{Magma G} (h : Equation2576 G) : Equation2494 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2584_implies_Equation2503
  (G : Type) `{Magma G} (h : Equation2584 G) : Equation2503 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2586_implies_Equation2503
  (G : Type) `{Magma G} (h : Equation2586 G) : Equation2503 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2588_implies_Equation2506
  (G : Type) `{Magma G} (h : Equation2588 G) : Equation2506 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2592_implies_Equation2503
  (G : Type) `{Magma G} (h : Equation2592 G) : Equation2503 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2593_implies_Equation2504
  (G : Type) `{Magma G} (h : Equation2593 G) : Equation2504 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2605_implies_Equation2496
  (G : Type) `{Magma G} (h : Equation2605 G) : Equation2496 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2606_implies_Equation2497
  (G : Type) `{Magma G} (h : Equation2606 G) : Equation2497 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2609_implies_Equation2493
  (G : Type) `{Magma G} (h : Equation2609 G) : Equation2493 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2655_implies_Equation2649
  (G : Type) `{Magma G} (h : Equation2655 G) : Equation2649 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2656_implies_Equation2650
  (G : Type) `{Magma G} (h : Equation2656 G) : Equation2650 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2665_implies_Equation2659
  (G : Type) `{Magma G} (h : Equation2665 G) : Equation2659 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2675_implies_Equation2669
  (G : Type) `{Magma G} (h : Equation2675 G) : Equation2669 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2676_implies_Equation2670
  (G : Type) `{Magma G} (h : Equation2676 G) : Equation2670 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2677_implies_Equation2669
  (G : Type) `{Magma G} (h : Equation2677 G) : Equation2669 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2679_implies_Equation2659
  (G : Type) `{Magma G} (h : Equation2679 G) : Equation2659 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2683_implies_Equation2662
  (G : Type) `{Magma G} (h : Equation2683 G) : Equation2662 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2685_implies_Equation2662
  (G : Type) `{Magma G} (h : Equation2685 G) : Equation2662 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2687_implies_Equation2659
  (G : Type) `{Magma G} (h : Equation2687 G) : Equation2659 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2688_implies_Equation2660
  (G : Type) `{Magma G} (h : Equation2688 G) : Equation2660 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2702_implies_Equation2696
  (G : Type) `{Magma G} (h : Equation2702 G) : Equation2696 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2712_implies_Equation2706
  (G : Type) `{Magma G} (h : Equation2712 G) : Equation2706 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2724_implies_Equation2696
  (G : Type) `{Magma G} (h : Equation2724 G) : Equation2696 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2739_implies_Equation2733
  (G : Type) `{Magma G} (h : Equation2739 G) : Equation2733 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2761_implies_Equation2733
  (G : Type) `{Magma G} (h : Equation2761 G) : Equation2733 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2770_implies_Equation2696
  (G : Type) `{Magma G} (h : Equation2770 G) : Equation2696 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2774_implies_Equation2699
  (G : Type) `{Magma G} (h : Equation2774 G) : Equation2699 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2776_implies_Equation2699
  (G : Type) `{Magma G} (h : Equation2776 G) : Equation2699 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2778_implies_Equation2696
  (G : Type) `{Magma G} (h : Equation2778 G) : Equation2696 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2795_implies_Equation2706
  (G : Type) `{Magma G} (h : Equation2795 G) : Equation2706 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2796_implies_Equation2707
  (G : Type) `{Magma G} (h : Equation2796 G) : Equation2707 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2805_implies_Equation2697
  (G : Type) `{Magma G} (h : Equation2805 G) : Equation2697 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2808_implies_Equation2699
  (G : Type) `{Magma G} (h : Equation2808 G) : Equation2699 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2809_implies_Equation2700
  (G : Type) `{Magma G} (h : Equation2809 G) : Equation2700 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2812_implies_Equation2696
  (G : Type) `{Magma G} (h : Equation2812 G) : Equation2696 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2860_implies_Equation2852
  (G : Type) `{Magma G} (h : Equation2860 G) : Equation2852 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2868_implies_Equation2862
  (G : Type) `{Magma G} (h : Equation2868 G) : Equation2862 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2878_implies_Equation2872
  (G : Type) `{Magma G} (h : Equation2878 G) : Equation2872 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2880_implies_Equation2872
  (G : Type) `{Magma G} (h : Equation2880 G) : Equation2872 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2882_implies_Equation2862
  (G : Type) `{Magma G} (h : Equation2882 G) : Equation2862 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2883_implies_Equation2863
  (G : Type) `{Magma G} (h : Equation2883 G) : Equation2863 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2886_implies_Equation2865
  (G : Type) `{Magma G} (h : Equation2886 G) : Equation2865 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2887_implies_Equation2866
  (G : Type) `{Magma G} (h : Equation2887 G) : Equation2866 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2888_implies_Equation2865
  (G : Type) `{Magma G} (h : Equation2888 G) : Equation2865 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2890_implies_Equation2862
  (G : Type) `{Magma G} (h : Equation2890 G) : Equation2862 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2891_implies_Equation2863
  (G : Type) `{Magma G} (h : Equation2891 G) : Equation2863 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2919_implies_Equation2899
  (G : Type) `{Magma G} (h : Equation2919 G) : Equation2899 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2958_implies_Equation2936
  (G : Type) `{Magma G} (h : Equation2958 G) : Equation2936 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2964_implies_Equation2936
  (G : Type) `{Magma G} (h : Equation2964 G) : Equation2936 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2965_implies_Equation2937
  (G : Type) `{Magma G} (h : Equation2965 G) : Equation2937 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2979_implies_Equation2902
  (G : Type) `{Magma G} (h : Equation2979 G) : Equation2902 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2982_implies_Equation2900
  (G : Type) `{Magma G} (h : Equation2982 G) : Equation2900 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2990_implies_Equation2909
  (G : Type) `{Magma G} (h : Equation2990 G) : Equation2909 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2992_implies_Equation2909
  (G : Type) `{Magma G} (h : Equation2992 G) : Equation2909 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2994_implies_Equation2912
  (G : Type) `{Magma G} (h : Equation2994 G) : Equation2912 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2998_implies_Equation2909
  (G : Type) `{Magma G} (h : Equation2998 G) : Equation2909 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation2999_implies_Equation2910
  (G : Type) `{Magma G} (h : Equation2999 G) : Equation2910 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3007_implies_Equation2899
  (G : Type) `{Magma G} (h : Equation3007 G) : Equation2899 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3008_implies_Equation2900
  (G : Type) `{Magma G} (h : Equation3008 G) : Equation2900 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3011_implies_Equation2902
  (G : Type) `{Magma G} (h : Equation3011 G) : Equation2902 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3012_implies_Equation2903
  (G : Type) `{Magma G} (h : Equation3012 G) : Equation2903 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3071_implies_Equation3065
  (G : Type) `{Magma G} (h : Equation3071 G) : Equation3065 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3083_implies_Equation3075
  (G : Type) `{Magma G} (h : Equation3083 G) : Equation3075 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3085_implies_Equation3065
  (G : Type) `{Magma G} (h : Equation3085 G) : Equation3065 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3090_implies_Equation3069
  (G : Type) `{Magma G} (h : Equation3090 G) : Equation3069 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3091_implies_Equation3068
  (G : Type) `{Magma G} (h : Equation3091 G) : Equation3068 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3094_implies_Equation3066
  (G : Type) `{Magma G} (h : Equation3094 G) : Equation3066 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3122_implies_Equation3102
  (G : Type) `{Magma G} (h : Equation3122 G) : Equation3102 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3128_implies_Equation3105
  (G : Type) `{Magma G} (h : Equation3128 G) : Equation3105 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3131_implies_Equation3103
  (G : Type) `{Magma G} (h : Equation3131 G) : Equation3103 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3161_implies_Equation3139
  (G : Type) `{Magma G} (h : Equation3161 G) : Equation3139 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3167_implies_Equation3139
  (G : Type) `{Magma G} (h : Equation3167 G) : Equation3139 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3168_implies_Equation3140
  (G : Type) `{Magma G} (h : Equation3168 G) : Equation3140 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3176_implies_Equation3102
  (G : Type) `{Magma G} (h : Equation3176 G) : Equation3102 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3180_implies_Equation3105
  (G : Type) `{Magma G} (h : Equation3180 G) : Equation3105 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3185_implies_Equation3103
  (G : Type) `{Magma G} (h : Equation3185 G) : Equation3103 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3195_implies_Equation3112
  (G : Type) `{Magma G} (h : Equation3195 G) : Equation3112 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3197_implies_Equation3115
  (G : Type) `{Magma G} (h : Equation3197 G) : Equation3115 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3201_implies_Equation3112
  (G : Type) `{Magma G} (h : Equation3201 G) : Equation3112 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3202_implies_Equation3113
  (G : Type) `{Magma G} (h : Equation3202 G) : Equation3113 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3214_implies_Equation3105
  (G : Type) `{Magma G} (h : Equation3214 G) : Equation3105 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3215_implies_Equation3106
  (G : Type) `{Magma G} (h : Equation3215 G) : Equation3106 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3257_implies_Equation3255
  (G : Type) `{Magma G} (h : Equation3257 G) : Equation3255 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3263_implies_Equation3261
  (G : Type) `{Magma G} (h : Equation3263 G) : Equation3261 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3264_implies_Equation3258
  (G : Type) `{Magma G} (h : Equation3264 G) : Equation3258 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3265_implies_Equation3259
  (G : Type) `{Magma G} (h : Equation3265 G) : Equation3259 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3266_implies_Equation3258
  (G : Type) `{Magma G} (h : Equation3266 G) : Equation3258 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3283_implies_Equation3281
  (G : Type) `{Magma G} (h : Equation3283 G) : Equation3281 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3285_implies_Equation3279
  (G : Type) `{Magma G} (h : Equation3285 G) : Equation3279 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3286_implies_Equation3278
  (G : Type) `{Magma G} (h : Equation3286 G) : Equation3278 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3288_implies_Equation3268
  (G : Type) `{Magma G} (h : Equation3288 G) : Equation3268 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3292_implies_Equation3271
  (G : Type) `{Magma G} (h : Equation3292 G) : Equation3271 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3293_implies_Equation3272
  (G : Type) `{Magma G} (h : Equation3293 G) : Equation3272 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3294_implies_Equation3271
  (G : Type) `{Magma G} (h : Equation3294 G) : Equation3271 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3297_implies_Equation3269
  (G : Type) `{Magma G} (h : Equation3297 G) : Equation3269 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3307_implies_Equation3305
  (G : Type) `{Magma G} (h : Equation3307 G) : Equation3305 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3311_implies_Equation3305
  (G : Type) `{Magma G} (h : Equation3311 G) : Equation3305 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3313_implies_Equation3305
  (G : Type) `{Magma G} (h : Equation3313 G) : Equation3305 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3317_implies_Equation3315
  (G : Type) `{Magma G} (h : Equation3317 G) : Equation3315 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3320_implies_Equation3318
  (G : Type) `{Magma G} (h : Equation3320 G) : Equation3318 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3321_implies_Equation3315
  (G : Type) `{Magma G} (h : Equation3321 G) : Equation3315 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3322_implies_Equation3316
  (G : Type) `{Magma G} (h : Equation3322 G) : Equation3316 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3323_implies_Equation3315
  (G : Type) `{Magma G} (h : Equation3323 G) : Equation3315 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3325_implies_Equation3305
  (G : Type) `{Magma G} (h : Equation3325 G) : Equation3305 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3326_implies_Equation3306
  (G : Type) `{Magma G} (h : Equation3326 G) : Equation3306 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3327_implies_Equation3305
  (G : Type) `{Magma G} (h : Equation3327 G) : Equation3305 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3331_implies_Equation3308
  (G : Type) `{Magma G} (h : Equation3331 G) : Equation3308 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3333_implies_Equation3305
  (G : Type) `{Magma G} (h : Equation3333 G) : Equation3305 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3334_implies_Equation3306
  (G : Type) `{Magma G} (h : Equation3334 G) : Equation3306 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3335_implies_Equation3305
  (G : Type) `{Magma G} (h : Equation3335 G) : Equation3305 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3350_implies_Equation3342
  (G : Type) `{Magma G} (h : Equation3350 G) : Equation3342 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3364_implies_Equation3342
  (G : Type) `{Magma G} (h : Equation3364 G) : Equation3342 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3405_implies_Equation3316
  (G : Type) `{Magma G} (h : Equation3405 G) : Equation3316 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3414_implies_Equation3306
  (G : Type) `{Magma G} (h : Equation3414 G) : Equation3306 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3460_implies_Equation3458
  (G : Type) `{Magma G} (h : Equation3460 G) : Equation3458 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3463_implies_Equation3461
  (G : Type) `{Magma G} (h : Equation3463 G) : Equation3461 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3466_implies_Equation3464
  (G : Type) `{Magma G} (h : Equation3466 G) : Equation3464 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3467_implies_Equation3461
  (G : Type) `{Magma G} (h : Equation3467 G) : Equation3461 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3468_implies_Equation3462
  (G : Type) `{Magma G} (h : Equation3468 G) : Equation3462 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3469_implies_Equation3461
  (G : Type) `{Magma G} (h : Equation3469 G) : Equation3461 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3487_implies_Equation3481
  (G : Type) `{Magma G} (h : Equation3487 G) : Equation3481 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3488_implies_Equation3482
  (G : Type) `{Magma G} (h : Equation3488 G) : Equation3482 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3489_implies_Equation3481
  (G : Type) `{Magma G} (h : Equation3489 G) : Equation3481 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3491_implies_Equation3471
  (G : Type) `{Magma G} (h : Equation3491 G) : Equation3471 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3495_implies_Equation3474
  (G : Type) `{Magma G} (h : Equation3495 G) : Equation3474 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3496_implies_Equation3475
  (G : Type) `{Magma G} (h : Equation3496 G) : Equation3475 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3497_implies_Equation3474
  (G : Type) `{Magma G} (h : Equation3497 G) : Equation3474 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3499_implies_Equation3471
  (G : Type) `{Magma G} (h : Equation3499 G) : Equation3471 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3501_implies_Equation3471
  (G : Type) `{Magma G} (h : Equation3501 G) : Equation3471 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3510_implies_Equation3508
  (G : Type) `{Magma G} (h : Equation3510 G) : Equation3508 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3513_implies_Equation3511
  (G : Type) `{Magma G} (h : Equation3513 G) : Equation3511 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3514_implies_Equation3508
  (G : Type) `{Magma G} (h : Equation3514 G) : Equation3508 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3515_implies_Equation3509
  (G : Type) `{Magma G} (h : Equation3515 G) : Equation3509 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3516_implies_Equation3508
  (G : Type) `{Magma G} (h : Equation3516 G) : Equation3508 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3520_implies_Equation3518
  (G : Type) `{Magma G} (h : Equation3520 G) : Equation3518 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3523_implies_Equation3521
  (G : Type) `{Magma G} (h : Equation3523 G) : Equation3521 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3524_implies_Equation3518
  (G : Type) `{Magma G} (h : Equation3524 G) : Equation3518 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3525_implies_Equation3519
  (G : Type) `{Magma G} (h : Equation3525 G) : Equation3519 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3526_implies_Equation3518
  (G : Type) `{Magma G} (h : Equation3526 G) : Equation3518 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3528_implies_Equation3508
  (G : Type) `{Magma G} (h : Equation3528 G) : Equation3508 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3529_implies_Equation3509
  (G : Type) `{Magma G} (h : Equation3529 G) : Equation3509 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3530_implies_Equation3508
  (G : Type) `{Magma G} (h : Equation3530 G) : Equation3508 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3533_implies_Equation3512
  (G : Type) `{Magma G} (h : Equation3533 G) : Equation3512 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3534_implies_Equation3511
  (G : Type) `{Magma G} (h : Equation3534 G) : Equation3511 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3536_implies_Equation3508
  (G : Type) `{Magma G} (h : Equation3536 G) : Equation3508 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3537_implies_Equation3509
  (G : Type) `{Magma G} (h : Equation3537 G) : Equation3509 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3538_implies_Equation3508
  (G : Type) `{Magma G} (h : Equation3538 G) : Equation3508 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3566_implies_Equation3546
  (G : Type) `{Magma G} (h : Equation3566 G) : Equation3546 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3567_implies_Equation3545
  (G : Type) `{Magma G} (h : Equation3567 G) : Equation3545 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3573_implies_Equation3545
  (G : Type) `{Magma G} (h : Equation3573 G) : Equation3545 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3583_implies_Equation3509
  (G : Type) `{Magma G} (h : Equation3583 G) : Equation3509 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3587_implies_Equation3512
  (G : Type) `{Magma G} (h : Equation3587 G) : Equation3512 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3588_implies_Equation3511
  (G : Type) `{Magma G} (h : Equation3588 G) : Equation3511 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3600_implies_Equation3519
  (G : Type) `{Magma G} (h : Equation3600 G) : Equation3519 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3601_implies_Equation3518
  (G : Type) `{Magma G} (h : Equation3601 G) : Equation3518 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3617_implies_Equation3509
  (G : Type) `{Magma G} (h : Equation3617 G) : Equation3509 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3620_implies_Equation3511
  (G : Type) `{Magma G} (h : Equation3620 G) : Equation3511 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3663_implies_Equation3661
  (G : Type) `{Magma G} (h : Equation3663 G) : Equation3661 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3666_implies_Equation3664
  (G : Type) `{Magma G} (h : Equation3666 G) : Equation3664 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3669_implies_Equation3667
  (G : Type) `{Magma G} (h : Equation3669 G) : Equation3667 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3670_implies_Equation3664
  (G : Type) `{Magma G} (h : Equation3670 G) : Equation3664 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3671_implies_Equation3665
  (G : Type) `{Magma G} (h : Equation3671 G) : Equation3665 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3672_implies_Equation3664
  (G : Type) `{Magma G} (h : Equation3672 G) : Equation3664 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3680_implies_Equation3674
  (G : Type) `{Magma G} (h : Equation3680 G) : Equation3674 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3690_implies_Equation3684
  (G : Type) `{Magma G} (h : Equation3690 G) : Equation3684 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3691_implies_Equation3685
  (G : Type) `{Magma G} (h : Equation3691 G) : Equation3685 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3694_implies_Equation3674
  (G : Type) `{Magma G} (h : Equation3694 G) : Equation3674 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3698_implies_Equation3677
  (G : Type) `{Magma G} (h : Equation3698 G) : Equation3677 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3699_implies_Equation3678
  (G : Type) `{Magma G} (h : Equation3699 G) : Equation3678 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3700_implies_Equation3677
  (G : Type) `{Magma G} (h : Equation3700 G) : Equation3677 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3702_implies_Equation3674
  (G : Type) `{Magma G} (h : Equation3702 G) : Equation3674 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3703_implies_Equation3675
  (G : Type) `{Magma G} (h : Equation3703 G) : Equation3675 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3713_implies_Equation3711
  (G : Type) `{Magma G} (h : Equation3713 G) : Equation3711 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3716_implies_Equation3714
  (G : Type) `{Magma G} (h : Equation3716 G) : Equation3714 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3717_implies_Equation3711
  (G : Type) `{Magma G} (h : Equation3717 G) : Equation3711 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3718_implies_Equation3712
  (G : Type) `{Magma G} (h : Equation3718 G) : Equation3712 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3719_implies_Equation3711
  (G : Type) `{Magma G} (h : Equation3719 G) : Equation3711 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3723_implies_Equation3721
  (G : Type) `{Magma G} (h : Equation3723 G) : Equation3721 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3726_implies_Equation3724
  (G : Type) `{Magma G} (h : Equation3726 G) : Equation3724 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3727_implies_Equation3721
  (G : Type) `{Magma G} (h : Equation3727 G) : Equation3721 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3728_implies_Equation3722
  (G : Type) `{Magma G} (h : Equation3728 G) : Equation3722 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3729_implies_Equation3721
  (G : Type) `{Magma G} (h : Equation3729 G) : Equation3721 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3732_implies_Equation3712
  (G : Type) `{Magma G} (h : Equation3732 G) : Equation3712 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3733_implies_Equation3711
  (G : Type) `{Magma G} (h : Equation3733 G) : Equation3711 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3736_implies_Equation3715
  (G : Type) `{Magma G} (h : Equation3736 G) : Equation3715 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3737_implies_Equation3714
  (G : Type) `{Magma G} (h : Equation3737 G) : Equation3714 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3739_implies_Equation3711
  (G : Type) `{Magma G} (h : Equation3739 G) : Equation3711 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3740_implies_Equation3712
  (G : Type) `{Magma G} (h : Equation3740 G) : Equation3712 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3741_implies_Equation3711
  (G : Type) `{Magma G} (h : Equation3741 G) : Equation3711 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3756_implies_Equation3748
  (G : Type) `{Magma G} (h : Equation3756 G) : Equation3748 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3776_implies_Equation3748
  (G : Type) `{Magma G} (h : Equation3776 G) : Equation3748 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3786_implies_Equation3712
  (G : Type) `{Magma G} (h : Equation3786 G) : Equation3712 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3790_implies_Equation3715
  (G : Type) `{Magma G} (h : Equation3790 G) : Equation3715 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3794_implies_Equation3712
  (G : Type) `{Magma G} (h : Equation3794 G) : Equation3712 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3803_implies_Equation3722
  (G : Type) `{Magma G} (h : Equation3803 G) : Equation3722 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3820_implies_Equation3712
  (G : Type) `{Magma G} (h : Equation3820 G) : Equation3712 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3823_implies_Equation3714
  (G : Type) `{Magma G} (h : Equation3823 G) : Equation3714 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3866_implies_Equation3864
  (G : Type) `{Magma G} (h : Equation3866 G) : Equation3864 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3869_implies_Equation3867
  (G : Type) `{Magma G} (h : Equation3869 G) : Equation3867 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3872_implies_Equation3870
  (G : Type) `{Magma G} (h : Equation3872 G) : Equation3870 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3873_implies_Equation3867
  (G : Type) `{Magma G} (h : Equation3873 G) : Equation3867 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3874_implies_Equation3868
  (G : Type) `{Magma G} (h : Equation3874 G) : Equation3868 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3875_implies_Equation3867
  (G : Type) `{Magma G} (h : Equation3875 G) : Equation3867 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3883_implies_Equation3877
  (G : Type) `{Magma G} (h : Equation3883 G) : Equation3877 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3893_implies_Equation3887
  (G : Type) `{Magma G} (h : Equation3893 G) : Equation3887 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3894_implies_Equation3888
  (G : Type) `{Magma G} (h : Equation3894 G) : Equation3888 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3895_implies_Equation3887
  (G : Type) `{Magma G} (h : Equation3895 G) : Equation3887 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3897_implies_Equation3877
  (G : Type) `{Magma G} (h : Equation3897 G) : Equation3877 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3901_implies_Equation3880
  (G : Type) `{Magma G} (h : Equation3901 G) : Equation3880 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3902_implies_Equation3881
  (G : Type) `{Magma G} (h : Equation3902 G) : Equation3881 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3903_implies_Equation3880
  (G : Type) `{Magma G} (h : Equation3903 G) : Equation3880 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3905_implies_Equation3877
  (G : Type) `{Magma G} (h : Equation3905 G) : Equation3877 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3906_implies_Equation3878
  (G : Type) `{Magma G} (h : Equation3906 G) : Equation3878 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3916_implies_Equation3914
  (G : Type) `{Magma G} (h : Equation3916 G) : Equation3914 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3919_implies_Equation3917
  (G : Type) `{Magma G} (h : Equation3919 G) : Equation3917 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3920_implies_Equation3914
  (G : Type) `{Magma G} (h : Equation3920 G) : Equation3914 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3921_implies_Equation3915
  (G : Type) `{Magma G} (h : Equation3921 G) : Equation3915 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3922_implies_Equation3914
  (G : Type) `{Magma G} (h : Equation3922 G) : Equation3914 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3926_implies_Equation3924
  (G : Type) `{Magma G} (h : Equation3926 G) : Equation3924 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3929_implies_Equation3927
  (G : Type) `{Magma G} (h : Equation3929 G) : Equation3927 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3930_implies_Equation3924
  (G : Type) `{Magma G} (h : Equation3930 G) : Equation3924 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3931_implies_Equation3925
  (G : Type) `{Magma G} (h : Equation3931 G) : Equation3925 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3932_implies_Equation3924
  (G : Type) `{Magma G} (h : Equation3932 G) : Equation3924 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3934_implies_Equation3914
  (G : Type) `{Magma G} (h : Equation3934 G) : Equation3914 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3935_implies_Equation3915
  (G : Type) `{Magma G} (h : Equation3935 G) : Equation3915 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3936_implies_Equation3914
  (G : Type) `{Magma G} (h : Equation3936 G) : Equation3914 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3939_implies_Equation3918
  (G : Type) `{Magma G} (h : Equation3939 G) : Equation3918 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3940_implies_Equation3917
  (G : Type) `{Magma G} (h : Equation3940 G) : Equation3917 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3942_implies_Equation3914
  (G : Type) `{Magma G} (h : Equation3942 G) : Equation3914 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3943_implies_Equation3915
  (G : Type) `{Magma G} (h : Equation3943 G) : Equation3915 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3944_implies_Equation3914
  (G : Type) `{Magma G} (h : Equation3944 G) : Equation3914 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3959_implies_Equation3951
  (G : Type) `{Magma G} (h : Equation3959 G) : Equation3951 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3972_implies_Equation3952
  (G : Type) `{Magma G} (h : Equation3972 G) : Equation3952 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3973_implies_Equation3951
  (G : Type) `{Magma G} (h : Equation3973 G) : Equation3951 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3979_implies_Equation3951
  (G : Type) `{Magma G} (h : Equation3979 G) : Equation3951 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3989_implies_Equation3915
  (G : Type) `{Magma G} (h : Equation3989 G) : Equation3915 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3993_implies_Equation3918
  (G : Type) `{Magma G} (h : Equation3993 G) : Equation3918 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3994_implies_Equation3917
  (G : Type) `{Magma G} (h : Equation3994 G) : Equation3917 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation3997_implies_Equation3915
  (G : Type) `{Magma G} (h : Equation3997 G) : Equation3915 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4006_implies_Equation3925
  (G : Type) `{Magma G} (h : Equation4006 G) : Equation3925 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4007_implies_Equation3924
  (G : Type) `{Magma G} (h : Equation4007 G) : Equation3924 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4013_implies_Equation3924
  (G : Type) `{Magma G} (h : Equation4013 G) : Equation3924 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4023_implies_Equation3915
  (G : Type) `{Magma G} (h : Equation4023 G) : Equation3915 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4026_implies_Equation3917
  (G : Type) `{Magma G} (h : Equation4026 G) : Equation3917 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4069_implies_Equation4067
  (G : Type) `{Magma G} (h : Equation4069 G) : Equation4067 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4072_implies_Equation4070
  (G : Type) `{Magma G} (h : Equation4072 G) : Equation4070 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4075_implies_Equation4073
  (G : Type) `{Magma G} (h : Equation4075 G) : Equation4073 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4076_implies_Equation4070
  (G : Type) `{Magma G} (h : Equation4076 G) : Equation4070 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4077_implies_Equation4071
  (G : Type) `{Magma G} (h : Equation4077 G) : Equation4071 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4078_implies_Equation4070
  (G : Type) `{Magma G} (h : Equation4078 G) : Equation4070 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4086_implies_Equation4080
  (G : Type) `{Magma G} (h : Equation4086 G) : Equation4080 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4096_implies_Equation4090
  (G : Type) `{Magma G} (h : Equation4096 G) : Equation4090 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4097_implies_Equation4091
  (G : Type) `{Magma G} (h : Equation4097 G) : Equation4091 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4098_implies_Equation4090
  (G : Type) `{Magma G} (h : Equation4098 G) : Equation4090 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4100_implies_Equation4080
  (G : Type) `{Magma G} (h : Equation4100 G) : Equation4080 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4104_implies_Equation4083
  (G : Type) `{Magma G} (h : Equation4104 G) : Equation4083 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4105_implies_Equation4084
  (G : Type) `{Magma G} (h : Equation4105 G) : Equation4084 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4106_implies_Equation4083
  (G : Type) `{Magma G} (h : Equation4106 G) : Equation4083 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4108_implies_Equation4080
  (G : Type) `{Magma G} (h : Equation4108 G) : Equation4080 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4109_implies_Equation4081
  (G : Type) `{Magma G} (h : Equation4109 G) : Equation4081 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4110_implies_Equation4080
  (G : Type) `{Magma G} (h : Equation4110 G) : Equation4080 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4119_implies_Equation4117
  (G : Type) `{Magma G} (h : Equation4119 G) : Equation4117 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4123_implies_Equation4117
  (G : Type) `{Magma G} (h : Equation4123 G) : Equation4117 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4125_implies_Equation4117
  (G : Type) `{Magma G} (h : Equation4125 G) : Equation4117 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4134_implies_Equation4128
  (G : Type) `{Magma G} (h : Equation4134 G) : Equation4128 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4135_implies_Equation4127
  (G : Type) `{Magma G} (h : Equation4135 G) : Equation4127 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4138_implies_Equation4118
  (G : Type) `{Magma G} (h : Equation4138 G) : Equation4118 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4139_implies_Equation4117
  (G : Type) `{Magma G} (h : Equation4139 G) : Equation4117 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4142_implies_Equation4121
  (G : Type) `{Magma G} (h : Equation4142 G) : Equation4121 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4143_implies_Equation4120
  (G : Type) `{Magma G} (h : Equation4143 G) : Equation4120 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4146_implies_Equation4118
  (G : Type) `{Magma G} (h : Equation4146 G) : Equation4118 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4162_implies_Equation4154
  (G : Type) `{Magma G} (h : Equation4162 G) : Equation4154 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4175_implies_Equation4155
  (G : Type) `{Magma G} (h : Equation4175 G) : Equation4155 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4182_implies_Equation4154
  (G : Type) `{Magma G} (h : Equation4182 G) : Equation4154 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4200_implies_Equation4118
  (G : Type) `{Magma G} (h : Equation4200 G) : Equation4118 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4216_implies_Equation4127
  (G : Type) `{Magma G} (h : Equation4216 G) : Equation4127 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4226_implies_Equation4118
  (G : Type) `{Magma G} (h : Equation4226 G) : Equation4118 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4229_implies_Equation4120
  (G : Type) `{Magma G} (h : Equation4229 G) : Equation4120 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4296_implies_Equation4291
  (G : Type) `{Magma G} (h : Equation4296 G) : Equation4291 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4297_implies_Equation4290
  (G : Type) `{Magma G} (h : Equation4297 G) : Equation4290 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4304_implies_Equation4284
  (G : Type) `{Magma G} (h : Equation4304 G) : Equation4284 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4305_implies_Equation4283
  (G : Type) `{Magma G} (h : Equation4305 G) : Equation4283 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4325_implies_Equation4320
  (G : Type) `{Magma G} (h : Equation4325 G) : Equation4320 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4331_implies_Equation4314
  (G : Type) `{Magma G} (h : Equation4331 G) : Equation4314 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4345_implies_Equation4343
  (G : Type) `{Magma G} (h : Equation4345 G) : Equation4343 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4362_implies_Equation4320
  (G : Type) `{Magma G} (h : Equation4362 G) : Equation4320 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4364_implies_Equation4320
  (G : Type) `{Magma G} (h : Equation4364 G) : Equation4320 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4384_implies_Equation4382
  (G : Type) `{Magma G} (h : Equation4384 G) : Equation4382 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4390_implies_Equation4388
  (G : Type) `{Magma G} (h : Equation4390 G) : Equation4388 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4391_implies_Equation4385
  (G : Type) `{Magma G} (h : Equation4391 G) : Equation4385 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4392_implies_Equation4386
  (G : Type) `{Magma G} (h : Equation4392 G) : Equation4386 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4393_implies_Equation4385
  (G : Type) `{Magma G} (h : Equation4393 G) : Equation4385 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4397_implies_Equation4395
  (G : Type) `{Magma G} (h : Equation4397 G) : Equation4395 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4400_implies_Equation4398
  (G : Type) `{Magma G} (h : Equation4400 G) : Equation4398 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4401_implies_Equation4395
  (G : Type) `{Magma G} (h : Equation4401 G) : Equation4395 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4402_implies_Equation4396
  (G : Type) `{Magma G} (h : Equation4402 G) : Equation4396 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4403_implies_Equation4395
  (G : Type) `{Magma G} (h : Equation4403 G) : Equation4395 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4412_implies_Equation4406
  (G : Type) `{Magma G} (h : Equation4412 G) : Equation4406 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4413_implies_Equation4405
  (G : Type) `{Magma G} (h : Equation4413 G) : Equation4405 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4415_implies_Equation4395
  (G : Type) `{Magma G} (h : Equation4415 G) : Equation4395 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4416_implies_Equation4396
  (G : Type) `{Magma G} (h : Equation4416 G) : Equation4396 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4420_implies_Equation4399
  (G : Type) `{Magma G} (h : Equation4420 G) : Equation4399 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4421_implies_Equation4398
  (G : Type) `{Magma G} (h : Equation4421 G) : Equation4398 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4423_implies_Equation4395
  (G : Type) `{Magma G} (h : Equation4423 G) : Equation4395 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4424_implies_Equation4396
  (G : Type) `{Magma G} (h : Equation4424 G) : Equation4396 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4425_implies_Equation4395
  (G : Type) `{Magma G} (h : Equation4425 G) : Equation4395 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4434_implies_Equation4432
  (G : Type) `{Magma G} (h : Equation4434 G) : Equation4432 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4437_implies_Equation4435
  (G : Type) `{Magma G} (h : Equation4437 G) : Equation4435 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4438_implies_Equation4432
  (G : Type) `{Magma G} (h : Equation4438 G) : Equation4432 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4439_implies_Equation4433
  (G : Type) `{Magma G} (h : Equation4439 G) : Equation4433 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4440_implies_Equation4432
  (G : Type) `{Magma G} (h : Equation4440 G) : Equation4432 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4450_implies_Equation4442
  (G : Type) `{Magma G} (h : Equation4450 G) : Equation4442 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4452_implies_Equation4432
  (G : Type) `{Magma G} (h : Equation4452 G) : Equation4432 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4456_implies_Equation4435
  (G : Type) `{Magma G} (h : Equation4456 G) : Equation4435 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4458_implies_Equation4435
  (G : Type) `{Magma G} (h : Equation4458 G) : Equation4435 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4460_implies_Equation4432
  (G : Type) `{Magma G} (h : Equation4460 G) : Equation4432 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4461_implies_Equation4433
  (G : Type) `{Magma G} (h : Equation4461 G) : Equation4433 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4462_implies_Equation4432
  (G : Type) `{Magma G} (h : Equation4462 G) : Equation4432 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4471_implies_Equation4469
  (G : Type) `{Magma G} (h : Equation4471 G) : Equation4469 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4474_implies_Equation4472
  (G : Type) `{Magma G} (h : Equation4474 G) : Equation4472 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4475_implies_Equation4469
  (G : Type) `{Magma G} (h : Equation4475 G) : Equation4469 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4476_implies_Equation4470
  (G : Type) `{Magma G} (h : Equation4476 G) : Equation4470 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4477_implies_Equation4469
  (G : Type) `{Magma G} (h : Equation4477 G) : Equation4469 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4486_implies_Equation4480
  (G : Type) `{Magma G} (h : Equation4486 G) : Equation4480 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4489_implies_Equation4469
  (G : Type) `{Magma G} (h : Equation4489 G) : Equation4469 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4490_implies_Equation4470
  (G : Type) `{Magma G} (h : Equation4490 G) : Equation4470 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4491_implies_Equation4469
  (G : Type) `{Magma G} (h : Equation4491 G) : Equation4469 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4494_implies_Equation4473
  (G : Type) `{Magma G} (h : Equation4494 G) : Equation4473 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4497_implies_Equation4469
  (G : Type) `{Magma G} (h : Equation4497 G) : Equation4469 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4498_implies_Equation4470
  (G : Type) `{Magma G} (h : Equation4498 G) : Equation4470 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4499_implies_Equation4469
  (G : Type) `{Magma G} (h : Equation4499 G) : Equation4469 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4506_implies_Equation4432
  (G : Type) `{Magma G} (h : Equation4506 G) : Equation4432 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4507_implies_Equation4433
  (G : Type) `{Magma G} (h : Equation4507 G) : Equation4433 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4508_implies_Equation4432
  (G : Type) `{Magma G} (h : Equation4508 G) : Equation4432 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4510_implies_Equation4435
  (G : Type) `{Magma G} (h : Equation4510 G) : Equation4435 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4511_implies_Equation4436
  (G : Type) `{Magma G} (h : Equation4511 G) : Equation4436 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4512_implies_Equation4435
  (G : Type) `{Magma G} (h : Equation4512 G) : Equation4435 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4515_implies_Equation4433
  (G : Type) `{Magma G} (h : Equation4515 G) : Equation4433 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4516_implies_Equation4432
  (G : Type) `{Magma G} (h : Equation4516 G) : Equation4432 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4525_implies_Equation4442
  (G : Type) `{Magma G} (h : Equation4525 G) : Equation4442 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4529_implies_Equation4445
  (G : Type) `{Magma G} (h : Equation4529 G) : Equation4445 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4531_implies_Equation4442
  (G : Type) `{Magma G} (h : Equation4531 G) : Equation4442 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4533_implies_Equation4442
  (G : Type) `{Magma G} (h : Equation4533 G) : Equation4442 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4541_implies_Equation4433
  (G : Type) `{Magma G} (h : Equation4541 G) : Equation4433 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4542_implies_Equation4432
  (G : Type) `{Magma G} (h : Equation4542 G) : Equation4432 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4544_implies_Equation4435
  (G : Type) `{Magma G} (h : Equation4544 G) : Equation4435 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4545_implies_Equation4436
  (G : Type) `{Magma G} (h : Equation4545 G) : Equation4436 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4546_implies_Equation4435
  (G : Type) `{Magma G} (h : Equation4546 G) : Equation4435 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4550_implies_Equation4432
  (G : Type) `{Magma G} (h : Equation4550 G) : Equation4432 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4592_implies_Equation4590
  (G : Type) `{Magma G} (h : Equation4592 G) : Equation4590 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4609_implies_Equation4608
  (G : Type) `{Magma G} (h : Equation4609 G) : Equation4608 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4611_implies_Equation4606
  (G : Type) `{Magma G} (h : Equation4611 G) : Equation4606 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4612_implies_Equation4605
  (G : Type) `{Magma G} (h : Equation4612 G) : Equation4605 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4619_implies_Equation4599
  (G : Type) `{Magma G} (h : Equation4619 G) : Equation4599 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4620_implies_Equation4598
  (G : Type) `{Magma G} (h : Equation4620 G) : Equation4598 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4640_implies_Equation4635
  (G : Type) `{Magma G} (h : Equation4640 G) : Equation4635 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4646_implies_Equation4629
  (G : Type) `{Magma G} (h : Equation4646 G) : Equation4629 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4659_implies_Equation4658
  (G : Type) `{Magma G} (h : Equation4659 G) : Equation4658 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4660_implies_Equation4658
  (G : Type) `{Magma G} (h : Equation4660 G) : Equation4658 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4677_implies_Equation4635
  (G : Type) `{Magma G} (h : Equation4677 G) : Equation4635 G.
Proof. intros x y. exact (h x y x). Qed.

Theorem Equation4679_implies_Equation4635
  (G : Type) `{Magma G} (h : Equation4679 G) : Equation4635 G.
Proof. intros x y. exact (h x y x). Qed.

