(** * SimpleRewrites/Rewrite_vx

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation3455_implies_Equation3450
  (G : Type) `{Magma G} (h : Equation3455 G) : Equation3450 G.
Proof. intros x y z w u. exact (h x y z w u x). Qed.

Theorem Equation3658_implies_Equation3653
  (G : Type) `{Magma G} (h : Equation3658 G) : Equation3653 G.
Proof. intros x y z w u. exact (h x y z w u x). Qed.

Theorem Equation4064_implies_Equation4059
  (G : Type) `{Magma G} (h : Equation4064 G) : Equation4059 G.
Proof. intros x y z w u. exact (h x y z w u x). Qed.

