(** * SimpleRewrites/Rewrite_ux_vu

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation816_implies_Equation795
  (G : Type) `{Magma G} (h : Equation816 G) : Equation795 G.
Proof. intros x y z w u. exact (h x y z w x u). Qed.

Theorem Equation1628_implies_Equation1607
  (G : Type) `{Magma G} (h : Equation1628 G) : Equation1607 G.
Proof. intros x y z w u. exact (h x y z w x u). Qed.

Theorem Equation2440_implies_Equation2419
  (G : Type) `{Magma G} (h : Equation2440 G) : Equation2419 G.
Proof. intros x y z w u. exact (h x y z w x u). Qed.

Theorem Equation3455_implies_Equation3434
  (G : Type) `{Magma G} (h : Equation3455 G) : Equation3434 G.
Proof. intros x y z w u. exact (h x y z w x u). Qed.

Theorem Equation3658_implies_Equation3637
  (G : Type) `{Magma G} (h : Equation3658 G) : Equation3637 G.
Proof. intros x y z w u. exact (h x y z w x u). Qed.

Theorem Equation4064_implies_Equation4043
  (G : Type) `{Magma G} (h : Equation4064 G) : Equation4043 G.
Proof. intros x y z w u. exact (h x y z w x u). Qed.

Theorem Equation4582_implies_Equation4561
  (G : Type) `{Magma G} (h : Equation4582 G) : Equation4561 G.
Proof. intros x y z w u. exact (h x y z w x u). Qed.

