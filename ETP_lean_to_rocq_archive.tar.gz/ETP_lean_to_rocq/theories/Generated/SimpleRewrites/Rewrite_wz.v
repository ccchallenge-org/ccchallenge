(** * SimpleRewrites/Rewrite_wz

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation37_implies_Equation36
  (G : Type) `{Magma G} (h : Equation37 G) : Equation36 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation61_implies_Equation60
  (G : Type) `{Magma G} (h : Equation61 G) : Equation60 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation95_implies_Equation91
  (G : Type) `{Magma G} (h : Equation95 G) : Equation91 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation113_implies_Equation112
  (G : Type) `{Magma G} (h : Equation113 G) : Equation112 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation123_implies_Equation122
  (G : Type) `{Magma G} (h : Equation123 G) : Equation122 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation133_implies_Equation132
  (G : Type) `{Magma G} (h : Equation133 G) : Equation132 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation137_implies_Equation136
  (G : Type) `{Magma G} (h : Equation137 G) : Equation136 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation141_implies_Equation140
  (G : Type) `{Magma G} (h : Equation141 G) : Equation140 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation145_implies_Equation144
  (G : Type) `{Magma G} (h : Equation145 G) : Equation144 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation146_implies_Equation142
  (G : Type) `{Magma G} (h : Equation146 G) : Equation142 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation185_implies_Equation184
  (G : Type) `{Magma G} (h : Equation185 G) : Equation184 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation193_implies_Equation192
  (G : Type) `{Magma G} (h : Equation193 G) : Equation192 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation197_implies_Equation196
  (G : Type) `{Magma G} (h : Equation197 G) : Equation196 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation237_implies_Equation236
  (G : Type) `{Magma G} (h : Equation237 G) : Equation236 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation241_implies_Equation240
  (G : Type) `{Magma G} (h : Equation241 G) : Equation240 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation245_implies_Equation244
  (G : Type) `{Magma G} (h : Equation245 G) : Equation244 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation249_implies_Equation248
  (G : Type) `{Magma G} (h : Equation249 G) : Equation248 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation252_implies_Equation248
  (G : Type) `{Magma G} (h : Equation252 G) : Equation248 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation253_implies_Equation248
  (G : Type) `{Magma G} (h : Equation253 G) : Equation248 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation279_implies_Equation278
  (G : Type) `{Magma G} (h : Equation279 G) : Equation278 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation293_implies_Equation292
  (G : Type) `{Magma G} (h : Equation293 G) : Equation292 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation302_implies_Equation298
  (G : Type) `{Magma G} (h : Equation302 G) : Equation298 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation305_implies_Equation300
  (G : Type) `{Magma G} (h : Equation305 G) : Equation300 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation331_implies_Equation330
  (G : Type) `{Magma G} (h : Equation331 G) : Equation330 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation345_implies_Equation344
  (G : Type) `{Magma G} (h : Equation345 G) : Equation344 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation355_implies_Equation351
  (G : Type) `{Magma G} (h : Equation355 G) : Equation351 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation393_implies_Equation392
  (G : Type) `{Magma G} (h : Equation393 G) : Equation392 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation397_implies_Equation396
  (G : Type) `{Magma G} (h : Equation397 G) : Equation396 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation401_implies_Equation400
  (G : Type) `{Magma G} (h : Equation401 G) : Equation400 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation405_implies_Equation404
  (G : Type) `{Magma G} (h : Equation405 G) : Equation404 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation407_implies_Equation403
  (G : Type) `{Magma G} (h : Equation407 G) : Equation403 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation457_implies_Equation456
  (G : Type) `{Magma G} (h : Equation457 G) : Equation456 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation458_implies_Equation454
  (G : Type) `{Magma G} (h : Equation458 G) : Equation454 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation459_implies_Equation455
  (G : Type) `{Magma G} (h : Equation459 G) : Equation455 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation460_implies_Equation456
  (G : Type) `{Magma G} (h : Equation460 G) : Equation456 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation472_implies_Equation471
  (G : Type) `{Magma G} (h : Equation472 G) : Equation471 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation486_implies_Equation485
  (G : Type) `{Magma G} (h : Equation486 G) : Equation485 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation498_implies_Equation493
  (G : Type) `{Magma G} (h : Equation498 G) : Equation493 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation509_implies_Equation508
  (G : Type) `{Magma G} (h : Equation509 G) : Equation508 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation519_implies_Equation518
  (G : Type) `{Magma G} (h : Equation519 G) : Equation518 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation527_implies_Equation526
  (G : Type) `{Magma G} (h : Equation527 G) : Equation526 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation531_implies_Equation530
  (G : Type) `{Magma G} (h : Equation531 G) : Equation530 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation540_implies_Equation539
  (G : Type) `{Magma G} (h : Equation540 G) : Equation539 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation548_implies_Equation547
  (G : Type) `{Magma G} (h : Equation548 G) : Equation547 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation549_implies_Equation545
  (G : Type) `{Magma G} (h : Equation549 G) : Equation545 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation551_implies_Equation547
  (G : Type) `{Magma G} (h : Equation551 G) : Equation547 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation552_implies_Equation547
  (G : Type) `{Magma G} (h : Equation552 G) : Equation547 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation561_implies_Equation560
  (G : Type) `{Magma G} (h : Equation561 G) : Equation560 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation565_implies_Equation564
  (G : Type) `{Magma G} (h : Equation565 G) : Equation564 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation574_implies_Equation573
  (G : Type) `{Magma G} (h : Equation574 G) : Equation573 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation578_implies_Equation577
  (G : Type) `{Magma G} (h : Equation578 G) : Equation577 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation582_implies_Equation581
  (G : Type) `{Magma G} (h : Equation582 G) : Equation581 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation583_implies_Equation579
  (G : Type) `{Magma G} (h : Equation583 G) : Equation579 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation586_implies_Equation581
  (G : Type) `{Magma G} (h : Equation586 G) : Equation581 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation593_implies_Equation575
  (G : Type) `{Magma G} (h : Equation593 G) : Equation575 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation599_implies_Equation580
  (G : Type) `{Magma G} (h : Equation599 G) : Equation580 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation600_implies_Equation581
  (G : Type) `{Magma G} (h : Equation600 G) : Equation581 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation601_implies_Equation581
  (G : Type) `{Magma G} (h : Equation601 G) : Equation581 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation605_implies_Equation581
  (G : Type) `{Magma G} (h : Equation605 G) : Equation581 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation606_implies_Equation581
  (G : Type) `{Magma G} (h : Equation606 G) : Equation581 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation628_implies_Equation627
  (G : Type) `{Magma G} (h : Equation628 G) : Equation627 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation638_implies_Equation637
  (G : Type) `{Magma G} (h : Equation638 G) : Equation637 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation652_implies_Equation651
  (G : Type) `{Magma G} (h : Equation652 G) : Equation651 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation660_implies_Equation659
  (G : Type) `{Magma G} (h : Equation660 G) : Equation659 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation661_implies_Equation657
  (G : Type) `{Magma G} (h : Equation661 G) : Equation657 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation689_implies_Equation688
  (G : Type) `{Magma G} (h : Equation689 G) : Equation688 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation697_implies_Equation696
  (G : Type) `{Magma G} (h : Equation697 G) : Equation696 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation722_implies_Equation721
  (G : Type) `{Magma G} (h : Equation722 G) : Equation721 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation730_implies_Equation729
  (G : Type) `{Magma G} (h : Equation730 G) : Equation729 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation734_implies_Equation733
  (G : Type) `{Magma G} (h : Equation734 G) : Equation733 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation736_implies_Equation732
  (G : Type) `{Magma G} (h : Equation736 G) : Equation732 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation738_implies_Equation733
  (G : Type) `{Magma G} (h : Equation738 G) : Equation733 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation743_implies_Equation742
  (G : Type) `{Magma G} (h : Equation743 G) : Equation742 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation754_implies_Equation750
  (G : Type) `{Magma G} (h : Equation754 G) : Equation750 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation764_implies_Equation763
  (G : Type) `{Magma G} (h : Equation764 G) : Equation763 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation768_implies_Equation767
  (G : Type) `{Magma G} (h : Equation768 G) : Equation767 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation769_implies_Equation765
  (G : Type) `{Magma G} (h : Equation769 G) : Equation765 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation781_implies_Equation780
  (G : Type) `{Magma G} (h : Equation781 G) : Equation780 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation789_implies_Equation784
  (G : Type) `{Magma G} (h : Equation789 G) : Equation784 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation791_implies_Equation774
  (G : Type) `{Magma G} (h : Equation791 G) : Equation774 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation794_implies_Equation776
  (G : Type) `{Magma G} (h : Equation794 G) : Equation776 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation831_implies_Equation830
  (G : Type) `{Magma G} (h : Equation831 G) : Equation830 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation863_implies_Equation862
  (G : Type) `{Magma G} (h : Equation863 G) : Equation862 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation865_implies_Equation861
  (G : Type) `{Magma G} (h : Equation865 G) : Equation861 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation866_implies_Equation862
  (G : Type) `{Magma G} (h : Equation866 G) : Equation862 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation867_implies_Equation862
  (G : Type) `{Magma G} (h : Equation867 G) : Equation862 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation878_implies_Equation877
  (G : Type) `{Magma G} (h : Equation878 G) : Equation877 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation892_implies_Equation891
  (G : Type) `{Magma G} (h : Equation892 G) : Equation891 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation904_implies_Equation899
  (G : Type) `{Magma G} (h : Equation904 G) : Equation899 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation925_implies_Equation924
  (G : Type) `{Magma G} (h : Equation925 G) : Equation924 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation933_implies_Equation932
  (G : Type) `{Magma G} (h : Equation933 G) : Equation932 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation937_implies_Equation936
  (G : Type) `{Magma G} (h : Equation937 G) : Equation936 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation955_implies_Equation951
  (G : Type) `{Magma G} (h : Equation955 G) : Equation951 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation957_implies_Equation953
  (G : Type) `{Magma G} (h : Equation957 G) : Equation953 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation967_implies_Equation966
  (G : Type) `{Magma G} (h : Equation967 G) : Equation966 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation975_implies_Equation970
  (G : Type) `{Magma G} (h : Equation975 G) : Equation970 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation984_implies_Equation983
  (G : Type) `{Magma G} (h : Equation984 G) : Equation983 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation996_implies_Equation979
  (G : Type) `{Magma G} (h : Equation996 G) : Equation979 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1004_implies_Equation985
  (G : Type) `{Magma G} (h : Equation1004 G) : Equation985 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1005_implies_Equation986
  (G : Type) `{Magma G} (h : Equation1005 G) : Equation986 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1006_implies_Equation987
  (G : Type) `{Magma G} (h : Equation1006 G) : Equation987 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1034_implies_Equation1033
  (G : Type) `{Magma G} (h : Equation1034 G) : Equation1033 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1058_implies_Equation1057
  (G : Type) `{Magma G} (h : Equation1058 G) : Equation1057 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1066_implies_Equation1065
  (G : Type) `{Magma G} (h : Equation1066 G) : Equation1065 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1067_implies_Equation1063
  (G : Type) `{Magma G} (h : Equation1067 G) : Equation1063 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1069_implies_Equation1065
  (G : Type) `{Magma G} (h : Equation1069 G) : Equation1065 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1070_implies_Equation1065
  (G : Type) `{Magma G} (h : Equation1070 G) : Equation1065 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1081_implies_Equation1080
  (G : Type) `{Magma G} (h : Equation1081 G) : Equation1080 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1095_implies_Equation1094
  (G : Type) `{Magma G} (h : Equation1095 G) : Equation1094 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1103_implies_Equation1102
  (G : Type) `{Magma G} (h : Equation1103 G) : Equation1102 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1104_implies_Equation1100
  (G : Type) `{Magma G} (h : Equation1104 G) : Equation1100 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1106_implies_Equation1102
  (G : Type) `{Magma G} (h : Equation1106 G) : Equation1102 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1107_implies_Equation1102
  (G : Type) `{Magma G} (h : Equation1107 G) : Equation1102 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1128_implies_Equation1127
  (G : Type) `{Magma G} (h : Equation1128 G) : Equation1127 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1136_implies_Equation1135
  (G : Type) `{Magma G} (h : Equation1136 G) : Equation1135 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1140_implies_Equation1139
  (G : Type) `{Magma G} (h : Equation1140 G) : Equation1139 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1149_implies_Equation1148
  (G : Type) `{Magma G} (h : Equation1149 G) : Equation1148 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1157_implies_Equation1156
  (G : Type) `{Magma G} (h : Equation1157 G) : Equation1156 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1158_implies_Equation1154
  (G : Type) `{Magma G} (h : Equation1158 G) : Equation1154 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1160_implies_Equation1156
  (G : Type) `{Magma G} (h : Equation1160 G) : Equation1156 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1161_implies_Equation1156
  (G : Type) `{Magma G} (h : Equation1161 G) : Equation1156 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1170_implies_Equation1169
  (G : Type) `{Magma G} (h : Equation1170 G) : Equation1169 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1174_implies_Equation1173
  (G : Type) `{Magma G} (h : Equation1174 G) : Equation1173 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1176_implies_Equation1172
  (G : Type) `{Magma G} (h : Equation1176 G) : Equation1172 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1183_implies_Equation1182
  (G : Type) `{Magma G} (h : Equation1183 G) : Equation1182 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1187_implies_Equation1186
  (G : Type) `{Magma G} (h : Equation1187 G) : Equation1186 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1191_implies_Equation1190
  (G : Type) `{Magma G} (h : Equation1191 G) : Equation1190 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1192_implies_Equation1188
  (G : Type) `{Magma G} (h : Equation1192 G) : Equation1188 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1197_implies_Equation1180
  (G : Type) `{Magma G} (h : Equation1197 G) : Equation1180 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1200_implies_Equation1182
  (G : Type) `{Magma G} (h : Equation1200 G) : Equation1182 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1207_implies_Equation1188
  (G : Type) `{Magma G} (h : Equation1207 G) : Equation1188 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1237_implies_Equation1236
  (G : Type) `{Magma G} (h : Equation1237 G) : Equation1236 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1247_implies_Equation1246
  (G : Type) `{Magma G} (h : Equation1247 G) : Equation1246 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1257_implies_Equation1256
  (G : Type) `{Magma G} (h : Equation1257 G) : Equation1256 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1261_implies_Equation1260
  (G : Type) `{Magma G} (h : Equation1261 G) : Equation1260 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1269_implies_Equation1268
  (G : Type) `{Magma G} (h : Equation1269 G) : Equation1268 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1270_implies_Equation1266
  (G : Type) `{Magma G} (h : Equation1270 G) : Equation1266 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1271_implies_Equation1267
  (G : Type) `{Magma G} (h : Equation1271 G) : Equation1267 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1272_implies_Equation1268
  (G : Type) `{Magma G} (h : Equation1272 G) : Equation1268 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1273_implies_Equation1268
  (G : Type) `{Magma G} (h : Equation1273 G) : Equation1268 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1284_implies_Equation1283
  (G : Type) `{Magma G} (h : Equation1284 G) : Equation1283 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1298_implies_Equation1297
  (G : Type) `{Magma G} (h : Equation1298 G) : Equation1297 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1306_implies_Equation1305
  (G : Type) `{Magma G} (h : Equation1306 G) : Equation1305 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1307_implies_Equation1303
  (G : Type) `{Magma G} (h : Equation1307 G) : Equation1303 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1309_implies_Equation1305
  (G : Type) `{Magma G} (h : Equation1309 G) : Equation1305 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1310_implies_Equation1305
  (G : Type) `{Magma G} (h : Equation1310 G) : Equation1305 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1331_implies_Equation1330
  (G : Type) `{Magma G} (h : Equation1331 G) : Equation1330 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1339_implies_Equation1338
  (G : Type) `{Magma G} (h : Equation1339 G) : Equation1338 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1343_implies_Equation1342
  (G : Type) `{Magma G} (h : Equation1343 G) : Equation1342 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1360_implies_Equation1359
  (G : Type) `{Magma G} (h : Equation1360 G) : Equation1359 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1361_implies_Equation1357
  (G : Type) `{Magma G} (h : Equation1361 G) : Equation1357 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1363_implies_Equation1359
  (G : Type) `{Magma G} (h : Equation1363 G) : Equation1359 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1364_implies_Equation1359
  (G : Type) `{Magma G} (h : Equation1364 G) : Equation1359 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1373_implies_Equation1372
  (G : Type) `{Magma G} (h : Equation1373 G) : Equation1372 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1377_implies_Equation1376
  (G : Type) `{Magma G} (h : Equation1377 G) : Equation1376 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1386_implies_Equation1385
  (G : Type) `{Magma G} (h : Equation1386 G) : Equation1385 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1394_implies_Equation1393
  (G : Type) `{Magma G} (h : Equation1394 G) : Equation1393 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1395_implies_Equation1391
  (G : Type) `{Magma G} (h : Equation1395 G) : Equation1391 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1400_implies_Equation1383
  (G : Type) `{Magma G} (h : Equation1400 G) : Equation1383 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1410_implies_Equation1391
  (G : Type) `{Magma G} (h : Equation1410 G) : Equation1391 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1415_implies_Equation1391
  (G : Type) `{Magma G} (h : Equation1415 G) : Equation1391 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1450_implies_Equation1449
  (G : Type) `{Magma G} (h : Equation1450 G) : Equation1449 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1464_implies_Equation1463
  (G : Type) `{Magma G} (h : Equation1464 G) : Equation1463 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1472_implies_Equation1471
  (G : Type) `{Magma G} (h : Equation1472 G) : Equation1471 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1473_implies_Equation1469
  (G : Type) `{Magma G} (h : Equation1473 G) : Equation1469 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1475_implies_Equation1471
  (G : Type) `{Magma G} (h : Equation1475 G) : Equation1471 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1487_implies_Equation1486
  (G : Type) `{Magma G} (h : Equation1487 G) : Equation1486 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1501_implies_Equation1500
  (G : Type) `{Magma G} (h : Equation1501 G) : Equation1500 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1509_implies_Equation1508
  (G : Type) `{Magma G} (h : Equation1509 G) : Equation1508 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1513_implies_Equation1508
  (G : Type) `{Magma G} (h : Equation1513 G) : Equation1508 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1534_implies_Equation1533
  (G : Type) `{Magma G} (h : Equation1534 G) : Equation1533 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1542_implies_Equation1541
  (G : Type) `{Magma G} (h : Equation1542 G) : Equation1541 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1546_implies_Equation1545
  (G : Type) `{Magma G} (h : Equation1546 G) : Equation1545 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1555_implies_Equation1554
  (G : Type) `{Magma G} (h : Equation1555 G) : Equation1554 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1563_implies_Equation1562
  (G : Type) `{Magma G} (h : Equation1563 G) : Equation1562 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1567_implies_Equation1562
  (G : Type) `{Magma G} (h : Equation1567 G) : Equation1562 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1572_implies_Equation1571
  (G : Type) `{Magma G} (h : Equation1572 G) : Equation1571 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1576_implies_Equation1575
  (G : Type) `{Magma G} (h : Equation1576 G) : Equation1575 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1580_implies_Equation1579
  (G : Type) `{Magma G} (h : Equation1580 G) : Equation1579 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1593_implies_Equation1592
  (G : Type) `{Magma G} (h : Equation1593 G) : Equation1592 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1597_implies_Equation1596
  (G : Type) `{Magma G} (h : Equation1597 G) : Equation1596 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1603_implies_Equation1586
  (G : Type) `{Magma G} (h : Equation1603 G) : Equation1586 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1606_implies_Equation1588
  (G : Type) `{Magma G} (h : Equation1606 G) : Equation1588 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1621_implies_Equation1596
  (G : Type) `{Magma G} (h : Equation1621 G) : Equation1596 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1653_implies_Equation1652
  (G : Type) `{Magma G} (h : Equation1653 G) : Equation1652 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1667_implies_Equation1666
  (G : Type) `{Magma G} (h : Equation1667 G) : Equation1666 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1675_implies_Equation1674
  (G : Type) `{Magma G} (h : Equation1675 G) : Equation1674 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1676_implies_Equation1672
  (G : Type) `{Magma G} (h : Equation1676 G) : Equation1672 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1678_implies_Equation1674
  (G : Type) `{Magma G} (h : Equation1678 G) : Equation1674 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1679_implies_Equation1674
  (G : Type) `{Magma G} (h : Equation1679 G) : Equation1674 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1704_implies_Equation1703
  (G : Type) `{Magma G} (h : Equation1704 G) : Equation1703 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1712_implies_Equation1711
  (G : Type) `{Magma G} (h : Equation1712 G) : Equation1711 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1713_implies_Equation1709
  (G : Type) `{Magma G} (h : Equation1713 G) : Equation1709 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1715_implies_Equation1711
  (G : Type) `{Magma G} (h : Equation1715 G) : Equation1711 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1737_implies_Equation1736
  (G : Type) `{Magma G} (h : Equation1737 G) : Equation1736 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1745_implies_Equation1744
  (G : Type) `{Magma G} (h : Equation1745 G) : Equation1744 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1749_implies_Equation1748
  (G : Type) `{Magma G} (h : Equation1749 G) : Equation1748 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1751_implies_Equation1747
  (G : Type) `{Magma G} (h : Equation1751 G) : Equation1747 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1779_implies_Equation1778
  (G : Type) `{Magma G} (h : Equation1779 G) : Equation1778 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1783_implies_Equation1782
  (G : Type) `{Magma G} (h : Equation1783 G) : Equation1782 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1785_implies_Equation1781
  (G : Type) `{Magma G} (h : Equation1785 G) : Equation1781 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1786_implies_Equation1782
  (G : Type) `{Magma G} (h : Equation1786 G) : Equation1782 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1787_implies_Equation1782
  (G : Type) `{Magma G} (h : Equation1787 G) : Equation1782 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1792_implies_Equation1791
  (G : Type) `{Magma G} (h : Equation1792 G) : Equation1791 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1796_implies_Equation1795
  (G : Type) `{Magma G} (h : Equation1796 G) : Equation1795 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1800_implies_Equation1799
  (G : Type) `{Magma G} (h : Equation1800 G) : Equation1799 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1802_implies_Equation1798
  (G : Type) `{Magma G} (h : Equation1802 G) : Equation1798 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1807_implies_Equation1790
  (G : Type) `{Magma G} (h : Equation1807 G) : Equation1790 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1816_implies_Equation1797
  (G : Type) `{Magma G} (h : Equation1816 G) : Equation1797 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1846_implies_Equation1845
  (G : Type) `{Magma G} (h : Equation1846 G) : Equation1845 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1856_implies_Equation1855
  (G : Type) `{Magma G} (h : Equation1856 G) : Equation1855 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1878_implies_Equation1877
  (G : Type) `{Magma G} (h : Equation1878 G) : Equation1877 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1879_implies_Equation1875
  (G : Type) `{Magma G} (h : Equation1879 G) : Equation1875 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1893_implies_Equation1892
  (G : Type) `{Magma G} (h : Equation1893 G) : Equation1892 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1907_implies_Equation1906
  (G : Type) `{Magma G} (h : Equation1907 G) : Equation1906 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1915_implies_Equation1914
  (G : Type) `{Magma G} (h : Equation1915 G) : Equation1914 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1918_implies_Equation1914
  (G : Type) `{Magma G} (h : Equation1918 G) : Equation1914 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1919_implies_Equation1914
  (G : Type) `{Magma G} (h : Equation1919 G) : Equation1914 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1940_implies_Equation1939
  (G : Type) `{Magma G} (h : Equation1940 G) : Equation1939 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1948_implies_Equation1947
  (G : Type) `{Magma G} (h : Equation1948 G) : Equation1947 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1952_implies_Equation1951
  (G : Type) `{Magma G} (h : Equation1952 G) : Equation1951 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1954_implies_Equation1950
  (G : Type) `{Magma G} (h : Equation1954 G) : Equation1950 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1961_implies_Equation1960
  (G : Type) `{Magma G} (h : Equation1961 G) : Equation1960 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1969_implies_Equation1968
  (G : Type) `{Magma G} (h : Equation1969 G) : Equation1968 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1970_implies_Equation1966
  (G : Type) `{Magma G} (h : Equation1970 G) : Equation1966 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1982_implies_Equation1981
  (G : Type) `{Magma G} (h : Equation1982 G) : Equation1981 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1995_implies_Equation1994
  (G : Type) `{Magma G} (h : Equation1995 G) : Equation1994 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation1999_implies_Equation1998
  (G : Type) `{Magma G} (h : Equation1999 G) : Equation1998 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2003_implies_Equation2002
  (G : Type) `{Magma G} (h : Equation2003 G) : Equation2002 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2009_implies_Equation1992
  (G : Type) `{Magma G} (h : Equation2009 G) : Equation1992 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2011_implies_Equation1994
  (G : Type) `{Magma G} (h : Equation2011 G) : Equation1994 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2016_implies_Equation1998
  (G : Type) `{Magma G} (h : Equation2016 G) : Equation1998 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2017_implies_Equation1998
  (G : Type) `{Magma G} (h : Equation2017 G) : Equation1998 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2024_implies_Equation2000
  (G : Type) `{Magma G} (h : Equation2024 G) : Equation2000 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2049_implies_Equation2048
  (G : Type) `{Magma G} (h : Equation2049 G) : Equation2048 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2059_implies_Equation2058
  (G : Type) `{Magma G} (h : Equation2059 G) : Equation2058 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2073_implies_Equation2072
  (G : Type) `{Magma G} (h : Equation2073 G) : Equation2072 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2081_implies_Equation2080
  (G : Type) `{Magma G} (h : Equation2081 G) : Equation2080 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2082_implies_Equation2078
  (G : Type) `{Magma G} (h : Equation2082 G) : Equation2078 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2118_implies_Equation2117
  (G : Type) `{Magma G} (h : Equation2118 G) : Equation2117 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2121_implies_Equation2117
  (G : Type) `{Magma G} (h : Equation2121 G) : Equation2117 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2143_implies_Equation2142
  (G : Type) `{Magma G} (h : Equation2143 G) : Equation2142 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2151_implies_Equation2150
  (G : Type) `{Magma G} (h : Equation2151 G) : Equation2150 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2155_implies_Equation2154
  (G : Type) `{Magma G} (h : Equation2155 G) : Equation2154 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2158_implies_Equation2154
  (G : Type) `{Magma G} (h : Equation2158 G) : Equation2154 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2159_implies_Equation2154
  (G : Type) `{Magma G} (h : Equation2159 G) : Equation2154 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2164_implies_Equation2163
  (G : Type) `{Magma G} (h : Equation2164 G) : Equation2163 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2176_implies_Equation2171
  (G : Type) `{Magma G} (h : Equation2176 G) : Equation2171 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2185_implies_Equation2184
  (G : Type) `{Magma G} (h : Equation2185 G) : Equation2184 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2189_implies_Equation2188
  (G : Type) `{Magma G} (h : Equation2189 G) : Equation2188 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2190_implies_Equation2186
  (G : Type) `{Magma G} (h : Equation2190 G) : Equation2186 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2192_implies_Equation2188
  (G : Type) `{Magma G} (h : Equation2192 G) : Equation2188 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2193_implies_Equation2188
  (G : Type) `{Magma G} (h : Equation2193 G) : Equation2188 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2202_implies_Equation2201
  (G : Type) `{Magma G} (h : Equation2202 G) : Equation2201 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2206_implies_Equation2205
  (G : Type) `{Magma G} (h : Equation2206 G) : Equation2205 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2209_implies_Equation2205
  (G : Type) `{Magma G} (h : Equation2209 G) : Equation2205 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2210_implies_Equation2205
  (G : Type) `{Magma G} (h : Equation2210 G) : Equation2205 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2215_implies_Equation2197
  (G : Type) `{Magma G} (h : Equation2215 G) : Equation2197 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2218_implies_Equation2200
  (G : Type) `{Magma G} (h : Equation2218 G) : Equation2200 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2219_implies_Equation2201
  (G : Type) `{Magma G} (h : Equation2219 G) : Equation2201 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2220_implies_Equation2201
  (G : Type) `{Magma G} (h : Equation2220 G) : Equation2201 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2223_implies_Equation2204
  (G : Type) `{Magma G} (h : Equation2223 G) : Equation2204 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2224_implies_Equation2205
  (G : Type) `{Magma G} (h : Equation2224 G) : Equation2205 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2225_implies_Equation2205
  (G : Type) `{Magma G} (h : Equation2225 G) : Equation2205 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2227_implies_Equation2203
  (G : Type) `{Magma G} (h : Equation2227 G) : Equation2203 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2229_implies_Equation2205
  (G : Type) `{Magma G} (h : Equation2229 G) : Equation2205 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2230_implies_Equation2205
  (G : Type) `{Magma G} (h : Equation2230 G) : Equation2205 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2252_implies_Equation2251
  (G : Type) `{Magma G} (h : Equation2252 G) : Equation2251 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2285_implies_Equation2281
  (G : Type) `{Magma G} (h : Equation2285 G) : Equation2281 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2286_implies_Equation2282
  (G : Type) `{Magma G} (h : Equation2286 G) : Equation2282 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2287_implies_Equation2283
  (G : Type) `{Magma G} (h : Equation2287 G) : Equation2283 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2299_implies_Equation2298
  (G : Type) `{Magma G} (h : Equation2299 G) : Equation2298 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2322_implies_Equation2318
  (G : Type) `{Magma G} (h : Equation2322 G) : Equation2318 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2324_implies_Equation2320
  (G : Type) `{Magma G} (h : Equation2324 G) : Equation2320 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2346_implies_Equation2345
  (G : Type) `{Magma G} (h : Equation2346 G) : Equation2345 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2354_implies_Equation2353
  (G : Type) `{Magma G} (h : Equation2354 G) : Equation2353 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2358_implies_Equation2357
  (G : Type) `{Magma G} (h : Equation2358 G) : Equation2357 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2375_implies_Equation2374
  (G : Type) `{Magma G} (h : Equation2375 G) : Equation2374 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2376_implies_Equation2372
  (G : Type) `{Magma G} (h : Equation2376 G) : Equation2372 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2388_implies_Equation2387
  (G : Type) `{Magma G} (h : Equation2388 G) : Equation2387 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2392_implies_Equation2391
  (G : Type) `{Magma G} (h : Equation2392 G) : Equation2391 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2405_implies_Equation2404
  (G : Type) `{Magma G} (h : Equation2405 G) : Equation2404 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2409_implies_Equation2408
  (G : Type) `{Magma G} (h : Equation2409 G) : Equation2408 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2415_implies_Equation2398
  (G : Type) `{Magma G} (h : Equation2415 G) : Equation2398 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2417_implies_Equation2400
  (G : Type) `{Magma G} (h : Equation2417 G) : Equation2400 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2420_implies_Equation2402
  (G : Type) `{Magma G} (h : Equation2420 G) : Equation2402 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2475_implies_Equation2474
  (G : Type) `{Magma G} (h : Equation2475 G) : Equation2474 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2488_implies_Equation2484
  (G : Type) `{Magma G} (h : Equation2488 G) : Equation2484 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2491_implies_Equation2486
  (G : Type) `{Magma G} (h : Equation2491 G) : Equation2486 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2502_implies_Equation2501
  (G : Type) `{Magma G} (h : Equation2502 G) : Equation2501 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2516_implies_Equation2515
  (G : Type) `{Magma G} (h : Equation2516 G) : Equation2515 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2524_implies_Equation2523
  (G : Type) `{Magma G} (h : Equation2524 G) : Equation2523 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2525_implies_Equation2521
  (G : Type) `{Magma G} (h : Equation2525 G) : Equation2521 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2549_implies_Equation2548
  (G : Type) `{Magma G} (h : Equation2549 G) : Equation2548 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2557_implies_Equation2556
  (G : Type) `{Magma G} (h : Equation2557 G) : Equation2556 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2561_implies_Equation2560
  (G : Type) `{Magma G} (h : Equation2561 G) : Equation2560 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2564_implies_Equation2560
  (G : Type) `{Magma G} (h : Equation2564 G) : Equation2560 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2565_implies_Equation2560
  (G : Type) `{Magma G} (h : Equation2565 G) : Equation2560 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2570_implies_Equation2569
  (G : Type) `{Magma G} (h : Equation2570 G) : Equation2569 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2579_implies_Equation2575
  (G : Type) `{Magma G} (h : Equation2579 G) : Equation2575 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2591_implies_Equation2590
  (G : Type) `{Magma G} (h : Equation2591 G) : Equation2590 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2595_implies_Equation2594
  (G : Type) `{Magma G} (h : Equation2595 G) : Equation2594 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2596_implies_Equation2592
  (G : Type) `{Magma G} (h : Equation2596 G) : Equation2592 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2598_implies_Equation2594
  (G : Type) `{Magma G} (h : Equation2598 G) : Equation2594 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2599_implies_Equation2594
  (G : Type) `{Magma G} (h : Equation2599 G) : Equation2594 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2604_implies_Equation2603
  (G : Type) `{Magma G} (h : Equation2604 G) : Equation2603 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2608_implies_Equation2607
  (G : Type) `{Magma G} (h : Equation2608 G) : Equation2607 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2612_implies_Equation2611
  (G : Type) `{Magma G} (h : Equation2612 G) : Equation2611 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2613_implies_Equation2609
  (G : Type) `{Magma G} (h : Equation2613 G) : Equation2609 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2615_implies_Equation2611
  (G : Type) `{Magma G} (h : Equation2615 G) : Equation2611 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2616_implies_Equation2611
  (G : Type) `{Magma G} (h : Equation2616 G) : Equation2611 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2618_implies_Equation2601
  (G : Type) `{Magma G} (h : Equation2618 G) : Equation2601 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2630_implies_Equation2611
  (G : Type) `{Magma G} (h : Equation2630 G) : Equation2611 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2631_implies_Equation2611
  (G : Type) `{Magma G} (h : Equation2631 G) : Equation2611 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2635_implies_Equation2611
  (G : Type) `{Magma G} (h : Equation2635 G) : Equation2611 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2636_implies_Equation2611
  (G : Type) `{Magma G} (h : Equation2636 G) : Equation2611 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2658_implies_Equation2657
  (G : Type) `{Magma G} (h : Equation2658 G) : Equation2657 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2668_implies_Equation2667
  (G : Type) `{Magma G} (h : Equation2668 G) : Equation2667 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2682_implies_Equation2681
  (G : Type) `{Magma G} (h : Equation2682 G) : Equation2681 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2691_implies_Equation2687
  (G : Type) `{Magma G} (h : Equation2691 G) : Equation2687 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2693_implies_Equation2689
  (G : Type) `{Magma G} (h : Equation2693 G) : Equation2689 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2719_implies_Equation2718
  (G : Type) `{Magma G} (h : Equation2719 G) : Equation2718 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2727_implies_Equation2726
  (G : Type) `{Magma G} (h : Equation2727 G) : Equation2726 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2730_implies_Equation2726
  (G : Type) `{Magma G} (h : Equation2730 G) : Equation2726 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2731_implies_Equation2726
  (G : Type) `{Magma G} (h : Equation2731 G) : Equation2726 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2752_implies_Equation2751
  (G : Type) `{Magma G} (h : Equation2752 G) : Equation2751 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2760_implies_Equation2759
  (G : Type) `{Magma G} (h : Equation2760 G) : Equation2759 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2766_implies_Equation2762
  (G : Type) `{Magma G} (h : Equation2766 G) : Equation2762 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2782_implies_Equation2778
  (G : Type) `{Magma G} (h : Equation2782 G) : Equation2778 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2785_implies_Equation2780
  (G : Type) `{Magma G} (h : Equation2785 G) : Equation2780 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2794_implies_Equation2793
  (G : Type) `{Magma G} (h : Equation2794 G) : Equation2793 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2798_implies_Equation2797
  (G : Type) `{Magma G} (h : Equation2798 G) : Equation2797 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2801_implies_Equation2797
  (G : Type) `{Magma G} (h : Equation2801 G) : Equation2797 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2802_implies_Equation2797
  (G : Type) `{Magma G} (h : Equation2802 G) : Equation2797 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2811_implies_Equation2810
  (G : Type) `{Magma G} (h : Equation2811 G) : Equation2810 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2817_implies_Equation2813
  (G : Type) `{Magma G} (h : Equation2817 G) : Equation2813 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2823_implies_Equation2806
  (G : Type) `{Magma G} (h : Equation2823 G) : Equation2806 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2824_implies_Equation2806
  (G : Type) `{Magma G} (h : Equation2824 G) : Equation2806 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2826_implies_Equation2808
  (G : Type) `{Magma G} (h : Equation2826 G) : Equation2808 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2828_implies_Equation2810
  (G : Type) `{Magma G} (h : Equation2828 G) : Equation2810 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2829_implies_Equation2810
  (G : Type) `{Magma G} (h : Equation2829 G) : Equation2810 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2836_implies_Equation2812
  (G : Type) `{Magma G} (h : Equation2836 G) : Equation2812 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2839_implies_Equation2814
  (G : Type) `{Magma G} (h : Equation2839 G) : Equation2814 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2894_implies_Equation2890
  (G : Type) `{Magma G} (h : Equation2894 G) : Equation2890 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2897_implies_Equation2892
  (G : Type) `{Magma G} (h : Equation2897 G) : Equation2892 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2930_implies_Equation2929
  (G : Type) `{Magma G} (h : Equation2930 G) : Equation2929 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2931_implies_Equation2927
  (G : Type) `{Magma G} (h : Equation2931 G) : Equation2927 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2955_implies_Equation2954
  (G : Type) `{Magma G} (h : Equation2955 G) : Equation2954 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2963_implies_Equation2962
  (G : Type) `{Magma G} (h : Equation2963 G) : Equation2962 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2967_implies_Equation2966
  (G : Type) `{Magma G} (h : Equation2967 G) : Equation2966 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2984_implies_Equation2983
  (G : Type) `{Magma G} (h : Equation2984 G) : Equation2983 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2985_implies_Equation2981
  (G : Type) `{Magma G} (h : Equation2985 G) : Equation2981 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2987_implies_Equation2983
  (G : Type) `{Magma G} (h : Equation2987 G) : Equation2983 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2988_implies_Equation2983
  (G : Type) `{Magma G} (h : Equation2988 G) : Equation2983 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation2997_implies_Equation2996
  (G : Type) `{Magma G} (h : Equation2997 G) : Equation2996 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3001_implies_Equation3000
  (G : Type) `{Magma G} (h : Equation3001 G) : Equation3000 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3010_implies_Equation3009
  (G : Type) `{Magma G} (h : Equation3010 G) : Equation3009 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3014_implies_Equation3013
  (G : Type) `{Magma G} (h : Equation3014 G) : Equation3013 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3018_implies_Equation3017
  (G : Type) `{Magma G} (h : Equation3018 G) : Equation3017 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3019_implies_Equation3015
  (G : Type) `{Magma G} (h : Equation3019 G) : Equation3015 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3030_implies_Equation3012
  (G : Type) `{Magma G} (h : Equation3030 G) : Equation3012 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3041_implies_Equation3017
  (G : Type) `{Magma G} (h : Equation3041 G) : Equation3017 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3042_implies_Equation3017
  (G : Type) `{Magma G} (h : Equation3042 G) : Equation3017 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3074_implies_Equation3073
  (G : Type) `{Magma G} (h : Equation3074 G) : Equation3073 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3088_implies_Equation3087
  (G : Type) `{Magma G} (h : Equation3088 G) : Equation3087 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3096_implies_Equation3095
  (G : Type) `{Magma G} (h : Equation3096 G) : Equation3095 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3097_implies_Equation3093
  (G : Type) `{Magma G} (h : Equation3097 G) : Equation3093 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3111_implies_Equation3110
  (G : Type) `{Magma G} (h : Equation3111 G) : Equation3110 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3125_implies_Equation3124
  (G : Type) `{Magma G} (h : Equation3125 G) : Equation3124 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3136_implies_Equation3132
  (G : Type) `{Magma G} (h : Equation3136 G) : Equation3132 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3158_implies_Equation3157
  (G : Type) `{Magma G} (h : Equation3158 G) : Equation3157 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3170_implies_Equation3169
  (G : Type) `{Magma G} (h : Equation3170 G) : Equation3169 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3179_implies_Equation3178
  (G : Type) `{Magma G} (h : Equation3179 G) : Equation3178 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3188_implies_Equation3184
  (G : Type) `{Magma G} (h : Equation3188 G) : Equation3184 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3190_implies_Equation3186
  (G : Type) `{Magma G} (h : Equation3190 G) : Equation3186 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3204_implies_Equation3203
  (G : Type) `{Magma G} (h : Equation3204 G) : Equation3203 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3217_implies_Equation3216
  (G : Type) `{Magma G} (h : Equation3217 G) : Equation3216 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3227_implies_Equation3210
  (G : Type) `{Magma G} (h : Equation3227 G) : Equation3210 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3230_implies_Equation3212
  (G : Type) `{Magma G} (h : Equation3230 G) : Equation3212 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3232_implies_Equation3214
  (G : Type) `{Magma G} (h : Equation3232 G) : Equation3214 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3235_implies_Equation3216
  (G : Type) `{Magma G} (h : Equation3235 G) : Equation3216 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3240_implies_Equation3220
  (G : Type) `{Magma G} (h : Equation3240 G) : Equation3220 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3242_implies_Equation3218
  (G : Type) `{Magma G} (h : Equation3242 G) : Equation3218 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3295_implies_Equation3294
  (G : Type) `{Magma G} (h : Equation3295 G) : Equation3294 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3300_implies_Equation3296
  (G : Type) `{Magma G} (h : Equation3300 G) : Equation3296 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3301_implies_Equation3297
  (G : Type) `{Magma G} (h : Equation3301 G) : Equation3297 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3324_implies_Equation3323
  (G : Type) `{Magma G} (h : Equation3324 G) : Equation3323 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3328_implies_Equation3327
  (G : Type) `{Magma G} (h : Equation3328 G) : Equation3327 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3337_implies_Equation3333
  (G : Type) `{Magma G} (h : Equation3337 G) : Equation3333 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3338_implies_Equation3334
  (G : Type) `{Magma G} (h : Equation3338 G) : Equation3334 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3340_implies_Equation3335
  (G : Type) `{Magma G} (h : Equation3340 G) : Equation3335 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3351_implies_Equation3350
  (G : Type) `{Magma G} (h : Equation3351 G) : Equation3350 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3361_implies_Equation3360
  (G : Type) `{Magma G} (h : Equation3361 G) : Equation3360 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3369_implies_Equation3368
  (G : Type) `{Magma G} (h : Equation3369 G) : Equation3368 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3373_implies_Equation3372
  (G : Type) `{Magma G} (h : Equation3373 G) : Equation3372 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3375_implies_Equation3371
  (G : Type) `{Magma G} (h : Equation3375 G) : Equation3371 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3377_implies_Equation3372
  (G : Type) `{Magma G} (h : Equation3377 G) : Equation3372 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3382_implies_Equation3381
  (G : Type) `{Magma G} (h : Equation3382 G) : Equation3381 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3392_implies_Equation3388
  (G : Type) `{Magma G} (h : Equation3392 G) : Equation3388 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3394_implies_Equation3389
  (G : Type) `{Magma G} (h : Equation3394 G) : Equation3389 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3403_implies_Equation3402
  (G : Type) `{Magma G} (h : Equation3403 G) : Equation3402 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3407_implies_Equation3406
  (G : Type) `{Magma G} (h : Equation3407 G) : Equation3406 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3409_implies_Equation3405
  (G : Type) `{Magma G} (h : Equation3409 G) : Equation3405 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3416_implies_Equation3415
  (G : Type) `{Magma G} (h : Equation3416 G) : Equation3415 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3420_implies_Equation3419
  (G : Type) `{Magma G} (h : Equation3420 G) : Equation3419 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3428_implies_Equation3423
  (G : Type) `{Magma G} (h : Equation3428 G) : Equation3423 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3430_implies_Equation3413
  (G : Type) `{Magma G} (h : Equation3430 G) : Equation3413 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3431_implies_Equation3414
  (G : Type) `{Magma G} (h : Equation3431 G) : Equation3414 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3433_implies_Equation3415
  (G : Type) `{Magma G} (h : Equation3433 G) : Equation3415 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3436_implies_Equation3418
  (G : Type) `{Magma G} (h : Equation3436 G) : Equation3418 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3438_implies_Equation3419
  (G : Type) `{Magma G} (h : Equation3438 G) : Equation3419 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3441_implies_Equation3422
  (G : Type) `{Magma G} (h : Equation3441 G) : Equation3422 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3442_implies_Equation3423
  (G : Type) `{Magma G} (h : Equation3442 G) : Equation3423 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3446_implies_Equation3422
  (G : Type) `{Magma G} (h : Equation3446 G) : Equation3422 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3448_implies_Equation3423
  (G : Type) `{Magma G} (h : Equation3448 G) : Equation3423 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3470_implies_Equation3469
  (G : Type) `{Magma G} (h : Equation3470 G) : Equation3469 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3498_implies_Equation3497
  (G : Type) `{Magma G} (h : Equation3498 G) : Equation3497 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3502_implies_Equation3501
  (G : Type) `{Magma G} (h : Equation3502 G) : Equation3501 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3505_implies_Equation3501
  (G : Type) `{Magma G} (h : Equation3505 G) : Equation3501 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3506_implies_Equation3501
  (G : Type) `{Magma G} (h : Equation3506 G) : Equation3501 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3517_implies_Equation3516
  (G : Type) `{Magma G} (h : Equation3517 G) : Equation3516 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3527_implies_Equation3526
  (G : Type) `{Magma G} (h : Equation3527 G) : Equation3526 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3531_implies_Equation3530
  (G : Type) `{Magma G} (h : Equation3531 G) : Equation3530 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3535_implies_Equation3534
  (G : Type) `{Magma G} (h : Equation3535 G) : Equation3534 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3539_implies_Equation3538
  (G : Type) `{Magma G} (h : Equation3539 G) : Equation3538 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3540_implies_Equation3536
  (G : Type) `{Magma G} (h : Equation3540 G) : Equation3536 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3541_implies_Equation3537
  (G : Type) `{Magma G} (h : Equation3541 G) : Equation3537 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3564_implies_Equation3563
  (G : Type) `{Magma G} (h : Equation3564 G) : Equation3563 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3568_implies_Equation3567
  (G : Type) `{Magma G} (h : Equation3568 G) : Equation3567 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3572_implies_Equation3571
  (G : Type) `{Magma G} (h : Equation3572 G) : Equation3571 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3576_implies_Equation3575
  (G : Type) `{Magma G} (h : Equation3576 G) : Equation3575 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3593_implies_Equation3592
  (G : Type) `{Magma G} (h : Equation3593 G) : Equation3592 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3606_implies_Equation3605
  (G : Type) `{Magma G} (h : Equation3606 G) : Equation3605 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3610_implies_Equation3609
  (G : Type) `{Magma G} (h : Equation3610 G) : Equation3609 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3612_implies_Equation3608
  (G : Type) `{Magma G} (h : Equation3612 G) : Equation3608 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3613_implies_Equation3609
  (G : Type) `{Magma G} (h : Equation3613 G) : Equation3609 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3614_implies_Equation3609
  (G : Type) `{Magma G} (h : Equation3614 G) : Equation3609 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3623_implies_Equation3622
  (G : Type) `{Magma G} (h : Equation3623 G) : Equation3622 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3627_implies_Equation3626
  (G : Type) `{Magma G} (h : Equation3627 G) : Equation3626 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3629_implies_Equation3625
  (G : Type) `{Magma G} (h : Equation3629 G) : Equation3625 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3634_implies_Equation3617
  (G : Type) `{Magma G} (h : Equation3634 G) : Equation3617 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3636_implies_Equation3618
  (G : Type) `{Magma G} (h : Equation3636 G) : Equation3618 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3639_implies_Equation3621
  (G : Type) `{Magma G} (h : Equation3639 G) : Equation3621 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3640_implies_Equation3622
  (G : Type) `{Magma G} (h : Equation3640 G) : Equation3622 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3641_implies_Equation3622
  (G : Type) `{Magma G} (h : Equation3641 G) : Equation3622 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3644_implies_Equation3625
  (G : Type) `{Magma G} (h : Equation3644 G) : Equation3625 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3648_implies_Equation3624
  (G : Type) `{Magma G} (h : Equation3648 G) : Equation3624 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3650_implies_Equation3626
  (G : Type) `{Magma G} (h : Equation3650 G) : Equation3626 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3651_implies_Equation3626
  (G : Type) `{Magma G} (h : Equation3651 G) : Equation3626 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3673_implies_Equation3672
  (G : Type) `{Magma G} (h : Equation3673 G) : Equation3672 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3705_implies_Equation3704
  (G : Type) `{Magma G} (h : Equation3705 G) : Equation3704 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3706_implies_Equation3702
  (G : Type) `{Magma G} (h : Equation3706 G) : Equation3702 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3707_implies_Equation3703
  (G : Type) `{Magma G} (h : Equation3707 G) : Equation3703 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3708_implies_Equation3704
  (G : Type) `{Magma G} (h : Equation3708 G) : Equation3704 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3709_implies_Equation3704
  (G : Type) `{Magma G} (h : Equation3709 G) : Equation3704 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3720_implies_Equation3719
  (G : Type) `{Magma G} (h : Equation3720 G) : Equation3719 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3730_implies_Equation3729
  (G : Type) `{Magma G} (h : Equation3730 G) : Equation3729 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3734_implies_Equation3733
  (G : Type) `{Magma G} (h : Equation3734 G) : Equation3733 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3738_implies_Equation3737
  (G : Type) `{Magma G} (h : Equation3738 G) : Equation3737 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3742_implies_Equation3741
  (G : Type) `{Magma G} (h : Equation3742 G) : Equation3741 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3744_implies_Equation3740
  (G : Type) `{Magma G} (h : Equation3744 G) : Equation3740 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3745_implies_Equation3741
  (G : Type) `{Magma G} (h : Equation3745 G) : Equation3741 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3767_implies_Equation3766
  (G : Type) `{Magma G} (h : Equation3767 G) : Equation3766 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3775_implies_Equation3774
  (G : Type) `{Magma G} (h : Equation3775 G) : Equation3774 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3781_implies_Equation3777
  (G : Type) `{Magma G} (h : Equation3781 G) : Equation3777 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3783_implies_Equation3778
  (G : Type) `{Magma G} (h : Equation3783 G) : Equation3778 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3788_implies_Equation3787
  (G : Type) `{Magma G} (h : Equation3788 G) : Equation3787 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3797_implies_Equation3793
  (G : Type) `{Magma G} (h : Equation3797 G) : Equation3793 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3798_implies_Equation3794
  (G : Type) `{Magma G} (h : Equation3798 G) : Equation3794 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3799_implies_Equation3795
  (G : Type) `{Magma G} (h : Equation3799 G) : Equation3795 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3800_implies_Equation3795
  (G : Type) `{Magma G} (h : Equation3800 G) : Equation3795 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3809_implies_Equation3808
  (G : Type) `{Magma G} (h : Equation3809 G) : Equation3808 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3815_implies_Equation3811
  (G : Type) `{Magma G} (h : Equation3815 G) : Equation3811 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3817_implies_Equation3812
  (G : Type) `{Magma G} (h : Equation3817 G) : Equation3812 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3822_implies_Equation3821
  (G : Type) `{Magma G} (h : Equation3822 G) : Equation3821 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3826_implies_Equation3825
  (G : Type) `{Magma G} (h : Equation3826 G) : Equation3825 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3830_implies_Equation3829
  (G : Type) `{Magma G} (h : Equation3830 G) : Equation3829 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3832_implies_Equation3828
  (G : Type) `{Magma G} (h : Equation3832 G) : Equation3828 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3836_implies_Equation3819
  (G : Type) `{Magma G} (h : Equation3836 G) : Equation3819 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3837_implies_Equation3820
  (G : Type) `{Magma G} (h : Equation3837 G) : Equation3820 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3839_implies_Equation3821
  (G : Type) `{Magma G} (h : Equation3839 G) : Equation3821 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3842_implies_Equation3824
  (G : Type) `{Magma G} (h : Equation3842 G) : Equation3824 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3876_implies_Equation3875
  (G : Type) `{Magma G} (h : Equation3876 G) : Equation3875 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3886_implies_Equation3885
  (G : Type) `{Magma G} (h : Equation3886 G) : Equation3885 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3896_implies_Equation3895
  (G : Type) `{Magma G} (h : Equation3896 G) : Equation3895 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3904_implies_Equation3903
  (G : Type) `{Magma G} (h : Equation3904 G) : Equation3903 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3909_implies_Equation3905
  (G : Type) `{Magma G} (h : Equation3909 G) : Equation3905 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3911_implies_Equation3907
  (G : Type) `{Magma G} (h : Equation3911 G) : Equation3907 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3912_implies_Equation3907
  (G : Type) `{Magma G} (h : Equation3912 G) : Equation3907 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3923_implies_Equation3922
  (G : Type) `{Magma G} (h : Equation3923 G) : Equation3922 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3933_implies_Equation3932
  (G : Type) `{Magma G} (h : Equation3933 G) : Equation3932 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3937_implies_Equation3936
  (G : Type) `{Magma G} (h : Equation3937 G) : Equation3936 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3945_implies_Equation3944
  (G : Type) `{Magma G} (h : Equation3945 G) : Equation3944 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3946_implies_Equation3942
  (G : Type) `{Magma G} (h : Equation3946 G) : Equation3942 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3947_implies_Equation3943
  (G : Type) `{Magma G} (h : Equation3947 G) : Equation3943 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3948_implies_Equation3944
  (G : Type) `{Magma G} (h : Equation3948 G) : Equation3944 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3949_implies_Equation3944
  (G : Type) `{Magma G} (h : Equation3949 G) : Equation3944 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3970_implies_Equation3969
  (G : Type) `{Magma G} (h : Equation3970 G) : Equation3969 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3978_implies_Equation3977
  (G : Type) `{Magma G} (h : Equation3978 G) : Equation3977 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3984_implies_Equation3980
  (G : Type) `{Magma G} (h : Equation3984 G) : Equation3980 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3991_implies_Equation3990
  (G : Type) `{Magma G} (h : Equation3991 G) : Equation3990 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation3999_implies_Equation3998
  (G : Type) `{Magma G} (h : Equation3999 G) : Equation3998 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4000_implies_Equation3996
  (G : Type) `{Magma G} (h : Equation4000 G) : Equation3996 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4001_implies_Equation3997
  (G : Type) `{Magma G} (h : Equation4001 G) : Equation3997 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4002_implies_Equation3998
  (G : Type) `{Magma G} (h : Equation4002 G) : Equation3998 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4012_implies_Equation4011
  (G : Type) `{Magma G} (h : Equation4012 G) : Equation4011 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4018_implies_Equation4014
  (G : Type) `{Magma G} (h : Equation4018 G) : Equation4014 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4019_implies_Equation4015
  (G : Type) `{Magma G} (h : Equation4019 G) : Equation4015 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4025_implies_Equation4024
  (G : Type) `{Magma G} (h : Equation4025 G) : Equation4024 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4033_implies_Equation4032
  (G : Type) `{Magma G} (h : Equation4033 G) : Equation4032 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4035_implies_Equation4031
  (G : Type) `{Magma G} (h : Equation4035 G) : Equation4031 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4040_implies_Equation4023
  (G : Type) `{Magma G} (h : Equation4040 G) : Equation4023 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4041_implies_Equation4024
  (G : Type) `{Magma G} (h : Equation4041 G) : Equation4024 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4079_implies_Equation4078
  (G : Type) `{Magma G} (h : Equation4079 G) : Equation4078 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4103_implies_Equation4102
  (G : Type) `{Magma G} (h : Equation4103 G) : Equation4102 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4107_implies_Equation4106
  (G : Type) `{Magma G} (h : Equation4107 G) : Equation4106 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4112_implies_Equation4108
  (G : Type) `{Magma G} (h : Equation4112 G) : Equation4108 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4113_implies_Equation4109
  (G : Type) `{Magma G} (h : Equation4113 G) : Equation4109 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4114_implies_Equation4110
  (G : Type) `{Magma G} (h : Equation4114 G) : Equation4110 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4140_implies_Equation4139
  (G : Type) `{Magma G} (h : Equation4140 G) : Equation4139 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4144_implies_Equation4143
  (G : Type) `{Magma G} (h : Equation4144 G) : Equation4143 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4148_implies_Equation4147
  (G : Type) `{Magma G} (h : Equation4148 G) : Equation4147 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4149_implies_Equation4145
  (G : Type) `{Magma G} (h : Equation4149 G) : Equation4145 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4150_implies_Equation4146
  (G : Type) `{Magma G} (h : Equation4150 G) : Equation4146 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4151_implies_Equation4147
  (G : Type) `{Magma G} (h : Equation4151 G) : Equation4147 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4187_implies_Equation4183
  (G : Type) `{Magma G} (h : Equation4187 G) : Equation4183 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4188_implies_Equation4184
  (G : Type) `{Magma G} (h : Equation4188 G) : Equation4184 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4194_implies_Equation4193
  (G : Type) `{Magma G} (h : Equation4194 G) : Equation4193 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4203_implies_Equation4199
  (G : Type) `{Magma G} (h : Equation4203 G) : Equation4199 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4206_implies_Equation4201
  (G : Type) `{Magma G} (h : Equation4206 G) : Equation4201 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4215_implies_Equation4214
  (G : Type) `{Magma G} (h : Equation4215 G) : Equation4214 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4221_implies_Equation4217
  (G : Type) `{Magma G} (h : Equation4221 G) : Equation4217 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4223_implies_Equation4218
  (G : Type) `{Magma G} (h : Equation4223 G) : Equation4218 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4232_implies_Equation4231
  (G : Type) `{Magma G} (h : Equation4232 G) : Equation4231 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4236_implies_Equation4235
  (G : Type) `{Magma G} (h : Equation4236 G) : Equation4235 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4237_implies_Equation4233
  (G : Type) `{Magma G} (h : Equation4237 G) : Equation4233 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4238_implies_Equation4234
  (G : Type) `{Magma G} (h : Equation4238 G) : Equation4234 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4239_implies_Equation4235
  (G : Type) `{Magma G} (h : Equation4239 G) : Equation4235 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4240_implies_Equation4235
  (G : Type) `{Magma G} (h : Equation4240 G) : Equation4235 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4243_implies_Equation4226
  (G : Type) `{Magma G} (h : Equation4243 G) : Equation4226 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4245_implies_Equation4227
  (G : Type) `{Magma G} (h : Equation4245 G) : Equation4227 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4247_implies_Equation4229
  (G : Type) `{Magma G} (h : Equation4247 G) : Equation4229 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4250_implies_Equation4231
  (G : Type) `{Magma G} (h : Equation4250 G) : Equation4231 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4255_implies_Equation4235
  (G : Type) `{Magma G} (h : Equation4255 G) : Equation4235 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4259_implies_Equation4235
  (G : Type) `{Magma G} (h : Equation4259 G) : Equation4235 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4260_implies_Equation4235
  (G : Type) `{Magma G} (h : Equation4260 G) : Equation4235 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4302_implies_Equation4301
  (G : Type) `{Magma G} (h : Equation4302 G) : Equation4301 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4319_implies_Equation4318
  (G : Type) `{Magma G} (h : Equation4319 G) : Equation4318 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4366_implies_Equation4364
  (G : Type) `{Magma G} (h : Equation4366 G) : Equation4364 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4404_implies_Equation4403
  (G : Type) `{Magma G} (h : Equation4404 G) : Equation4403 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4418_implies_Equation4417
  (G : Type) `{Magma G} (h : Equation4418 G) : Equation4417 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4426_implies_Equation4425
  (G : Type) `{Magma G} (h : Equation4426 G) : Equation4425 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4427_implies_Equation4423
  (G : Type) `{Magma G} (h : Equation4427 G) : Equation4423 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4428_implies_Equation4424
  (G : Type) `{Magma G} (h : Equation4428 G) : Equation4424 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4429_implies_Equation4425
  (G : Type) `{Magma G} (h : Equation4429 G) : Equation4425 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4430_implies_Equation4425
  (G : Type) `{Magma G} (h : Equation4430 G) : Equation4425 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4441_implies_Equation4440
  (G : Type) `{Magma G} (h : Equation4441 G) : Equation4440 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4455_implies_Equation4454
  (G : Type) `{Magma G} (h : Equation4455 G) : Equation4454 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4463_implies_Equation4462
  (G : Type) `{Magma G} (h : Equation4463 G) : Equation4462 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4466_implies_Equation4462
  (G : Type) `{Magma G} (h : Equation4466 G) : Equation4462 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4467_implies_Equation4462
  (G : Type) `{Magma G} (h : Equation4467 G) : Equation4462 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4478_implies_Equation4477
  (G : Type) `{Magma G} (h : Equation4478 G) : Equation4477 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4496_implies_Equation4495
  (G : Type) `{Magma G} (h : Equation4496 G) : Equation4495 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4500_implies_Equation4499
  (G : Type) `{Magma G} (h : Equation4500 G) : Equation4499 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4501_implies_Equation4497
  (G : Type) `{Magma G} (h : Equation4501 G) : Equation4497 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4502_implies_Equation4498
  (G : Type) `{Magma G} (h : Equation4502 G) : Equation4498 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4503_implies_Equation4499
  (G : Type) `{Magma G} (h : Equation4503 G) : Equation4499 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4504_implies_Equation4499
  (G : Type) `{Magma G} (h : Equation4504 G) : Equation4499 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4509_implies_Equation4508
  (G : Type) `{Magma G} (h : Equation4509 G) : Equation4508 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4513_implies_Equation4512
  (G : Type) `{Magma G} (h : Equation4513 G) : Equation4512 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4518_implies_Equation4514
  (G : Type) `{Magma G} (h : Equation4518 G) : Equation4514 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4519_implies_Equation4515
  (G : Type) `{Magma G} (h : Equation4519 G) : Equation4515 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4520_implies_Equation4516
  (G : Type) `{Magma G} (h : Equation4520 G) : Equation4516 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4521_implies_Equation4516
  (G : Type) `{Magma G} (h : Equation4521 G) : Equation4516 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4535_implies_Equation4531
  (G : Type) `{Magma G} (h : Equation4535 G) : Equation4531 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4554_implies_Equation4550
  (G : Type) `{Magma G} (h : Equation4554 G) : Equation4550 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4558_implies_Equation4541
  (G : Type) `{Magma G} (h : Equation4558 G) : Equation4541 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4559_implies_Equation4542
  (G : Type) `{Magma G} (h : Equation4559 G) : Equation4542 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4563_implies_Equation4545
  (G : Type) `{Magma G} (h : Equation4563 G) : Equation4545 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4564_implies_Equation4546
  (G : Type) `{Magma G} (h : Equation4564 G) : Equation4546 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4569_implies_Equation4550
  (G : Type) `{Magma G} (h : Equation4569 G) : Equation4550 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4572_implies_Equation4548
  (G : Type) `{Magma G} (h : Equation4572 G) : Equation4548 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4573_implies_Equation4549
  (G : Type) `{Magma G} (h : Equation4573 G) : Equation4549 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4574_implies_Equation4550
  (G : Type) `{Magma G} (h : Equation4574 G) : Equation4550 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4575_implies_Equation4550
  (G : Type) `{Magma G} (h : Equation4575 G) : Equation4550 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4625_implies_Equation4622
  (G : Type) `{Magma G} (h : Equation4625 G) : Equation4622 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4634_implies_Equation4633
  (G : Type) `{Magma G} (h : Equation4634 G) : Equation4633 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4678_implies_Equation4677
  (G : Type) `{Magma G} (h : Equation4678 G) : Equation4677 G.
Proof. intros x y z. exact (h x y z z). Qed.

Theorem Equation4681_implies_Equation4679
  (G : Type) `{Magma G} (h : Equation4681 G) : Equation4679 G.
Proof. intros x y z. exact (h x y z z). Qed.

