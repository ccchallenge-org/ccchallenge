(** * SimpleRewrites/Rewrite_yx_zy

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation27_implies_Equation24
  (G : Type) `{Magma G} (h : Equation27 G) : Equation24 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation34_implies_Equation25
  (G : Type) `{Magma G} (h : Equation34 G) : Equation25 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation41_implies_Equation38
  (G : Type) `{Magma G} (h : Equation41 G) : Equation38 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation42_implies_Equation38
  (G : Type) `{Magma G} (h : Equation42 G) : Equation38 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation45_implies_Equation39
  (G : Type) `{Magma G} (h : Equation45 G) : Equation39 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation51_implies_Equation48
  (G : Type) `{Magma G} (h : Equation51 G) : Equation48 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation58_implies_Equation49
  (G : Type) `{Magma G} (h : Equation58 G) : Equation49 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation74_implies_Equation48
  (G : Type) `{Magma G} (h : Equation74 G) : Equation48 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation164_implies_Equation154
  (G : Type) `{Magma G} (h : Equation164 G) : Equation154 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation171_implies_Equation152
  (G : Type) `{Magma G} (h : Equation171 G) : Equation152 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation207_implies_Equation204
  (G : Type) `{Magma G} (h : Equation207 G) : Equation204 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation262_implies_Equation256
  (G : Type) `{Magma G} (h : Equation262 G) : Equation256 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation278_implies_Equation258
  (G : Type) `{Magma G} (h : Equation278 G) : Equation258 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation311_implies_Equation308
  (G : Type) `{Magma G} (h : Equation311 G) : Equation308 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation317_implies_Equation308
  (G : Type) `{Magma G} (h : Equation317 G) : Equation308 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation318_implies_Equation309
  (G : Type) `{Magma G} (h : Equation318 G) : Equation309 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation319_implies_Equation309
  (G : Type) `{Magma G} (h : Equation319 G) : Equation309 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation320_implies_Equation310
  (G : Type) `{Magma G} (h : Equation320 G) : Equation310 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation329_implies_Equation309
  (G : Type) `{Magma G} (h : Equation329 G) : Equation309 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation343_implies_Equation312
  (G : Type) `{Magma G} (h : Equation343 G) : Equation312 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation363_implies_Equation360
  (G : Type) `{Magma G} (h : Equation363 G) : Equation360 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation370_implies_Equation361
  (G : Type) `{Magma G} (h : Equation370 G) : Equation361 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation371_implies_Equation361
  (G : Type) `{Magma G} (h : Equation371 G) : Equation361 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation372_implies_Equation362
  (G : Type) `{Magma G} (h : Equation372 G) : Equation362 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation379_implies_Equation360
  (G : Type) `{Magma G} (h : Equation379 G) : Equation360 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation381_implies_Equation361
  (G : Type) `{Magma G} (h : Equation381 G) : Equation361 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation415_implies_Equation412
  (G : Type) `{Magma G} (h : Equation415 G) : Equation412 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation422_implies_Equation413
  (G : Type) `{Magma G} (h : Equation422 G) : Equation413 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation432_implies_Equation413
  (G : Type) `{Magma G} (h : Equation432 G) : Equation413 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation443_implies_Equation413
  (G : Type) `{Magma G} (h : Equation443 G) : Equation413 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation444_implies_Equation414
  (G : Type) `{Magma G} (h : Equation444 G) : Equation414 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation450_implies_Equation416
  (G : Type) `{Magma G} (h : Equation450 G) : Equation416 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation452_implies_Equation417
  (G : Type) `{Magma G} (h : Equation452 G) : Equation417 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation455_implies_Equation419
  (G : Type) `{Magma G} (h : Equation455 G) : Equation419 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation481_implies_Equation414
  (G : Type) `{Magma G} (h : Equation481 G) : Equation414 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation489_implies_Equation417
  (G : Type) `{Magma G} (h : Equation489 G) : Equation417 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation528_implies_Equation419
  (G : Type) `{Magma G} (h : Equation528 G) : Equation419 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation556_implies_Equation427
  (G : Type) `{Magma G} (h : Equation556 G) : Equation427 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation562_implies_Equation429
  (G : Type) `{Magma G} (h : Equation562 G) : Equation429 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation575_implies_Equation436
  (G : Type) `{Magma G} (h : Equation575 G) : Equation436 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation621_implies_Equation615
  (G : Type) `{Magma G} (h : Equation621 G) : Equation615 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation624_implies_Equation615
  (G : Type) `{Magma G} (h : Equation624 G) : Equation615 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation625_implies_Equation616
  (G : Type) `{Magma G} (h : Equation625 G) : Equation616 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation626_implies_Equation616
  (G : Type) `{Magma G} (h : Equation626 G) : Equation616 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation635_implies_Equation616
  (G : Type) `{Magma G} (h : Equation635 G) : Equation616 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation645_implies_Equation616
  (G : Type) `{Magma G} (h : Equation645 G) : Equation616 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation646_implies_Equation616
  (G : Type) `{Magma G} (h : Equation646 G) : Equation616 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation647_implies_Equation617
  (G : Type) `{Magma G} (h : Equation647 G) : Equation617 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation653_implies_Equation619
  (G : Type) `{Magma G} (h : Equation653 G) : Equation619 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation655_implies_Equation620
  (G : Type) `{Magma G} (h : Equation655 G) : Equation620 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation657_implies_Equation622
  (G : Type) `{Magma G} (h : Equation657 G) : Equation622 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation658_implies_Equation622
  (G : Type) `{Magma G} (h : Equation658 G) : Equation622 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation690_implies_Equation619
  (G : Type) `{Magma G} (h : Equation690 G) : Equation619 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation692_implies_Equation620
  (G : Type) `{Magma G} (h : Equation692 G) : Equation620 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation695_implies_Equation622
  (G : Type) `{Magma G} (h : Equation695 G) : Equation622 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation711_implies_Equation617
  (G : Type) `{Magma G} (h : Equation711 G) : Equation617 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation723_implies_Equation619
  (G : Type) `{Magma G} (h : Equation723 G) : Equation619 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation731_implies_Equation622
  (G : Type) `{Magma G} (h : Equation731 G) : Equation622 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation746_implies_Equation630
  (G : Type) `{Magma G} (h : Equation746 G) : Equation630 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation749_implies_Equation632
  (G : Type) `{Magma G} (h : Equation749 G) : Equation632 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation765_implies_Equation632
  (G : Type) `{Magma G} (h : Equation765 G) : Equation632 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation775_implies_Equation639
  (G : Type) `{Magma G} (h : Equation775 G) : Equation639 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation778_implies_Equation639
  (G : Type) `{Magma G} (h : Equation778 G) : Equation639 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation821_implies_Equation818
  (G : Type) `{Magma G} (h : Equation821 G) : Equation818 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation828_implies_Equation819
  (G : Type) `{Magma G} (h : Equation828 G) : Equation819 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation834_implies_Equation818
  (G : Type) `{Magma G} (h : Equation834 G) : Equation818 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation837_implies_Equation818
  (G : Type) `{Magma G} (h : Equation837 G) : Equation818 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation838_implies_Equation819
  (G : Type) `{Magma G} (h : Equation838 G) : Equation819 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation839_implies_Equation819
  (G : Type) `{Magma G} (h : Equation839 G) : Equation819 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation840_implies_Equation820
  (G : Type) `{Magma G} (h : Equation840 G) : Equation820 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation844_implies_Equation818
  (G : Type) `{Magma G} (h : Equation844 G) : Equation818 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation847_implies_Equation818
  (G : Type) `{Magma G} (h : Equation847 G) : Equation818 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation848_implies_Equation819
  (G : Type) `{Magma G} (h : Equation848 G) : Equation819 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation850_implies_Equation820
  (G : Type) `{Magma G} (h : Equation850 G) : Equation820 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation852_implies_Equation822
  (G : Type) `{Magma G} (h : Equation852 G) : Equation822 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation854_implies_Equation823
  (G : Type) `{Magma G} (h : Equation854 G) : Equation823 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation856_implies_Equation822
  (G : Type) `{Magma G} (h : Equation856 G) : Equation822 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation858_implies_Equation823
  (G : Type) `{Magma G} (h : Equation858 G) : Equation823 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation860_implies_Equation825
  (G : Type) `{Magma G} (h : Equation860 G) : Equation825 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation861_implies_Equation825
  (G : Type) `{Magma G} (h : Equation861 G) : Equation825 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation874_implies_Equation818
  (G : Type) `{Magma G} (h : Equation874 G) : Equation818 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation898_implies_Equation825
  (G : Type) `{Magma G} (h : Equation898 G) : Equation825 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation934_implies_Equation825
  (G : Type) `{Magma G} (h : Equation934 G) : Equation825 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation949_implies_Equation833
  (G : Type) `{Magma G} (h : Equation949 G) : Equation833 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation960_implies_Equation832
  (G : Type) `{Magma G} (h : Equation960 G) : Equation832 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation964_implies_Equation832
  (G : Type) `{Magma G} (h : Equation964 G) : Equation832 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation968_implies_Equation835
  (G : Type) `{Magma G} (h : Equation968 G) : Equation835 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation979_implies_Equation843
  (G : Type) `{Magma G} (h : Equation979 G) : Equation843 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation981_implies_Equation842
  (G : Type) `{Magma G} (h : Equation981 G) : Equation842 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1024_implies_Equation1021
  (G : Type) `{Magma G} (h : Equation1024 G) : Equation1021 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1031_implies_Equation1022
  (G : Type) `{Magma G} (h : Equation1031 G) : Equation1022 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1032_implies_Equation1022
  (G : Type) `{Magma G} (h : Equation1032 G) : Equation1022 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1041_implies_Equation1022
  (G : Type) `{Magma G} (h : Equation1041 G) : Equation1022 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1042_implies_Equation1022
  (G : Type) `{Magma G} (h : Equation1042 G) : Equation1022 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1050_implies_Equation1021
  (G : Type) `{Magma G} (h : Equation1050 G) : Equation1021 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1051_implies_Equation1022
  (G : Type) `{Magma G} (h : Equation1051 G) : Equation1022 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1052_implies_Equation1022
  (G : Type) `{Magma G} (h : Equation1052 G) : Equation1022 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1053_implies_Equation1023
  (G : Type) `{Magma G} (h : Equation1053 G) : Equation1023 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1055_implies_Equation1025
  (G : Type) `{Magma G} (h : Equation1055 G) : Equation1025 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1056_implies_Equation1025
  (G : Type) `{Magma G} (h : Equation1056 G) : Equation1025 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1060_implies_Equation1025
  (G : Type) `{Magma G} (h : Equation1060 G) : Equation1025 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1061_implies_Equation1026
  (G : Type) `{Magma G} (h : Equation1061 G) : Equation1026 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1063_implies_Equation1028
  (G : Type) `{Magma G} (h : Equation1063 G) : Equation1028 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1064_implies_Equation1028
  (G : Type) `{Magma G} (h : Equation1064 G) : Equation1028 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1098_implies_Equation1026
  (G : Type) `{Magma G} (h : Equation1098 G) : Equation1026 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1101_implies_Equation1028
  (G : Type) `{Magma G} (h : Equation1101 G) : Equation1028 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1117_implies_Equation1023
  (G : Type) `{Magma G} (h : Equation1117 G) : Equation1023 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1131_implies_Equation1026
  (G : Type) `{Magma G} (h : Equation1131 G) : Equation1026 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1133_implies_Equation1025
  (G : Type) `{Magma G} (h : Equation1133 G) : Equation1025 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1137_implies_Equation1028
  (G : Type) `{Magma G} (h : Equation1137 G) : Equation1028 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1152_implies_Equation1036
  (G : Type) `{Magma G} (h : Equation1152 G) : Equation1036 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1155_implies_Equation1038
  (G : Type) `{Magma G} (h : Equation1155 G) : Equation1038 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1184_implies_Equation1045
  (G : Type) `{Magma G} (h : Equation1184 G) : Equation1045 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1227_implies_Equation1224
  (G : Type) `{Magma G} (h : Equation1227 G) : Equation1224 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1230_implies_Equation1224
  (G : Type) `{Magma G} (h : Equation1230 G) : Equation1224 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1234_implies_Equation1225
  (G : Type) `{Magma G} (h : Equation1234 G) : Equation1225 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1240_implies_Equation1224
  (G : Type) `{Magma G} (h : Equation1240 G) : Equation1224 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1243_implies_Equation1224
  (G : Type) `{Magma G} (h : Equation1243 G) : Equation1224 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1244_implies_Equation1225
  (G : Type) `{Magma G} (h : Equation1244 G) : Equation1225 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1245_implies_Equation1225
  (G : Type) `{Magma G} (h : Equation1245 G) : Equation1225 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1250_implies_Equation1224
  (G : Type) `{Magma G} (h : Equation1250 G) : Equation1224 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1253_implies_Equation1224
  (G : Type) `{Magma G} (h : Equation1253 G) : Equation1224 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1254_implies_Equation1225
  (G : Type) `{Magma G} (h : Equation1254 G) : Equation1225 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1255_implies_Equation1225
  (G : Type) `{Magma G} (h : Equation1255 G) : Equation1225 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1256_implies_Equation1226
  (G : Type) `{Magma G} (h : Equation1256 G) : Equation1226 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1258_implies_Equation1228
  (G : Type) `{Magma G} (h : Equation1258 G) : Equation1228 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1259_implies_Equation1228
  (G : Type) `{Magma G} (h : Equation1259 G) : Equation1228 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1262_implies_Equation1228
  (G : Type) `{Magma G} (h : Equation1262 G) : Equation1228 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1263_implies_Equation1228
  (G : Type) `{Magma G} (h : Equation1263 G) : Equation1228 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1264_implies_Equation1229
  (G : Type) `{Magma G} (h : Equation1264 G) : Equation1229 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1267_implies_Equation1231
  (G : Type) `{Magma G} (h : Equation1267 G) : Equation1231 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1301_implies_Equation1229
  (G : Type) `{Magma G} (h : Equation1301 G) : Equation1229 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1320_implies_Equation1226
  (G : Type) `{Magma G} (h : Equation1320 G) : Equation1226 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1340_implies_Equation1231
  (G : Type) `{Magma G} (h : Equation1340 G) : Equation1231 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1353_implies_Equation1238
  (G : Type) `{Magma G} (h : Equation1353 G) : Equation1238 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1355_implies_Equation1239
  (G : Type) `{Magma G} (h : Equation1355 G) : Equation1239 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1358_implies_Equation1241
  (G : Type) `{Magma G} (h : Equation1358 G) : Equation1241 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1368_implies_Equation1239
  (G : Type) `{Magma G} (h : Equation1368 G) : Equation1239 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1370_implies_Equation1238
  (G : Type) `{Magma G} (h : Equation1370 G) : Equation1238 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1374_implies_Equation1241
  (G : Type) `{Magma G} (h : Equation1374 G) : Equation1241 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1387_implies_Equation1248
  (G : Type) `{Magma G} (h : Equation1387 G) : Equation1248 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1430_implies_Equation1427
  (G : Type) `{Magma G} (h : Equation1430 G) : Equation1427 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1437_implies_Equation1428
  (G : Type) `{Magma G} (h : Equation1437 G) : Equation1428 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1443_implies_Equation1427
  (G : Type) `{Magma G} (h : Equation1443 G) : Equation1427 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1447_implies_Equation1428
  (G : Type) `{Magma G} (h : Equation1447 G) : Equation1428 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1453_implies_Equation1427
  (G : Type) `{Magma G} (h : Equation1453 G) : Equation1427 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1457_implies_Equation1428
  (G : Type) `{Magma G} (h : Equation1457 G) : Equation1428 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1459_implies_Equation1429
  (G : Type) `{Magma G} (h : Equation1459 G) : Equation1429 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1461_implies_Equation1431
  (G : Type) `{Magma G} (h : Equation1461 G) : Equation1431 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1467_implies_Equation1432
  (G : Type) `{Magma G} (h : Equation1467 G) : Equation1432 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1469_implies_Equation1434
  (G : Type) `{Magma G} (h : Equation1469 G) : Equation1434 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1470_implies_Equation1434
  (G : Type) `{Magma G} (h : Equation1470 G) : Equation1434 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1480_implies_Equation1427
  (G : Type) `{Magma G} (h : Equation1480 G) : Equation1427 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1484_implies_Equation1428
  (G : Type) `{Magma G} (h : Equation1484 G) : Equation1428 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1486_implies_Equation1429
  (G : Type) `{Magma G} (h : Equation1486 G) : Equation1429 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1504_implies_Equation1432
  (G : Type) `{Magma G} (h : Equation1504 G) : Equation1432 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1523_implies_Equation1429
  (G : Type) `{Magma G} (h : Equation1523 G) : Equation1429 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1558_implies_Equation1442
  (G : Type) `{Magma G} (h : Equation1558 G) : Equation1442 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1577_implies_Equation1444
  (G : Type) `{Magma G} (h : Equation1577 G) : Equation1444 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1586_implies_Equation1451
  (G : Type) `{Magma G} (h : Equation1586 G) : Equation1451 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1587_implies_Equation1451
  (G : Type) `{Magma G} (h : Equation1587 G) : Equation1451 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1590_implies_Equation1451
  (G : Type) `{Magma G} (h : Equation1590 G) : Equation1451 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1594_implies_Equation1454
  (G : Type) `{Magma G} (h : Equation1594 G) : Equation1454 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1633_implies_Equation1630
  (G : Type) `{Magma G} (h : Equation1633 G) : Equation1630 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1640_implies_Equation1631
  (G : Type) `{Magma G} (h : Equation1640 G) : Equation1631 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1641_implies_Equation1631
  (G : Type) `{Magma G} (h : Equation1641 G) : Equation1631 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1650_implies_Equation1631
  (G : Type) `{Magma G} (h : Equation1650 G) : Equation1631 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1661_implies_Equation1631
  (G : Type) `{Magma G} (h : Equation1661 G) : Equation1631 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1662_implies_Equation1632
  (G : Type) `{Magma G} (h : Equation1662 G) : Equation1632 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1664_implies_Equation1634
  (G : Type) `{Magma G} (h : Equation1664 G) : Equation1634 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1668_implies_Equation1634
  (G : Type) `{Magma G} (h : Equation1668 G) : Equation1634 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1670_implies_Equation1635
  (G : Type) `{Magma G} (h : Equation1670 G) : Equation1635 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1672_implies_Equation1637
  (G : Type) `{Magma G} (h : Equation1672 G) : Equation1637 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1673_implies_Equation1637
  (G : Type) `{Magma G} (h : Equation1673 G) : Equation1637 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1687_implies_Equation1631
  (G : Type) `{Magma G} (h : Equation1687 G) : Equation1631 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1701_implies_Equation1634
  (G : Type) `{Magma G} (h : Equation1701 G) : Equation1634 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1705_implies_Equation1634
  (G : Type) `{Magma G} (h : Equation1705 G) : Equation1634 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1707_implies_Equation1635
  (G : Type) `{Magma G} (h : Equation1707 G) : Equation1635 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1724_implies_Equation1631
  (G : Type) `{Magma G} (h : Equation1724 G) : Equation1631 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1738_implies_Equation1634
  (G : Type) `{Magma G} (h : Equation1738 G) : Equation1634 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1746_implies_Equation1637
  (G : Type) `{Magma G} (h : Equation1746 G) : Equation1637 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1780_implies_Equation1647
  (G : Type) `{Magma G} (h : Equation1780 G) : Equation1647 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1793_implies_Equation1654
  (G : Type) `{Magma G} (h : Equation1793 G) : Equation1654 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1839_implies_Equation1833
  (G : Type) `{Magma G} (h : Equation1839 G) : Equation1833 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1843_implies_Equation1834
  (G : Type) `{Magma G} (h : Equation1843 G) : Equation1834 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1845_implies_Equation1835
  (G : Type) `{Magma G} (h : Equation1845 G) : Equation1835 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1849_implies_Equation1833
  (G : Type) `{Magma G} (h : Equation1849 G) : Equation1833 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1853_implies_Equation1834
  (G : Type) `{Magma G} (h : Equation1853 G) : Equation1834 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1855_implies_Equation1835
  (G : Type) `{Magma G} (h : Equation1855 G) : Equation1835 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1859_implies_Equation1833
  (G : Type) `{Magma G} (h : Equation1859 G) : Equation1833 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1863_implies_Equation1834
  (G : Type) `{Magma G} (h : Equation1863 G) : Equation1834 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1865_implies_Equation1835
  (G : Type) `{Magma G} (h : Equation1865 G) : Equation1835 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1867_implies_Equation1837
  (G : Type) `{Magma G} (h : Equation1867 G) : Equation1837 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1868_implies_Equation1837
  (G : Type) `{Magma G} (h : Equation1868 G) : Equation1837 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1871_implies_Equation1837
  (G : Type) `{Magma G} (h : Equation1871 G) : Equation1837 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1873_implies_Equation1838
  (G : Type) `{Magma G} (h : Equation1873 G) : Equation1838 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1875_implies_Equation1840
  (G : Type) `{Magma G} (h : Equation1875 G) : Equation1840 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1876_implies_Equation1840
  (G : Type) `{Magma G} (h : Equation1876 G) : Equation1840 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1904_implies_Equation1837
  (G : Type) `{Magma G} (h : Equation1904 G) : Equation1837 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1949_implies_Equation1840
  (G : Type) `{Magma G} (h : Equation1949 G) : Equation1840 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1958_implies_Equation1847
  (G : Type) `{Magma G} (h : Equation1958 G) : Equation1847 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1975_implies_Equation1847
  (G : Type) `{Magma G} (h : Equation1975 G) : Equation1847 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1977_implies_Equation1848
  (G : Type) `{Magma G} (h : Equation1977 G) : Equation1848 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1979_implies_Equation1847
  (G : Type) `{Magma G} (h : Equation1979 G) : Equation1847 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1983_implies_Equation1850
  (G : Type) `{Magma G} (h : Equation1983 G) : Equation1850 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation1996_implies_Equation1857
  (G : Type) `{Magma G} (h : Equation1996 G) : Equation1857 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2000_implies_Equation1860
  (G : Type) `{Magma G} (h : Equation2000 G) : Equation1860 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2042_implies_Equation2036
  (G : Type) `{Magma G} (h : Equation2042 G) : Equation2036 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2045_implies_Equation2036
  (G : Type) `{Magma G} (h : Equation2045 G) : Equation2036 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2052_implies_Equation2036
  (G : Type) `{Magma G} (h : Equation2052 G) : Equation2036 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2055_implies_Equation2036
  (G : Type) `{Magma G} (h : Equation2055 G) : Equation2036 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2056_implies_Equation2037
  (G : Type) `{Magma G} (h : Equation2056 G) : Equation2037 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2062_implies_Equation2036
  (G : Type) `{Magma G} (h : Equation2062 G) : Equation2036 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2065_implies_Equation2036
  (G : Type) `{Magma G} (h : Equation2065 G) : Equation2036 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2066_implies_Equation2037
  (G : Type) `{Magma G} (h : Equation2066 G) : Equation2037 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2068_implies_Equation2038
  (G : Type) `{Magma G} (h : Equation2068 G) : Equation2038 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2070_implies_Equation2040
  (G : Type) `{Magma G} (h : Equation2070 G) : Equation2040 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2072_implies_Equation2041
  (G : Type) `{Magma G} (h : Equation2072 G) : Equation2041 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2076_implies_Equation2041
  (G : Type) `{Magma G} (h : Equation2076 G) : Equation2041 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2078_implies_Equation2043
  (G : Type) `{Magma G} (h : Equation2078 G) : Equation2043 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2079_implies_Equation2043
  (G : Type) `{Magma G} (h : Equation2079 G) : Equation2043 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2089_implies_Equation2036
  (G : Type) `{Magma G} (h : Equation2089 G) : Equation2036 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2093_implies_Equation2037
  (G : Type) `{Magma G} (h : Equation2093 G) : Equation2037 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2115_implies_Equation2043
  (G : Type) `{Magma G} (h : Equation2115 G) : Equation2043 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2116_implies_Equation2043
  (G : Type) `{Magma G} (h : Equation2116 G) : Equation2043 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2126_implies_Equation2036
  (G : Type) `{Magma G} (h : Equation2126 G) : Equation2036 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2132_implies_Equation2038
  (G : Type) `{Magma G} (h : Equation2132 G) : Equation2038 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2146_implies_Equation2041
  (G : Type) `{Magma G} (h : Equation2146 G) : Equation2041 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2152_implies_Equation2043
  (G : Type) `{Magma G} (h : Equation2152 G) : Equation2043 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2161_implies_Equation2050
  (G : Type) `{Magma G} (h : Equation2161 G) : Equation2050 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2162_implies_Equation2050
  (G : Type) `{Magma G} (h : Equation2162 G) : Equation2050 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2163_implies_Equation2051
  (G : Type) `{Magma G} (h : Equation2163 G) : Equation2051 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2180_implies_Equation2051
  (G : Type) `{Magma G} (h : Equation2180 G) : Equation2051 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2186_implies_Equation2053
  (G : Type) `{Magma G} (h : Equation2186 G) : Equation2053 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2199_implies_Equation2060
  (G : Type) `{Magma G} (h : Equation2199 G) : Equation2060 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2203_implies_Equation2063
  (G : Type) `{Magma G} (h : Equation2203 G) : Equation2063 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2242_implies_Equation2239
  (G : Type) `{Magma G} (h : Equation2242 G) : Equation2239 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2245_implies_Equation2239
  (G : Type) `{Magma G} (h : Equation2245 G) : Equation2239 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2248_implies_Equation2239
  (G : Type) `{Magma G} (h : Equation2248 G) : Equation2239 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2249_implies_Equation2240
  (G : Type) `{Magma G} (h : Equation2249 G) : Equation2240 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2255_implies_Equation2239
  (G : Type) `{Magma G} (h : Equation2255 G) : Equation2239 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2258_implies_Equation2239
  (G : Type) `{Magma G} (h : Equation2258 G) : Equation2239 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2260_implies_Equation2240
  (G : Type) `{Magma G} (h : Equation2260 G) : Equation2240 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2261_implies_Equation2241
  (G : Type) `{Magma G} (h : Equation2261 G) : Equation2241 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2265_implies_Equation2239
  (G : Type) `{Magma G} (h : Equation2265 G) : Equation2239 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2268_implies_Equation2239
  (G : Type) `{Magma G} (h : Equation2268 G) : Equation2239 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2270_implies_Equation2240
  (G : Type) `{Magma G} (h : Equation2270 G) : Equation2240 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2271_implies_Equation2241
  (G : Type) `{Magma G} (h : Equation2271 G) : Equation2241 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2273_implies_Equation2243
  (G : Type) `{Magma G} (h : Equation2273 G) : Equation2243 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2277_implies_Equation2243
  (G : Type) `{Magma G} (h : Equation2277 G) : Equation2243 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2279_implies_Equation2244
  (G : Type) `{Magma G} (h : Equation2279 G) : Equation2244 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2281_implies_Equation2246
  (G : Type) `{Magma G} (h : Equation2281 G) : Equation2246 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2282_implies_Equation2246
  (G : Type) `{Magma G} (h : Equation2282 G) : Equation2246 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2310_implies_Equation2243
  (G : Type) `{Magma G} (h : Equation2310 G) : Equation2243 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2314_implies_Equation2243
  (G : Type) `{Magma G} (h : Equation2314 G) : Equation2243 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2316_implies_Equation2244
  (G : Type) `{Magma G} (h : Equation2316 G) : Equation2244 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2318_implies_Equation2246
  (G : Type) `{Magma G} (h : Equation2318 G) : Equation2246 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2347_implies_Equation2243
  (G : Type) `{Magma G} (h : Equation2347 G) : Equation2243 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2351_implies_Equation2243
  (G : Type) `{Magma G} (h : Equation2351 G) : Equation2243 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2355_implies_Equation2246
  (G : Type) `{Magma G} (h : Equation2355 G) : Equation2246 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2364_implies_Equation2253
  (G : Type) `{Magma G} (h : Equation2364 G) : Equation2253 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2368_implies_Equation2253
  (G : Type) `{Magma G} (h : Equation2368 G) : Equation2253 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2372_implies_Equation2256
  (G : Type) `{Magma G} (h : Equation2372 G) : Equation2256 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2373_implies_Equation2256
  (G : Type) `{Magma G} (h : Equation2373 G) : Equation2256 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2383_implies_Equation2254
  (G : Type) `{Magma G} (h : Equation2383 G) : Equation2254 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2385_implies_Equation2253
  (G : Type) `{Magma G} (h : Equation2385 G) : Equation2253 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2389_implies_Equation2256
  (G : Type) `{Magma G} (h : Equation2389 G) : Equation2256 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2398_implies_Equation2263
  (G : Type) `{Magma G} (h : Equation2398 G) : Equation2263 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2402_implies_Equation2263
  (G : Type) `{Magma G} (h : Equation2402 G) : Equation2263 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2406_implies_Equation2266
  (G : Type) `{Magma G} (h : Equation2406 G) : Equation2266 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2445_implies_Equation2442
  (G : Type) `{Magma G} (h : Equation2445 G) : Equation2442 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2448_implies_Equation2442
  (G : Type) `{Magma G} (h : Equation2448 G) : Equation2442 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2451_implies_Equation2442
  (G : Type) `{Magma G} (h : Equation2451 G) : Equation2442 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2452_implies_Equation2443
  (G : Type) `{Magma G} (h : Equation2452 G) : Equation2443 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2458_implies_Equation2442
  (G : Type) `{Magma G} (h : Equation2458 G) : Equation2442 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2461_implies_Equation2442
  (G : Type) `{Magma G} (h : Equation2461 G) : Equation2442 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2462_implies_Equation2443
  (G : Type) `{Magma G} (h : Equation2462 G) : Equation2443 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2468_implies_Equation2442
  (G : Type) `{Magma G} (h : Equation2468 G) : Equation2442 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2471_implies_Equation2442
  (G : Type) `{Magma G} (h : Equation2471 G) : Equation2442 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2472_implies_Equation2443
  (G : Type) `{Magma G} (h : Equation2472 G) : Equation2443 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2473_implies_Equation2443
  (G : Type) `{Magma G} (h : Equation2473 G) : Equation2443 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2474_implies_Equation2444
  (G : Type) `{Magma G} (h : Equation2474 G) : Equation2444 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2476_implies_Equation2446
  (G : Type) `{Magma G} (h : Equation2476 G) : Equation2446 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2481_implies_Equation2446
  (G : Type) `{Magma G} (h : Equation2481 G) : Equation2446 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2482_implies_Equation2447
  (G : Type) `{Magma G} (h : Equation2482 G) : Equation2447 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2484_implies_Equation2449
  (G : Type) `{Magma G} (h : Equation2484 G) : Equation2449 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2485_implies_Equation2449
  (G : Type) `{Magma G} (h : Equation2485 G) : Equation2449 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2505_implies_Equation2442
  (G : Type) `{Magma G} (h : Equation2505 G) : Equation2442 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2508_implies_Equation2442
  (G : Type) `{Magma G} (h : Equation2508 G) : Equation2442 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2513_implies_Equation2446
  (G : Type) `{Magma G} (h : Equation2513 G) : Equation2446 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2517_implies_Equation2446
  (G : Type) `{Magma G} (h : Equation2517 G) : Equation2446 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2538_implies_Equation2444
  (G : Type) `{Magma G} (h : Equation2538 G) : Equation2444 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2550_implies_Equation2446
  (G : Type) `{Magma G} (h : Equation2550 G) : Equation2446 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2554_implies_Equation2446
  (G : Type) `{Magma G} (h : Equation2554 G) : Equation2446 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2558_implies_Equation2449
  (G : Type) `{Magma G} (h : Equation2558 G) : Equation2449 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2567_implies_Equation2456
  (G : Type) `{Magma G} (h : Equation2567 G) : Equation2456 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2571_implies_Equation2456
  (G : Type) `{Magma G} (h : Equation2571 G) : Equation2456 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2573_implies_Equation2457
  (G : Type) `{Magma G} (h : Equation2573 G) : Equation2457 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2576_implies_Equation2459
  (G : Type) `{Magma G} (h : Equation2576 G) : Equation2459 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2584_implies_Equation2456
  (G : Type) `{Magma G} (h : Equation2584 G) : Equation2456 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2588_implies_Equation2456
  (G : Type) `{Magma G} (h : Equation2588 G) : Equation2456 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2592_implies_Equation2459
  (G : Type) `{Magma G} (h : Equation2592 G) : Equation2459 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2605_implies_Equation2466
  (G : Type) `{Magma G} (h : Equation2605 G) : Equation2466 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2609_implies_Equation2469
  (G : Type) `{Magma G} (h : Equation2609 G) : Equation2469 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2648_implies_Equation2645
  (G : Type) `{Magma G} (h : Equation2648 G) : Equation2645 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2651_implies_Equation2645
  (G : Type) `{Magma G} (h : Equation2651 G) : Equation2645 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2654_implies_Equation2645
  (G : Type) `{Magma G} (h : Equation2654 G) : Equation2645 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2655_implies_Equation2646
  (G : Type) `{Magma G} (h : Equation2655 G) : Equation2646 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2656_implies_Equation2646
  (G : Type) `{Magma G} (h : Equation2656 G) : Equation2646 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2664_implies_Equation2645
  (G : Type) `{Magma G} (h : Equation2664 G) : Equation2645 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2665_implies_Equation2646
  (G : Type) `{Magma G} (h : Equation2665 G) : Equation2646 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2675_implies_Equation2646
  (G : Type) `{Magma G} (h : Equation2675 G) : Equation2646 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2676_implies_Equation2646
  (G : Type) `{Magma G} (h : Equation2676 G) : Equation2646 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2677_implies_Equation2647
  (G : Type) `{Magma G} (h : Equation2677 G) : Equation2647 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2679_implies_Equation2649
  (G : Type) `{Magma G} (h : Equation2679 G) : Equation2649 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2683_implies_Equation2649
  (G : Type) `{Magma G} (h : Equation2683 G) : Equation2649 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2685_implies_Equation2650
  (G : Type) `{Magma G} (h : Equation2685 G) : Equation2650 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2687_implies_Equation2652
  (G : Type) `{Magma G} (h : Equation2687 G) : Equation2652 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2688_implies_Equation2652
  (G : Type) `{Magma G} (h : Equation2688 G) : Equation2652 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2702_implies_Equation2646
  (G : Type) `{Magma G} (h : Equation2702 G) : Equation2646 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2712_implies_Equation2646
  (G : Type) `{Magma G} (h : Equation2712 G) : Equation2646 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2716_implies_Equation2649
  (G : Type) `{Magma G} (h : Equation2716 G) : Equation2649 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2722_implies_Equation2650
  (G : Type) `{Magma G} (h : Equation2722 G) : Equation2650 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2726_implies_Equation2653
  (G : Type) `{Magma G} (h : Equation2726 G) : Equation2653 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2739_implies_Equation2646
  (G : Type) `{Magma G} (h : Equation2739 G) : Equation2646 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2741_implies_Equation2647
  (G : Type) `{Magma G} (h : Equation2741 G) : Equation2647 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2755_implies_Equation2650
  (G : Type) `{Magma G} (h : Equation2755 G) : Equation2650 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2761_implies_Equation2652
  (G : Type) `{Magma G} (h : Equation2761 G) : Equation2652 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2770_implies_Equation2659
  (G : Type) `{Magma G} (h : Equation2770 G) : Equation2659 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2774_implies_Equation2659
  (G : Type) `{Magma G} (h : Equation2774 G) : Equation2659 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2776_implies_Equation2660
  (G : Type) `{Magma G} (h : Equation2776 G) : Equation2660 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2778_implies_Equation2662
  (G : Type) `{Magma G} (h : Equation2778 G) : Equation2662 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2795_implies_Equation2662
  (G : Type) `{Magma G} (h : Equation2795 G) : Equation2662 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2804_implies_Equation2669
  (G : Type) `{Magma G} (h : Equation2804 G) : Equation2669 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2805_implies_Equation2669
  (G : Type) `{Magma G} (h : Equation2805 G) : Equation2669 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2808_implies_Equation2669
  (G : Type) `{Magma G} (h : Equation2808 G) : Equation2669 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2812_implies_Equation2672
  (G : Type) `{Magma G} (h : Equation2812 G) : Equation2672 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2851_implies_Equation2848
  (G : Type) `{Magma G} (h : Equation2851 G) : Equation2848 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2854_implies_Equation2848
  (G : Type) `{Magma G} (h : Equation2854 G) : Equation2848 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2857_implies_Equation2848
  (G : Type) `{Magma G} (h : Equation2857 G) : Equation2848 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2874_implies_Equation2848
  (G : Type) `{Magma G} (h : Equation2874 G) : Equation2848 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2878_implies_Equation2849
  (G : Type) `{Magma G} (h : Equation2878 G) : Equation2849 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2880_implies_Equation2850
  (G : Type) `{Magma G} (h : Equation2880 G) : Equation2850 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2882_implies_Equation2852
  (G : Type) `{Magma G} (h : Equation2882 G) : Equation2852 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2883_implies_Equation2852
  (G : Type) `{Magma G} (h : Equation2883 G) : Equation2852 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2886_implies_Equation2852
  (G : Type) `{Magma G} (h : Equation2886 G) : Equation2852 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2887_implies_Equation2852
  (G : Type) `{Magma G} (h : Equation2887 G) : Equation2852 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2888_implies_Equation2853
  (G : Type) `{Magma G} (h : Equation2888 G) : Equation2853 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2890_implies_Equation2855
  (G : Type) `{Magma G} (h : Equation2890 G) : Equation2855 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2891_implies_Equation2855
  (G : Type) `{Magma G} (h : Equation2891 G) : Equation2855 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2925_implies_Equation2853
  (G : Type) `{Magma G} (h : Equation2925 G) : Equation2853 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2928_implies_Equation2855
  (G : Type) `{Magma G} (h : Equation2928 G) : Equation2855 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2944_implies_Equation2850
  (G : Type) `{Magma G} (h : Equation2944 G) : Equation2850 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2964_implies_Equation2855
  (G : Type) `{Magma G} (h : Equation2964 G) : Equation2855 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2973_implies_Equation2862
  (G : Type) `{Magma G} (h : Equation2973 G) : Equation2862 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2979_implies_Equation2863
  (G : Type) `{Magma G} (h : Equation2979 G) : Equation2863 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2982_implies_Equation2865
  (G : Type) `{Magma G} (h : Equation2982 G) : Equation2865 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2990_implies_Equation2862
  (G : Type) `{Magma G} (h : Equation2990 G) : Equation2862 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2994_implies_Equation2862
  (G : Type) `{Magma G} (h : Equation2994 G) : Equation2862 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation2998_implies_Equation2865
  (G : Type) `{Magma G} (h : Equation2998 G) : Equation2865 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3007_implies_Equation2872
  (G : Type) `{Magma G} (h : Equation3007 G) : Equation2872 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3008_implies_Equation2872
  (G : Type) `{Magma G} (h : Equation3008 G) : Equation2872 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3011_implies_Equation2872
  (G : Type) `{Magma G} (h : Equation3011 G) : Equation2872 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3054_implies_Equation3051
  (G : Type) `{Magma G} (h : Equation3054 G) : Equation3051 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3060_implies_Equation3051
  (G : Type) `{Magma G} (h : Equation3060 G) : Equation3051 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3067_implies_Equation3051
  (G : Type) `{Magma G} (h : Equation3067 G) : Equation3051 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3071_implies_Equation3052
  (G : Type) `{Magma G} (h : Equation3071 G) : Equation3052 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3073_implies_Equation3053
  (G : Type) `{Magma G} (h : Equation3073 G) : Equation3053 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3080_implies_Equation3051
  (G : Type) `{Magma G} (h : Equation3080 G) : Equation3051 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3083_implies_Equation3053
  (G : Type) `{Magma G} (h : Equation3083 G) : Equation3053 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3085_implies_Equation3055
  (G : Type) `{Magma G} (h : Equation3085 G) : Equation3055 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3089_implies_Equation3055
  (G : Type) `{Magma G} (h : Equation3089 G) : Equation3055 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3091_implies_Equation3056
  (G : Type) `{Magma G} (h : Equation3091 G) : Equation3056 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3093_implies_Equation3058
  (G : Type) `{Magma G} (h : Equation3093 G) : Equation3058 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3094_implies_Equation3058
  (G : Type) `{Magma G} (h : Equation3094 G) : Equation3058 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3095_implies_Equation3059
  (G : Type) `{Magma G} (h : Equation3095 G) : Equation3059 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3122_implies_Equation3055
  (G : Type) `{Magma G} (h : Equation3122 G) : Equation3055 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3161_implies_Equation3056
  (G : Type) `{Magma G} (h : Equation3161 G) : Equation3056 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3167_implies_Equation3058
  (G : Type) `{Magma G} (h : Equation3167 G) : Equation3058 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3176_implies_Equation3065
  (G : Type) `{Magma G} (h : Equation3176 G) : Equation3065 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3195_implies_Equation3066
  (G : Type) `{Magma G} (h : Equation3195 G) : Equation3066 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3197_implies_Equation3065
  (G : Type) `{Magma G} (h : Equation3197 G) : Equation3065 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3201_implies_Equation3068
  (G : Type) `{Magma G} (h : Equation3201 G) : Equation3068 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3214_implies_Equation3075
  (G : Type) `{Magma G} (h : Equation3214 G) : Equation3075 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3257_implies_Equation3254
  (G : Type) `{Magma G} (h : Equation3257 G) : Equation3254 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3260_implies_Equation3254
  (G : Type) `{Magma G} (h : Equation3260 G) : Equation3254 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3263_implies_Equation3254
  (G : Type) `{Magma G} (h : Equation3263 G) : Equation3254 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3264_implies_Equation3255
  (G : Type) `{Magma G} (h : Equation3264 G) : Equation3255 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3265_implies_Equation3255
  (G : Type) `{Magma G} (h : Equation3265 G) : Equation3255 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3266_implies_Equation3256
  (G : Type) `{Magma G} (h : Equation3266 G) : Equation3256 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3274_implies_Equation3255
  (G : Type) `{Magma G} (h : Equation3274 G) : Equation3255 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3283_implies_Equation3254
  (G : Type) `{Magma G} (h : Equation3283 G) : Equation3254 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3284_implies_Equation3255
  (G : Type) `{Magma G} (h : Equation3284 G) : Equation3255 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3285_implies_Equation3255
  (G : Type) `{Magma G} (h : Equation3285 G) : Equation3255 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3286_implies_Equation3256
  (G : Type) `{Magma G} (h : Equation3286 G) : Equation3256 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3288_implies_Equation3258
  (G : Type) `{Magma G} (h : Equation3288 G) : Equation3258 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3293_implies_Equation3258
  (G : Type) `{Magma G} (h : Equation3293 G) : Equation3258 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3294_implies_Equation3259
  (G : Type) `{Magma G} (h : Equation3294 G) : Equation3259 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3296_implies_Equation3261
  (G : Type) `{Magma G} (h : Equation3296 G) : Equation3261 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3297_implies_Equation3261
  (G : Type) `{Magma G} (h : Equation3297 G) : Equation3261 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3317_implies_Equation3254
  (G : Type) `{Magma G} (h : Equation3317 G) : Equation3254 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3320_implies_Equation3254
  (G : Type) `{Magma G} (h : Equation3320 G) : Equation3254 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3321_implies_Equation3255
  (G : Type) `{Magma G} (h : Equation3321 G) : Equation3255 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3322_implies_Equation3255
  (G : Type) `{Magma G} (h : Equation3322 G) : Equation3255 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3323_implies_Equation3256
  (G : Type) `{Magma G} (h : Equation3323 G) : Equation3256 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3326_implies_Equation3258
  (G : Type) `{Magma G} (h : Equation3326 G) : Equation3258 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3331_implies_Equation3259
  (G : Type) `{Magma G} (h : Equation3331 G) : Equation3259 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3334_implies_Equation3261
  (G : Type) `{Magma G} (h : Equation3334 G) : Equation3261 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3381_implies_Equation3269
  (G : Type) `{Magma G} (h : Equation3381 G) : Equation3269 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3388_implies_Equation3271
  (G : Type) `{Magma G} (h : Equation3388 G) : Equation3271 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3401_implies_Equation3268
  (G : Type) `{Magma G} (h : Equation3401 G) : Equation3268 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3414_implies_Equation3278
  (G : Type) `{Magma G} (h : Equation3414 G) : Equation3278 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3423_implies_Equation3282
  (G : Type) `{Magma G} (h : Equation3423 G) : Equation3282 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3460_implies_Equation3457
  (G : Type) `{Magma G} (h : Equation3460 G) : Equation3457 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3463_implies_Equation3457
  (G : Type) `{Magma G} (h : Equation3463 G) : Equation3457 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3466_implies_Equation3457
  (G : Type) `{Magma G} (h : Equation3466 G) : Equation3457 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3467_implies_Equation3458
  (G : Type) `{Magma G} (h : Equation3467 G) : Equation3458 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3468_implies_Equation3458
  (G : Type) `{Magma G} (h : Equation3468 G) : Equation3458 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3469_implies_Equation3459
  (G : Type) `{Magma G} (h : Equation3469 G) : Equation3459 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3477_implies_Equation3458
  (G : Type) `{Magma G} (h : Equation3477 G) : Equation3458 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3487_implies_Equation3458
  (G : Type) `{Magma G} (h : Equation3487 G) : Equation3458 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3488_implies_Equation3458
  (G : Type) `{Magma G} (h : Equation3488 G) : Equation3458 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3489_implies_Equation3459
  (G : Type) `{Magma G} (h : Equation3489 G) : Equation3459 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3491_implies_Equation3461
  (G : Type) `{Magma G} (h : Equation3491 G) : Equation3461 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3495_implies_Equation3461
  (G : Type) `{Magma G} (h : Equation3495 G) : Equation3461 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3496_implies_Equation3461
  (G : Type) `{Magma G} (h : Equation3496 G) : Equation3461 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3497_implies_Equation3462
  (G : Type) `{Magma G} (h : Equation3497 G) : Equation3462 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3499_implies_Equation3464
  (G : Type) `{Magma G} (h : Equation3499 G) : Equation3464 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3500_implies_Equation3464
  (G : Type) `{Magma G} (h : Equation3500 G) : Equation3464 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3501_implies_Equation3465
  (G : Type) `{Magma G} (h : Equation3501 G) : Equation3465 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3513_implies_Equation3457
  (G : Type) `{Magma G} (h : Equation3513 G) : Equation3457 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3515_implies_Equation3458
  (G : Type) `{Magma G} (h : Equation3515 G) : Equation3458 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3520_implies_Equation3457
  (G : Type) `{Magma G} (h : Equation3520 G) : Equation3457 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3523_implies_Equation3457
  (G : Type) `{Magma G} (h : Equation3523 G) : Equation3457 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3524_implies_Equation3458
  (G : Type) `{Magma G} (h : Equation3524 G) : Equation3458 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3525_implies_Equation3458
  (G : Type) `{Magma G} (h : Equation3525 G) : Equation3458 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3526_implies_Equation3459
  (G : Type) `{Magma G} (h : Equation3526 G) : Equation3459 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3529_implies_Equation3461
  (G : Type) `{Magma G} (h : Equation3529 G) : Equation3461 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3533_implies_Equation3461
  (G : Type) `{Magma G} (h : Equation3533 G) : Equation3461 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3534_implies_Equation3462
  (G : Type) `{Magma G} (h : Equation3534 G) : Equation3462 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3537_implies_Equation3464
  (G : Type) `{Magma G} (h : Equation3537 G) : Equation3464 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3566_implies_Equation3461
  (G : Type) `{Magma G} (h : Equation3566 G) : Equation3461 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3583_implies_Equation3471
  (G : Type) `{Magma G} (h : Equation3583 G) : Equation3471 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3587_implies_Equation3471
  (G : Type) `{Magma G} (h : Equation3587 G) : Equation3471 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3588_implies_Equation3472
  (G : Type) `{Magma G} (h : Equation3588 G) : Equation3472 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3591_implies_Equation3474
  (G : Type) `{Magma G} (h : Equation3591 G) : Equation3474 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3600_implies_Equation3471
  (G : Type) `{Magma G} (h : Equation3600 G) : Equation3471 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3601_implies_Equation3472
  (G : Type) `{Magma G} (h : Equation3601 G) : Equation3472 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3607_implies_Equation3474
  (G : Type) `{Magma G} (h : Equation3607 G) : Equation3474 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3617_implies_Equation3481
  (G : Type) `{Magma G} (h : Equation3617 G) : Equation3481 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3620_implies_Equation3481
  (G : Type) `{Magma G} (h : Equation3620 G) : Equation3481 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3663_implies_Equation3660
  (G : Type) `{Magma G} (h : Equation3663 G) : Equation3660 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3666_implies_Equation3660
  (G : Type) `{Magma G} (h : Equation3666 G) : Equation3660 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3669_implies_Equation3660
  (G : Type) `{Magma G} (h : Equation3669 G) : Equation3660 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3670_implies_Equation3661
  (G : Type) `{Magma G} (h : Equation3670 G) : Equation3661 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3671_implies_Equation3661
  (G : Type) `{Magma G} (h : Equation3671 G) : Equation3661 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3672_implies_Equation3662
  (G : Type) `{Magma G} (h : Equation3672 G) : Equation3662 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3680_implies_Equation3661
  (G : Type) `{Magma G} (h : Equation3680 G) : Equation3661 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3690_implies_Equation3661
  (G : Type) `{Magma G} (h : Equation3690 G) : Equation3661 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3694_implies_Equation3664
  (G : Type) `{Magma G} (h : Equation3694 G) : Equation3664 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3698_implies_Equation3664
  (G : Type) `{Magma G} (h : Equation3698 G) : Equation3664 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3700_implies_Equation3665
  (G : Type) `{Magma G} (h : Equation3700 G) : Equation3665 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3702_implies_Equation3667
  (G : Type) `{Magma G} (h : Equation3702 G) : Equation3667 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3703_implies_Equation3667
  (G : Type) `{Magma G} (h : Equation3703 G) : Equation3667 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3716_implies_Equation3660
  (G : Type) `{Magma G} (h : Equation3716 G) : Equation3660 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3718_implies_Equation3661
  (G : Type) `{Magma G} (h : Equation3718 G) : Equation3661 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3723_implies_Equation3660
  (G : Type) `{Magma G} (h : Equation3723 G) : Equation3660 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3726_implies_Equation3660
  (G : Type) `{Magma G} (h : Equation3726 G) : Equation3660 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3727_implies_Equation3661
  (G : Type) `{Magma G} (h : Equation3727 G) : Equation3661 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3728_implies_Equation3661
  (G : Type) `{Magma G} (h : Equation3728 G) : Equation3661 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3729_implies_Equation3662
  (G : Type) `{Magma G} (h : Equation3729 G) : Equation3662 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3732_implies_Equation3664
  (G : Type) `{Magma G} (h : Equation3732 G) : Equation3664 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3736_implies_Equation3664
  (G : Type) `{Magma G} (h : Equation3736 G) : Equation3664 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3737_implies_Equation3665
  (G : Type) `{Magma G} (h : Equation3737 G) : Equation3665 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3740_implies_Equation3667
  (G : Type) `{Magma G} (h : Equation3740 G) : Equation3667 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3769_implies_Equation3664
  (G : Type) `{Magma G} (h : Equation3769 G) : Equation3664 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3776_implies_Equation3667
  (G : Type) `{Magma G} (h : Equation3776 G) : Equation3667 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3786_implies_Equation3674
  (G : Type) `{Magma G} (h : Equation3786 G) : Equation3674 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3790_implies_Equation3674
  (G : Type) `{Magma G} (h : Equation3790 G) : Equation3674 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3794_implies_Equation3677
  (G : Type) `{Magma G} (h : Equation3794 G) : Equation3677 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3803_implies_Equation3674
  (G : Type) `{Magma G} (h : Equation3803 G) : Equation3674 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3820_implies_Equation3684
  (G : Type) `{Magma G} (h : Equation3820 G) : Equation3684 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3829_implies_Equation3688
  (G : Type) `{Magma G} (h : Equation3829 G) : Equation3688 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3866_implies_Equation3863
  (G : Type) `{Magma G} (h : Equation3866 G) : Equation3863 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3872_implies_Equation3863
  (G : Type) `{Magma G} (h : Equation3872 G) : Equation3863 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3873_implies_Equation3864
  (G : Type) `{Magma G} (h : Equation3873 G) : Equation3864 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3874_implies_Equation3864
  (G : Type) `{Magma G} (h : Equation3874 G) : Equation3864 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3875_implies_Equation3865
  (G : Type) `{Magma G} (h : Equation3875 G) : Equation3865 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3883_implies_Equation3864
  (G : Type) `{Magma G} (h : Equation3883 G) : Equation3864 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3892_implies_Equation3863
  (G : Type) `{Magma G} (h : Equation3892 G) : Equation3863 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3893_implies_Equation3864
  (G : Type) `{Magma G} (h : Equation3893 G) : Equation3864 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3894_implies_Equation3864
  (G : Type) `{Magma G} (h : Equation3894 G) : Equation3864 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3895_implies_Equation3865
  (G : Type) `{Magma G} (h : Equation3895 G) : Equation3865 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3897_implies_Equation3867
  (G : Type) `{Magma G} (h : Equation3897 G) : Equation3867 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3901_implies_Equation3867
  (G : Type) `{Magma G} (h : Equation3901 G) : Equation3867 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3902_implies_Equation3867
  (G : Type) `{Magma G} (h : Equation3902 G) : Equation3867 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3903_implies_Equation3868
  (G : Type) `{Magma G} (h : Equation3903 G) : Equation3868 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3905_implies_Equation3870
  (G : Type) `{Magma G} (h : Equation3905 G) : Equation3870 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3906_implies_Equation3870
  (G : Type) `{Magma G} (h : Equation3906 G) : Equation3870 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3907_implies_Equation3871
  (G : Type) `{Magma G} (h : Equation3907 G) : Equation3871 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3919_implies_Equation3863
  (G : Type) `{Magma G} (h : Equation3919 G) : Equation3863 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3921_implies_Equation3864
  (G : Type) `{Magma G} (h : Equation3921 G) : Equation3864 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3926_implies_Equation3863
  (G : Type) `{Magma G} (h : Equation3926 G) : Equation3863 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3929_implies_Equation3863
  (G : Type) `{Magma G} (h : Equation3929 G) : Equation3863 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3930_implies_Equation3864
  (G : Type) `{Magma G} (h : Equation3930 G) : Equation3864 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3931_implies_Equation3864
  (G : Type) `{Magma G} (h : Equation3931 G) : Equation3864 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3932_implies_Equation3865
  (G : Type) `{Magma G} (h : Equation3932 G) : Equation3865 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3935_implies_Equation3867
  (G : Type) `{Magma G} (h : Equation3935 G) : Equation3867 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3939_implies_Equation3867
  (G : Type) `{Magma G} (h : Equation3939 G) : Equation3867 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3940_implies_Equation3868
  (G : Type) `{Magma G} (h : Equation3940 G) : Equation3868 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3943_implies_Equation3870
  (G : Type) `{Magma G} (h : Equation3943 G) : Equation3870 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3959_implies_Equation3865
  (G : Type) `{Magma G} (h : Equation3959 G) : Equation3865 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3972_implies_Equation3867
  (G : Type) `{Magma G} (h : Equation3972 G) : Equation3867 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3973_implies_Equation3868
  (G : Type) `{Magma G} (h : Equation3973 G) : Equation3868 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3989_implies_Equation3877
  (G : Type) `{Magma G} (h : Equation3989 G) : Equation3877 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3993_implies_Equation3877
  (G : Type) `{Magma G} (h : Equation3993 G) : Equation3877 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3994_implies_Equation3878
  (G : Type) `{Magma G} (h : Equation3994 G) : Equation3878 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation3997_implies_Equation3880
  (G : Type) `{Magma G} (h : Equation3997 G) : Equation3880 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4006_implies_Equation3877
  (G : Type) `{Magma G} (h : Equation4006 G) : Equation3877 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4007_implies_Equation3878
  (G : Type) `{Magma G} (h : Equation4007 G) : Equation3878 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4023_implies_Equation3887
  (G : Type) `{Magma G} (h : Equation4023 G) : Equation3887 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4069_implies_Equation4066
  (G : Type) `{Magma G} (h : Equation4069 G) : Equation4066 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4076_implies_Equation4067
  (G : Type) `{Magma G} (h : Equation4076 G) : Equation4067 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4096_implies_Equation4067
  (G : Type) `{Magma G} (h : Equation4096 G) : Equation4067 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4097_implies_Equation4067
  (G : Type) `{Magma G} (h : Equation4097 G) : Equation4067 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4100_implies_Equation4070
  (G : Type) `{Magma G} (h : Equation4100 G) : Equation4070 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4104_implies_Equation4070
  (G : Type) `{Magma G} (h : Equation4104 G) : Equation4070 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4105_implies_Equation4070
  (G : Type) `{Magma G} (h : Equation4105 G) : Equation4070 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4106_implies_Equation4071
  (G : Type) `{Magma G} (h : Equation4106 G) : Equation4071 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4108_implies_Equation4073
  (G : Type) `{Magma G} (h : Equation4108 G) : Equation4073 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4109_implies_Equation4073
  (G : Type) `{Magma G} (h : Equation4109 G) : Equation4073 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4110_implies_Equation4074
  (G : Type) `{Magma G} (h : Equation4110 G) : Equation4074 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4134_implies_Equation4067
  (G : Type) `{Magma G} (h : Equation4134 G) : Equation4067 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4135_implies_Equation4068
  (G : Type) `{Magma G} (h : Equation4135 G) : Equation4068 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4138_implies_Equation4070
  (G : Type) `{Magma G} (h : Equation4138 G) : Equation4070 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4143_implies_Equation4071
  (G : Type) `{Magma G} (h : Equation4143 G) : Equation4071 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4146_implies_Equation4073
  (G : Type) `{Magma G} (h : Equation4146 G) : Equation4073 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4175_implies_Equation4070
  (G : Type) `{Magma G} (h : Equation4175 G) : Equation4070 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4192_implies_Equation4080
  (G : Type) `{Magma G} (h : Equation4192 G) : Equation4080 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4200_implies_Equation4083
  (G : Type) `{Magma G} (h : Equation4200 G) : Equation4083 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4209_implies_Equation4080
  (G : Type) `{Magma G} (h : Equation4209 G) : Equation4080 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4226_implies_Equation4090
  (G : Type) `{Magma G} (h : Equation4226 G) : Equation4090 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4280_implies_Equation4270
  (G : Type) `{Magma G} (h : Equation4280 G) : Equation4270 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4282_implies_Equation4268
  (G : Type) `{Magma G} (h : Equation4282 G) : Equation4268 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4286_implies_Equation4269
  (G : Type) `{Magma G} (h : Equation4286 G) : Equation4269 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4288_implies_Equation4270
  (G : Type) `{Magma G} (h : Equation4288 G) : Equation4270 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4296_implies_Equation4269
  (G : Type) `{Magma G} (h : Equation4296 G) : Equation4269 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4297_implies_Equation4270
  (G : Type) `{Magma G} (h : Equation4297 G) : Equation4270 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4304_implies_Equation4272
  (G : Type) `{Magma G} (h : Equation4304 G) : Equation4272 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4305_implies_Equation4273
  (G : Type) `{Magma G} (h : Equation4305 G) : Equation4273 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4307_implies_Equation4275
  (G : Type) `{Magma G} (h : Equation4307 G) : Equation4275 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4316_implies_Equation4269
  (G : Type) `{Magma G} (h : Equation4316 G) : Equation4269 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4318_implies_Equation4270
  (G : Type) `{Magma G} (h : Equation4318 G) : Equation4270 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4325_implies_Equation4270
  (G : Type) `{Magma G} (h : Equation4325 G) : Equation4270 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4327_implies_Equation4272
  (G : Type) `{Magma G} (h : Equation4327 G) : Equation4272 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4330_implies_Equation4272
  (G : Type) `{Magma G} (h : Equation4330 G) : Equation4272 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4332_implies_Equation4273
  (G : Type) `{Magma G} (h : Equation4332 G) : Equation4273 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4339_implies_Equation4268
  (G : Type) `{Magma G} (h : Equation4339 G) : Equation4268 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4340_implies_Equation4269
  (G : Type) `{Magma G} (h : Equation4340 G) : Equation4269 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4341_implies_Equation4270
  (G : Type) `{Magma G} (h : Equation4341 G) : Equation4270 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4351_implies_Equation4272
  (G : Type) `{Magma G} (h : Equation4351 G) : Equation4272 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4358_implies_Equation4283
  (G : Type) `{Magma G} (h : Equation4358 G) : Equation4283 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4364_implies_Equation4283
  (G : Type) `{Magma G} (h : Equation4364 G) : Equation4283 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4369_implies_Equation4290
  (G : Type) `{Magma G} (h : Equation4369 G) : Equation4290 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4384_implies_Equation4381
  (G : Type) `{Magma G} (h : Equation4384 G) : Equation4381 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4390_implies_Equation4381
  (G : Type) `{Magma G} (h : Equation4390 G) : Equation4381 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4391_implies_Equation4382
  (G : Type) `{Magma G} (h : Equation4391 G) : Equation4382 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4392_implies_Equation4382
  (G : Type) `{Magma G} (h : Equation4392 G) : Equation4382 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4393_implies_Equation4383
  (G : Type) `{Magma G} (h : Equation4393 G) : Equation4383 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4397_implies_Equation4381
  (G : Type) `{Magma G} (h : Equation4397 G) : Equation4381 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4400_implies_Equation4381
  (G : Type) `{Magma G} (h : Equation4400 G) : Equation4381 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4401_implies_Equation4382
  (G : Type) `{Magma G} (h : Equation4401 G) : Equation4382 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4402_implies_Equation4382
  (G : Type) `{Magma G} (h : Equation4402 G) : Equation4382 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4403_implies_Equation4383
  (G : Type) `{Magma G} (h : Equation4403 G) : Equation4383 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4412_implies_Equation4382
  (G : Type) `{Magma G} (h : Equation4412 G) : Equation4382 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4413_implies_Equation4383
  (G : Type) `{Magma G} (h : Equation4413 G) : Equation4383 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4415_implies_Equation4385
  (G : Type) `{Magma G} (h : Equation4415 G) : Equation4385 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4416_implies_Equation4385
  (G : Type) `{Magma G} (h : Equation4416 G) : Equation4385 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4420_implies_Equation4385
  (G : Type) `{Magma G} (h : Equation4420 G) : Equation4385 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4421_implies_Equation4386
  (G : Type) `{Magma G} (h : Equation4421 G) : Equation4386 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4423_implies_Equation4388
  (G : Type) `{Magma G} (h : Equation4423 G) : Equation4388 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4424_implies_Equation4388
  (G : Type) `{Magma G} (h : Equation4424 G) : Equation4388 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4425_implies_Equation4389
  (G : Type) `{Magma G} (h : Equation4425 G) : Equation4389 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4434_implies_Equation4381
  (G : Type) `{Magma G} (h : Equation4434 G) : Equation4381 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4437_implies_Equation4381
  (G : Type) `{Magma G} (h : Equation4437 G) : Equation4381 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4438_implies_Equation4382
  (G : Type) `{Magma G} (h : Equation4438 G) : Equation4382 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4439_implies_Equation4382
  (G : Type) `{Magma G} (h : Equation4439 G) : Equation4382 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4440_implies_Equation4383
  (G : Type) `{Magma G} (h : Equation4440 G) : Equation4383 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4450_implies_Equation4383
  (G : Type) `{Magma G} (h : Equation4450 G) : Equation4383 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4452_implies_Equation4385
  (G : Type) `{Magma G} (h : Equation4452 G) : Equation4385 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4456_implies_Equation4385
  (G : Type) `{Magma G} (h : Equation4456 G) : Equation4385 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4458_implies_Equation4386
  (G : Type) `{Magma G} (h : Equation4458 G) : Equation4386 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4460_implies_Equation4388
  (G : Type) `{Magma G} (h : Equation4460 G) : Equation4388 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4461_implies_Equation4388
  (G : Type) `{Magma G} (h : Equation4461 G) : Equation4388 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4462_implies_Equation4389
  (G : Type) `{Magma G} (h : Equation4462 G) : Equation4389 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4471_implies_Equation4381
  (G : Type) `{Magma G} (h : Equation4471 G) : Equation4381 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4474_implies_Equation4381
  (G : Type) `{Magma G} (h : Equation4474 G) : Equation4381 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4475_implies_Equation4382
  (G : Type) `{Magma G} (h : Equation4475 G) : Equation4382 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4476_implies_Equation4382
  (G : Type) `{Magma G} (h : Equation4476 G) : Equation4382 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4477_implies_Equation4383
  (G : Type) `{Magma G} (h : Equation4477 G) : Equation4383 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4486_implies_Equation4382
  (G : Type) `{Magma G} (h : Equation4486 G) : Equation4382 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4489_implies_Equation4385
  (G : Type) `{Magma G} (h : Equation4489 G) : Equation4385 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4490_implies_Equation4385
  (G : Type) `{Magma G} (h : Equation4490 G) : Equation4385 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4491_implies_Equation4386
  (G : Type) `{Magma G} (h : Equation4491 G) : Equation4386 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4494_implies_Equation4385
  (G : Type) `{Magma G} (h : Equation4494 G) : Equation4385 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4497_implies_Equation4388
  (G : Type) `{Magma G} (h : Equation4497 G) : Equation4388 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4498_implies_Equation4388
  (G : Type) `{Magma G} (h : Equation4498 G) : Equation4388 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4499_implies_Equation4389
  (G : Type) `{Magma G} (h : Equation4499 G) : Equation4389 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4506_implies_Equation4395
  (G : Type) `{Magma G} (h : Equation4506 G) : Equation4395 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4507_implies_Equation4395
  (G : Type) `{Magma G} (h : Equation4507 G) : Equation4395 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4508_implies_Equation4396
  (G : Type) `{Magma G} (h : Equation4508 G) : Equation4396 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4510_implies_Equation4395
  (G : Type) `{Magma G} (h : Equation4510 G) : Equation4395 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4511_implies_Equation4395
  (G : Type) `{Magma G} (h : Equation4511 G) : Equation4395 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4512_implies_Equation4396
  (G : Type) `{Magma G} (h : Equation4512 G) : Equation4396 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4515_implies_Equation4398
  (G : Type) `{Magma G} (h : Equation4515 G) : Equation4398 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4516_implies_Equation4399
  (G : Type) `{Magma G} (h : Equation4516 G) : Equation4399 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4525_implies_Equation4396
  (G : Type) `{Magma G} (h : Equation4525 G) : Equation4396 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4529_implies_Equation4396
  (G : Type) `{Magma G} (h : Equation4529 G) : Equation4396 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4531_implies_Equation4398
  (G : Type) `{Magma G} (h : Equation4531 G) : Equation4398 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4533_implies_Equation4399
  (G : Type) `{Magma G} (h : Equation4533 G) : Equation4399 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4541_implies_Equation4405
  (G : Type) `{Magma G} (h : Equation4541 G) : Equation4405 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4542_implies_Equation4406
  (G : Type) `{Magma G} (h : Equation4542 G) : Equation4406 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4544_implies_Equation4405
  (G : Type) `{Magma G} (h : Equation4544 G) : Equation4405 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4546_implies_Equation4406
  (G : Type) `{Magma G} (h : Equation4546 G) : Equation4406 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4550_implies_Equation4409
  (G : Type) `{Magma G} (h : Equation4550 G) : Equation4409 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4595_implies_Equation4585
  (G : Type) `{Magma G} (h : Equation4595 G) : Equation4585 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4597_implies_Equation4583
  (G : Type) `{Magma G} (h : Equation4597 G) : Equation4583 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4601_implies_Equation4584
  (G : Type) `{Magma G} (h : Equation4601 G) : Equation4584 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4603_implies_Equation4585
  (G : Type) `{Magma G} (h : Equation4603 G) : Equation4585 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4609_implies_Equation4583
  (G : Type) `{Magma G} (h : Equation4609 G) : Equation4583 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4611_implies_Equation4584
  (G : Type) `{Magma G} (h : Equation4611 G) : Equation4584 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4612_implies_Equation4585
  (G : Type) `{Magma G} (h : Equation4612 G) : Equation4585 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4619_implies_Equation4587
  (G : Type) `{Magma G} (h : Equation4619 G) : Equation4587 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4620_implies_Equation4588
  (G : Type) `{Magma G} (h : Equation4620 G) : Equation4588 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4622_implies_Equation4590
  (G : Type) `{Magma G} (h : Equation4622 G) : Equation4590 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4631_implies_Equation4584
  (G : Type) `{Magma G} (h : Equation4631 G) : Equation4584 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4633_implies_Equation4585
  (G : Type) `{Magma G} (h : Equation4633 G) : Equation4585 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4640_implies_Equation4585
  (G : Type) `{Magma G} (h : Equation4640 G) : Equation4585 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4642_implies_Equation4587
  (G : Type) `{Magma G} (h : Equation4642 G) : Equation4587 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4645_implies_Equation4587
  (G : Type) `{Magma G} (h : Equation4645 G) : Equation4587 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4647_implies_Equation4588
  (G : Type) `{Magma G} (h : Equation4647 G) : Equation4588 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4656_implies_Equation4585
  (G : Type) `{Magma G} (h : Equation4656 G) : Equation4585 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4666_implies_Equation4587
  (G : Type) `{Magma G} (h : Equation4666 G) : Equation4587 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4673_implies_Equation4598
  (G : Type) `{Magma G} (h : Equation4673 G) : Equation4598 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4679_implies_Equation4598
  (G : Type) `{Magma G} (h : Equation4679 G) : Equation4598 G.
Proof. intros x y. exact (h x x y). Qed.

Theorem Equation4684_implies_Equation4605
  (G : Type) `{Magma G} (h : Equation4684 G) : Equation4605 G.
Proof. intros x y. exact (h x x y). Qed.

