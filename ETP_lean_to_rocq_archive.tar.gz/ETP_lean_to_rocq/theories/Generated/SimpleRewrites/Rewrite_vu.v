(** * SimpleRewrites/Rewrite_vu

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation613_implies_Equation612
  (G : Type) `{Magma G} (h : Equation613 G) : Equation612 G.
Proof. intros x y z w u. exact (h x y z w u u). Qed.

Theorem Equation816_implies_Equation815
  (G : Type) `{Magma G} (h : Equation816 G) : Equation815 G.
Proof. intros x y z w u. exact (h x y z w u u). Qed.

Theorem Equation1019_implies_Equation1018
  (G : Type) `{Magma G} (h : Equation1019 G) : Equation1018 G.
Proof. intros x y z w u. exact (h x y z w u u). Qed.

Theorem Equation1222_implies_Equation1221
  (G : Type) `{Magma G} (h : Equation1222 G) : Equation1221 G.
Proof. intros x y z w u. exact (h x y z w u u). Qed.

Theorem Equation1425_implies_Equation1424
  (G : Type) `{Magma G} (h : Equation1425 G) : Equation1424 G.
Proof. intros x y z w u. exact (h x y z w u u). Qed.

Theorem Equation1628_implies_Equation1627
  (G : Type) `{Magma G} (h : Equation1628 G) : Equation1627 G.
Proof. intros x y z w u. exact (h x y z w u u). Qed.

Theorem Equation1831_implies_Equation1830
  (G : Type) `{Magma G} (h : Equation1831 G) : Equation1830 G.
Proof. intros x y z w u. exact (h x y z w u u). Qed.

Theorem Equation2034_implies_Equation2033
  (G : Type) `{Magma G} (h : Equation2034 G) : Equation2033 G.
Proof. intros x y z w u. exact (h x y z w u u). Qed.

Theorem Equation2237_implies_Equation2236
  (G : Type) `{Magma G} (h : Equation2237 G) : Equation2236 G.
Proof. intros x y z w u. exact (h x y z w u u). Qed.

Theorem Equation2643_implies_Equation2642
  (G : Type) `{Magma G} (h : Equation2643 G) : Equation2642 G.
Proof. intros x y z w u. exact (h x y z w u u). Qed.

Theorem Equation2846_implies_Equation2845
  (G : Type) `{Magma G} (h : Equation2846 G) : Equation2845 G.
Proof. intros x y z w u. exact (h x y z w u u). Qed.

Theorem Equation3049_implies_Equation3048
  (G : Type) `{Magma G} (h : Equation3049 G) : Equation3048 G.
Proof. intros x y z w u. exact (h x y z w u u). Qed.

Theorem Equation3252_implies_Equation3251
  (G : Type) `{Magma G} (h : Equation3252 G) : Equation3251 G.
Proof. intros x y z w u. exact (h x y z w u u). Qed.

