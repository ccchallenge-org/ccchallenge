(** * SimpleRewrites/Rewrite_wx

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation146_implies_Equation134
  (G : Type) `{Magma G} (h : Equation146 G) : Equation134 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation304_implies_Equation292
  (G : Type) `{Magma G} (h : Equation304 G) : Equation292 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation341_implies_Equation338
  (G : Type) `{Magma G} (h : Equation341 G) : Equation338 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation349_implies_Equation346
  (G : Type) `{Magma G} (h : Equation349 G) : Equation346 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation353_implies_Equation350
  (G : Type) `{Magma G} (h : Equation353 G) : Equation350 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation357_implies_Equation342
  (G : Type) `{Magma G} (h : Equation357 G) : Equation342 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation383_implies_Equation380
  (G : Type) `{Magma G} (h : Equation383 G) : Equation380 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation393_implies_Equation390
  (G : Type) `{Magma G} (h : Equation393 G) : Equation390 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation405_implies_Equation402
  (G : Type) `{Magma G} (h : Equation405 G) : Equation402 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation409_implies_Equation394
  (G : Type) `{Magma G} (h : Equation409 G) : Equation394 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation425_implies_Equation422
  (G : Type) `{Magma G} (h : Equation425 G) : Equation422 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation457_implies_Equation454
  (G : Type) `{Magma G} (h : Equation457 G) : Equation454 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation459_implies_Equation447
  (G : Type) `{Magma G} (h : Equation459 G) : Equation447 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation533_implies_Equation521
  (G : Type) `{Magma G} (h : Equation533 G) : Equation521 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation583_implies_Equation571
  (G : Type) `{Magma G} (h : Equation583 G) : Equation571 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation588_implies_Equation537
  (G : Type) `{Magma G} (h : Equation588 G) : Equation537 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation603_implies_Equation537
  (G : Type) `{Magma G} (h : Equation603 G) : Equation537 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation661_implies_Equation649
  (G : Type) `{Magma G} (h : Equation661 G) : Equation649 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation663_implies_Equation651
  (G : Type) `{Magma G} (h : Equation663 G) : Equation651 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation664_implies_Equation649
  (G : Type) `{Magma G} (h : Equation664 G) : Equation649 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation769_implies_Equation757
  (G : Type) `{Magma G} (h : Equation769 G) : Equation757 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation786_implies_Equation774
  (G : Type) `{Magma G} (h : Equation786 G) : Equation774 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation793_implies_Equation742
  (G : Type) `{Magma G} (h : Equation793 G) : Equation742 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation796_implies_Equation744
  (G : Type) `{Magma G} (h : Equation796 G) : Equation744 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation801_implies_Equation748
  (G : Type) `{Magma G} (h : Equation801 G) : Equation748 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation806_implies_Equation740
  (G : Type) `{Magma G} (h : Equation806 G) : Equation740 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation831_implies_Equation828
  (G : Type) `{Magma G} (h : Equation831 G) : Equation828 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation841_implies_Equation838
  (G : Type) `{Magma G} (h : Equation841 G) : Equation838 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation851_implies_Equation848
  (G : Type) `{Magma G} (h : Equation851 G) : Equation848 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation865_implies_Equation853
  (G : Type) `{Magma G} (h : Equation865 G) : Equation853 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation903_implies_Equation891
  (G : Type) `{Magma G} (h : Equation903 G) : Equation891 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation938_implies_Equation926
  (G : Type) `{Magma G} (h : Equation938 G) : Equation926 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation955_implies_Equation943
  (G : Type) `{Magma G} (h : Equation955 G) : Equation943 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation972_implies_Equation960
  (G : Type) `{Magma G} (h : Equation972 G) : Equation960 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation989_implies_Equation977
  (G : Type) `{Magma G} (h : Equation989 G) : Equation977 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation994_implies_Equation943
  (G : Type) `{Magma G} (h : Equation994 G) : Equation943 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation995_implies_Equation944
  (G : Type) `{Magma G} (h : Equation995 G) : Equation944 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation996_implies_Equation945
  (G : Type) `{Magma G} (h : Equation996 G) : Equation945 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation999_implies_Equation947
  (G : Type) `{Magma G} (h : Equation999 G) : Equation947 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1004_implies_Equation951
  (G : Type) `{Magma G} (h : Equation1004 G) : Equation951 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1006_implies_Equation953
  (G : Type) `{Magma G} (h : Equation1006 G) : Equation953 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1009_implies_Equation943
  (G : Type) `{Magma G} (h : Equation1009 G) : Equation943 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1067_implies_Equation1055
  (G : Type) `{Magma G} (h : Equation1067 G) : Equation1055 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1068_implies_Equation1056
  (G : Type) `{Magma G} (h : Equation1068 G) : Equation1056 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1104_implies_Equation1092
  (G : Type) `{Magma G} (h : Equation1104 G) : Equation1092 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1175_implies_Equation1163
  (G : Type) `{Magma G} (h : Equation1175 G) : Equation1163 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1192_implies_Equation1180
  (G : Type) `{Magma G} (h : Equation1192 G) : Equation1180 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1198_implies_Equation1147
  (G : Type) `{Magma G} (h : Equation1198 G) : Equation1147 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1199_implies_Equation1148
  (G : Type) `{Magma G} (h : Equation1199 G) : Equation1148 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1202_implies_Equation1150
  (G : Type) `{Magma G} (h : Equation1202 G) : Equation1150 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1203_implies_Equation1151
  (G : Type) `{Magma G} (h : Equation1203 G) : Equation1151 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1209_implies_Equation1156
  (G : Type) `{Magma G} (h : Equation1209 G) : Equation1156 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1237_implies_Equation1234
  (G : Type) `{Magma G} (h : Equation1237 G) : Equation1234 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1257_implies_Equation1254
  (G : Type) `{Magma G} (h : Equation1257 G) : Equation1254 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1271_implies_Equation1259
  (G : Type) `{Magma G} (h : Equation1271 G) : Equation1259 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1378_implies_Equation1366
  (G : Type) `{Magma G} (h : Equation1378 G) : Equation1366 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1400_implies_Equation1349
  (G : Type) `{Magma G} (h : Equation1400 G) : Equation1349 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1401_implies_Equation1350
  (G : Type) `{Magma G} (h : Equation1401 G) : Equation1350 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1402_implies_Equation1351
  (G : Type) `{Magma G} (h : Equation1402 G) : Equation1351 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1405_implies_Equation1353
  (G : Type) `{Magma G} (h : Equation1405 G) : Equation1353 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1473_implies_Equation1461
  (G : Type) `{Magma G} (h : Equation1473 G) : Equation1461 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1474_implies_Equation1462
  (G : Type) `{Magma G} (h : Equation1474 G) : Equation1462 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1487_implies_Equation1484
  (G : Type) `{Magma G} (h : Equation1487 G) : Equation1484 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1511_implies_Equation1499
  (G : Type) `{Magma G} (h : Equation1511 G) : Equation1499 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1512_implies_Equation1500
  (G : Type) `{Magma G} (h : Equation1512 G) : Equation1500 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1548_implies_Equation1536
  (G : Type) `{Magma G} (h : Equation1548 G) : Equation1536 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1564_implies_Equation1552
  (G : Type) `{Magma G} (h : Equation1564 G) : Equation1552 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1566_implies_Equation1554
  (G : Type) `{Magma G} (h : Equation1566 G) : Equation1554 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1581_implies_Equation1569
  (G : Type) `{Magma G} (h : Equation1581 G) : Equation1569 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1604_implies_Equation1553
  (G : Type) `{Magma G} (h : Equation1604 G) : Equation1553 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1676_implies_Equation1664
  (G : Type) `{Magma G} (h : Equation1676 G) : Equation1664 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1677_implies_Equation1665
  (G : Type) `{Magma G} (h : Equation1677 G) : Equation1665 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1714_implies_Equation1702
  (G : Type) `{Magma G} (h : Equation1714 G) : Equation1702 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1715_implies_Equation1703
  (G : Type) `{Magma G} (h : Equation1715 G) : Equation1703 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1751_implies_Equation1739
  (G : Type) `{Magma G} (h : Equation1751 G) : Equation1739 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1768_implies_Equation1756
  (G : Type) `{Magma G} (h : Equation1768 G) : Equation1756 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1769_implies_Equation1757
  (G : Type) `{Magma G} (h : Equation1769 G) : Equation1757 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1785_implies_Equation1773
  (G : Type) `{Magma G} (h : Equation1785 G) : Equation1773 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1801_implies_Equation1789
  (G : Type) `{Magma G} (h : Equation1801 G) : Equation1789 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1807_implies_Equation1756
  (G : Type) `{Magma G} (h : Equation1807 G) : Equation1756 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1808_implies_Equation1757
  (G : Type) `{Magma G} (h : Equation1808 G) : Equation1757 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1812_implies_Equation1760
  (G : Type) `{Magma G} (h : Equation1812 G) : Equation1760 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1823_implies_Equation1757
  (G : Type) `{Magma G} (h : Equation1823 G) : Equation1757 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1874_implies_Equation1871
  (G : Type) `{Magma G} (h : Equation1874 G) : Equation1871 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1879_implies_Equation1867
  (G : Type) `{Magma G} (h : Equation1879 G) : Equation1867 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1917_implies_Equation1905
  (G : Type) `{Magma G} (h : Equation1917 G) : Equation1905 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1971_implies_Equation1959
  (G : Type) `{Magma G} (h : Equation1971 G) : Equation1959 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1972_implies_Equation1960
  (G : Type) `{Magma G} (h : Equation1972 G) : Equation1960 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1987_implies_Equation1975
  (G : Type) `{Magma G} (h : Equation1987 G) : Equation1975 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation1988_implies_Equation1976
  (G : Type) `{Magma G} (h : Equation1988 G) : Equation1976 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2010_implies_Equation1959
  (G : Type) `{Magma G} (h : Equation2010 G) : Equation1959 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2014_implies_Equation1962
  (G : Type) `{Magma G} (h : Equation2014 G) : Equation1962 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2019_implies_Equation1966
  (G : Type) `{Magma G} (h : Equation2019 G) : Equation1966 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2024_implies_Equation1958
  (G : Type) `{Magma G} (h : Equation2024 G) : Equation1958 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2077_implies_Equation2074
  (G : Type) `{Magma G} (h : Equation2077 G) : Equation2074 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2082_implies_Equation2070
  (G : Type) `{Magma G} (h : Equation2082 G) : Equation2070 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2083_implies_Equation2071
  (G : Type) `{Magma G} (h : Equation2083 G) : Equation2071 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2120_implies_Equation2108
  (G : Type) `{Magma G} (h : Equation2120 G) : Equation2108 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2164_implies_Equation2161
  (G : Type) `{Magma G} (h : Equation2164 G) : Equation2161 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2207_implies_Equation2195
  (G : Type) `{Magma G} (h : Equation2207 G) : Equation2195 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2285_implies_Equation2273
  (G : Type) `{Magma G} (h : Equation2285 G) : Equation2273 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2286_implies_Equation2274
  (G : Type) `{Magma G} (h : Equation2286 G) : Equation2274 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2287_implies_Equation2275
  (G : Type) `{Magma G} (h : Equation2287 G) : Equation2275 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2322_implies_Equation2310
  (G : Type) `{Magma G} (h : Equation2322 G) : Equation2310 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2323_implies_Equation2311
  (G : Type) `{Magma G} (h : Equation2323 G) : Equation2311 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2324_implies_Equation2312
  (G : Type) `{Magma G} (h : Equation2324 G) : Equation2312 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2376_implies_Equation2364
  (G : Type) `{Magma G} (h : Equation2376 G) : Equation2364 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2377_implies_Equation2365
  (G : Type) `{Magma G} (h : Equation2377 G) : Equation2365 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2417_implies_Equation2366
  (G : Type) `{Magma G} (h : Equation2417 G) : Equation2366 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2420_implies_Equation2368
  (G : Type) `{Magma G} (h : Equation2420 G) : Equation2368 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2425_implies_Equation2372
  (G : Type) `{Magma G} (h : Equation2425 G) : Equation2372 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2483_implies_Equation2480
  (G : Type) `{Magma G} (h : Equation2483 G) : Equation2480 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2527_implies_Equation2515
  (G : Type) `{Magma G} (h : Equation2527 G) : Equation2515 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2619_implies_Equation2568
  (G : Type) `{Magma G} (h : Equation2619 G) : Equation2568 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2620_implies_Equation2569
  (G : Type) `{Magma G} (h : Equation2620 G) : Equation2569 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2623_implies_Equation2571
  (G : Type) `{Magma G} (h : Equation2623 G) : Equation2571 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2628_implies_Equation2575
  (G : Type) `{Magma G} (h : Equation2628 G) : Equation2575 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2691_implies_Equation2679
  (G : Type) `{Magma G} (h : Equation2691 G) : Equation2679 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2692_implies_Equation2680
  (G : Type) `{Magma G} (h : Equation2692 G) : Equation2680 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2784_implies_Equation2772
  (G : Type) `{Magma G} (h : Equation2784 G) : Equation2772 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2822_implies_Equation2771
  (G : Type) `{Magma G} (h : Equation2822 G) : Equation2771 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2895_implies_Equation2883
  (G : Type) `{Magma G} (h : Equation2895 G) : Equation2883 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2908_implies_Equation2905
  (G : Type) `{Magma G} (h : Equation2908 G) : Equation2905 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation2932_implies_Equation2920
  (G : Type) `{Magma G} (h : Equation2932 G) : Equation2920 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3024_implies_Equation2973
  (G : Type) `{Magma G} (h : Equation3024 G) : Equation2973 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3026_implies_Equation2975
  (G : Type) `{Magma G} (h : Equation3026 G) : Equation2975 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3029_implies_Equation2977
  (G : Type) `{Magma G} (h : Equation3029 G) : Equation2977 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3034_implies_Equation2981
  (G : Type) `{Magma G} (h : Equation3034 G) : Equation2981 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3064_implies_Equation3061
  (G : Type) `{Magma G} (h : Equation3064 G) : Equation3061 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3097_implies_Equation3085
  (G : Type) `{Magma G} (h : Equation3097 G) : Equation3085 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3098_implies_Equation3086
  (G : Type) `{Magma G} (h : Equation3098 G) : Equation3086 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3136_implies_Equation3124
  (G : Type) `{Magma G} (h : Equation3136 G) : Equation3124 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3162_implies_Equation3159
  (G : Type) `{Magma G} (h : Equation3162 G) : Equation3159 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3172_implies_Equation3160
  (G : Type) `{Magma G} (h : Equation3172 G) : Equation3160 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3191_implies_Equation3176
  (G : Type) `{Magma G} (h : Equation3191 G) : Equation3176 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3239_implies_Equation3186
  (G : Type) `{Magma G} (h : Equation3239 G) : Equation3186 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3267_implies_Equation3264
  (G : Type) `{Magma G} (h : Equation3267 G) : Equation3264 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3295_implies_Equation3292
  (G : Type) `{Magma G} (h : Equation3295 G) : Equation3292 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3299_implies_Equation3296
  (G : Type) `{Magma G} (h : Equation3299 G) : Equation3296 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3301_implies_Equation3289
  (G : Type) `{Magma G} (h : Equation3301 G) : Equation3289 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3302_implies_Equation3290
  (G : Type) `{Magma G} (h : Equation3302 G) : Equation3290 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3314_implies_Equation3311
  (G : Type) `{Magma G} (h : Equation3314 G) : Equation3311 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3324_implies_Equation3321
  (G : Type) `{Magma G} (h : Equation3324 G) : Equation3321 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3332_implies_Equation3329
  (G : Type) `{Magma G} (h : Equation3332 G) : Equation3329 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3336_implies_Equation3333
  (G : Type) `{Magma G} (h : Equation3336 G) : Equation3333 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3338_implies_Equation3326
  (G : Type) `{Magma G} (h : Equation3338 G) : Equation3326 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3339_implies_Equation3327
  (G : Type) `{Magma G} (h : Equation3339 G) : Equation3327 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3340_implies_Equation3325
  (G : Type) `{Magma G} (h : Equation3340 G) : Equation3325 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3351_implies_Equation3348
  (G : Type) `{Magma G} (h : Equation3351 G) : Equation3348 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3365_implies_Equation3362
  (G : Type) `{Magma G} (h : Equation3365 G) : Equation3362 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3369_implies_Equation3366
  (G : Type) `{Magma G} (h : Equation3369 G) : Equation3366 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3374_implies_Equation3362
  (G : Type) `{Magma G} (h : Equation3374 G) : Equation3362 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3377_implies_Equation3362
  (G : Type) `{Magma G} (h : Equation3377 G) : Equation3362 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3386_implies_Equation3383
  (G : Type) `{Magma G} (h : Equation3386 G) : Equation3383 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3390_implies_Equation3387
  (G : Type) `{Magma G} (h : Equation3390 G) : Equation3387 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3392_implies_Equation3380
  (G : Type) `{Magma G} (h : Equation3392 G) : Equation3380 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3399_implies_Equation3396
  (G : Type) `{Magma G} (h : Equation3399 G) : Equation3396 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3424_implies_Equation3421
  (G : Type) `{Magma G} (h : Equation3424 G) : Equation3421 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3427_implies_Equation3415
  (G : Type) `{Magma G} (h : Equation3427 G) : Equation3415 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3431_implies_Equation3380
  (G : Type) `{Magma G} (h : Equation3431 G) : Equation3380 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3435_implies_Equation3383
  (G : Type) `{Magma G} (h : Equation3435 G) : Equation3383 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3438_implies_Equation3383
  (G : Type) `{Magma G} (h : Equation3438 G) : Equation3383 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3448_implies_Equation3379
  (G : Type) `{Magma G} (h : Equation3448 G) : Equation3379 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3470_implies_Equation3467
  (G : Type) `{Magma G} (h : Equation3470 G) : Equation3467 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3498_implies_Equation3495
  (G : Type) `{Magma G} (h : Equation3498 G) : Equation3495 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3502_implies_Equation3499
  (G : Type) `{Magma G} (h : Equation3502 G) : Equation3499 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3503_implies_Equation3491
  (G : Type) `{Magma G} (h : Equation3503 G) : Equation3491 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3504_implies_Equation3492
  (G : Type) `{Magma G} (h : Equation3504 G) : Equation3492 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3505_implies_Equation3493
  (G : Type) `{Magma G} (h : Equation3505 G) : Equation3493 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3506_implies_Equation3491
  (G : Type) `{Magma G} (h : Equation3506 G) : Equation3491 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3527_implies_Equation3524
  (G : Type) `{Magma G} (h : Equation3527 G) : Equation3524 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3535_implies_Equation3532
  (G : Type) `{Magma G} (h : Equation3535 G) : Equation3532 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3539_implies_Equation3536
  (G : Type) `{Magma G} (h : Equation3539 G) : Equation3536 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3540_implies_Equation3528
  (G : Type) `{Magma G} (h : Equation3540 G) : Equation3528 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3541_implies_Equation3529
  (G : Type) `{Magma G} (h : Equation3541 G) : Equation3529 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3542_implies_Equation3530
  (G : Type) `{Magma G} (h : Equation3542 G) : Equation3530 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3568_implies_Equation3565
  (G : Type) `{Magma G} (h : Equation3568 G) : Equation3565 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3589_implies_Equation3586
  (G : Type) `{Magma G} (h : Equation3589 G) : Equation3586 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3593_implies_Equation3590
  (G : Type) `{Magma G} (h : Equation3593 G) : Equation3590 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3602_implies_Equation3599
  (G : Type) `{Magma G} (h : Equation3602 G) : Equation3599 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3606_implies_Equation3603
  (G : Type) `{Magma G} (h : Equation3606 G) : Equation3603 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3611_implies_Equation3599
  (G : Type) `{Magma G} (h : Equation3611 G) : Equation3599 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3627_implies_Equation3624
  (G : Type) `{Magma G} (h : Equation3627 G) : Equation3624 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3630_implies_Equation3618
  (G : Type) `{Magma G} (h : Equation3630 G) : Equation3618 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3631_implies_Equation3616
  (G : Type) `{Magma G} (h : Equation3631 G) : Equation3616 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3634_implies_Equation3583
  (G : Type) `{Magma G} (h : Equation3634 G) : Equation3583 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3644_implies_Equation3591
  (G : Type) `{Magma G} (h : Equation3644 G) : Equation3591 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3651_implies_Equation3582
  (G : Type) `{Magma G} (h : Equation3651 G) : Equation3582 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3673_implies_Equation3670
  (G : Type) `{Magma G} (h : Equation3673 G) : Equation3670 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3693_implies_Equation3690
  (G : Type) `{Magma G} (h : Equation3693 G) : Equation3690 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3701_implies_Equation3698
  (G : Type) `{Magma G} (h : Equation3701 G) : Equation3698 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3705_implies_Equation3702
  (G : Type) `{Magma G} (h : Equation3705 G) : Equation3702 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3706_implies_Equation3694
  (G : Type) `{Magma G} (h : Equation3706 G) : Equation3694 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3707_implies_Equation3695
  (G : Type) `{Magma G} (h : Equation3707 G) : Equation3695 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3708_implies_Equation3696
  (G : Type) `{Magma G} (h : Equation3708 G) : Equation3696 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3709_implies_Equation3694
  (G : Type) `{Magma G} (h : Equation3709 G) : Equation3694 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3730_implies_Equation3727
  (G : Type) `{Magma G} (h : Equation3730 G) : Equation3727 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3734_implies_Equation3731
  (G : Type) `{Magma G} (h : Equation3734 G) : Equation3731 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3738_implies_Equation3735
  (G : Type) `{Magma G} (h : Equation3738 G) : Equation3735 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3742_implies_Equation3739
  (G : Type) `{Magma G} (h : Equation3742 G) : Equation3739 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3743_implies_Equation3731
  (G : Type) `{Magma G} (h : Equation3743 G) : Equation3731 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3744_implies_Equation3732
  (G : Type) `{Magma G} (h : Equation3744 G) : Equation3732 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3746_implies_Equation3731
  (G : Type) `{Magma G} (h : Equation3746 G) : Equation3731 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3757_implies_Equation3754
  (G : Type) `{Magma G} (h : Equation3757 G) : Equation3754 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3767_implies_Equation3764
  (G : Type) `{Magma G} (h : Equation3767 G) : Equation3764 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3783_implies_Equation3768
  (G : Type) `{Magma G} (h : Equation3783 G) : Equation3768 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3796_implies_Equation3793
  (G : Type) `{Magma G} (h : Equation3796 G) : Equation3793 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3798_implies_Equation3786
  (G : Type) `{Magma G} (h : Equation3798 G) : Equation3786 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3805_implies_Equation3802
  (G : Type) `{Magma G} (h : Equation3805 G) : Equation3802 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3830_implies_Equation3827
  (G : Type) `{Magma G} (h : Equation3830 G) : Equation3827 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3836_implies_Equation3785
  (G : Type) `{Magma G} (h : Equation3836 G) : Equation3785 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3838_implies_Equation3787
  (G : Type) `{Magma G} (h : Equation3838 G) : Equation3787 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3841_implies_Equation3789
  (G : Type) `{Magma G} (h : Equation3841 G) : Equation3789 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3846_implies_Equation3793
  (G : Type) `{Magma G} (h : Equation3846 G) : Equation3793 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3848_implies_Equation3795
  (G : Type) `{Magma G} (h : Equation3848 G) : Equation3795 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3876_implies_Equation3873
  (G : Type) `{Magma G} (h : Equation3876 G) : Equation3873 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3896_implies_Equation3893
  (G : Type) `{Magma G} (h : Equation3896 G) : Equation3893 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3904_implies_Equation3901
  (G : Type) `{Magma G} (h : Equation3904 G) : Equation3901 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3909_implies_Equation3897
  (G : Type) `{Magma G} (h : Equation3909 G) : Equation3897 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3911_implies_Equation3899
  (G : Type) `{Magma G} (h : Equation3911 G) : Equation3899 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3912_implies_Equation3897
  (G : Type) `{Magma G} (h : Equation3912 G) : Equation3897 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3923_implies_Equation3920
  (G : Type) `{Magma G} (h : Equation3923 G) : Equation3920 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3933_implies_Equation3930
  (G : Type) `{Magma G} (h : Equation3933 G) : Equation3930 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3937_implies_Equation3934
  (G : Type) `{Magma G} (h : Equation3937 G) : Equation3934 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3941_implies_Equation3938
  (G : Type) `{Magma G} (h : Equation3941 G) : Equation3938 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3945_implies_Equation3942
  (G : Type) `{Magma G} (h : Equation3945 G) : Equation3942 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3947_implies_Equation3935
  (G : Type) `{Magma G} (h : Equation3947 G) : Equation3935 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3960_implies_Equation3957
  (G : Type) `{Magma G} (h : Equation3960 G) : Equation3957 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3974_implies_Equation3971
  (G : Type) `{Magma G} (h : Equation3974 G) : Equation3971 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation3995_implies_Equation3992
  (G : Type) `{Magma G} (h : Equation3995 G) : Equation3992 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4001_implies_Equation3989
  (G : Type) `{Magma G} (h : Equation4001 G) : Equation3989 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4002_implies_Equation3990
  (G : Type) `{Magma G} (h : Equation4002 G) : Equation3990 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4003_implies_Equation3988
  (G : Type) `{Magma G} (h : Equation4003 G) : Equation3988 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4008_implies_Equation4005
  (G : Type) `{Magma G} (h : Equation4008 G) : Equation4005 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4033_implies_Equation4030
  (G : Type) `{Magma G} (h : Equation4033 G) : Equation4030 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4034_implies_Equation4022
  (G : Type) `{Magma G} (h : Equation4034 G) : Equation4022 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4036_implies_Equation4024
  (G : Type) `{Magma G} (h : Equation4036 G) : Equation4024 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4037_implies_Equation4022
  (G : Type) `{Magma G} (h : Equation4037 G) : Equation4022 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4040_implies_Equation3989
  (G : Type) `{Magma G} (h : Equation4040 G) : Equation3989 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4041_implies_Equation3990
  (G : Type) `{Magma G} (h : Equation4041 G) : Equation3990 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4042_implies_Equation3988
  (G : Type) `{Magma G} (h : Equation4042 G) : Equation3988 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4051_implies_Equation3998
  (G : Type) `{Magma G} (h : Equation4051 G) : Equation3998 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4052_implies_Equation3996
  (G : Type) `{Magma G} (h : Equation4052 G) : Equation3996 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4054_implies_Equation3988
  (G : Type) `{Magma G} (h : Equation4054 G) : Equation3988 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4056_implies_Equation3990
  (G : Type) `{Magma G} (h : Equation4056 G) : Equation3990 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4057_implies_Equation3988
  (G : Type) `{Magma G} (h : Equation4057 G) : Equation3988 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4079_implies_Equation4076
  (G : Type) `{Magma G} (h : Equation4079 G) : Equation4076 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4107_implies_Equation4104
  (G : Type) `{Magma G} (h : Equation4107 G) : Equation4104 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4112_implies_Equation4100
  (G : Type) `{Magma G} (h : Equation4112 G) : Equation4100 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4113_implies_Equation4101
  (G : Type) `{Magma G} (h : Equation4113 G) : Equation4101 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4114_implies_Equation4102
  (G : Type) `{Magma G} (h : Equation4114 G) : Equation4102 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4115_implies_Equation4100
  (G : Type) `{Magma G} (h : Equation4115 G) : Equation4100 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4148_implies_Equation4145
  (G : Type) `{Magma G} (h : Equation4148 G) : Equation4145 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4150_implies_Equation4138
  (G : Type) `{Magma G} (h : Equation4150 G) : Equation4138 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4186_implies_Equation4174
  (G : Type) `{Magma G} (h : Equation4186 G) : Equation4174 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4203_implies_Equation4191
  (G : Type) `{Magma G} (h : Equation4203 G) : Equation4191 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4204_implies_Equation4192
  (G : Type) `{Magma G} (h : Equation4204 G) : Equation4192 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4211_implies_Equation4208
  (G : Type) `{Magma G} (h : Equation4211 G) : Equation4208 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4215_implies_Equation4212
  (G : Type) `{Magma G} (h : Equation4215 G) : Equation4212 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4220_implies_Equation4208
  (G : Type) `{Magma G} (h : Equation4220 G) : Equation4208 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4237_implies_Equation4225
  (G : Type) `{Magma G} (h : Equation4237 G) : Equation4225 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4239_implies_Equation4227
  (G : Type) `{Magma G} (h : Equation4239 G) : Equation4227 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4243_implies_Equation4192
  (G : Type) `{Magma G} (h : Equation4243 G) : Equation4192 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4248_implies_Equation4196
  (G : Type) `{Magma G} (h : Equation4248 G) : Equation4196 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4249_implies_Equation4197
  (G : Type) `{Magma G} (h : Equation4249 G) : Equation4197 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4252_implies_Equation4199
  (G : Type) `{Magma G} (h : Equation4252 G) : Equation4199 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4253_implies_Equation4200
  (G : Type) `{Magma G} (h : Equation4253 G) : Equation4200 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4254_implies_Equation4201
  (G : Type) `{Magma G} (h : Equation4254 G) : Equation4201 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4255_implies_Equation4199
  (G : Type) `{Magma G} (h : Equation4255 G) : Equation4199 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4309_implies_Equation4299
  (G : Type) `{Magma G} (h : Equation4309 G) : Equation4299 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4311_implies_Equation4301
  (G : Type) `{Magma G} (h : Equation4311 G) : Equation4301 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4312_implies_Equation4299
  (G : Type) `{Magma G} (h : Equation4312 G) : Equation4299 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4334_implies_Equation4327
  (G : Type) `{Magma G} (h : Equation4334 G) : Equation4327 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4335_implies_Equation4328
  (G : Type) `{Magma G} (h : Equation4335 G) : Equation4328 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4337_implies_Equation4327
  (G : Type) `{Magma G} (h : Equation4337 G) : Equation4327 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4352_implies_Equation4350
  (G : Type) `{Magma G} (h : Equation4352 G) : Equation4350 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4354_implies_Equation4348
  (G : Type) `{Magma G} (h : Equation4354 G) : Equation4348 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4367_implies_Equation4362
  (G : Type) `{Magma G} (h : Equation4367 G) : Equation4362 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4376_implies_Equation4358
  (G : Type) `{Magma G} (h : Equation4376 G) : Equation4358 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4404_implies_Equation4401
  (G : Type) `{Magma G} (h : Equation4404 G) : Equation4401 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4422_implies_Equation4419
  (G : Type) `{Magma G} (h : Equation4422 G) : Equation4419 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4426_implies_Equation4423
  (G : Type) `{Magma G} (h : Equation4426 G) : Equation4423 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4427_implies_Equation4415
  (G : Type) `{Magma G} (h : Equation4427 G) : Equation4415 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4428_implies_Equation4416
  (G : Type) `{Magma G} (h : Equation4428 G) : Equation4416 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4429_implies_Equation4417
  (G : Type) `{Magma G} (h : Equation4429 G) : Equation4417 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4430_implies_Equation4415
  (G : Type) `{Magma G} (h : Equation4430 G) : Equation4415 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4441_implies_Equation4438
  (G : Type) `{Magma G} (h : Equation4441 G) : Equation4438 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4451_implies_Equation4448
  (G : Type) `{Magma G} (h : Equation4451 G) : Equation4448 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4463_implies_Equation4460
  (G : Type) `{Magma G} (h : Equation4463 G) : Equation4460 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4465_implies_Equation4453
  (G : Type) `{Magma G} (h : Equation4465 G) : Equation4453 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4466_implies_Equation4454
  (G : Type) `{Magma G} (h : Equation4466 G) : Equation4454 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4467_implies_Equation4452
  (G : Type) `{Magma G} (h : Equation4467 G) : Equation4452 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4478_implies_Equation4475
  (G : Type) `{Magma G} (h : Equation4478 G) : Equation4475 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4496_implies_Equation4493
  (G : Type) `{Magma G} (h : Equation4496 G) : Equation4493 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4500_implies_Equation4497
  (G : Type) `{Magma G} (h : Equation4500 G) : Equation4497 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4501_implies_Equation4489
  (G : Type) `{Magma G} (h : Equation4501 G) : Equation4489 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4502_implies_Equation4490
  (G : Type) `{Magma G} (h : Equation4502 G) : Equation4490 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4503_implies_Equation4491
  (G : Type) `{Magma G} (h : Equation4503 G) : Equation4491 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4504_implies_Equation4489
  (G : Type) `{Magma G} (h : Equation4504 G) : Equation4489 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4509_implies_Equation4506
  (G : Type) `{Magma G} (h : Equation4509 G) : Equation4506 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4513_implies_Equation4510
  (G : Type) `{Magma G} (h : Equation4513 G) : Equation4510 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4518_implies_Equation4506
  (G : Type) `{Magma G} (h : Equation4518 G) : Equation4506 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4519_implies_Equation4507
  (G : Type) `{Magma G} (h : Equation4519 G) : Equation4507 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4520_implies_Equation4508
  (G : Type) `{Magma G} (h : Equation4520 G) : Equation4508 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4521_implies_Equation4506
  (G : Type) `{Magma G} (h : Equation4521 G) : Equation4506 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4536_implies_Equation4524
  (G : Type) `{Magma G} (h : Equation4536 G) : Equation4524 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4551_implies_Equation4548
  (G : Type) `{Magma G} (h : Equation4551 G) : Equation4548 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4554_implies_Equation4542
  (G : Type) `{Magma G} (h : Equation4554 G) : Equation4542 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4557_implies_Equation4506
  (G : Type) `{Magma G} (h : Equation4557 G) : Equation4506 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4559_implies_Equation4508
  (G : Type) `{Magma G} (h : Equation4559 G) : Equation4508 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4563_implies_Equation4511
  (G : Type) `{Magma G} (h : Equation4563 G) : Equation4511 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4564_implies_Equation4512
  (G : Type) `{Magma G} (h : Equation4564 G) : Equation4512 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4569_implies_Equation4516
  (G : Type) `{Magma G} (h : Equation4569 G) : Equation4516 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4570_implies_Equation4514
  (G : Type) `{Magma G} (h : Equation4570 G) : Equation4514 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4572_implies_Equation4506
  (G : Type) `{Magma G} (h : Equation4572 G) : Equation4506 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4574_implies_Equation4508
  (G : Type) `{Magma G} (h : Equation4574 G) : Equation4508 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4575_implies_Equation4506
  (G : Type) `{Magma G} (h : Equation4575 G) : Equation4506 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4617_implies_Equation4614
  (G : Type) `{Magma G} (h : Equation4617 G) : Equation4614 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4624_implies_Equation4614
  (G : Type) `{Magma G} (h : Equation4624 G) : Equation4614 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4626_implies_Equation4616
  (G : Type) `{Magma G} (h : Equation4626 G) : Equation4616 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4627_implies_Equation4614
  (G : Type) `{Magma G} (h : Equation4627 G) : Equation4614 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4652_implies_Equation4642
  (G : Type) `{Magma G} (h : Equation4652 G) : Equation4642 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4667_implies_Equation4665
  (G : Type) `{Magma G} (h : Equation4667 G) : Equation4665 G.
Proof. intros x y z. exact (h x y z x). Qed.

Theorem Equation4682_implies_Equation4677
  (G : Type) `{Magma G} (h : Equation4682 G) : Equation4677 G.
Proof. intros x y z. exact (h x y z x). Qed.

