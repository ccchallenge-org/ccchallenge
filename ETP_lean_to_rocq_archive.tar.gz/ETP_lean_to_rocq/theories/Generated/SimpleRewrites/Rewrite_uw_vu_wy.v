(** * SimpleRewrites/Rewrite_uw_vu_wy

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation1222_implies_Equation1179
  (G : Type) `{Magma G} (h : Equation1222 G) : Equation1179 G.
Proof. intros x y z w u. exact (h x y z y w u). Qed.

Theorem Equation1628_implies_Equation1585
  (G : Type) `{Magma G} (h : Equation1628 G) : Equation1585 G.
Proof. intros x y z w u. exact (h x y z y w u). Qed.

Theorem Equation2034_implies_Equation1991
  (G : Type) `{Magma G} (h : Equation2034 G) : Equation1991 G.
Proof. intros x y z w u. exact (h x y z y w u). Qed.

Theorem Equation2237_implies_Equation2194
  (G : Type) `{Magma G} (h : Equation2237 G) : Equation2194 G.
Proof. intros x y z w u. exact (h x y z y w u). Qed.

Theorem Equation2643_implies_Equation2600
  (G : Type) `{Magma G} (h : Equation2643 G) : Equation2600 G.
Proof. intros x y z w u. exact (h x y z y w u). Qed.

Theorem Equation3049_implies_Equation3006
  (G : Type) `{Magma G} (h : Equation3049 G) : Equation3006 G.
Proof. intros x y z w u. exact (h x y z y w u). Qed.

Theorem Equation3658_implies_Equation3615
  (G : Type) `{Magma G} (h : Equation3658 G) : Equation3615 G.
Proof. intros x y z w u. exact (h x y z y w u). Qed.

Theorem Equation4064_implies_Equation4021
  (G : Type) `{Magma G} (h : Equation4064 G) : Equation4021 G.
Proof. intros x y z w u. exact (h x y z y w u). Qed.

Theorem Equation4267_implies_Equation4224
  (G : Type) `{Magma G} (h : Equation4267 G) : Equation4224 G.
Proof. intros x y z w u. exact (h x y z y w u). Qed.

Theorem Equation4582_implies_Equation4539
  (G : Type) `{Magma G} (h : Equation4582 G) : Equation4539 G.
Proof. intros x y z w u. exact (h x y z y w u). Qed.

Theorem Equation4694_implies_Equation4683
  (G : Type) `{Magma G} (h : Equation4694 G) : Equation4683 G.
Proof. intros x y z w u. exact (h x y z y w u). Qed.

