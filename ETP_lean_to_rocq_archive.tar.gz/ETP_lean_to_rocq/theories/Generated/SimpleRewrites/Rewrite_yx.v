(** * SimpleRewrites/Rewrite_yx

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation9_implies_Equation8
  (G : Type) `{Magma G} (h : Equation9 G) : Equation8 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation14_implies_Equation8
  (G : Type) `{Magma G} (h : Equation14 G) : Equation8 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation16_implies_Equation8
  (G : Type) `{Magma G} (h : Equation16 G) : Equation8 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation25_implies_Equation23
  (G : Type) `{Magma G} (h : Equation25 G) : Equation23 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation26_implies_Equation23
  (G : Type) `{Magma G} (h : Equation26 G) : Equation23 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation48_implies_Equation47
  (G : Type) `{Magma G} (h : Equation48 G) : Equation47 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation50_implies_Equation47
  (G : Type) `{Magma G} (h : Equation50 G) : Equation47 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation53_implies_Equation47
  (G : Type) `{Magma G} (h : Equation53 G) : Equation47 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation55_implies_Equation47
  (G : Type) `{Magma G} (h : Equation55 G) : Equation47 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation56_implies_Equation47
  (G : Type) `{Magma G} (h : Equation56 G) : Equation47 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation63_implies_Equation47
  (G : Type) `{Magma G} (h : Equation63 G) : Equation47 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation65_implies_Equation47
  (G : Type) `{Magma G} (h : Equation65 G) : Equation47 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation73_implies_Equation47
  (G : Type) `{Magma G} (h : Equation73 G) : Equation47 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation75_implies_Equation47
  (G : Type) `{Magma G} (h : Equation75 G) : Equation47 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation105_implies_Equation99
  (G : Type) `{Magma G} (h : Equation105 G) : Equation99 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation107_implies_Equation99
  (G : Type) `{Magma G} (h : Equation107 G) : Equation99 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation108_implies_Equation99
  (G : Type) `{Magma G} (h : Equation108 G) : Equation99 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation115_implies_Equation99
  (G : Type) `{Magma G} (h : Equation115 G) : Equation99 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation117_implies_Equation99
  (G : Type) `{Magma G} (h : Equation117 G) : Equation99 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation118_implies_Equation99
  (G : Type) `{Magma G} (h : Equation118 G) : Equation99 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation124_implies_Equation99
  (G : Type) `{Magma G} (h : Equation124 G) : Equation99 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation152_implies_Equation151
  (G : Type) `{Magma G} (h : Equation152 G) : Equation151 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation153_implies_Equation151
  (G : Type) `{Magma G} (h : Equation153 G) : Equation151 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation156_implies_Equation151
  (G : Type) `{Magma G} (h : Equation156 G) : Equation151 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation159_implies_Equation151
  (G : Type) `{Magma G} (h : Equation159 G) : Equation151 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation160_implies_Equation151
  (G : Type) `{Magma G} (h : Equation160 G) : Equation151 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation166_implies_Equation151
  (G : Type) `{Magma G} (h : Equation166 G) : Equation151 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation167_implies_Equation151
  (G : Type) `{Magma G} (h : Equation167 G) : Equation151 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation177_implies_Equation151
  (G : Type) `{Magma G} (h : Equation177 G) : Equation151 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation179_implies_Equation151
  (G : Type) `{Magma G} (h : Equation179 G) : Equation151 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation206_implies_Equation203
  (G : Type) `{Magma G} (h : Equation206 G) : Equation203 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation209_implies_Equation203
  (G : Type) `{Magma G} (h : Equation209 G) : Equation203 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation211_implies_Equation203
  (G : Type) `{Magma G} (h : Equation211 G) : Equation203 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation212_implies_Equation203
  (G : Type) `{Magma G} (h : Equation212 G) : Equation203 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation219_implies_Equation203
  (G : Type) `{Magma G} (h : Equation219 G) : Equation203 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation221_implies_Equation203
  (G : Type) `{Magma G} (h : Equation221 G) : Equation203 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation229_implies_Equation203
  (G : Type) `{Magma G} (h : Equation229 G) : Equation203 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation231_implies_Equation203
  (G : Type) `{Magma G} (h : Equation231 G) : Equation203 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation261_implies_Equation255
  (G : Type) `{Magma G} (h : Equation261 G) : Equation255 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation263_implies_Equation255
  (G : Type) `{Magma G} (h : Equation263 G) : Equation255 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation264_implies_Equation255
  (G : Type) `{Magma G} (h : Equation264 G) : Equation255 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation270_implies_Equation255
  (G : Type) `{Magma G} (h : Equation270 G) : Equation255 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation271_implies_Equation255
  (G : Type) `{Magma G} (h : Equation271 G) : Equation255 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation273_implies_Equation255
  (G : Type) `{Magma G} (h : Equation273 G) : Equation255 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation274_implies_Equation255
  (G : Type) `{Magma G} (h : Equation274 G) : Equation255 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation280_implies_Equation255
  (G : Type) `{Magma G} (h : Equation280 G) : Equation255 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation281_implies_Equation255
  (G : Type) `{Magma G} (h : Equation281 G) : Equation255 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation283_implies_Equation255
  (G : Type) `{Magma G} (h : Equation283 G) : Equation255 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation308_implies_Equation307
  (G : Type) `{Magma G} (h : Equation308 G) : Equation307 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation309_implies_Equation307
  (G : Type) `{Magma G} (h : Equation309 G) : Equation307 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation310_implies_Equation307
  (G : Type) `{Magma G} (h : Equation310 G) : Equation307 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation312_implies_Equation307
  (G : Type) `{Magma G} (h : Equation312 G) : Equation307 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation313_implies_Equation307
  (G : Type) `{Magma G} (h : Equation313 G) : Equation307 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation315_implies_Equation307
  (G : Type) `{Magma G} (h : Equation315 G) : Equation307 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation323_implies_Equation307
  (G : Type) `{Magma G} (h : Equation323 G) : Equation307 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation325_implies_Equation307
  (G : Type) `{Magma G} (h : Equation325 G) : Equation307 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation326_implies_Equation307
  (G : Type) `{Magma G} (h : Equation326 G) : Equation307 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation333_implies_Equation307
  (G : Type) `{Magma G} (h : Equation333 G) : Equation307 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation335_implies_Equation307
  (G : Type) `{Magma G} (h : Equation335 G) : Equation307 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation360_implies_Equation359
  (G : Type) `{Magma G} (h : Equation360 G) : Equation359 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation361_implies_Equation359
  (G : Type) `{Magma G} (h : Equation361 G) : Equation359 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation362_implies_Equation359
  (G : Type) `{Magma G} (h : Equation362 G) : Equation359 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation364_implies_Equation359
  (G : Type) `{Magma G} (h : Equation364 G) : Equation359 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation365_implies_Equation359
  (G : Type) `{Magma G} (h : Equation365 G) : Equation359 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation367_implies_Equation359
  (G : Type) `{Magma G} (h : Equation367 G) : Equation359 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation375_implies_Equation359
  (G : Type) `{Magma G} (h : Equation375 G) : Equation359 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation377_implies_Equation359
  (G : Type) `{Magma G} (h : Equation377 G) : Equation359 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation378_implies_Equation359
  (G : Type) `{Magma G} (h : Equation378 G) : Equation359 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation384_implies_Equation359
  (G : Type) `{Magma G} (h : Equation384 G) : Equation359 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation385_implies_Equation359
  (G : Type) `{Magma G} (h : Equation385 G) : Equation359 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation387_implies_Equation359
  (G : Type) `{Magma G} (h : Equation387 G) : Equation359 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation412_implies_Equation411
  (G : Type) `{Magma G} (h : Equation412 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation413_implies_Equation411
  (G : Type) `{Magma G} (h : Equation413 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation414_implies_Equation411
  (G : Type) `{Magma G} (h : Equation414 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation416_implies_Equation411
  (G : Type) `{Magma G} (h : Equation416 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation417_implies_Equation411
  (G : Type) `{Magma G} (h : Equation417 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation419_implies_Equation411
  (G : Type) `{Magma G} (h : Equation419 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation420_implies_Equation411
  (G : Type) `{Magma G} (h : Equation420 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation426_implies_Equation411
  (G : Type) `{Magma G} (h : Equation426 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation427_implies_Equation411
  (G : Type) `{Magma G} (h : Equation427 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation429_implies_Equation411
  (G : Type) `{Magma G} (h : Equation429 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation436_implies_Equation411
  (G : Type) `{Magma G} (h : Equation436 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation437_implies_Equation411
  (G : Type) `{Magma G} (h : Equation437 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation439_implies_Equation411
  (G : Type) `{Magma G} (h : Equation439 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation440_implies_Equation411
  (G : Type) `{Magma G} (h : Equation440 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation464_implies_Equation411
  (G : Type) `{Magma G} (h : Equation464 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation466_implies_Equation411
  (G : Type) `{Magma G} (h : Equation466 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation467_implies_Equation411
  (G : Type) `{Magma G} (h : Equation467 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation473_implies_Equation411
  (G : Type) `{Magma G} (h : Equation473 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation476_implies_Equation411
  (G : Type) `{Magma G} (h : Equation476 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation477_implies_Equation411
  (G : Type) `{Magma G} (h : Equation477 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation501_implies_Equation411
  (G : Type) `{Magma G} (h : Equation501 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation503_implies_Equation411
  (G : Type) `{Magma G} (h : Equation503 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation504_implies_Equation411
  (G : Type) `{Magma G} (h : Equation504 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation511_implies_Equation411
  (G : Type) `{Magma G} (h : Equation511 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation513_implies_Equation411
  (G : Type) `{Magma G} (h : Equation513 G) : Equation411 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation615_implies_Equation614
  (G : Type) `{Magma G} (h : Equation615 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation616_implies_Equation614
  (G : Type) `{Magma G} (h : Equation616 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation617_implies_Equation614
  (G : Type) `{Magma G} (h : Equation617 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation619_implies_Equation614
  (G : Type) `{Magma G} (h : Equation619 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation620_implies_Equation614
  (G : Type) `{Magma G} (h : Equation620 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation622_implies_Equation614
  (G : Type) `{Magma G} (h : Equation622 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation623_implies_Equation614
  (G : Type) `{Magma G} (h : Equation623 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation629_implies_Equation614
  (G : Type) `{Magma G} (h : Equation629 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation630_implies_Equation614
  (G : Type) `{Magma G} (h : Equation630 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation632_implies_Equation614
  (G : Type) `{Magma G} (h : Equation632 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation633_implies_Equation614
  (G : Type) `{Magma G} (h : Equation633 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation639_implies_Equation614
  (G : Type) `{Magma G} (h : Equation639 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation640_implies_Equation614
  (G : Type) `{Magma G} (h : Equation640 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation642_implies_Equation614
  (G : Type) `{Magma G} (h : Equation642 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation643_implies_Equation614
  (G : Type) `{Magma G} (h : Equation643 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation667_implies_Equation614
  (G : Type) `{Magma G} (h : Equation667 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation669_implies_Equation614
  (G : Type) `{Magma G} (h : Equation669 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation670_implies_Equation614
  (G : Type) `{Magma G} (h : Equation670 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation676_implies_Equation614
  (G : Type) `{Magma G} (h : Equation676 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation677_implies_Equation614
  (G : Type) `{Magma G} (h : Equation677 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation679_implies_Equation614
  (G : Type) `{Magma G} (h : Equation679 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation680_implies_Equation614
  (G : Type) `{Magma G} (h : Equation680 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation703_implies_Equation614
  (G : Type) `{Magma G} (h : Equation703 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation704_implies_Equation614
  (G : Type) `{Magma G} (h : Equation704 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation706_implies_Equation614
  (G : Type) `{Magma G} (h : Equation706 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation707_implies_Equation614
  (G : Type) `{Magma G} (h : Equation707 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation713_implies_Equation614
  (G : Type) `{Magma G} (h : Equation713 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation716_implies_Equation614
  (G : Type) `{Magma G} (h : Equation716 G) : Equation614 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation818_implies_Equation817
  (G : Type) `{Magma G} (h : Equation818 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation819_implies_Equation817
  (G : Type) `{Magma G} (h : Equation819 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation820_implies_Equation817
  (G : Type) `{Magma G} (h : Equation820 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation822_implies_Equation817
  (G : Type) `{Magma G} (h : Equation822 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation823_implies_Equation817
  (G : Type) `{Magma G} (h : Equation823 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation825_implies_Equation817
  (G : Type) `{Magma G} (h : Equation825 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation826_implies_Equation817
  (G : Type) `{Magma G} (h : Equation826 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation832_implies_Equation817
  (G : Type) `{Magma G} (h : Equation832 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation833_implies_Equation817
  (G : Type) `{Magma G} (h : Equation833 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation835_implies_Equation817
  (G : Type) `{Magma G} (h : Equation835 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation836_implies_Equation817
  (G : Type) `{Magma G} (h : Equation836 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation842_implies_Equation817
  (G : Type) `{Magma G} (h : Equation842 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation843_implies_Equation817
  (G : Type) `{Magma G} (h : Equation843 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation845_implies_Equation817
  (G : Type) `{Magma G} (h : Equation845 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation846_implies_Equation817
  (G : Type) `{Magma G} (h : Equation846 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation870_implies_Equation817
  (G : Type) `{Magma G} (h : Equation870 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation872_implies_Equation817
  (G : Type) `{Magma G} (h : Equation872 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation873_implies_Equation817
  (G : Type) `{Magma G} (h : Equation873 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation879_implies_Equation817
  (G : Type) `{Magma G} (h : Equation879 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation882_implies_Equation817
  (G : Type) `{Magma G} (h : Equation882 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation883_implies_Equation817
  (G : Type) `{Magma G} (h : Equation883 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation906_implies_Equation817
  (G : Type) `{Magma G} (h : Equation906 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation907_implies_Equation817
  (G : Type) `{Magma G} (h : Equation907 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation910_implies_Equation817
  (G : Type) `{Magma G} (h : Equation910 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation916_implies_Equation817
  (G : Type) `{Magma G} (h : Equation916 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation917_implies_Equation817
  (G : Type) `{Magma G} (h : Equation917 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation919_implies_Equation817
  (G : Type) `{Magma G} (h : Equation919 G) : Equation817 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1021_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1021 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1022_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1022 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1023_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1023 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1026_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1026 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1028_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1028 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1029_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1029 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1035_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1035 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1036_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1036 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1038_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1038 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1039_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1039 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1045_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1045 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1046_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1046 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1048_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1048 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1049_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1049 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1075_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1075 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1076_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1076 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1082_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1082 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1083_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1083 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1085_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1085 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1086_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1086 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1109_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1109 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1110_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1110 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1112_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1112 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1113_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1113 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1122_implies_Equation1020
  (G : Type) `{Magma G} (h : Equation1122 G) : Equation1020 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1224_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1224 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1225_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1225 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1226_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1226 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1228_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1228 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1229_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1229 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1231_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1231 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1238_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1238 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1239_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1239 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1241_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1241 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1242_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1242 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1248_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1248 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1249_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1249 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1251_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1251 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1252_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1252 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1276_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1276 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1278_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1278 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1279_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1279 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1285_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1285 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1286_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1286 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1288_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1288 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1289_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1289 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1312_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1312 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1313_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1313 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1315_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1315 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1316_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1316 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1322_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1322 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1323_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1323 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1325_implies_Equation1223
  (G : Type) `{Magma G} (h : Equation1325 G) : Equation1223 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1427_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1427 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1428_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1428 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1429_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1429 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1431_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1431 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1432_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1432 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1434_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1434 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1435_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1435 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1441_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1441 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1442_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1442 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1444_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1444 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1445_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1445 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1451_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1451 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1454_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1454 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1455_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1455 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1478_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1478 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1479_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1479 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1481_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1481 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1482_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1482 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1488_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1488 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1489_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1489 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1491_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1491 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1515_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1515 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1516_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1516 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1518_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1518 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1519_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1519 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1525_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1525 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1526_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1526 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1528_implies_Equation1426
  (G : Type) `{Magma G} (h : Equation1528 G) : Equation1426 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1631_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1631 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1632_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1632 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1634_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1634 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1635_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1635 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1637_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1637 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1638_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1638 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1644_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1644 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1645_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1645 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1647_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1647 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1648_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1648 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1654_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1654 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1655_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1655 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1657_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1657 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1658_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1658 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1681_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1681 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1682_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1682 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1684_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1684 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1685_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1685 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1691_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1691 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1692_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1692 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1694_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1694 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1719_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1719 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1721_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1721 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1722_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1722 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1728_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1728 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1729_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1729 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1731_implies_Equation1629
  (G : Type) `{Magma G} (h : Equation1731 G) : Equation1629 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1833_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1833 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1834_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1834 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1835_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1835 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1837_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1837 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1838_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1838 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1840_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1840 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1841_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1841 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1847_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1847 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1848_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1848 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1850_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1850 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1851_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1851 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1857_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1857 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1858_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1858 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1860_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1860 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1861_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1861 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1885_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1885 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1887_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1887 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1888_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1888 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1894_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1894 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1895_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1895 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1897_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1897 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1898_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1898 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1921_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1921 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1922_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1922 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1924_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1924 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1925_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1925 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1931_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1931 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1932_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1932 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation1934_implies_Equation1832
  (G : Type) `{Magma G} (h : Equation1934 G) : Equation1832 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2036_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2036 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2037_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2037 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2038_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2038 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2040_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2040 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2041_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2041 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2043_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2043 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2044_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2044 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2050_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2050 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2051_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2051 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2053_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2053 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2054_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2054 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2060_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2060 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2061_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2061 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2063_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2063 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2064_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2064 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2087_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2087 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2088_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2088 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2090_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2090 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2091_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2091 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2097_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2097 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2098_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2098 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2101_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2101 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2124_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2124 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2125_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2125 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2127_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2127 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2128_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2128 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2134_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2134 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2137_implies_Equation2035
  (G : Type) `{Magma G} (h : Equation2137 G) : Equation2035 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2240_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2240 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2241_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2241 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2243_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2243 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2244_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2244 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2246_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2246 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2247_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2247 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2253_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2253 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2254_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2254 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2256_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2256 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2257_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2257 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2263_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2263 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2264_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2264 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2266_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2266 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2267_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2267 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2290_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2290 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2291_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2291 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2293_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2293 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2294_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2294 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2300_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2300 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2301_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2301 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2303_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2303 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2304_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2304 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2327_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2327 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2328_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2328 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2330_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2330 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2331_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2331 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2338_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2338 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2340_implies_Equation2238
  (G : Type) `{Magma G} (h : Equation2340 G) : Equation2238 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2443_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2443 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2444_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2444 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2447_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2447 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2449_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2449 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2456_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2456 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2457_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2457 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2459_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2459 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2460_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2460 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2466_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2466 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2467_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2467 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2469_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2469 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2470_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2470 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2493_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2493 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2496_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2496 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2497_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2497 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2503_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2503 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2504_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2504 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2506_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2506 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2530_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2530 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2531_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2531 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2533_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2533 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2534_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2534 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2540_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2540 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2541_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2541 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2543_implies_Equation2441
  (G : Type) `{Magma G} (h : Equation2543 G) : Equation2441 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2646_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2646 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2647_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2647 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2649_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2649 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2650_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2650 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2652_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2652 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2653_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2653 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2659_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2659 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2660_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2660 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2662_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2662 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2669_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2669 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2670_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2670 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2672_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2672 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2673_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2673 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2696_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2696 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2697_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2697 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2699_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2699 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2700_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2700 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2706_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2706 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2709_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2709 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2710_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2710 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2733_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2733 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2734_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2734 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2736_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2736 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2737_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2737 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2743_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2743 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2744_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2744 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2746_implies_Equation2644
  (G : Type) `{Magma G} (h : Equation2746 G) : Equation2644 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2849_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2849 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2850_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2850 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2852_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2852 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2853_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2853 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2855_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2855 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2856_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2856 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2862_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2862 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2863_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2863 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2865_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2865 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2866_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2866 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2872_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2872 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2873_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2873 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2875_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2875 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2876_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2876 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2899_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2899 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2900_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2900 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2902_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2902 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2903_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2903 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2909_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2909 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2910_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2910 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2912_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2912 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2936_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2936 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2937_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2937 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2939_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2939 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2940_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2940 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2946_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2946 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2947_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2947 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation2949_implies_Equation2847
  (G : Type) `{Magma G} (h : Equation2949 G) : Equation2847 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3052_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3052 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3053_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3053 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3055_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3055 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3056_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3056 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3058_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3058 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3065_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3065 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3066_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3066 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3068_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3068 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3069_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3069 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3075_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3075 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3076_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3076 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3078_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3078 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3079_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3079 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3103_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3103 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3105_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3105 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3106_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3106 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3112_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3112 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3115_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3115 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3116_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3116 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3139_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3139 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3140_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3140 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3143_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3143 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3149_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3149 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3150_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3150 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3152_implies_Equation3050
  (G : Type) `{Magma G} (h : Equation3152 G) : Equation3050 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3254_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3254 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3255_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3255 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3256_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3256 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3258_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3258 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3259_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3259 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3261_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3261 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3262_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3262 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3268_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3268 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3269_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3269 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3271_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3271 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3272_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3272 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3278_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3278 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3279_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3279 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3281_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3281 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3306_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3306 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3308_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3308 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3309_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3309 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3315_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3315 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3316_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3316 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3318_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3318 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3319_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3319 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3342_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3342 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3343_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3343 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3345_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3345 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3346_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3346 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3352_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3352 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3353_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3353 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3355_implies_Equation3253
  (G : Type) `{Magma G} (h : Equation3355 G) : Equation3253 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3457_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3457 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3458_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3458 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3459_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3459 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3461_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3461 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3462_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3462 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3464_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3464 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3465_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3465 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3471_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3471 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3472_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3472 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3474_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3474 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3475_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3475 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3481_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3481 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3482_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3482 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3484_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3484 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3509_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3509 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3511_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3511 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3512_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3512 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3518_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3518 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3519_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3519 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3521_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3521 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3522_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3522 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3545_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3545 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3546_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3546 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3548_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3548 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3549_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3549 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3555_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3555 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3556_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3556 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3558_implies_Equation3456
  (G : Type) `{Magma G} (h : Equation3558 G) : Equation3456 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3660_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3660 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3661_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3661 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3662_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3662 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3664_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3664 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3665_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3665 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3667_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3667 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3668_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3668 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3674_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3674 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3675_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3675 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3677_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3677 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3678_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3678 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3684_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3684 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3685_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3685 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3687_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3687 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3688_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3688 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3712_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3712 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3714_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3714 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3715_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3715 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3721_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3721 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3722_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3722 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3724_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3724 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3725_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3725 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3748_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3748 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3749_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3749 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3752_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3752 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3759_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3759 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3761_implies_Equation3659
  (G : Type) `{Magma G} (h : Equation3761 G) : Equation3659 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3863_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3863 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3864_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3864 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3865_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3865 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3867_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3867 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3868_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3868 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3870_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3870 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3871_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3871 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3877_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3877 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3878_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3878 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3880_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3880 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3881_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3881 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3887_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3887 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3888_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3888 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3890_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3890 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3915_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3915 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3917_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3917 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3918_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3918 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3924_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3924 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3925_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3925 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3927_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3927 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3928_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3928 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3951_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3951 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3952_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3952 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3954_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3954 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3955_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3955 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3961_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3961 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3962_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3962 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation3964_implies_Equation3862
  (G : Type) `{Magma G} (h : Equation3964 G) : Equation3862 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4066_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4066 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4067_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4067 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4068_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4068 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4070_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4070 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4071_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4071 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4073_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4073 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4074_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4074 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4081_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4081 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4083_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4083 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4084_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4084 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4090_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4090 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4091_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4091 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4093_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4093 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4118_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4118 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4120_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4120 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4121_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4121 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4127_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4127 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4128_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4128 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4130_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4130 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4131_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4131 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4154_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4154 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4155_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4155 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4157_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4157 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4158_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4158 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4164_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4164 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4165_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4165 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4167_implies_Equation4065
  (G : Type) `{Magma G} (h : Equation4167 G) : Equation4065 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4381_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4381 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4382_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4382 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4383_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4383 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4385_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4385 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4386_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4386 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4388_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4388 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4389_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4389 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4395_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4395 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4396_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4396 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4398_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4398 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4399_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4399 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4405_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4405 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4406_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4406 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4408_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4408 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4409_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4409 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4432_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4432 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4433_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4433 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4435_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4435 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4436_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4436 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4442_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4442 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4443_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4443 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4445_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4445 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4446_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4446 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4469_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4469 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4470_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4470 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4472_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4472 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4473_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4473 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4479_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4479 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4480_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4480 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4482_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4482 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

Theorem Equation4483_implies_Equation4380
  (G : Type) `{Magma G} (h : Equation4483 G) : Equation4380 G.
Proof. intros x. exact (h x x). Qed.

