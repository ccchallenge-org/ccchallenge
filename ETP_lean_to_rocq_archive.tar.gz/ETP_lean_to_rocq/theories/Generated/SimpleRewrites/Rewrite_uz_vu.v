(** * SimpleRewrites/Rewrite_uz_vu

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation613_implies_Equation602
  (G : Type) `{Magma G} (h : Equation613 G) : Equation602 G.
Proof. intros x y z w u. exact (h x y z w z u). Qed.

Theorem Equation816_implies_Equation805
  (G : Type) `{Magma G} (h : Equation816 G) : Equation805 G.
Proof. intros x y z w u. exact (h x y z w z u). Qed.

Theorem Equation1222_implies_Equation1211
  (G : Type) `{Magma G} (h : Equation1222 G) : Equation1211 G.
Proof. intros x y z w u. exact (h x y z w z u). Qed.

Theorem Equation1425_implies_Equation1414
  (G : Type) `{Magma G} (h : Equation1425 G) : Equation1414 G.
Proof. intros x y z w u. exact (h x y z w z u). Qed.

Theorem Equation1628_implies_Equation1617
  (G : Type) `{Magma G} (h : Equation1628 G) : Equation1617 G.
Proof. intros x y z w u. exact (h x y z w z u). Qed.

Theorem Equation2034_implies_Equation2023
  (G : Type) `{Magma G} (h : Equation2034 G) : Equation2023 G.
Proof. intros x y z w u. exact (h x y z w z u). Qed.

Theorem Equation2237_implies_Equation2226
  (G : Type) `{Magma G} (h : Equation2237 G) : Equation2226 G.
Proof. intros x y z w u. exact (h x y z w z u). Qed.

Theorem Equation2643_implies_Equation2632
  (G : Type) `{Magma G} (h : Equation2643 G) : Equation2632 G.
Proof. intros x y z w u. exact (h x y z w z u). Qed.

Theorem Equation3049_implies_Equation3038
  (G : Type) `{Magma G} (h : Equation3049 G) : Equation3038 G.
Proof. intros x y z w u. exact (h x y z w z u). Qed.

Theorem Equation3861_implies_Equation3850
  (G : Type) `{Magma G} (h : Equation3861 G) : Equation3850 G.
Proof. intros x y z w u. exact (h x y z w z u). Qed.

