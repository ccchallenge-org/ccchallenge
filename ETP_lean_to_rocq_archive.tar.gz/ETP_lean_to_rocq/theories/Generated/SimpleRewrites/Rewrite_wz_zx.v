(** * SimpleRewrites/Rewrite_wz_zx

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation61_implies_Equation54
  (G : Type) `{Magma G} (h : Equation61 G) : Equation54 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation81_implies_Equation74
  (G : Type) `{Magma G} (h : Equation81 G) : Equation74 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation93_implies_Equation64
  (G : Type) `{Magma G} (h : Equation93 G) : Equation64 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation94_implies_Equation68
  (G : Type) `{Magma G} (h : Equation94 G) : Equation68 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation133_implies_Equation126
  (G : Type) `{Magma G} (h : Equation133 G) : Equation126 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation146_implies_Equation120
  (G : Type) `{Magma G} (h : Equation146 G) : Equation120 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation185_implies_Equation178
  (G : Type) `{Magma G} (h : Equation185 G) : Equation178 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation193_implies_Equation171
  (G : Type) `{Magma G} (h : Equation193 G) : Equation171 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation198_implies_Equation172
  (G : Type) `{Magma G} (h : Equation198 G) : Equation172 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation217_implies_Equation210
  (G : Type) `{Magma G} (h : Equation217 G) : Equation210 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation237_implies_Equation230
  (G : Type) `{Magma G} (h : Equation237 G) : Equation230 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation279_implies_Equation272
  (G : Type) `{Magma G} (h : Equation279 G) : Equation272 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation289_implies_Equation282
  (G : Type) `{Magma G} (h : Equation289 G) : Equation282 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation302_implies_Equation276
  (G : Type) `{Magma G} (h : Equation302 G) : Equation276 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation321_implies_Equation314
  (G : Type) `{Magma G} (h : Equation321 G) : Equation314 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation373_implies_Equation366
  (G : Type) `{Magma G} (h : Equation373 G) : Equation366 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation383_implies_Equation376
  (G : Type) `{Magma G} (h : Equation383 G) : Equation376 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation393_implies_Equation386
  (G : Type) `{Magma G} (h : Equation393 G) : Equation386 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation406_implies_Equation380
  (G : Type) `{Magma G} (h : Equation406 G) : Equation380 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation425_implies_Equation418
  (G : Type) `{Magma G} (h : Equation425 G) : Equation418 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation445_implies_Equation438
  (G : Type) `{Magma G} (h : Equation445 G) : Equation438 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation472_implies_Equation465
  (G : Type) `{Magma G} (h : Equation472 G) : Equation465 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation482_implies_Equation475
  (G : Type) `{Magma G} (h : Equation482 G) : Equation475 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation495_implies_Equation469
  (G : Type) `{Magma G} (h : Equation495 G) : Equation469 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation509_implies_Equation502
  (G : Type) `{Magma G} (h : Equation509 G) : Equation502 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation523_implies_Equation502
  (G : Type) `{Magma G} (h : Equation523 G) : Equation502 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation540_implies_Equation465
  (G : Type) `{Magma G} (h : Equation540 G) : Equation465 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation544_implies_Equation468
  (G : Type) `{Magma G} (h : Equation544 G) : Equation468 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation557_implies_Equation475
  (G : Type) `{Magma G} (h : Equation557 G) : Equation475 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation565_implies_Equation475
  (G : Type) `{Magma G} (h : Equation565 G) : Equation475 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation566_implies_Equation479
  (G : Type) `{Magma G} (h : Equation566 G) : Equation479 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation574_implies_Equation465
  (G : Type) `{Magma G} (h : Equation574 G) : Equation465 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation589_implies_Equation484
  (G : Type) `{Magma G} (h : Equation589 G) : Equation484 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation591_implies_Equation485
  (G : Type) `{Magma G} (h : Equation591 G) : Equation485 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation598_implies_Equation483
  (G : Type) `{Magma G} (h : Equation598 G) : Equation483 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation603_implies_Equation491
  (G : Type) `{Magma G} (h : Equation603 G) : Equation491 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation628_implies_Equation621
  (G : Type) `{Magma G} (h : Equation628 G) : Equation621 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation638_implies_Equation631
  (G : Type) `{Magma G} (h : Equation638 G) : Equation631 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation648_implies_Equation641
  (G : Type) `{Magma G} (h : Equation648 G) : Equation641 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation652_implies_Equation631
  (G : Type) `{Magma G} (h : Equation652 G) : Equation631 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation660_implies_Equation631
  (G : Type) `{Magma G} (h : Equation660 G) : Equation631 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation661_implies_Equation635
  (G : Type) `{Magma G} (h : Equation661 G) : Equation635 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation675_implies_Equation668
  (G : Type) `{Magma G} (h : Equation675 G) : Equation668 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation689_implies_Equation668
  (G : Type) `{Magma G} (h : Equation689 G) : Equation668 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation697_implies_Equation668
  (G : Type) `{Magma G} (h : Equation697 G) : Equation668 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation699_implies_Equation673
  (G : Type) `{Magma G} (h : Equation699 G) : Equation673 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation722_implies_Equation715
  (G : Type) `{Magma G} (h : Equation722 G) : Equation715 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation730_implies_Equation708
  (G : Type) `{Magma G} (h : Equation730 G) : Equation708 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation735_implies_Equation709
  (G : Type) `{Magma G} (h : Equation735 G) : Equation709 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation747_implies_Equation671
  (G : Type) `{Magma G} (h : Equation747 G) : Equation671 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation752_implies_Equation672
  (G : Type) `{Magma G} (h : Equation752 G) : Equation672 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation755_implies_Equation674
  (G : Type) `{Magma G} (h : Equation755 G) : Equation674 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation760_implies_Equation678
  (G : Type) `{Magma G} (h : Equation760 G) : Equation678 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation768_implies_Equation678
  (G : Type) `{Magma G} (h : Equation768 G) : Equation678 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation770_implies_Equation683
  (G : Type) `{Magma G} (h : Equation770 G) : Equation683 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation777_implies_Equation668
  (G : Type) `{Magma G} (h : Equation777 G) : Equation668 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation796_implies_Equation690
  (G : Type) `{Magma G} (h : Equation796 G) : Equation690 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation797_implies_Equation691
  (G : Type) `{Magma G} (h : Equation797 G) : Equation691 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation831_implies_Equation824
  (G : Type) `{Magma G} (h : Equation831 G) : Equation824 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation851_implies_Equation844
  (G : Type) `{Magma G} (h : Equation851 G) : Equation844 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation864_implies_Equation838
  (G : Type) `{Magma G} (h : Equation864 G) : Equation838 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation878_implies_Equation871
  (G : Type) `{Magma G} (h : Equation878 G) : Equation871 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation888_implies_Equation881
  (G : Type) `{Magma G} (h : Equation888 G) : Equation881 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation915_implies_Equation908
  (G : Type) `{Magma G} (h : Equation915 G) : Equation908 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation925_implies_Equation918
  (G : Type) `{Magma G} (h : Equation925 G) : Equation918 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation938_implies_Equation912
  (G : Type) `{Magma G} (h : Equation938 G) : Equation912 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation954_implies_Equation871
  (G : Type) `{Magma G} (h : Equation954 G) : Equation871 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation957_implies_Equation875
  (G : Type) `{Magma G} (h : Equation957 G) : Equation875 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation972_implies_Equation885
  (G : Type) `{Magma G} (h : Equation972 G) : Equation885 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation989_implies_Equation875
  (G : Type) `{Magma G} (h : Equation989 G) : Equation875 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation994_implies_Equation889
  (G : Type) `{Magma G} (h : Equation994 G) : Equation889 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation995_implies_Equation890
  (G : Type) `{Magma G} (h : Equation995 G) : Equation890 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation997_implies_Equation891
  (G : Type) `{Magma G} (h : Equation997 G) : Equation891 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation999_implies_Equation893
  (G : Type) `{Magma G} (h : Equation999 G) : Equation893 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1000_implies_Equation894
  (G : Type) `{Magma G} (h : Equation1000 G) : Equation894 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1002_implies_Equation895
  (G : Type) `{Magma G} (h : Equation1002 G) : Equation895 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1006_implies_Equation889
  (G : Type) `{Magma G} (h : Equation1006 G) : Equation889 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1007_implies_Equation891
  (G : Type) `{Magma G} (h : Equation1007 G) : Equation891 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1012_implies_Equation899
  (G : Type) `{Magma G} (h : Equation1012 G) : Equation899 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1034_implies_Equation1027
  (G : Type) `{Magma G} (h : Equation1034 G) : Equation1027 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1054_implies_Equation1047
  (G : Type) `{Magma G} (h : Equation1054 G) : Equation1047 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1062_implies_Equation1040
  (G : Type) `{Magma G} (h : Equation1062 G) : Equation1040 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1066_implies_Equation1037
  (G : Type) `{Magma G} (h : Equation1066 G) : Equation1037 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1067_implies_Equation1041
  (G : Type) `{Magma G} (h : Equation1067 G) : Equation1041 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1068_implies_Equation1042
  (G : Type) `{Magma G} (h : Equation1068 G) : Equation1042 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1070_implies_Equation1043
  (G : Type) `{Magma G} (h : Equation1070 G) : Equation1043 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1095_implies_Equation1074
  (G : Type) `{Magma G} (h : Equation1095 G) : Equation1074 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1104_implies_Equation1078
  (G : Type) `{Magma G} (h : Equation1104 G) : Equation1078 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1132_implies_Equation1111
  (G : Type) `{Magma G} (h : Equation1132 G) : Equation1111 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1141_implies_Equation1115
  (G : Type) `{Magma G} (h : Equation1141 G) : Equation1115 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1170_implies_Equation1087
  (G : Type) `{Magma G} (h : Equation1170 G) : Equation1087 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1212_implies_Equation1100
  (G : Type) `{Magma G} (h : Equation1212 G) : Equation1100 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1237_implies_Equation1230
  (G : Type) `{Magma G} (h : Equation1237 G) : Equation1230 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1247_implies_Equation1240
  (G : Type) `{Magma G} (h : Equation1247 G) : Equation1240 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1257_implies_Equation1250
  (G : Type) `{Magma G} (h : Equation1257 G) : Equation1250 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1270_implies_Equation1244
  (G : Type) `{Magma G} (h : Equation1270 G) : Equation1244 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1271_implies_Equation1245
  (G : Type) `{Magma G} (h : Equation1271 G) : Equation1245 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1294_implies_Equation1287
  (G : Type) `{Magma G} (h : Equation1294 G) : Equation1287 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1298_implies_Equation1277
  (G : Type) `{Magma G} (h : Equation1298 G) : Equation1277 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1307_implies_Equation1281
  (G : Type) `{Magma G} (h : Equation1307 G) : Equation1281 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1335_implies_Equation1314
  (G : Type) `{Magma G} (h : Equation1335 G) : Equation1314 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1344_implies_Equation1318
  (G : Type) `{Magma G} (h : Equation1344 G) : Equation1318 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1378_implies_Equation1291
  (G : Type) `{Magma G} (h : Equation1378 G) : Equation1291 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1400_implies_Equation1295
  (G : Type) `{Magma G} (h : Equation1400 G) : Equation1295 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1405_implies_Equation1299
  (G : Type) `{Magma G} (h : Equation1405 G) : Equation1299 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1440_implies_Equation1433
  (G : Type) `{Magma G} (h : Equation1440 G) : Equation1433 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1472_implies_Equation1443
  (G : Type) `{Magma G} (h : Equation1472 G) : Equation1443 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1474_implies_Equation1448
  (G : Type) `{Magma G} (h : Equation1474 G) : Equation1448 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1487_implies_Equation1480
  (G : Type) `{Magma G} (h : Equation1487 G) : Equation1480 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1497_implies_Equation1490
  (G : Type) `{Magma G} (h : Equation1497 G) : Equation1490 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1510_implies_Equation1484
  (G : Type) `{Magma G} (h : Equation1510 G) : Equation1484 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1534_implies_Equation1527
  (G : Type) `{Magma G} (h : Equation1534 G) : Equation1527 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1547_implies_Equation1521
  (G : Type) `{Magma G} (h : Equation1547 G) : Equation1521 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1572_implies_Equation1490
  (G : Type) `{Magma G} (h : Equation1572 G) : Equation1490 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1603_implies_Equation1498
  (G : Type) `{Magma G} (h : Equation1603 G) : Equation1498 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1606_implies_Equation1500
  (G : Type) `{Magma G} (h : Equation1606 G) : Equation1500 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1608_implies_Equation1502
  (G : Type) `{Magma G} (h : Equation1608 G) : Equation1502 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1613_implies_Equation1498
  (G : Type) `{Magma G} (h : Equation1613 G) : Equation1498 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1663_implies_Equation1656
  (G : Type) `{Magma G} (h : Equation1663 G) : Equation1656 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1671_implies_Equation1649
  (G : Type) `{Magma G} (h : Equation1671 G) : Equation1649 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1676_implies_Equation1650
  (G : Type) `{Magma G} (h : Equation1676 G) : Equation1650 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1677_implies_Equation1651
  (G : Type) `{Magma G} (h : Equation1677 G) : Equation1651 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1690_implies_Equation1683
  (G : Type) `{Magma G} (h : Equation1690 G) : Equation1683 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1704_implies_Equation1683
  (G : Type) `{Magma G} (h : Equation1704 G) : Equation1683 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1714_implies_Equation1688
  (G : Type) `{Magma G} (h : Equation1714 G) : Equation1688 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1715_implies_Equation1687
  (G : Type) `{Magma G} (h : Equation1715 G) : Equation1687 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1727_implies_Equation1720
  (G : Type) `{Magma G} (h : Equation1727 G) : Equation1720 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1737_implies_Equation1730
  (G : Type) `{Magma G} (h : Equation1737 G) : Equation1730 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1758_implies_Equation1683
  (G : Type) `{Magma G} (h : Equation1758 G) : Equation1683 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1766_implies_Equation1683
  (G : Type) `{Magma G} (h : Equation1766 G) : Equation1683 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1770_implies_Equation1689
  (G : Type) `{Magma G} (h : Equation1770 G) : Equation1689 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1775_implies_Equation1693
  (G : Type) `{Magma G} (h : Equation1775 G) : Equation1693 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1779_implies_Equation1696
  (G : Type) `{Magma G} (h : Equation1779 G) : Equation1696 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1783_implies_Equation1693
  (G : Type) `{Magma G} (h : Equation1783 G) : Equation1693 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1784_implies_Equation1697
  (G : Type) `{Magma G} (h : Equation1784 G) : Equation1697 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1792_implies_Equation1683
  (G : Type) `{Magma G} (h : Equation1792 G) : Equation1683 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1800_implies_Equation1683
  (G : Type) `{Magma G} (h : Equation1800 G) : Equation1683 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1807_implies_Equation1702
  (G : Type) `{Magma G} (h : Equation1807 G) : Equation1702 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1816_implies_Equation1701
  (G : Type) `{Magma G} (h : Equation1816 G) : Equation1701 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1821_implies_Equation1709
  (G : Type) `{Magma G} (h : Equation1821 G) : Equation1709 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1874_implies_Equation1852
  (G : Type) `{Magma G} (h : Equation1874 G) : Equation1852 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1879_implies_Equation1853
  (G : Type) `{Magma G} (h : Equation1879 G) : Equation1853 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1893_implies_Equation1886
  (G : Type) `{Magma G} (h : Equation1893 G) : Equation1886 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1903_implies_Equation1896
  (G : Type) `{Magma G} (h : Equation1903 G) : Equation1896 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1907_implies_Equation1886
  (G : Type) `{Magma G} (h : Equation1907 G) : Equation1886 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1915_implies_Equation1886
  (G : Type) `{Magma G} (h : Equation1915 G) : Equation1886 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1948_implies_Equation1926
  (G : Type) `{Magma G} (h : Equation1948 G) : Equation1926 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1961_implies_Equation1886
  (G : Type) `{Magma G} (h : Equation1961 G) : Equation1886 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1969_implies_Equation1886
  (G : Type) `{Magma G} (h : Equation1969 G) : Equation1886 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation1999_implies_Equation1889
  (G : Type) `{Magma G} (h : Equation1999 G) : Equation1889 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2010_implies_Equation1905
  (G : Type) `{Magma G} (h : Equation2010 G) : Equation1905 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2014_implies_Equation1908
  (G : Type) `{Magma G} (h : Equation2014 G) : Equation1908 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2019_implies_Equation1904
  (G : Type) `{Magma G} (h : Equation2019 G) : Equation1904 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2024_implies_Equation1912
  (G : Type) `{Magma G} (h : Equation2024 G) : Equation1912 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2049_implies_Equation2042
  (G : Type) `{Magma G} (h : Equation2049 G) : Equation2042 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2077_implies_Equation2055
  (G : Type) `{Magma G} (h : Equation2077 G) : Equation2055 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2081_implies_Equation2052
  (G : Type) `{Magma G} (h : Equation2081 G) : Equation2052 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2114_implies_Equation2092
  (G : Type) `{Magma G} (h : Equation2114 G) : Equation2092 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2120_implies_Equation2094
  (G : Type) `{Magma G} (h : Equation2120 G) : Equation2094 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2156_implies_Equation2130
  (G : Type) `{Magma G} (h : Equation2156 G) : Equation2130 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2164_implies_Equation2089
  (G : Type) `{Magma G} (h : Equation2164 G) : Equation2089 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2176_implies_Equation2095
  (G : Type) `{Magma G} (h : Equation2176 G) : Equation2095 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2181_implies_Equation2099
  (G : Type) `{Magma G} (h : Equation2181 G) : Equation2099 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2190_implies_Equation2103
  (G : Type) `{Magma G} (h : Equation2190 G) : Equation2103 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2207_implies_Equation2093
  (G : Type) `{Magma G} (h : Equation2207 G) : Equation2093 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2212_implies_Equation2107
  (G : Type) `{Magma G} (h : Equation2212 G) : Equation2107 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2213_implies_Equation2108
  (G : Type) `{Magma G} (h : Equation2213 G) : Equation2108 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2217_implies_Equation2111
  (G : Type) `{Magma G} (h : Equation2217 G) : Equation2111 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2227_implies_Equation2115
  (G : Type) `{Magma G} (h : Equation2227 G) : Equation2115 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2252_implies_Equation2245
  (G : Type) `{Magma G} (h : Equation2252 G) : Equation2245 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2262_implies_Equation2255
  (G : Type) `{Magma G} (h : Equation2262 G) : Equation2255 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2272_implies_Equation2265
  (G : Type) `{Magma G} (h : Equation2272 G) : Equation2265 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2285_implies_Equation2259
  (G : Type) `{Magma G} (h : Equation2285 G) : Equation2259 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2286_implies_Equation2260
  (G : Type) `{Magma G} (h : Equation2286 G) : Equation2260 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2299_implies_Equation2292
  (G : Type) `{Magma G} (h : Equation2299 G) : Equation2292 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2309_implies_Equation2302
  (G : Type) `{Magma G} (h : Equation2309 G) : Equation2302 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2313_implies_Equation2292
  (G : Type) `{Magma G} (h : Equation2313 G) : Equation2292 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2321_implies_Equation2292
  (G : Type) `{Magma G} (h : Equation2321 G) : Equation2292 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2323_implies_Equation2297
  (G : Type) `{Magma G} (h : Equation2323 G) : Equation2297 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2336_implies_Equation2329
  (G : Type) `{Magma G} (h : Equation2336 G) : Equation2329 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2346_implies_Equation2339
  (G : Type) `{Magma G} (h : Equation2346 G) : Equation2339 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2376_implies_Equation2296
  (G : Type) `{Magma G} (h : Equation2376 G) : Equation2296 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2415_implies_Equation2310
  (G : Type) `{Magma G} (h : Equation2415 G) : Equation2310 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2420_implies_Equation2314
  (G : Type) `{Magma G} (h : Equation2420 G) : Equation2314 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2425_implies_Equation2310
  (G : Type) `{Magma G} (h : Equation2425 G) : Equation2310 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2430_implies_Equation2318
  (G : Type) `{Magma G} (h : Equation2430 G) : Equation2318 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2479_implies_Equation2458
  (G : Type) `{Magma G} (h : Equation2479 G) : Equation2458 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2488_implies_Equation2462
  (G : Type) `{Magma G} (h : Equation2488 G) : Equation2462 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2489_implies_Equation2463
  (G : Type) `{Magma G} (h : Equation2489 G) : Equation2463 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2491_implies_Equation2464
  (G : Type) `{Magma G} (h : Equation2491 G) : Equation2464 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2502_implies_Equation2495
  (G : Type) `{Magma G} (h : Equation2502 G) : Equation2495 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2512_implies_Equation2505
  (G : Type) `{Magma G} (h : Equation2512 G) : Equation2505 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2516_implies_Equation2495
  (G : Type) `{Magma G} (h : Equation2516 G) : Equation2495 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2520_implies_Equation2498
  (G : Type) `{Magma G} (h : Equation2520 G) : Equation2498 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2524_implies_Equation2495
  (G : Type) `{Magma G} (h : Equation2524 G) : Equation2495 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2526_implies_Equation2500
  (G : Type) `{Magma G} (h : Equation2526 G) : Equation2500 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2528_implies_Equation2501
  (G : Type) `{Magma G} (h : Equation2528 G) : Equation2501 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2539_implies_Equation2532
  (G : Type) `{Magma G} (h : Equation2539 G) : Equation2532 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2549_implies_Equation2542
  (G : Type) `{Magma G} (h : Equation2549 G) : Equation2542 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2562_implies_Equation2536
  (G : Type) `{Magma G} (h : Equation2562 G) : Equation2536 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2580_implies_Equation2500
  (G : Type) `{Magma G} (h : Equation2580 G) : Equation2500 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2582_implies_Equation2501
  (G : Type) `{Magma G} (h : Equation2582 G) : Equation2501 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2613_implies_Equation2499
  (G : Type) `{Magma G} (h : Equation2613 G) : Equation2499 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2618_implies_Equation2513
  (G : Type) `{Magma G} (h : Equation2618 G) : Equation2513 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2621_implies_Equation2515
  (G : Type) `{Magma G} (h : Equation2621 G) : Equation2515 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2623_implies_Equation2517
  (G : Type) `{Magma G} (h : Equation2623 G) : Equation2517 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2633_implies_Equation2521
  (G : Type) `{Magma G} (h : Equation2633 G) : Equation2521 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2686_implies_Equation2664
  (G : Type) `{Magma G} (h : Equation2686 G) : Equation2664 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2690_implies_Equation2661
  (G : Type) `{Magma G} (h : Equation2690 G) : Equation2661 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2691_implies_Equation2665
  (G : Type) `{Magma G} (h : Equation2691 G) : Equation2665 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2692_implies_Equation2666
  (G : Type) `{Magma G} (h : Equation2692 G) : Equation2666 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2705_implies_Equation2698
  (G : Type) `{Magma G} (h : Equation2705 G) : Equation2698 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2715_implies_Equation2708
  (G : Type) `{Magma G} (h : Equation2715 G) : Equation2708 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2729_implies_Equation2703
  (G : Type) `{Magma G} (h : Equation2729 G) : Equation2703 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2782_implies_Equation2702
  (G : Type) `{Magma G} (h : Equation2782 G) : Equation2702 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2783_implies_Equation2703
  (G : Type) `{Magma G} (h : Equation2783 G) : Equation2703 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2821_implies_Equation2716
  (G : Type) `{Magma G} (h : Equation2821 G) : Equation2716 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2836_implies_Equation2724
  (G : Type) `{Magma G} (h : Equation2836 G) : Equation2724 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2881_implies_Equation2874
  (G : Type) `{Magma G} (h : Equation2881 G) : Equation2874 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2885_implies_Equation2864
  (G : Type) `{Magma G} (h : Equation2885 G) : Equation2864 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2889_implies_Equation2867
  (G : Type) `{Magma G} (h : Equation2889 G) : Equation2867 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2894_implies_Equation2868
  (G : Type) `{Magma G} (h : Equation2894 G) : Equation2868 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2895_implies_Equation2869
  (G : Type) `{Magma G} (h : Equation2895 G) : Equation2869 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2897_implies_Equation2870
  (G : Type) `{Magma G} (h : Equation2897 G) : Equation2870 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2918_implies_Equation2911
  (G : Type) `{Magma G} (h : Equation2918 G) : Equation2911 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2926_implies_Equation2904
  (G : Type) `{Magma G} (h : Equation2926 G) : Equation2904 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2932_implies_Equation2906
  (G : Type) `{Magma G} (h : Equation2932 G) : Equation2906 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2933_implies_Equation2905
  (G : Type) `{Magma G} (h : Equation2933 G) : Equation2905 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2945_implies_Equation2938
  (G : Type) `{Magma G} (h : Equation2945 G) : Equation2938 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2955_implies_Equation2948
  (G : Type) `{Magma G} (h : Equation2955 G) : Equation2948 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2959_implies_Equation2938
  (G : Type) `{Magma G} (h : Equation2959 G) : Equation2938 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2968_implies_Equation2942
  (G : Type) `{Magma G} (h : Equation2968 G) : Equation2942 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2980_implies_Equation2904
  (G : Type) `{Magma G} (h : Equation2980 G) : Equation2904 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2987_implies_Equation2905
  (G : Type) `{Magma G} (h : Equation2987 G) : Equation2905 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation2993_implies_Equation2911
  (G : Type) `{Magma G} (h : Equation2993 G) : Equation2911 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3024_implies_Equation2919
  (G : Type) `{Magma G} (h : Equation3024 G) : Equation2919 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3025_implies_Equation2920
  (G : Type) `{Magma G} (h : Equation3025 G) : Equation2920 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3039_implies_Equation2927
  (G : Type) `{Magma G} (h : Equation3039 G) : Equation2927 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3064_implies_Equation3057
  (G : Type) `{Magma G} (h : Equation3064 G) : Equation3057 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3074_implies_Equation3067
  (G : Type) `{Magma G} (h : Equation3074 G) : Equation3067 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3084_implies_Equation3077
  (G : Type) `{Magma G} (h : Equation3084 G) : Equation3077 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3111_implies_Equation3104
  (G : Type) `{Magma G} (h : Equation3111 G) : Equation3104 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3125_implies_Equation3104
  (G : Type) `{Magma G} (h : Equation3125 G) : Equation3104 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3129_implies_Equation3107
  (G : Type) `{Magma G} (h : Equation3129 G) : Equation3107 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3137_implies_Equation3110
  (G : Type) `{Magma G} (h : Equation3137 G) : Equation3110 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3158_implies_Equation3151
  (G : Type) `{Magma G} (h : Equation3158 G) : Equation3151 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3170_implies_Equation3141
  (G : Type) `{Magma G} (h : Equation3170 G) : Equation3141 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3179_implies_Equation3104
  (G : Type) `{Magma G} (h : Equation3179 G) : Equation3104 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3187_implies_Equation3104
  (G : Type) `{Magma G} (h : Equation3187 G) : Equation3104 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3191_implies_Equation3110
  (G : Type) `{Magma G} (h : Equation3191 G) : Equation3110 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3213_implies_Equation3104
  (G : Type) `{Magma G} (h : Equation3213 G) : Equation3104 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3227_implies_Equation3122
  (G : Type) `{Magma G} (h : Equation3227 G) : Equation3122 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3228_implies_Equation3123
  (G : Type) `{Magma G} (h : Equation3228 G) : Equation3123 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3230_implies_Equation3124
  (G : Type) `{Magma G} (h : Equation3230 G) : Equation3124 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3232_implies_Equation3126
  (G : Type) `{Magma G} (h : Equation3232 G) : Equation3126 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3242_implies_Equation3130
  (G : Type) `{Magma G} (h : Equation3242 G) : Equation3130 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3267_implies_Equation3260
  (G : Type) `{Magma G} (h : Equation3267 G) : Equation3260 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3277_implies_Equation3270
  (G : Type) `{Magma G} (h : Equation3277 G) : Equation3270 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3287_implies_Equation3280
  (G : Type) `{Magma G} (h : Equation3287 G) : Equation3280 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3295_implies_Equation3273
  (G : Type) `{Magma G} (h : Equation3295 G) : Equation3273 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3299_implies_Equation3270
  (G : Type) `{Magma G} (h : Equation3299 G) : Equation3270 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3300_implies_Equation3274
  (G : Type) `{Magma G} (h : Equation3300 G) : Equation3274 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3301_implies_Equation3275
  (G : Type) `{Magma G} (h : Equation3301 G) : Equation3275 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3302_implies_Equation3274
  (G : Type) `{Magma G} (h : Equation3302 G) : Equation3274 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3303_implies_Equation3276
  (G : Type) `{Magma G} (h : Equation3303 G) : Equation3276 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3314_implies_Equation3307
  (G : Type) `{Magma G} (h : Equation3314 G) : Equation3307 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3324_implies_Equation3317
  (G : Type) `{Magma G} (h : Equation3324 G) : Equation3317 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3332_implies_Equation3310
  (G : Type) `{Magma G} (h : Equation3332 G) : Equation3310 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3338_implies_Equation3312
  (G : Type) `{Magma G} (h : Equation3338 G) : Equation3312 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3340_implies_Equation3313
  (G : Type) `{Magma G} (h : Equation3340 G) : Equation3313 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3351_implies_Equation3344
  (G : Type) `{Magma G} (h : Equation3351 G) : Equation3344 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3361_implies_Equation3354
  (G : Type) `{Magma G} (h : Equation3361 G) : Equation3354 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3365_implies_Equation3344
  (G : Type) `{Magma G} (h : Equation3365 G) : Equation3344 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3386_implies_Equation3310
  (G : Type) `{Magma G} (h : Equation3386 G) : Equation3310 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3392_implies_Equation3312
  (G : Type) `{Magma G} (h : Equation3392 G) : Equation3312 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3403_implies_Equation3320
  (G : Type) `{Magma G} (h : Equation3403 G) : Equation3320 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3431_implies_Equation3326
  (G : Type) `{Magma G} (h : Equation3431 G) : Equation3326 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3436_implies_Equation3330
  (G : Type) `{Magma G} (h : Equation3436 G) : Equation3330 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3470_implies_Equation3463
  (G : Type) `{Magma G} (h : Equation3470 G) : Equation3463 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3490_implies_Equation3483
  (G : Type) `{Magma G} (h : Equation3490 G) : Equation3483 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3498_implies_Equation3476
  (G : Type) `{Magma G} (h : Equation3498 G) : Equation3476 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3503_implies_Equation3477
  (G : Type) `{Magma G} (h : Equation3503 G) : Equation3477 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3504_implies_Equation3478
  (G : Type) `{Magma G} (h : Equation3504 G) : Equation3478 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3505_implies_Equation3477
  (G : Type) `{Magma G} (h : Equation3505 G) : Equation3477 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3506_implies_Equation3479
  (G : Type) `{Magma G} (h : Equation3506 G) : Equation3479 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3517_implies_Equation3510
  (G : Type) `{Magma G} (h : Equation3517 G) : Equation3510 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3527_implies_Equation3520
  (G : Type) `{Magma G} (h : Equation3527 G) : Equation3520 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3535_implies_Equation3513
  (G : Type) `{Magma G} (h : Equation3535 G) : Equation3513 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3540_implies_Equation3514
  (G : Type) `{Magma G} (h : Equation3540 G) : Equation3514 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3541_implies_Equation3515
  (G : Type) `{Magma G} (h : Equation3541 G) : Equation3515 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3543_implies_Equation3516
  (G : Type) `{Magma G} (h : Equation3543 G) : Equation3516 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3554_implies_Equation3547
  (G : Type) `{Magma G} (h : Equation3554 G) : Equation3547 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3564_implies_Equation3557
  (G : Type) `{Magma G} (h : Equation3564 G) : Equation3557 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3577_implies_Equation3551
  (G : Type) `{Magma G} (h : Equation3577 G) : Equation3551 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3578_implies_Equation3552
  (G : Type) `{Magma G} (h : Equation3578 G) : Equation3552 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3623_implies_Equation3513
  (G : Type) `{Magma G} (h : Equation3623 G) : Equation3513 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3634_implies_Equation3529
  (G : Type) `{Magma G} (h : Equation3634 G) : Equation3529 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3673_implies_Equation3666
  (G : Type) `{Magma G} (h : Equation3673 G) : Equation3666 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3683_implies_Equation3676
  (G : Type) `{Magma G} (h : Equation3683 G) : Equation3676 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3693_implies_Equation3686
  (G : Type) `{Magma G} (h : Equation3693 G) : Equation3686 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3701_implies_Equation3679
  (G : Type) `{Magma G} (h : Equation3701 G) : Equation3679 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3705_implies_Equation3676
  (G : Type) `{Magma G} (h : Equation3705 G) : Equation3676 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3706_implies_Equation3680
  (G : Type) `{Magma G} (h : Equation3706 G) : Equation3680 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3707_implies_Equation3681
  (G : Type) `{Magma G} (h : Equation3707 G) : Equation3681 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3708_implies_Equation3680
  (G : Type) `{Magma G} (h : Equation3708 G) : Equation3680 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3709_implies_Equation3682
  (G : Type) `{Magma G} (h : Equation3709 G) : Equation3682 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3720_implies_Equation3713
  (G : Type) `{Magma G} (h : Equation3720 G) : Equation3713 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3730_implies_Equation3723
  (G : Type) `{Magma G} (h : Equation3730 G) : Equation3723 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3738_implies_Equation3716
  (G : Type) `{Magma G} (h : Equation3738 G) : Equation3716 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3743_implies_Equation3717
  (G : Type) `{Magma G} (h : Equation3743 G) : Equation3717 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3744_implies_Equation3718
  (G : Type) `{Magma G} (h : Equation3744 G) : Equation3718 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3746_implies_Equation3719
  (G : Type) `{Magma G} (h : Equation3746 G) : Equation3719 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3757_implies_Equation3750
  (G : Type) `{Magma G} (h : Equation3757 G) : Equation3750 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3767_implies_Equation3760
  (G : Type) `{Magma G} (h : Equation3767 G) : Equation3760 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3780_implies_Equation3754
  (G : Type) `{Magma G} (h : Equation3780 G) : Equation3754 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3798_implies_Equation3718
  (G : Type) `{Magma G} (h : Equation3798 G) : Equation3718 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3837_implies_Equation3732
  (G : Type) `{Magma G} (h : Equation3837 G) : Equation3732 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3876_implies_Equation3869
  (G : Type) `{Magma G} (h : Equation3876 G) : Equation3869 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3896_implies_Equation3889
  (G : Type) `{Magma G} (h : Equation3896 G) : Equation3889 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3904_implies_Equation3882
  (G : Type) `{Magma G} (h : Equation3904 G) : Equation3882 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3908_implies_Equation3879
  (G : Type) `{Magma G} (h : Equation3908 G) : Equation3879 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3909_implies_Equation3883
  (G : Type) `{Magma G} (h : Equation3909 G) : Equation3883 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3910_implies_Equation3884
  (G : Type) `{Magma G} (h : Equation3910 G) : Equation3884 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3911_implies_Equation3883
  (G : Type) `{Magma G} (h : Equation3911 G) : Equation3883 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3912_implies_Equation3885
  (G : Type) `{Magma G} (h : Equation3912 G) : Equation3885 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3923_implies_Equation3916
  (G : Type) `{Magma G} (h : Equation3923 G) : Equation3916 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3933_implies_Equation3926
  (G : Type) `{Magma G} (h : Equation3933 G) : Equation3926 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3941_implies_Equation3919
  (G : Type) `{Magma G} (h : Equation3941 G) : Equation3919 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3947_implies_Equation3921
  (G : Type) `{Magma G} (h : Equation3947 G) : Equation3921 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3960_implies_Equation3953
  (G : Type) `{Magma G} (h : Equation3960 G) : Equation3953 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3970_implies_Equation3963
  (G : Type) `{Magma G} (h : Equation3970 G) : Equation3963 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation3984_implies_Equation3958
  (G : Type) `{Magma G} (h : Equation3984 G) : Equation3958 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4001_implies_Equation3921
  (G : Type) `{Magma G} (h : Equation4001 G) : Equation3921 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4017_implies_Equation3930
  (G : Type) `{Magma G} (h : Equation4017 G) : Equation3930 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4040_implies_Equation3935
  (G : Type) `{Magma G} (h : Equation4040 G) : Equation3935 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4079_implies_Equation4072
  (G : Type) `{Magma G} (h : Equation4079 G) : Equation4072 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4099_implies_Equation4092
  (G : Type) `{Magma G} (h : Equation4099 G) : Equation4092 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4103_implies_Equation4082
  (G : Type) `{Magma G} (h : Equation4103 G) : Equation4082 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4107_implies_Equation4085
  (G : Type) `{Magma G} (h : Equation4107 G) : Equation4085 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4111_implies_Equation4082
  (G : Type) `{Magma G} (h : Equation4111 G) : Equation4082 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4112_implies_Equation4086
  (G : Type) `{Magma G} (h : Equation4112 G) : Equation4086 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4113_implies_Equation4087
  (G : Type) `{Magma G} (h : Equation4113 G) : Equation4087 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4114_implies_Equation4086
  (G : Type) `{Magma G} (h : Equation4114 G) : Equation4086 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4115_implies_Equation4088
  (G : Type) `{Magma G} (h : Equation4115 G) : Equation4088 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4126_implies_Equation4119
  (G : Type) `{Magma G} (h : Equation4126 G) : Equation4119 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4136_implies_Equation4129
  (G : Type) `{Magma G} (h : Equation4136 G) : Equation4129 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4140_implies_Equation4119
  (G : Type) `{Magma G} (h : Equation4140 G) : Equation4119 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4144_implies_Equation4122
  (G : Type) `{Magma G} (h : Equation4144 G) : Equation4122 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4151_implies_Equation4123
  (G : Type) `{Magma G} (h : Equation4151 G) : Equation4123 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4152_implies_Equation4125
  (G : Type) `{Magma G} (h : Equation4152 G) : Equation4125 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4163_implies_Equation4156
  (G : Type) `{Magma G} (h : Equation4163 G) : Equation4156 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4173_implies_Equation4166
  (G : Type) `{Magma G} (h : Equation4173 G) : Equation4166 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4181_implies_Equation4159
  (G : Type) `{Magma G} (h : Equation4181 G) : Equation4159 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4186_implies_Equation4160
  (G : Type) `{Magma G} (h : Equation4186 G) : Equation4160 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4215_implies_Equation4132
  (G : Type) `{Magma G} (h : Equation4215 G) : Equation4132 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4243_implies_Equation4138
  (G : Type) `{Magma G} (h : Equation4243 G) : Equation4138 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4281_implies_Equation4274
  (G : Type) `{Magma G} (h : Equation4281 G) : Equation4274 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4308_implies_Equation4282
  (G : Type) `{Magma G} (h : Equation4308 G) : Equation4282 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4311_implies_Equation4286
  (G : Type) `{Magma G} (h : Equation4311 G) : Equation4286 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4326_implies_Equation4322
  (G : Type) `{Magma G} (h : Equation4326 G) : Equation4322 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4336_implies_Equation4316
  (G : Type) `{Magma G} (h : Equation4336 G) : Equation4316 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4337_implies_Equation4318
  (G : Type) `{Magma G} (h : Equation4337 G) : Equation4318 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4347_implies_Equation4344
  (G : Type) `{Magma G} (h : Equation4347 G) : Equation4344 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4355_implies_Equation4341
  (G : Type) `{Magma G} (h : Equation4355 G) : Equation4341 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4357_implies_Equation4315
  (G : Type) `{Magma G} (h : Equation4357 G) : Equation4315 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4367_implies_Equation4323
  (G : Type) `{Magma G} (h : Equation4367 G) : Equation4323 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4374_implies_Equation4330
  (G : Type) `{Magma G} (h : Equation4374 G) : Equation4330 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4376_implies_Equation4328
  (G : Type) `{Magma G} (h : Equation4376 G) : Equation4328 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4394_implies_Equation4387
  (G : Type) `{Magma G} (h : Equation4394 G) : Equation4387 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4404_implies_Equation4397
  (G : Type) `{Magma G} (h : Equation4404 G) : Equation4397 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4426_implies_Equation4397
  (G : Type) `{Magma G} (h : Equation4426 G) : Equation4397 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4427_implies_Equation4401
  (G : Type) `{Magma G} (h : Equation4427 G) : Equation4401 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4428_implies_Equation4402
  (G : Type) `{Magma G} (h : Equation4428 G) : Equation4402 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4429_implies_Equation4401
  (G : Type) `{Magma G} (h : Equation4429 G) : Equation4401 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4430_implies_Equation4403
  (G : Type) `{Magma G} (h : Equation4430 G) : Equation4403 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4441_implies_Equation4434
  (G : Type) `{Magma G} (h : Equation4441 G) : Equation4434 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4463_implies_Equation4434
  (G : Type) `{Magma G} (h : Equation4463 G) : Equation4434 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4466_implies_Equation4438
  (G : Type) `{Magma G} (h : Equation4466 G) : Equation4438 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4467_implies_Equation4440
  (G : Type) `{Magma G} (h : Equation4467 G) : Equation4440 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4478_implies_Equation4471
  (G : Type) `{Magma G} (h : Equation4478 G) : Equation4471 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4488_implies_Equation4481
  (G : Type) `{Magma G} (h : Equation4488 G) : Equation4481 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4492_implies_Equation4471
  (G : Type) `{Magma G} (h : Equation4492 G) : Equation4471 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4500_implies_Equation4471
  (G : Type) `{Magma G} (h : Equation4500 G) : Equation4471 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4501_implies_Equation4475
  (G : Type) `{Magma G} (h : Equation4501 G) : Equation4475 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4502_implies_Equation4476
  (G : Type) `{Magma G} (h : Equation4502 G) : Equation4476 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4503_implies_Equation4475
  (G : Type) `{Magma G} (h : Equation4503 G) : Equation4475 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4504_implies_Equation4477
  (G : Type) `{Magma G} (h : Equation4504 G) : Equation4477 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4509_implies_Equation4434
  (G : Type) `{Magma G} (h : Equation4509 G) : Equation4434 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4513_implies_Equation4437
  (G : Type) `{Magma G} (h : Equation4513 G) : Equation4437 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4518_implies_Equation4438
  (G : Type) `{Magma G} (h : Equation4518 G) : Equation4438 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4519_implies_Equation4439
  (G : Type) `{Magma G} (h : Equation4519 G) : Equation4439 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4520_implies_Equation4438
  (G : Type) `{Magma G} (h : Equation4520 G) : Equation4438 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4521_implies_Equation4440
  (G : Type) `{Magma G} (h : Equation4521 G) : Equation4440 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4530_implies_Equation4447
  (G : Type) `{Magma G} (h : Equation4530 G) : Equation4447 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4537_implies_Equation4448
  (G : Type) `{Magma G} (h : Equation4537 G) : Equation4448 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4554_implies_Equation4438
  (G : Type) `{Magma G} (h : Equation4554 G) : Equation4438 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4557_implies_Equation4452
  (G : Type) `{Magma G} (h : Equation4557 G) : Equation4452 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4559_implies_Equation4452
  (G : Type) `{Magma G} (h : Equation4559 G) : Equation4452 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4562_implies_Equation4456
  (G : Type) `{Magma G} (h : Equation4562 G) : Equation4456 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4563_implies_Equation4457
  (G : Type) `{Magma G} (h : Equation4563 G) : Equation4457 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4564_implies_Equation4456
  (G : Type) `{Magma G} (h : Equation4564 G) : Equation4456 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4569_implies_Equation4452
  (G : Type) `{Magma G} (h : Equation4569 G) : Equation4452 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4572_implies_Equation4460
  (G : Type) `{Magma G} (h : Equation4572 G) : Equation4460 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4574_implies_Equation4460
  (G : Type) `{Magma G} (h : Equation4574 G) : Equation4460 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4575_implies_Equation4462
  (G : Type) `{Magma G} (h : Equation4575 G) : Equation4462 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4613_implies_Equation4607
  (G : Type) `{Magma G} (h : Equation4613 G) : Equation4607 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4626_implies_Equation4601
  (G : Type) `{Magma G} (h : Equation4626 G) : Equation4601 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4627_implies_Equation4603
  (G : Type) `{Magma G} (h : Equation4627 G) : Equation4603 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4651_implies_Equation4631
  (G : Type) `{Magma G} (h : Equation4651 G) : Equation4631 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4652_implies_Equation4633
  (G : Type) `{Magma G} (h : Equation4652 G) : Equation4633 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4670_implies_Equation4656
  (G : Type) `{Magma G} (h : Equation4670 G) : Equation4656 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4672_implies_Equation4630
  (G : Type) `{Magma G} (h : Equation4672 G) : Equation4630 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4675_implies_Equation4631
  (G : Type) `{Magma G} (h : Equation4675 G) : Equation4631 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4678_implies_Equation4637
  (G : Type) `{Magma G} (h : Equation4678 G) : Equation4637 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4681_implies_Equation4638
  (G : Type) `{Magma G} (h : Equation4681 G) : Equation4638 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4682_implies_Equation4638
  (G : Type) `{Magma G} (h : Equation4682 G) : Equation4638 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4689_implies_Equation4645
  (G : Type) `{Magma G} (h : Equation4689 G) : Equation4645 G.
Proof. intros x y z. exact (h x y x z). Qed.

Theorem Equation4691_implies_Equation4643
  (G : Type) `{Magma G} (h : Equation4691 G) : Equation4643 G.
Proof. intros x y z. exact (h x y x z). Qed.

