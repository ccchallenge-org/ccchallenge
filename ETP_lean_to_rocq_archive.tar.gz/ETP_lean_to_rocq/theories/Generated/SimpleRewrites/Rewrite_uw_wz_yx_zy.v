(** * SimpleRewrites/Rewrite_uw_wz_yx_zy

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation499_implies_Equation425
  (G : Type) `{Magma G} (h : Equation499 G) : Equation425 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation612_implies_Equation461
  (G : Type) `{Magma G} (h : Equation612 G) : Equation461 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation811_implies_Equation661
  (G : Type) `{Magma G} (h : Equation811 G) : Equation661 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation1477_implies_Equation1440
  (G : Type) `{Magma G} (h : Equation1477 G) : Equation1440 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation1514_implies_Equation1440
  (G : Type) `{Magma G} (h : Equation1514 G) : Equation1440 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation1883_implies_Equation1846
  (G : Type) `{Magma G} (h : Equation1883 G) : Equation1846 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation2029_implies_Equation1879
  (G : Type) `{Magma G} (h : Equation2029 G) : Equation1879 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation2086_implies_Equation2049
  (G : Type) `{Magma G} (h : Equation2086 G) : Equation2049 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation2216_implies_Equation2073
  (G : Type) `{Magma G} (h : Equation2216 G) : Equation2073 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation2232_implies_Equation2082
  (G : Type) `{Magma G} (h : Equation2232 G) : Equation2082 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation2492_implies_Equation2455
  (G : Type) `{Magma G} (h : Equation2492 G) : Equation2455 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation2695_implies_Equation2658
  (G : Type) `{Magma G} (h : Equation2695 G) : Equation2658 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation2898_implies_Equation2861
  (G : Type) `{Magma G} (h : Equation2898 G) : Equation2861 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation3101_implies_Equation3064
  (G : Type) `{Magma G} (h : Equation3101 G) : Equation3064 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation3341_implies_Equation3267
  (G : Type) `{Magma G} (h : Equation3341 G) : Equation3267 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation3434_implies_Equation3291
  (G : Type) `{Magma G} (h : Equation3434 G) : Equation3291 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation3507_implies_Equation3470
  (G : Type) `{Magma G} (h : Equation3507 G) : Equation3470 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation3710_implies_Equation3673
  (G : Type) `{Magma G} (h : Equation3710 G) : Equation3673 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation3913_implies_Equation3876
  (G : Type) `{Magma G} (h : Equation3913 G) : Equation3876 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4116_implies_Equation4079
  (G : Type) `{Magma G} (h : Equation4116 G) : Equation4079 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4251_implies_Equation4103
  (G : Type) `{Magma G} (h : Equation4251 G) : Equation4103 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4313_implies_Equation4281
  (G : Type) `{Magma G} (h : Equation4313 G) : Equation4281 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4361_implies_Equation4289
  (G : Type) `{Magma G} (h : Equation4361 G) : Equation4289 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4375_implies_Equation4302
  (G : Type) `{Magma G} (h : Equation4375 G) : Equation4302 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4561_implies_Equation4418
  (G : Type) `{Magma G} (h : Equation4561 G) : Equation4418 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4577_implies_Equation4427
  (G : Type) `{Magma G} (h : Equation4577 G) : Equation4427 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4578_implies_Equation4427
  (G : Type) `{Magma G} (h : Equation4578 G) : Equation4427 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4579_implies_Equation4428
  (G : Type) `{Magma G} (h : Equation4579 G) : Equation4428 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4628_implies_Equation4596
  (G : Type) `{Magma G} (h : Equation4628 G) : Equation4596 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4671_implies_Equation4596
  (G : Type) `{Magma G} (h : Equation4671 G) : Equation4596 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4676_implies_Equation4604
  (G : Type) `{Magma G} (h : Equation4676 G) : Equation4604 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4688_implies_Equation4613
  (G : Type) `{Magma G} (h : Equation4688 G) : Equation4613 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4690_implies_Equation4617
  (G : Type) `{Magma G} (h : Equation4690 G) : Equation4617 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

Theorem Equation4693_implies_Equation4625
  (G : Type) `{Magma G} (h : Equation4693 G) : Equation4625 G.
Proof. intros x y z w. exact (h x x y z w). Qed.

