(** * SimpleRewrites/Rewrite_uw_vu

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation613_implies_Equation607
  (G : Type) `{Magma G} (h : Equation613 G) : Equation607 G.
Proof. intros x y z w u. exact (h x y z w w u). Qed.

Theorem Equation816_implies_Equation810
  (G : Type) `{Magma G} (h : Equation816 G) : Equation810 G.
Proof. intros x y z w u. exact (h x y z w w u). Qed.

Theorem Equation1019_implies_Equation1013
  (G : Type) `{Magma G} (h : Equation1019 G) : Equation1013 G.
Proof. intros x y z w u. exact (h x y z w w u). Qed.

Theorem Equation1222_implies_Equation1216
  (G : Type) `{Magma G} (h : Equation1222 G) : Equation1216 G.
Proof. intros x y z w u. exact (h x y z w w u). Qed.

Theorem Equation1425_implies_Equation1419
  (G : Type) `{Magma G} (h : Equation1425 G) : Equation1419 G.
Proof. intros x y z w u. exact (h x y z w w u). Qed.

Theorem Equation1628_implies_Equation1622
  (G : Type) `{Magma G} (h : Equation1628 G) : Equation1622 G.
Proof. intros x y z w u. exact (h x y z w w u). Qed.

Theorem Equation2034_implies_Equation2028
  (G : Type) `{Magma G} (h : Equation2034 G) : Equation2028 G.
Proof. intros x y z w u. exact (h x y z w w u). Qed.

Theorem Equation2237_implies_Equation2231
  (G : Type) `{Magma G} (h : Equation2237 G) : Equation2231 G.
Proof. intros x y z w u. exact (h x y z w w u). Qed.

Theorem Equation2643_implies_Equation2637
  (G : Type) `{Magma G} (h : Equation2643 G) : Equation2637 G.
Proof. intros x y z w u. exact (h x y z w w u). Qed.

Theorem Equation2846_implies_Equation2840
  (G : Type) `{Magma G} (h : Equation2846 G) : Equation2840 G.
Proof. intros x y z w u. exact (h x y z w w u). Qed.

Theorem Equation3049_implies_Equation3043
  (G : Type) `{Magma G} (h : Equation3049 G) : Equation3043 G.
Proof. intros x y z w u. exact (h x y z w w u). Qed.

Theorem Equation3252_implies_Equation3246
  (G : Type) `{Magma G} (h : Equation3252 G) : Equation3246 G.
Proof. intros x y z w u. exact (h x y z w w u). Qed.

Theorem Equation3861_implies_Equation3855
  (G : Type) `{Magma G} (h : Equation3861 G) : Equation3855 G.
Proof. intros x y z w u. exact (h x y z w w u). Qed.

