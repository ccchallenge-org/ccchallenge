(** * SimpleRewrites/Rewrite_uw_wz_zy

    Auto-generated from Lean4 SimpleRewrites. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.
From ETP.Equations Require Import All.

Open Scope magma_scope.

Theorem Equation150_implies_Equation133
  (G : Type) `{Magma G} (h : Equation150 G) : Equation133 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation254_implies_Equation237
  (G : Type) `{Magma G} (h : Equation254 G) : Equation237 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation358_implies_Equation341
  (G : Type) `{Magma G} (h : Equation358 G) : Equation341 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation410_implies_Equation393
  (G : Type) `{Magma G} (h : Equation410 G) : Equation393 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation592_implies_Equation523
  (G : Type) `{Magma G} (h : Equation592 G) : Equation523 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation608_implies_Equation532
  (G : Type) `{Magma G} (h : Equation608 G) : Equation532 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation665_implies_Equation648
  (G : Type) `{Magma G} (h : Equation665 G) : Equation648 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation739_implies_Equation722
  (G : Type) `{Magma G} (h : Equation739 G) : Equation722 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation795_implies_Equation726
  (G : Type) `{Magma G} (h : Equation795 G) : Equation726 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation800_implies_Equation730
  (G : Type) `{Magma G} (h : Equation800 G) : Equation730 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation810_implies_Equation734
  (G : Type) `{Magma G} (h : Equation810 G) : Equation734 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation812_implies_Equation736
  (G : Type) `{Magma G} (h : Equation812 G) : Equation736 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation814_implies_Equation737
  (G : Type) `{Magma G} (h : Equation814 G) : Equation737 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation815_implies_Equation738
  (G : Type) `{Magma G} (h : Equation815 G) : Equation738 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation942_implies_Equation925
  (G : Type) `{Magma G} (h : Equation942 G) : Equation925 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation1071_implies_Equation1054
  (G : Type) `{Magma G} (h : Equation1071 G) : Equation1054 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation1108_implies_Equation1091
  (G : Type) `{Magma G} (h : Equation1108 G) : Equation1091 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation1145_implies_Equation1128
  (G : Type) `{Magma G} (h : Equation1145 G) : Equation1128 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation1201_implies_Equation1132
  (G : Type) `{Magma G} (h : Equation1201 G) : Equation1132 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation1382_implies_Equation1331
  (G : Type) `{Magma G} (h : Equation1382 G) : Equation1331 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation1404_implies_Equation1335
  (G : Type) `{Magma G} (h : Equation1404 G) : Equation1335 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation1420_implies_Equation1344
  (G : Type) `{Magma G} (h : Equation1420 G) : Equation1344 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation1514_implies_Equation1497
  (G : Type) `{Magma G} (h : Equation1514 G) : Equation1497 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation1551_implies_Equation1534
  (G : Type) `{Magma G} (h : Equation1551 G) : Equation1534 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation1623_implies_Equation1547
  (G : Type) `{Magma G} (h : Equation1623 G) : Equation1547 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation1771_implies_Equation1727
  (G : Type) `{Magma G} (h : Equation1771 G) : Equation1727 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation1883_implies_Equation1866
  (G : Type) `{Magma G} (h : Equation1883 G) : Equation1866 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation1957_implies_Equation1940
  (G : Type) `{Magma G} (h : Equation1957 G) : Equation1940 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2013_implies_Equation1944
  (G : Type) `{Magma G} (h : Equation2013 G) : Equation1944 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2029_implies_Equation1953
  (G : Type) `{Magma G} (h : Equation2029 G) : Equation1953 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2123_implies_Equation2106
  (G : Type) `{Magma G} (h : Equation2123 G) : Equation2106 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2160_implies_Equation2143
  (G : Type) `{Magma G} (h : Equation2160 G) : Equation2143 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2216_implies_Equation2147
  (G : Type) `{Magma G} (h : Equation2216 G) : Equation2147 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2289_implies_Equation2272
  (G : Type) `{Magma G} (h : Equation2289 G) : Equation2272 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2326_implies_Equation2309
  (G : Type) `{Magma G} (h : Equation2326 G) : Equation2309 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2492_implies_Equation2475
  (G : Type) `{Magma G} (h : Equation2492 G) : Equation2475 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2529_implies_Equation2512
  (G : Type) `{Magma G} (h : Equation2529 G) : Equation2512 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2566_implies_Equation2549
  (G : Type) `{Magma G} (h : Equation2566 G) : Equation2549 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2638_implies_Equation2562
  (G : Type) `{Magma G} (h : Equation2638 G) : Equation2562 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2732_implies_Equation2715
  (G : Type) `{Magma G} (h : Equation2732 G) : Equation2715 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2786_implies_Equation2742
  (G : Type) `{Magma G} (h : Equation2786 G) : Equation2742 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2825_implies_Equation2756
  (G : Type) `{Magma G} (h : Equation2825 G) : Equation2756 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2841_implies_Equation2765
  (G : Type) `{Magma G} (h : Equation2841 G) : Equation2765 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation2972_implies_Equation2955
  (G : Type) `{Magma G} (h : Equation2972 G) : Equation2955 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3044_implies_Equation2968
  (G : Type) `{Magma G} (h : Equation3044 G) : Equation2968 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3247_implies_Equation3171
  (G : Type) `{Magma G} (h : Equation3247 G) : Equation3171 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3304_implies_Equation3287
  (G : Type) `{Magma G} (h : Equation3304 G) : Equation3287 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3434_implies_Equation3365
  (G : Type) `{Magma G} (h : Equation3434 G) : Equation3365 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3439_implies_Equation3369
  (G : Type) `{Magma G} (h : Equation3439 G) : Equation3369 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3451_implies_Equation3375
  (G : Type) `{Magma G} (h : Equation3451 G) : Equation3375 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3507_implies_Equation3490
  (G : Type) `{Magma G} (h : Equation3507 G) : Equation3490 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3581_implies_Equation3564
  (G : Type) `{Magma G} (h : Equation3581 G) : Equation3564 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3784_implies_Equation3767
  (G : Type) `{Magma G} (h : Equation3784 G) : Equation3767 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3855_implies_Equation3779
  (G : Type) `{Magma G} (h : Equation3855 G) : Equation3779 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3857_implies_Equation3781
  (G : Type) `{Magma G} (h : Equation3857 G) : Equation3781 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3860_implies_Equation3783
  (G : Type) `{Magma G} (h : Equation3860 G) : Equation3783 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3913_implies_Equation3896
  (G : Type) `{Magma G} (h : Equation3913 G) : Equation3896 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation3987_implies_Equation3970
  (G : Type) `{Magma G} (h : Equation3987 G) : Equation3970 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4060_implies_Equation3984
  (G : Type) `{Magma G} (h : Equation4060 G) : Equation3984 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4153_implies_Equation4136
  (G : Type) `{Magma G} (h : Equation4153 G) : Equation4136 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4224_implies_Equation4173
  (G : Type) `{Magma G} (h : Equation4224 G) : Equation4173 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4246_implies_Equation4177
  (G : Type) `{Magma G} (h : Equation4246 G) : Equation4177 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4256_implies_Equation4181
  (G : Type) `{Magma G} (h : Equation4256 G) : Equation4181 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4261_implies_Equation4185
  (G : Type) `{Magma G} (h : Equation4261 G) : Equation4185 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4262_implies_Equation4186
  (G : Type) `{Magma G} (h : Equation4262 G) : Equation4186 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4263_implies_Equation4187
  (G : Type) `{Magma G} (h : Equation4263 G) : Equation4187 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4265_implies_Equation4188
  (G : Type) `{Magma G} (h : Equation4265 G) : Equation4188 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4266_implies_Equation4189
  (G : Type) `{Magma G} (h : Equation4266 G) : Equation4189 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4338_implies_Equation4326
  (G : Type) `{Magma G} (h : Equation4338 G) : Equation4326 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4356_implies_Equation4347
  (G : Type) `{Magma G} (h : Equation4356 G) : Equation4347 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4361_implies_Equation4342
  (G : Type) `{Magma G} (h : Equation4361 G) : Equation4342 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4368_implies_Equation4347
  (G : Type) `{Magma G} (h : Equation4368 G) : Equation4347 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4375_implies_Equation4352
  (G : Type) `{Magma G} (h : Equation4375 G) : Equation4352 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4431_implies_Equation4414
  (G : Type) `{Magma G} (h : Equation4431 G) : Equation4414 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4468_implies_Equation4451
  (G : Type) `{Magma G} (h : Equation4468 G) : Equation4451 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4577_implies_Equation4501
  (G : Type) `{Magma G} (h : Equation4577 G) : Equation4501 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4676_implies_Equation4657
  (G : Type) `{Magma G} (h : Equation4676 G) : Equation4657 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4690_implies_Equation4667
  (G : Type) `{Magma G} (h : Equation4690 G) : Equation4667 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

Theorem Equation4693_implies_Equation4669
  (G : Type) `{Magma G} (h : Equation4693 G) : Equation4669 G.
Proof. intros x y z w. exact (h x y y z w). Qed.

