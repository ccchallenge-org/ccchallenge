(** * MagmaLaw — equational laws over free magmas *)

From Stdlib Require Import Utf8.
From Stdlib Require Import List.

From ETP Require Import Magma.
From ETP Require Import FreeMagma.

Import ListNotations.

Open Scope magma_scope.

(** ---------- the record -------------------------------------------------- *)

(** A [MagmaLaw] over a variable type [A] is a pair of [FreeMagma A] trees
    (left-hand side and right-hand side). *)

Record MagmaLaw (A : Type) : Type :=
  { law_lhs : FreeMagma A
  ; law_rhs : FreeMagma A
  }.

Arguments law_lhs {A} _.
Arguments law_rhs {A} _.

(** ---------- satisfaction under a single valuation ----------------------- *)

(** [φ] satisfies the law [E] when both sides evaluate to the same element. *)
Definition satisfiesPhi {A G : Type} `{Magma G}
  (φ : A -> G) (E : MagmaLaw A) : Prop :=
  evalInMagma φ (law_lhs E) = evalInMagma φ (law_rhs E).

(** Notation matching Lean4's [E.lhs ⬝ φ = E.rhs ⬝ φ]. *)
(** Already covered by [satisfiesPhi] — the user can unfold to see the
    [⬝] notation from FreeMagma. *)

(** ---------- satisfaction (universal, a magma "models" the law) ----------- *)

(** [G] satisfies [E] when *every* valuation satisfies it. *)
Definition satisfies {A : Type} (G : Type) `{Magma G}
  (E : MagmaLaw A) : Prop :=
  forall (φ : A -> G), satisfiesPhi φ E.

(** ---------- satisfaction of a set of laws ------------------------------- *)

Definition satisfies_all {A : Type} (G : Type) `{Magma G}
  (Es : list (MagmaLaw A)) : Prop :=
  forall E, In E Es -> satisfies G E.

(** ---------- semantic entailment ----------------------------------------- *)

(** A law [E'] is entailed by a set of laws [Es] when every magma
    satisfying all of [Es] also satisfies [E']. *)
Definition entails {A : Type}
  (Es : list (MagmaLaw A)) (E' : MagmaLaw A) : Prop :=
  forall (G : Type) (M : Magma G),
    @satisfies_all A G M Es -> @satisfies A G M E'.

(** ---------- basic lemmas ------------------------------------------------ *)

Lemma satisfiesPhi_iff :
  forall {A G : Type} `{Magma G} (φ : A -> G) (E : MagmaLaw A),
    satisfiesPhi φ E <->
    (law_lhs E) ⬝ φ = (law_rhs E) ⬝ φ.
Proof. intros. unfold satisfiesPhi. tauto. Qed.

Lemma satisfies_iff :
  forall {A : Type} (G : Type) `{Magma G} (E : MagmaLaw A),
    satisfies G E <->
    forall φ : A -> G, (law_lhs E) ⬝ φ = (law_rhs E) ⬝ φ.
Proof. intros. unfold satisfies, satisfiesPhi. tauto. Qed.
