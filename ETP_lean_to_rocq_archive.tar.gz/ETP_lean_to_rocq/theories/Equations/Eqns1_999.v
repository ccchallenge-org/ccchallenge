(** * Equations 1–999

    Auto-generated from the Lean4 Equational Theories Project. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.

Open Scope magma_scope.

Definition Equation1 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = x.

Definition Equation2 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y.

Definition Equation3 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = x ◇ x.

Definition Equation4 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ y.

Definition Equation5 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ x.

Definition Equation6 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ y.

Definition Equation7 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ z.

Definition Equation8 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = x ◇ (x ◇ x).

Definition Equation9 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ y).

Definition Equation10 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ x).

Definition Equation11 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ y).

Definition Equation12 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ z).

Definition Equation13 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ x).

Definition Equation14 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ y).

Definition Equation15 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ z).

Definition Equation16 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ x).

Definition Equation17 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ y).

Definition Equation18 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ z).

Definition Equation19 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ x).

Definition Equation20 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ y).

Definition Equation21 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ z).

Definition Equation22 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ w).

Definition Equation23 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = (x ◇ x) ◇ x.

Definition Equation24 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ y.

Definition Equation25 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ x.

Definition Equation26 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ y.

Definition Equation27 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ z.

Definition Equation28 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ x.

Definition Equation29 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ y.

Definition Equation30 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ z.

Definition Equation31 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ x.

Definition Equation32 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ y.

Definition Equation33 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ z.

Definition Equation34 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ x.

Definition Equation35 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ y.

Definition Equation36 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ z.

Definition Equation37 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ w.

Definition Equation38 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ y.

Definition Equation39 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ x.

Definition Equation40 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ y.

Definition Equation41 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ z.

Definition Equation42 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ z.

Definition Equation43 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ x.

Definition Equation44 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ z.

Definition Equation45 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ y.

Definition Equation46 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ w.

Definition Equation47 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = x ◇ (x ◇ (x ◇ x)).

Definition Equation48 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ (x ◇ y)).

Definition Equation49 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ (y ◇ x)).

Definition Equation50 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ (y ◇ y)).

Definition Equation51 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (x ◇ (y ◇ z)).

Definition Equation52 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ (x ◇ x)).

Definition Equation53 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ (x ◇ y)).

Definition Equation54 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (x ◇ z)).

Definition Equation55 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ (y ◇ x)).

Definition Equation56 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ (y ◇ y)).

Definition Equation57 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (y ◇ z)).

Definition Equation58 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (z ◇ x)).

Definition Equation59 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (z ◇ y)).

Definition Equation60 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (z ◇ z)).

Definition Equation61 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ (z ◇ w)).

Definition Equation62 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ (x ◇ x)).

Definition Equation63 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ (x ◇ y)).

Definition Equation64 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (x ◇ z)).

Definition Equation65 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ (y ◇ x)).

Definition Equation66 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ (y ◇ y)).

Definition Equation67 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (y ◇ z)).

Definition Equation68 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (z ◇ x)).

Definition Equation69 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (z ◇ y)).

Definition Equation70 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (z ◇ z)).

Definition Equation71 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ (z ◇ w)).

Definition Equation72 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ (x ◇ x)).

Definition Equation73 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ (x ◇ y)).

Definition Equation74 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (x ◇ z)).

Definition Equation75 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ (y ◇ x)).

Definition Equation76 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ (y ◇ y)).

Definition Equation77 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (y ◇ z)).

Definition Equation78 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (z ◇ x)).

Definition Equation79 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (z ◇ y)).

Definition Equation80 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (z ◇ z)).

Definition Equation81 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ (z ◇ w)).

Definition Equation82 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (x ◇ x)).

Definition Equation83 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (x ◇ y)).

Definition Equation84 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (x ◇ z)).

Definition Equation85 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (x ◇ w)).

Definition Equation86 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (y ◇ x)).

Definition Equation87 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (y ◇ y)).

Definition Equation88 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (y ◇ z)).

Definition Equation89 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (y ◇ w)).

Definition Equation90 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (z ◇ x)).

Definition Equation91 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (z ◇ y)).

Definition Equation92 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (z ◇ z)).

Definition Equation93 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (z ◇ w)).

Definition Equation94 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ x)).

Definition Equation95 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ y)).

Definition Equation96 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ z)).

Definition Equation97 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ w)).

Definition Equation98 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ (w ◇ u)).

Definition Equation99 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = x ◇ ((x ◇ x) ◇ x).

Definition Equation100 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ x) ◇ y).

Definition Equation101 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ y) ◇ x).

Definition Equation102 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ y) ◇ y).

Definition Equation103 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((x ◇ y) ◇ z).

Definition Equation104 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ x) ◇ x).

Definition Equation105 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ x) ◇ y).

Definition Equation106 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ x) ◇ z).

Definition Equation107 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ y) ◇ x).

Definition Equation108 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ y) ◇ y).

Definition Equation109 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ y) ◇ z).

Definition Equation110 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ z) ◇ x).

Definition Equation111 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ z) ◇ y).

Definition Equation112 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ z) ◇ z).

Definition Equation113 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ z) ◇ w).

Definition Equation114 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ x) ◇ x).

Definition Equation115 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ x) ◇ y).

Definition Equation116 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ x) ◇ z).

Definition Equation117 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ y) ◇ x).

Definition Equation118 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ y) ◇ y).

Definition Equation119 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ y) ◇ z).

Definition Equation120 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ z) ◇ x).

Definition Equation121 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ z) ◇ y).

Definition Equation122 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ z) ◇ z).

Definition Equation123 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ z) ◇ w).

Definition Equation124 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ x) ◇ x).

Definition Equation125 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ x) ◇ y).

Definition Equation126 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ x) ◇ z).

Definition Equation127 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ y) ◇ x).

Definition Equation128 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ y) ◇ y).

Definition Equation129 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ y) ◇ z).

Definition Equation130 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ z) ◇ x).

Definition Equation131 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ z) ◇ y).

Definition Equation132 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ z) ◇ z).

Definition Equation133 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ z) ◇ w).

Definition Equation134 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ x) ◇ x).

Definition Equation135 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ x) ◇ y).

Definition Equation136 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ x) ◇ z).

Definition Equation137 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ x) ◇ w).

Definition Equation138 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ y) ◇ x).

Definition Equation139 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ y) ◇ y).

Definition Equation140 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ y) ◇ z).

Definition Equation141 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ y) ◇ w).

Definition Equation142 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ z) ◇ x).

Definition Equation143 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ z) ◇ y).

Definition Equation144 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ z) ◇ z).

Definition Equation145 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ z) ◇ w).

Definition Equation146 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ x).

Definition Equation147 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ y).

Definition Equation148 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ z).

Definition Equation149 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ w).

Definition Equation150 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ w) ◇ u).

Definition Equation151 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = (x ◇ x) ◇ (x ◇ x).

Definition Equation152 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ (x ◇ y).

Definition Equation153 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ (y ◇ x).

Definition Equation154 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ (y ◇ y).

Definition Equation155 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ x) ◇ (y ◇ z).

Definition Equation156 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ (x ◇ x).

Definition Equation157 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ (x ◇ y).

Definition Equation158 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (x ◇ z).

Definition Equation159 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ (y ◇ x).

Definition Equation160 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ (y ◇ y).

Definition Equation161 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (y ◇ z).

Definition Equation162 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (z ◇ x).

Definition Equation163 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (z ◇ y).

Definition Equation164 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (z ◇ z).

Definition Equation165 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ (z ◇ w).

Definition Equation166 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ (x ◇ x).

Definition Equation167 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ (x ◇ y).

Definition Equation168 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (x ◇ z).

Definition Equation169 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ (y ◇ x).

Definition Equation170 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ (y ◇ y).

Definition Equation171 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (y ◇ z).

Definition Equation172 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (z ◇ x).

Definition Equation173 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (z ◇ y).

Definition Equation174 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (z ◇ z).

Definition Equation175 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ (z ◇ w).

Definition Equation176 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ (x ◇ x).

Definition Equation177 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ (x ◇ y).

Definition Equation178 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (x ◇ z).

Definition Equation179 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ (y ◇ x).

Definition Equation180 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ (y ◇ y).

Definition Equation181 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (y ◇ z).

Definition Equation182 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (z ◇ x).

Definition Equation183 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (z ◇ y).

Definition Equation184 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (z ◇ z).

Definition Equation185 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ (z ◇ w).

Definition Equation186 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (x ◇ x).

Definition Equation187 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (x ◇ y).

Definition Equation188 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (x ◇ z).

Definition Equation189 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (x ◇ w).

Definition Equation190 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (y ◇ x).

Definition Equation191 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (y ◇ y).

Definition Equation192 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (y ◇ z).

Definition Equation193 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (y ◇ w).

Definition Equation194 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (z ◇ x).

Definition Equation195 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (z ◇ y).

Definition Equation196 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (z ◇ z).

Definition Equation197 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (z ◇ w).

Definition Equation198 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ x).

Definition Equation199 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ y).

Definition Equation200 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ z).

Definition Equation201 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ w).

Definition Equation202 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ (w ◇ u).

Definition Equation203 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = (x ◇ (x ◇ x)) ◇ x.

Definition Equation204 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ x)) ◇ y.

Definition Equation205 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ y)) ◇ x.

Definition Equation206 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ y)) ◇ y.

Definition Equation207 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (x ◇ y)) ◇ z.

Definition Equation208 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ x)) ◇ x.

Definition Equation209 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ x)) ◇ y.

Definition Equation210 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ x)) ◇ z.

Definition Equation211 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ y)) ◇ x.

Definition Equation212 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ y)) ◇ y.

Definition Equation213 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ y)) ◇ z.

Definition Equation214 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ z)) ◇ x.

Definition Equation215 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ z)) ◇ y.

Definition Equation216 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ z)) ◇ z.

Definition Equation217 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ z)) ◇ w.

Definition Equation218 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ x)) ◇ x.

Definition Equation219 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ x)) ◇ y.

Definition Equation220 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ x)) ◇ z.

Definition Equation221 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ y)) ◇ x.

Definition Equation222 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ y)) ◇ y.

Definition Equation223 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ y)) ◇ z.

Definition Equation224 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ z)) ◇ x.

Definition Equation225 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ z)) ◇ y.

Definition Equation226 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ z)) ◇ z.

Definition Equation227 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ z)) ◇ w.

Definition Equation228 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ x)) ◇ x.

Definition Equation229 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ x)) ◇ y.

Definition Equation230 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ x)) ◇ z.

Definition Equation231 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ y)) ◇ x.

Definition Equation232 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ y)) ◇ y.

Definition Equation233 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ y)) ◇ z.

Definition Equation234 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ z)) ◇ x.

Definition Equation235 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ z)) ◇ y.

Definition Equation236 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ z)) ◇ z.

Definition Equation237 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ z)) ◇ w.

Definition Equation238 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ x)) ◇ x.

Definition Equation239 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ x)) ◇ y.

Definition Equation240 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ x)) ◇ z.

Definition Equation241 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ x)) ◇ w.

Definition Equation242 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ y)) ◇ x.

Definition Equation243 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ y)) ◇ y.

Definition Equation244 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ y)) ◇ z.

Definition Equation245 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ y)) ◇ w.

Definition Equation246 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ z)) ◇ x.

Definition Equation247 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ z)) ◇ y.

Definition Equation248 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ z)) ◇ z.

Definition Equation249 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ z)) ◇ w.

Definition Equation250 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ x.

Definition Equation251 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ y.

Definition Equation252 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ z.

Definition Equation253 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ w.

Definition Equation254 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ w)) ◇ u.

Definition Equation255 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = ((x ◇ x) ◇ x) ◇ x.

Definition Equation256 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ x) ◇ y.

Definition Equation257 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ y) ◇ x.

Definition Equation258 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ y) ◇ y.

Definition Equation259 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ x) ◇ y) ◇ z.

Definition Equation260 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ x) ◇ x.

Definition Equation261 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ x) ◇ y.

Definition Equation262 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ x) ◇ z.

Definition Equation263 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ y) ◇ x.

Definition Equation264 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ y) ◇ y.

Definition Equation265 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ y) ◇ z.

Definition Equation266 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ z) ◇ x.

Definition Equation267 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ z) ◇ y.

Definition Equation268 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ z) ◇ z.

Definition Equation269 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ z) ◇ w.

Definition Equation270 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ x) ◇ x.

Definition Equation271 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ x) ◇ y.

Definition Equation272 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ x) ◇ z.

Definition Equation273 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ y) ◇ x.

Definition Equation274 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ y) ◇ y.

Definition Equation275 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ y) ◇ z.

Definition Equation276 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ z) ◇ x.

Definition Equation277 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ z) ◇ y.

Definition Equation278 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ z) ◇ z.

Definition Equation279 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ z) ◇ w.

Definition Equation280 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ x) ◇ x.

Definition Equation281 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ x) ◇ y.

Definition Equation282 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ x) ◇ z.

Definition Equation283 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ y) ◇ x.

Definition Equation284 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ y) ◇ y.

Definition Equation285 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ y) ◇ z.

Definition Equation286 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ z) ◇ x.

Definition Equation287 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ z) ◇ y.

Definition Equation288 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ z) ◇ z.

Definition Equation289 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ z) ◇ w.

Definition Equation290 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ x) ◇ x.

Definition Equation291 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ x) ◇ y.

Definition Equation292 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ x) ◇ z.

Definition Equation293 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ x) ◇ w.

Definition Equation294 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ y) ◇ x.

Definition Equation295 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ y) ◇ y.

Definition Equation296 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ y) ◇ z.

Definition Equation297 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ y) ◇ w.

Definition Equation298 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ z) ◇ x.

Definition Equation299 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ z) ◇ y.

Definition Equation300 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ z) ◇ z.

Definition Equation301 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ z) ◇ w.

Definition Equation302 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ x.

Definition Equation303 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ y.

Definition Equation304 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ z.

Definition Equation305 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ w.

Definition Equation306 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ w) ◇ u.

Definition Equation307 (G : Type) `{Magma G} : Prop :=
  forall x : G, x ◇ x = x ◇ (x ◇ x).

Definition Equation308 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ (x ◇ y).

Definition Equation309 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ (y ◇ x).

Definition Equation310 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ (y ◇ y).

Definition Equation311 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = x ◇ (y ◇ z).

Definition Equation312 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ (x ◇ x).

Definition Equation313 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ (x ◇ y).

Definition Equation314 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (x ◇ z).

Definition Equation315 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ (y ◇ x).

Definition Equation316 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ (y ◇ y).

Definition Equation317 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (y ◇ z).

Definition Equation318 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (z ◇ x).

Definition Equation319 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (z ◇ y).

Definition Equation320 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (z ◇ z).

Definition Equation321 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ (z ◇ w).

Definition Equation322 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ (x ◇ x).

Definition Equation323 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ (x ◇ y).

Definition Equation324 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (x ◇ z).

Definition Equation325 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ (y ◇ x).

Definition Equation326 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ (y ◇ y).

Definition Equation327 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (y ◇ z).

Definition Equation328 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (z ◇ x).

Definition Equation329 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (z ◇ y).

Definition Equation330 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (z ◇ z).

Definition Equation331 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ (z ◇ w).

Definition Equation332 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ (x ◇ x).

Definition Equation333 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ (x ◇ y).

Definition Equation334 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (x ◇ z).

Definition Equation335 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ (y ◇ x).

Definition Equation336 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ (y ◇ y).

Definition Equation337 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (y ◇ z).

Definition Equation338 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (z ◇ x).

Definition Equation339 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (z ◇ y).

Definition Equation340 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (z ◇ z).

Definition Equation341 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ (z ◇ w).

Definition Equation342 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (x ◇ x).

Definition Equation343 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (x ◇ y).

Definition Equation344 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (x ◇ z).

Definition Equation345 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (x ◇ w).

Definition Equation346 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (y ◇ x).

Definition Equation347 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (y ◇ y).

Definition Equation348 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (y ◇ z).

Definition Equation349 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (y ◇ w).

Definition Equation350 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (z ◇ x).

Definition Equation351 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (z ◇ y).

Definition Equation352 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (z ◇ z).

Definition Equation353 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (z ◇ w).

Definition Equation354 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ x).

Definition Equation355 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ y).

Definition Equation356 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ z).

Definition Equation357 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ w).

Definition Equation358 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ (w ◇ u).

Definition Equation359 (G : Type) `{Magma G} : Prop :=
  forall x : G, x ◇ x = (x ◇ x) ◇ x.

Definition Equation360 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ x) ◇ y.

Definition Equation361 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ y) ◇ x.

Definition Equation362 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ y) ◇ y.

Definition Equation363 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (x ◇ y) ◇ z.

Definition Equation364 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ x) ◇ x.

Definition Equation365 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ x) ◇ y.

Definition Equation366 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ x) ◇ z.

Definition Equation367 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ y) ◇ x.

Definition Equation368 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ y) ◇ y.

Definition Equation369 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ y) ◇ z.

Definition Equation370 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ z) ◇ x.

Definition Equation371 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ z) ◇ y.

Definition Equation372 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ z) ◇ z.

Definition Equation373 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ z) ◇ w.

Definition Equation374 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ x) ◇ x.

Definition Equation375 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ x) ◇ y.

Definition Equation376 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ x) ◇ z.

Definition Equation377 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ y) ◇ x.

Definition Equation378 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ y) ◇ y.

Definition Equation379 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ y) ◇ z.

Definition Equation380 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ z) ◇ x.

Definition Equation381 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ z) ◇ y.

Definition Equation382 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ z) ◇ z.

Definition Equation383 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ z) ◇ w.

Definition Equation384 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ x) ◇ x.

Definition Equation385 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ x) ◇ y.

Definition Equation386 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ x) ◇ z.

Definition Equation387 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ y) ◇ x.

Definition Equation388 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ y) ◇ y.

Definition Equation389 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ y) ◇ z.

Definition Equation390 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ z) ◇ x.

Definition Equation391 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ z) ◇ y.

Definition Equation392 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ z) ◇ z.

Definition Equation393 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ z) ◇ w.

Definition Equation394 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ x) ◇ x.

Definition Equation395 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ x) ◇ y.

Definition Equation396 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ x) ◇ z.

Definition Equation397 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ x) ◇ w.

Definition Equation398 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ y) ◇ x.

Definition Equation399 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ y) ◇ y.

Definition Equation400 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ y) ◇ z.

Definition Equation401 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ y) ◇ w.

Definition Equation402 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ z) ◇ x.

Definition Equation403 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ z) ◇ y.

Definition Equation404 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ z) ◇ z.

Definition Equation405 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ z) ◇ w.

Definition Equation406 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ x.

Definition Equation407 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ y.

Definition Equation408 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ z.

Definition Equation409 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ w.

Definition Equation410 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ w) ◇ u.

Definition Equation411 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = x ◇ (x ◇ (x ◇ (x ◇ x))).

Definition Equation412 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ (x ◇ (x ◇ y))).

Definition Equation413 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ (x ◇ (y ◇ x))).

Definition Equation414 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ (x ◇ (y ◇ y))).

Definition Equation415 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (x ◇ (x ◇ (y ◇ z))).

Definition Equation416 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ (y ◇ (x ◇ x))).

Definition Equation417 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ (y ◇ (x ◇ y))).

Definition Equation418 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (x ◇ (y ◇ (x ◇ z))).

Definition Equation419 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ (y ◇ (y ◇ x))).

Definition Equation420 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ (y ◇ (y ◇ y))).

Definition Equation421 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (x ◇ (y ◇ (y ◇ z))).

Definition Equation422 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (x ◇ (y ◇ (z ◇ x))).

Definition Equation423 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (x ◇ (y ◇ (z ◇ y))).

Definition Equation424 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (x ◇ (y ◇ (z ◇ z))).

Definition Equation425 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (x ◇ (y ◇ (z ◇ w))).

Definition Equation426 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ (x ◇ (x ◇ x))).

Definition Equation427 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ (x ◇ (x ◇ y))).

Definition Equation428 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (x ◇ (x ◇ z))).

Definition Equation429 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ (x ◇ (y ◇ x))).

Definition Equation430 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ (x ◇ (y ◇ y))).

Definition Equation431 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (x ◇ (y ◇ z))).

Definition Equation432 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (x ◇ (z ◇ x))).

Definition Equation433 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (x ◇ (z ◇ y))).

Definition Equation434 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (x ◇ (z ◇ z))).

Definition Equation435 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ (x ◇ (z ◇ w))).

Definition Equation436 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ (y ◇ (x ◇ x))).

Definition Equation437 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ (y ◇ (x ◇ y))).

Definition Equation438 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (y ◇ (x ◇ z))).

Definition Equation439 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ (y ◇ (y ◇ x))).

Definition Equation440 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ (y ◇ (y ◇ y))).

Definition Equation441 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (y ◇ (y ◇ z))).

Definition Equation442 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (y ◇ (z ◇ x))).

Definition Equation443 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (y ◇ (z ◇ y))).

Definition Equation444 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (y ◇ (z ◇ z))).

Definition Equation445 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ (y ◇ (z ◇ w))).

Definition Equation446 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (z ◇ (x ◇ x))).

Definition Equation447 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (z ◇ (x ◇ y))).

Definition Equation448 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (z ◇ (x ◇ z))).

Definition Equation449 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ (z ◇ (x ◇ w))).

Definition Equation450 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (z ◇ (y ◇ x))).

Definition Equation451 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (z ◇ (y ◇ y))).

Definition Equation452 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (z ◇ (y ◇ z))).

Definition Equation453 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ (z ◇ (y ◇ w))).

Definition Equation454 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (z ◇ (z ◇ x))).

Definition Equation455 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (z ◇ (z ◇ y))).

Definition Equation456 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ (z ◇ (z ◇ z))).

Definition Equation457 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ (z ◇ (z ◇ w))).

Definition Equation458 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ (z ◇ (w ◇ x))).

Definition Equation459 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ (z ◇ (w ◇ y))).

Definition Equation460 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ (z ◇ (w ◇ z))).

Definition Equation461 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ (z ◇ (w ◇ w))).

Definition Equation462 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = x ◇ (y ◇ (z ◇ (w ◇ u))).

Definition Equation463 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ (x ◇ (x ◇ x))).

Definition Equation464 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ (x ◇ (x ◇ y))).

Definition Equation465 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (x ◇ (x ◇ z))).

Definition Equation466 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ (x ◇ (y ◇ x))).

Definition Equation467 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ (x ◇ (y ◇ y))).

Definition Equation468 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (x ◇ (y ◇ z))).

Definition Equation469 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (x ◇ (z ◇ x))).

Definition Equation470 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (x ◇ (z ◇ y))).

Definition Equation471 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (x ◇ (z ◇ z))).

Definition Equation472 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ (x ◇ (z ◇ w))).

Definition Equation473 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ (y ◇ (x ◇ x))).

Definition Equation474 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ (y ◇ (x ◇ y))).

Definition Equation475 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (y ◇ (x ◇ z))).

Definition Equation476 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ (y ◇ (y ◇ x))).

Definition Equation477 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ (y ◇ (y ◇ y))).

Definition Equation478 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (y ◇ (y ◇ z))).

Definition Equation479 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (y ◇ (z ◇ x))).

Definition Equation480 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (y ◇ (z ◇ y))).

Definition Equation481 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (y ◇ (z ◇ z))).

Definition Equation482 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ (y ◇ (z ◇ w))).

Definition Equation483 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (z ◇ (x ◇ x))).

Definition Equation484 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (z ◇ (x ◇ y))).

Definition Equation485 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (z ◇ (x ◇ z))).

Definition Equation486 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ (z ◇ (x ◇ w))).

Definition Equation487 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (z ◇ (y ◇ x))).

Definition Equation488 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (z ◇ (y ◇ y))).

Definition Equation489 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (z ◇ (y ◇ z))).

Definition Equation490 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ (z ◇ (y ◇ w))).

Definition Equation491 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (z ◇ (z ◇ x))).

Definition Equation492 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (z ◇ (z ◇ y))).

Definition Equation493 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ (z ◇ (z ◇ z))).

Definition Equation494 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ (z ◇ (z ◇ w))).

Definition Equation495 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ (z ◇ (w ◇ x))).

Definition Equation496 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ (z ◇ (w ◇ y))).

Definition Equation497 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ (z ◇ (w ◇ z))).

Definition Equation498 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ (z ◇ (w ◇ w))).

Definition Equation499 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (x ◇ (z ◇ (w ◇ u))).

Definition Equation500 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ (x ◇ (x ◇ x))).

Definition Equation501 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ (x ◇ (x ◇ y))).

Definition Equation502 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (x ◇ (x ◇ z))).

Definition Equation503 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ (x ◇ (y ◇ x))).

Definition Equation504 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ (x ◇ (y ◇ y))).

Definition Equation505 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (x ◇ (y ◇ z))).

Definition Equation506 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (x ◇ (z ◇ x))).

Definition Equation507 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (x ◇ (z ◇ y))).

Definition Equation508 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (x ◇ (z ◇ z))).

Definition Equation509 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ (x ◇ (z ◇ w))).

Definition Equation510 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ (y ◇ (x ◇ x))).

Definition Equation511 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ (y ◇ (x ◇ y))).

Definition Equation512 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (y ◇ (x ◇ z))).

Definition Equation513 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ (y ◇ (y ◇ x))).

Definition Equation514 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ (y ◇ (y ◇ y))).

Definition Equation515 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (y ◇ (y ◇ z))).

Definition Equation516 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (y ◇ (z ◇ x))).

Definition Equation517 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (y ◇ (z ◇ y))).

Definition Equation518 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (y ◇ (z ◇ z))).

Definition Equation519 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ (y ◇ (z ◇ w))).

Definition Equation520 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (z ◇ (x ◇ x))).

Definition Equation521 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (z ◇ (x ◇ y))).

Definition Equation522 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (z ◇ (x ◇ z))).

Definition Equation523 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ (z ◇ (x ◇ w))).

Definition Equation524 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (z ◇ (y ◇ x))).

Definition Equation525 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (z ◇ (y ◇ y))).

Definition Equation526 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (z ◇ (y ◇ z))).

Definition Equation527 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ (z ◇ (y ◇ w))).

Definition Equation528 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (z ◇ (z ◇ x))).

Definition Equation529 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (z ◇ (z ◇ y))).

Definition Equation530 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (z ◇ (z ◇ z))).

Definition Equation531 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ (z ◇ (z ◇ w))).

Definition Equation532 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ (z ◇ (w ◇ x))).

Definition Equation533 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ (z ◇ (w ◇ y))).

Definition Equation534 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ (z ◇ (w ◇ z))).

Definition Equation535 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ (z ◇ (w ◇ w))).

Definition Equation536 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (y ◇ (z ◇ (w ◇ u))).

Definition Equation537 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (x ◇ (x ◇ x))).

Definition Equation538 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (x ◇ (x ◇ y))).

Definition Equation539 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (x ◇ (x ◇ z))).

Definition Equation540 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (x ◇ (x ◇ w))).

Definition Equation541 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (x ◇ (y ◇ x))).

Definition Equation542 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (x ◇ (y ◇ y))).

Definition Equation543 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (x ◇ (y ◇ z))).

Definition Equation544 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (x ◇ (y ◇ w))).

Definition Equation545 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (x ◇ (z ◇ x))).

Definition Equation546 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (x ◇ (z ◇ y))).

Definition Equation547 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (x ◇ (z ◇ z))).

Definition Equation548 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (x ◇ (z ◇ w))).

Definition Equation549 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (x ◇ (w ◇ x))).

Definition Equation550 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (x ◇ (w ◇ y))).

Definition Equation551 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (x ◇ (w ◇ z))).

Definition Equation552 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (x ◇ (w ◇ w))).

Definition Equation553 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ (x ◇ (w ◇ u))).

Definition Equation554 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (y ◇ (x ◇ x))).

Definition Equation555 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (y ◇ (x ◇ y))).

Definition Equation556 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (y ◇ (x ◇ z))).

Definition Equation557 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (y ◇ (x ◇ w))).

Definition Equation558 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (y ◇ (y ◇ x))).

Definition Equation559 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (y ◇ (y ◇ y))).

Definition Equation560 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (y ◇ (y ◇ z))).

Definition Equation561 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (y ◇ (y ◇ w))).

Definition Equation562 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (y ◇ (z ◇ x))).

Definition Equation563 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (y ◇ (z ◇ y))).

Definition Equation564 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (y ◇ (z ◇ z))).

Definition Equation565 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (y ◇ (z ◇ w))).

Definition Equation566 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (y ◇ (w ◇ x))).

Definition Equation567 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (y ◇ (w ◇ y))).

Definition Equation568 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (y ◇ (w ◇ z))).

Definition Equation569 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (y ◇ (w ◇ w))).

Definition Equation570 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ (y ◇ (w ◇ u))).

Definition Equation571 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (z ◇ (x ◇ x))).

Definition Equation572 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (z ◇ (x ◇ y))).

Definition Equation573 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (z ◇ (x ◇ z))).

Definition Equation574 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (z ◇ (x ◇ w))).

Definition Equation575 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (z ◇ (y ◇ x))).

Definition Equation576 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (z ◇ (y ◇ y))).

Definition Equation577 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (z ◇ (y ◇ z))).

Definition Equation578 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (z ◇ (y ◇ w))).

Definition Equation579 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (z ◇ (z ◇ x))).

Definition Equation580 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (z ◇ (z ◇ y))).

Definition Equation581 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ (z ◇ (z ◇ z))).

Definition Equation582 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (z ◇ (z ◇ w))).

Definition Equation583 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (z ◇ (w ◇ x))).

Definition Equation584 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (z ◇ (w ◇ y))).

Definition Equation585 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (z ◇ (w ◇ z))).

Definition Equation586 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (z ◇ (w ◇ w))).

Definition Equation587 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ (z ◇ (w ◇ u))).

Definition Equation588 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (x ◇ x))).

Definition Equation589 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (x ◇ y))).

Definition Equation590 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (x ◇ z))).

Definition Equation591 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (x ◇ w))).

Definition Equation592 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ (w ◇ (x ◇ u))).

Definition Equation593 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (y ◇ x))).

Definition Equation594 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (y ◇ y))).

Definition Equation595 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (y ◇ z))).

Definition Equation596 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (y ◇ w))).

Definition Equation597 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ (w ◇ (y ◇ u))).

Definition Equation598 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (z ◇ x))).

Definition Equation599 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (z ◇ y))).

Definition Equation600 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (z ◇ z))).

Definition Equation601 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (z ◇ w))).

Definition Equation602 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ (w ◇ (z ◇ u))).

Definition Equation603 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (w ◇ x))).

Definition Equation604 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (w ◇ y))).

Definition Equation605 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (w ◇ z))).

Definition Equation606 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ (w ◇ (w ◇ w))).

Definition Equation607 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ (w ◇ (w ◇ u))).

Definition Equation608 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ (w ◇ (u ◇ x))).

Definition Equation609 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ (w ◇ (u ◇ y))).

Definition Equation610 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ (w ◇ (u ◇ z))).

Definition Equation611 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ (w ◇ (u ◇ w))).

Definition Equation612 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ (w ◇ (u ◇ u))).

Definition Equation613 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = y ◇ (z ◇ (w ◇ (u ◇ v))).

Definition Equation614 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = x ◇ (x ◇ ((x ◇ x) ◇ x)).

Definition Equation615 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ ((x ◇ x) ◇ y)).

Definition Equation616 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ ((x ◇ y) ◇ x)).

Definition Equation617 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ ((x ◇ y) ◇ y)).

Definition Equation618 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (x ◇ ((x ◇ y) ◇ z)).

Definition Equation619 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ ((y ◇ x) ◇ x)).

Definition Equation620 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ ((y ◇ x) ◇ y)).

Definition Equation621 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (x ◇ ((y ◇ x) ◇ z)).

Definition Equation622 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ ((y ◇ y) ◇ x)).

Definition Equation623 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (x ◇ ((y ◇ y) ◇ y)).

Definition Equation624 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (x ◇ ((y ◇ y) ◇ z)).

Definition Equation625 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (x ◇ ((y ◇ z) ◇ x)).

Definition Equation626 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (x ◇ ((y ◇ z) ◇ y)).

Definition Equation627 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (x ◇ ((y ◇ z) ◇ z)).

Definition Equation628 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (x ◇ ((y ◇ z) ◇ w)).

Definition Equation629 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ ((x ◇ x) ◇ x)).

Definition Equation630 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ ((x ◇ x) ◇ y)).

Definition Equation631 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((x ◇ x) ◇ z)).

Definition Equation632 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ ((x ◇ y) ◇ x)).

Definition Equation633 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ ((x ◇ y) ◇ y)).

Definition Equation634 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((x ◇ y) ◇ z)).

Definition Equation635 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((x ◇ z) ◇ x)).

Definition Equation636 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((x ◇ z) ◇ y)).

Definition Equation637 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((x ◇ z) ◇ z)).

Definition Equation638 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ ((x ◇ z) ◇ w)).

Definition Equation639 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ ((y ◇ x) ◇ x)).

Definition Equation640 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ ((y ◇ x) ◇ y)).

Definition Equation641 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((y ◇ x) ◇ z)).

Definition Equation642 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ ((y ◇ y) ◇ x)).

Definition Equation643 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (y ◇ ((y ◇ y) ◇ y)).

Definition Equation644 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((y ◇ y) ◇ z)).

Definition Equation645 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((y ◇ z) ◇ x)).

Definition Equation646 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((y ◇ z) ◇ y)).

Definition Equation647 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((y ◇ z) ◇ z)).

Definition Equation648 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ ((y ◇ z) ◇ w)).

Definition Equation649 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((z ◇ x) ◇ x)).

Definition Equation650 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((z ◇ x) ◇ y)).

Definition Equation651 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((z ◇ x) ◇ z)).

Definition Equation652 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ ((z ◇ x) ◇ w)).

Definition Equation653 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((z ◇ y) ◇ x)).

Definition Equation654 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((z ◇ y) ◇ y)).

Definition Equation655 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((z ◇ y) ◇ z)).

Definition Equation656 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ ((z ◇ y) ◇ w)).

Definition Equation657 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((z ◇ z) ◇ x)).

Definition Equation658 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((z ◇ z) ◇ y)).

Definition Equation659 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (y ◇ ((z ◇ z) ◇ z)).

Definition Equation660 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ ((z ◇ z) ◇ w)).

Definition Equation661 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ ((z ◇ w) ◇ x)).

Definition Equation662 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ ((z ◇ w) ◇ y)).

Definition Equation663 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ ((z ◇ w) ◇ z)).

Definition Equation664 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (y ◇ ((z ◇ w) ◇ w)).

Definition Equation665 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = x ◇ (y ◇ ((z ◇ w) ◇ u)).

Definition Equation666 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ ((x ◇ x) ◇ x)).

Definition Equation667 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ ((x ◇ x) ◇ y)).

Definition Equation668 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((x ◇ x) ◇ z)).

Definition Equation669 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ ((x ◇ y) ◇ x)).

Definition Equation670 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ ((x ◇ y) ◇ y)).

Definition Equation671 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((x ◇ y) ◇ z)).

Definition Equation672 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((x ◇ z) ◇ x)).

Definition Equation673 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((x ◇ z) ◇ y)).

Definition Equation674 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((x ◇ z) ◇ z)).

Definition Equation675 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ ((x ◇ z) ◇ w)).

Definition Equation676 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ ((y ◇ x) ◇ x)).

Definition Equation677 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ ((y ◇ x) ◇ y)).

Definition Equation678 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((y ◇ x) ◇ z)).

Definition Equation679 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ ((y ◇ y) ◇ x)).

Definition Equation680 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (x ◇ ((y ◇ y) ◇ y)).

Definition Equation681 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((y ◇ y) ◇ z)).

Definition Equation682 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((y ◇ z) ◇ x)).

Definition Equation683 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((y ◇ z) ◇ y)).

Definition Equation684 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((y ◇ z) ◇ z)).

Definition Equation685 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ ((y ◇ z) ◇ w)).

Definition Equation686 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((z ◇ x) ◇ x)).

Definition Equation687 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((z ◇ x) ◇ y)).

Definition Equation688 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((z ◇ x) ◇ z)).

Definition Equation689 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ ((z ◇ x) ◇ w)).

Definition Equation690 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((z ◇ y) ◇ x)).

Definition Equation691 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((z ◇ y) ◇ y)).

Definition Equation692 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((z ◇ y) ◇ z)).

Definition Equation693 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ ((z ◇ y) ◇ w)).

Definition Equation694 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((z ◇ z) ◇ x)).

Definition Equation695 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((z ◇ z) ◇ y)).

Definition Equation696 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (x ◇ ((z ◇ z) ◇ z)).

Definition Equation697 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ ((z ◇ z) ◇ w)).

Definition Equation698 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ ((z ◇ w) ◇ x)).

Definition Equation699 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ ((z ◇ w) ◇ y)).

Definition Equation700 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ ((z ◇ w) ◇ z)).

Definition Equation701 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (x ◇ ((z ◇ w) ◇ w)).

Definition Equation702 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (x ◇ ((z ◇ w) ◇ u)).

Definition Equation703 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ ((x ◇ x) ◇ x)).

Definition Equation704 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ ((x ◇ x) ◇ y)).

Definition Equation705 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((x ◇ x) ◇ z)).

Definition Equation706 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ ((x ◇ y) ◇ x)).

Definition Equation707 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ ((x ◇ y) ◇ y)).

Definition Equation708 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((x ◇ y) ◇ z)).

Definition Equation709 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((x ◇ z) ◇ x)).

Definition Equation710 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((x ◇ z) ◇ y)).

Definition Equation711 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((x ◇ z) ◇ z)).

Definition Equation712 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ ((x ◇ z) ◇ w)).

Definition Equation713 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ ((y ◇ x) ◇ x)).

Definition Equation714 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ ((y ◇ x) ◇ y)).

Definition Equation715 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((y ◇ x) ◇ z)).

Definition Equation716 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ ((y ◇ y) ◇ x)).

Definition Equation717 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (y ◇ ((y ◇ y) ◇ y)).

Definition Equation718 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((y ◇ y) ◇ z)).

Definition Equation719 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((y ◇ z) ◇ x)).

Definition Equation720 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((y ◇ z) ◇ y)).

Definition Equation721 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((y ◇ z) ◇ z)).

Definition Equation722 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ ((y ◇ z) ◇ w)).

Definition Equation723 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((z ◇ x) ◇ x)).

Definition Equation724 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((z ◇ x) ◇ y)).

Definition Equation725 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((z ◇ x) ◇ z)).

Definition Equation726 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ ((z ◇ x) ◇ w)).

Definition Equation727 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((z ◇ y) ◇ x)).

Definition Equation728 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((z ◇ y) ◇ y)).

Definition Equation729 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((z ◇ y) ◇ z)).

Definition Equation730 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ ((z ◇ y) ◇ w)).

Definition Equation731 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((z ◇ z) ◇ x)).

Definition Equation732 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((z ◇ z) ◇ y)).

Definition Equation733 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ ((z ◇ z) ◇ z)).

Definition Equation734 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ ((z ◇ z) ◇ w)).

Definition Equation735 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ ((z ◇ w) ◇ x)).

Definition Equation736 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ ((z ◇ w) ◇ y)).

Definition Equation737 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ ((z ◇ w) ◇ z)).

Definition Equation738 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (y ◇ ((z ◇ w) ◇ w)).

Definition Equation739 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (y ◇ ((z ◇ w) ◇ u)).

Definition Equation740 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((x ◇ x) ◇ x)).

Definition Equation741 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((x ◇ x) ◇ y)).

Definition Equation742 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((x ◇ x) ◇ z)).

Definition Equation743 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((x ◇ x) ◇ w)).

Definition Equation744 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((x ◇ y) ◇ x)).

Definition Equation745 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((x ◇ y) ◇ y)).

Definition Equation746 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((x ◇ y) ◇ z)).

Definition Equation747 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((x ◇ y) ◇ w)).

Definition Equation748 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((x ◇ z) ◇ x)).

Definition Equation749 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((x ◇ z) ◇ y)).

Definition Equation750 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((x ◇ z) ◇ z)).

Definition Equation751 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((x ◇ z) ◇ w)).

Definition Equation752 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((x ◇ w) ◇ x)).

Definition Equation753 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((x ◇ w) ◇ y)).

Definition Equation754 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((x ◇ w) ◇ z)).

Definition Equation755 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((x ◇ w) ◇ w)).

Definition Equation756 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ ((x ◇ w) ◇ u)).

Definition Equation757 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((y ◇ x) ◇ x)).

Definition Equation758 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((y ◇ x) ◇ y)).

Definition Equation759 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((y ◇ x) ◇ z)).

Definition Equation760 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((y ◇ x) ◇ w)).

Definition Equation761 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((y ◇ y) ◇ x)).

Definition Equation762 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((y ◇ y) ◇ y)).

Definition Equation763 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((y ◇ y) ◇ z)).

Definition Equation764 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((y ◇ y) ◇ w)).

Definition Equation765 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((y ◇ z) ◇ x)).

Definition Equation766 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((y ◇ z) ◇ y)).

Definition Equation767 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((y ◇ z) ◇ z)).

Definition Equation768 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((y ◇ z) ◇ w)).

Definition Equation769 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((y ◇ w) ◇ x)).

Definition Equation770 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((y ◇ w) ◇ y)).

Definition Equation771 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((y ◇ w) ◇ z)).

Definition Equation772 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((y ◇ w) ◇ w)).

Definition Equation773 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ ((y ◇ w) ◇ u)).

Definition Equation774 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((z ◇ x) ◇ x)).

Definition Equation775 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((z ◇ x) ◇ y)).

Definition Equation776 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((z ◇ x) ◇ z)).

Definition Equation777 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((z ◇ x) ◇ w)).

Definition Equation778 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((z ◇ y) ◇ x)).

Definition Equation779 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((z ◇ y) ◇ y)).

Definition Equation780 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((z ◇ y) ◇ z)).

Definition Equation781 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((z ◇ y) ◇ w)).

Definition Equation782 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((z ◇ z) ◇ x)).

Definition Equation783 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((z ◇ z) ◇ y)).

Definition Equation784 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (z ◇ ((z ◇ z) ◇ z)).

Definition Equation785 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((z ◇ z) ◇ w)).

Definition Equation786 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((z ◇ w) ◇ x)).

Definition Equation787 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((z ◇ w) ◇ y)).

Definition Equation788 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((z ◇ w) ◇ z)).

Definition Equation789 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((z ◇ w) ◇ w)).

Definition Equation790 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ ((z ◇ w) ◇ u)).

Definition Equation791 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ x) ◇ x)).

Definition Equation792 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ x) ◇ y)).

Definition Equation793 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ x) ◇ z)).

Definition Equation794 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ x) ◇ w)).

Definition Equation795 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ ((w ◇ x) ◇ u)).

Definition Equation796 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ y) ◇ x)).

Definition Equation797 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ y) ◇ y)).

Definition Equation798 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ y) ◇ z)).

Definition Equation799 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ y) ◇ w)).

Definition Equation800 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ ((w ◇ y) ◇ u)).

Definition Equation801 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ z) ◇ x)).

Definition Equation802 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ z) ◇ y)).

Definition Equation803 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ z) ◇ z)).

Definition Equation804 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ z) ◇ w)).

Definition Equation805 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ ((w ◇ z) ◇ u)).

Definition Equation806 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ w) ◇ x)).

Definition Equation807 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ w) ◇ y)).

Definition Equation808 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ w) ◇ z)).

Definition Equation809 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (z ◇ ((w ◇ w) ◇ w)).

Definition Equation810 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ ((w ◇ w) ◇ u)).

Definition Equation811 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ ((w ◇ u) ◇ x)).

Definition Equation812 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ ((w ◇ u) ◇ y)).

Definition Equation813 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ ((w ◇ u) ◇ z)).

Definition Equation814 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ ((w ◇ u) ◇ w)).

Definition Equation815 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (z ◇ ((w ◇ u) ◇ u)).

Definition Equation816 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = y ◇ (z ◇ ((w ◇ u) ◇ v)).

Definition Equation817 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = x ◇ ((x ◇ x) ◇ (x ◇ x)).

Definition Equation818 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ x) ◇ (x ◇ y)).

Definition Equation819 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ x) ◇ (y ◇ x)).

Definition Equation820 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ x) ◇ (y ◇ y)).

Definition Equation821 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((x ◇ x) ◇ (y ◇ z)).

Definition Equation822 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ y) ◇ (x ◇ x)).

Definition Equation823 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ y) ◇ (x ◇ y)).

Definition Equation824 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((x ◇ y) ◇ (x ◇ z)).

Definition Equation825 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ y) ◇ (y ◇ x)).

Definition Equation826 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ y) ◇ (y ◇ y)).

Definition Equation827 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((x ◇ y) ◇ (y ◇ z)).

Definition Equation828 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((x ◇ y) ◇ (z ◇ x)).

Definition Equation829 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((x ◇ y) ◇ (z ◇ y)).

Definition Equation830 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((x ◇ y) ◇ (z ◇ z)).

Definition Equation831 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((x ◇ y) ◇ (z ◇ w)).

Definition Equation832 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ x) ◇ (x ◇ x)).

Definition Equation833 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ x) ◇ (x ◇ y)).

Definition Equation834 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ x) ◇ (x ◇ z)).

Definition Equation835 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ x) ◇ (y ◇ x)).

Definition Equation836 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ x) ◇ (y ◇ y)).

Definition Equation837 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ x) ◇ (y ◇ z)).

Definition Equation838 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ x) ◇ (z ◇ x)).

Definition Equation839 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ x) ◇ (z ◇ y)).

Definition Equation840 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ x) ◇ (z ◇ z)).

Definition Equation841 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ x) ◇ (z ◇ w)).

Definition Equation842 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ y) ◇ (x ◇ x)).

Definition Equation843 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ y) ◇ (x ◇ y)).

Definition Equation844 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ y) ◇ (x ◇ z)).

Definition Equation845 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ y) ◇ (y ◇ x)).

Definition Equation846 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ y) ◇ (y ◇ y)).

Definition Equation847 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ y) ◇ (y ◇ z)).

Definition Equation848 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ y) ◇ (z ◇ x)).

Definition Equation849 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ y) ◇ (z ◇ y)).

Definition Equation850 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ y) ◇ (z ◇ z)).

Definition Equation851 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ y) ◇ (z ◇ w)).

Definition Equation852 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ z) ◇ (x ◇ x)).

Definition Equation853 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ z) ◇ (x ◇ y)).

Definition Equation854 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ z) ◇ (x ◇ z)).

Definition Equation855 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ z) ◇ (x ◇ w)).

Definition Equation856 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ z) ◇ (y ◇ x)).

Definition Equation857 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ z) ◇ (y ◇ y)).

Definition Equation858 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ z) ◇ (y ◇ z)).

Definition Equation859 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ z) ◇ (y ◇ w)).

Definition Equation860 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ z) ◇ (z ◇ x)).

Definition Equation861 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ z) ◇ (z ◇ y)).

Definition Equation862 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ z) ◇ (z ◇ z)).

Definition Equation863 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ z) ◇ (z ◇ w)).

Definition Equation864 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ z) ◇ (w ◇ x)).

Definition Equation865 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ z) ◇ (w ◇ y)).

Definition Equation866 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ z) ◇ (w ◇ z)).

Definition Equation867 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ z) ◇ (w ◇ w)).

Definition Equation868 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = x ◇ ((y ◇ z) ◇ (w ◇ u)).

Definition Equation869 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ x) ◇ (x ◇ x)).

Definition Equation870 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ x) ◇ (x ◇ y)).

Definition Equation871 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ x) ◇ (x ◇ z)).

Definition Equation872 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ x) ◇ (y ◇ x)).

Definition Equation873 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ x) ◇ (y ◇ y)).

Definition Equation874 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ x) ◇ (y ◇ z)).

Definition Equation875 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ x) ◇ (z ◇ x)).

Definition Equation876 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ x) ◇ (z ◇ y)).

Definition Equation877 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ x) ◇ (z ◇ z)).

Definition Equation878 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ x) ◇ (z ◇ w)).

Definition Equation879 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ y) ◇ (x ◇ x)).

Definition Equation880 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ y) ◇ (x ◇ y)).

Definition Equation881 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ y) ◇ (x ◇ z)).

Definition Equation882 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ y) ◇ (y ◇ x)).

Definition Equation883 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ y) ◇ (y ◇ y)).

Definition Equation884 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ y) ◇ (y ◇ z)).

Definition Equation885 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ y) ◇ (z ◇ x)).

Definition Equation886 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ y) ◇ (z ◇ y)).

Definition Equation887 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ y) ◇ (z ◇ z)).

Definition Equation888 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ y) ◇ (z ◇ w)).

Definition Equation889 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ z) ◇ (x ◇ x)).

Definition Equation890 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ z) ◇ (x ◇ y)).

Definition Equation891 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ z) ◇ (x ◇ z)).

Definition Equation892 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ z) ◇ (x ◇ w)).

Definition Equation893 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ z) ◇ (y ◇ x)).

Definition Equation894 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ z) ◇ (y ◇ y)).

Definition Equation895 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ z) ◇ (y ◇ z)).

Definition Equation896 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ z) ◇ (y ◇ w)).

Definition Equation897 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ z) ◇ (z ◇ x)).

Definition Equation898 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ z) ◇ (z ◇ y)).

Definition Equation899 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ z) ◇ (z ◇ z)).

Definition Equation900 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ z) ◇ (z ◇ w)).

Definition Equation901 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ z) ◇ (w ◇ x)).

Definition Equation902 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ z) ◇ (w ◇ y)).

Definition Equation903 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ z) ◇ (w ◇ z)).

Definition Equation904 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ z) ◇ (w ◇ w)).

Definition Equation905 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((x ◇ z) ◇ (w ◇ u)).

Definition Equation906 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ x) ◇ (x ◇ x)).

Definition Equation907 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ x) ◇ (x ◇ y)).

Definition Equation908 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ x) ◇ (x ◇ z)).

Definition Equation909 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ x) ◇ (y ◇ x)).

Definition Equation910 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ x) ◇ (y ◇ y)).

Definition Equation911 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ x) ◇ (y ◇ z)).

Definition Equation912 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ x) ◇ (z ◇ x)).

Definition Equation913 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ x) ◇ (z ◇ y)).

Definition Equation914 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ x) ◇ (z ◇ z)).

Definition Equation915 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ x) ◇ (z ◇ w)).

Definition Equation916 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ y) ◇ (x ◇ x)).

Definition Equation917 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ y) ◇ (x ◇ y)).

Definition Equation918 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ y) ◇ (x ◇ z)).

Definition Equation919 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ y) ◇ (y ◇ x)).

Definition Equation920 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ y) ◇ (y ◇ y)).

Definition Equation921 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ y) ◇ (y ◇ z)).

Definition Equation922 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ y) ◇ (z ◇ x)).

Definition Equation923 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ y) ◇ (z ◇ y)).

Definition Equation924 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ y) ◇ (z ◇ z)).

Definition Equation925 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ y) ◇ (z ◇ w)).

Definition Equation926 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ z) ◇ (x ◇ x)).

Definition Equation927 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ z) ◇ (x ◇ y)).

Definition Equation928 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ z) ◇ (x ◇ z)).

Definition Equation929 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ z) ◇ (x ◇ w)).

Definition Equation930 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ z) ◇ (y ◇ x)).

Definition Equation931 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ z) ◇ (y ◇ y)).

Definition Equation932 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ z) ◇ (y ◇ z)).

Definition Equation933 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ z) ◇ (y ◇ w)).

Definition Equation934 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ z) ◇ (z ◇ x)).

Definition Equation935 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ z) ◇ (z ◇ y)).

Definition Equation936 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ z) ◇ (z ◇ z)).

Definition Equation937 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ z) ◇ (z ◇ w)).

Definition Equation938 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ z) ◇ (w ◇ x)).

Definition Equation939 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ z) ◇ (w ◇ y)).

Definition Equation940 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ z) ◇ (w ◇ z)).

Definition Equation941 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ z) ◇ (w ◇ w)).

Definition Equation942 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((y ◇ z) ◇ (w ◇ u)).

Definition Equation943 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ x) ◇ (x ◇ x)).

Definition Equation944 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ x) ◇ (x ◇ y)).

Definition Equation945 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ x) ◇ (x ◇ z)).

Definition Equation946 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ x) ◇ (x ◇ w)).

Definition Equation947 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ x) ◇ (y ◇ x)).

Definition Equation948 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ x) ◇ (y ◇ y)).

Definition Equation949 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ x) ◇ (y ◇ z)).

Definition Equation950 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ x) ◇ (y ◇ w)).

Definition Equation951 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ x) ◇ (z ◇ x)).

Definition Equation952 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ x) ◇ (z ◇ y)).

Definition Equation953 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ x) ◇ (z ◇ z)).

Definition Equation954 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ x) ◇ (z ◇ w)).

Definition Equation955 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ x) ◇ (w ◇ x)).

Definition Equation956 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ x) ◇ (w ◇ y)).

Definition Equation957 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ x) ◇ (w ◇ z)).

Definition Equation958 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ x) ◇ (w ◇ w)).

Definition Equation959 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ x) ◇ (w ◇ u)).

Definition Equation960 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ y) ◇ (x ◇ x)).

Definition Equation961 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ y) ◇ (x ◇ y)).

Definition Equation962 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ y) ◇ (x ◇ z)).

Definition Equation963 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ y) ◇ (x ◇ w)).

Definition Equation964 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ y) ◇ (y ◇ x)).

Definition Equation965 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ y) ◇ (y ◇ y)).

Definition Equation966 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ y) ◇ (y ◇ z)).

Definition Equation967 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ y) ◇ (y ◇ w)).

Definition Equation968 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ y) ◇ (z ◇ x)).

Definition Equation969 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ y) ◇ (z ◇ y)).

Definition Equation970 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ y) ◇ (z ◇ z)).

Definition Equation971 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ y) ◇ (z ◇ w)).

Definition Equation972 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ y) ◇ (w ◇ x)).

Definition Equation973 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ y) ◇ (w ◇ y)).

Definition Equation974 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ y) ◇ (w ◇ z)).

Definition Equation975 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ y) ◇ (w ◇ w)).

Definition Equation976 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ y) ◇ (w ◇ u)).

Definition Equation977 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ z) ◇ (x ◇ x)).

Definition Equation978 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ z) ◇ (x ◇ y)).

Definition Equation979 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ z) ◇ (x ◇ z)).

Definition Equation980 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ z) ◇ (x ◇ w)).

Definition Equation981 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ z) ◇ (y ◇ x)).

Definition Equation982 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ z) ◇ (y ◇ y)).

Definition Equation983 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ z) ◇ (y ◇ z)).

Definition Equation984 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ z) ◇ (y ◇ w)).

Definition Equation985 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ z) ◇ (z ◇ x)).

Definition Equation986 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ z) ◇ (z ◇ y)).

Definition Equation987 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ z) ◇ (z ◇ z)).

Definition Equation988 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ z) ◇ (z ◇ w)).

Definition Equation989 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ z) ◇ (w ◇ x)).

Definition Equation990 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ z) ◇ (w ◇ y)).

Definition Equation991 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ z) ◇ (w ◇ z)).

Definition Equation992 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ z) ◇ (w ◇ w)).

Definition Equation993 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ z) ◇ (w ◇ u)).

Definition Equation994 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (x ◇ x)).

Definition Equation995 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (x ◇ y)).

Definition Equation996 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (x ◇ z)).

Definition Equation997 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (x ◇ w)).

Definition Equation998 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ w) ◇ (x ◇ u)).

Definition Equation999 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (y ◇ x)).

