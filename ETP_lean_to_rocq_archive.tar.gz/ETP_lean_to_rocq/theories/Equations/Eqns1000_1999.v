(** * Equations 1000–1999

    Auto-generated from the Lean4 Equational Theories Project. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.

Open Scope magma_scope.

Definition Equation1000 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (y ◇ y)).

Definition Equation1001 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (y ◇ z)).

Definition Equation1002 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (y ◇ w)).

Definition Equation1003 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ w) ◇ (y ◇ u)).

Definition Equation1004 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (z ◇ x)).

Definition Equation1005 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (z ◇ y)).

Definition Equation1006 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (z ◇ z)).

Definition Equation1007 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (z ◇ w)).

Definition Equation1008 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ w) ◇ (z ◇ u)).

Definition Equation1009 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (w ◇ x)).

Definition Equation1010 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (w ◇ y)).

Definition Equation1011 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (w ◇ z)).

Definition Equation1012 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ w) ◇ (w ◇ w)).

Definition Equation1013 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ w) ◇ (w ◇ u)).

Definition Equation1014 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ w) ◇ (u ◇ x)).

Definition Equation1015 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ w) ◇ (u ◇ y)).

Definition Equation1016 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ w) ◇ (u ◇ z)).

Definition Equation1017 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ w) ◇ (u ◇ w)).

Definition Equation1018 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ w) ◇ (u ◇ u)).

Definition Equation1019 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = y ◇ ((z ◇ w) ◇ (u ◇ v)).

Definition Equation1020 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = x ◇ ((x ◇ (x ◇ x)) ◇ x).

Definition Equation1021 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ (x ◇ x)) ◇ y).

Definition Equation1022 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ (x ◇ y)) ◇ x).

Definition Equation1023 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ (x ◇ y)) ◇ y).

Definition Equation1024 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((x ◇ (x ◇ y)) ◇ z).

Definition Equation1025 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ (y ◇ x)) ◇ x).

Definition Equation1026 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ (y ◇ x)) ◇ y).

Definition Equation1027 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((x ◇ (y ◇ x)) ◇ z).

Definition Equation1028 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ (y ◇ y)) ◇ x).

Definition Equation1029 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((x ◇ (y ◇ y)) ◇ y).

Definition Equation1030 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((x ◇ (y ◇ y)) ◇ z).

Definition Equation1031 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((x ◇ (y ◇ z)) ◇ x).

Definition Equation1032 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((x ◇ (y ◇ z)) ◇ y).

Definition Equation1033 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((x ◇ (y ◇ z)) ◇ z).

Definition Equation1034 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((x ◇ (y ◇ z)) ◇ w).

Definition Equation1035 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ (x ◇ x)) ◇ x).

Definition Equation1036 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ (x ◇ x)) ◇ y).

Definition Equation1037 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (x ◇ x)) ◇ z).

Definition Equation1038 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ (x ◇ y)) ◇ x).

Definition Equation1039 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ (x ◇ y)) ◇ y).

Definition Equation1040 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (x ◇ y)) ◇ z).

Definition Equation1041 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (x ◇ z)) ◇ x).

Definition Equation1042 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (x ◇ z)) ◇ y).

Definition Equation1043 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (x ◇ z)) ◇ z).

Definition Equation1044 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ (x ◇ z)) ◇ w).

Definition Equation1045 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ (y ◇ x)) ◇ x).

Definition Equation1046 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ (y ◇ x)) ◇ y).

Definition Equation1047 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (y ◇ x)) ◇ z).

Definition Equation1048 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ (y ◇ y)) ◇ x).

Definition Equation1049 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ ((y ◇ (y ◇ y)) ◇ y).

Definition Equation1050 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (y ◇ y)) ◇ z).

Definition Equation1051 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (y ◇ z)) ◇ x).

Definition Equation1052 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (y ◇ z)) ◇ y).

Definition Equation1053 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (y ◇ z)) ◇ z).

Definition Equation1054 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ (y ◇ z)) ◇ w).

Definition Equation1055 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (z ◇ x)) ◇ x).

Definition Equation1056 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (z ◇ x)) ◇ y).

Definition Equation1057 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (z ◇ x)) ◇ z).

Definition Equation1058 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ (z ◇ x)) ◇ w).

Definition Equation1059 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (z ◇ y)) ◇ x).

Definition Equation1060 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (z ◇ y)) ◇ y).

Definition Equation1061 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (z ◇ y)) ◇ z).

Definition Equation1062 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ (z ◇ y)) ◇ w).

Definition Equation1063 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (z ◇ z)) ◇ x).

Definition Equation1064 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (z ◇ z)) ◇ y).

Definition Equation1065 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ ((y ◇ (z ◇ z)) ◇ z).

Definition Equation1066 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ (z ◇ z)) ◇ w).

Definition Equation1067 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ (z ◇ w)) ◇ x).

Definition Equation1068 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ (z ◇ w)) ◇ y).

Definition Equation1069 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ (z ◇ w)) ◇ z).

Definition Equation1070 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ ((y ◇ (z ◇ w)) ◇ w).

Definition Equation1071 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = x ◇ ((y ◇ (z ◇ w)) ◇ u).

Definition Equation1072 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ (x ◇ x)) ◇ x).

Definition Equation1073 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ (x ◇ x)) ◇ y).

Definition Equation1074 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (x ◇ x)) ◇ z).

Definition Equation1075 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ (x ◇ y)) ◇ x).

Definition Equation1076 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ (x ◇ y)) ◇ y).

Definition Equation1077 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (x ◇ y)) ◇ z).

Definition Equation1078 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (x ◇ z)) ◇ x).

Definition Equation1079 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (x ◇ z)) ◇ y).

Definition Equation1080 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (x ◇ z)) ◇ z).

Definition Equation1081 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ (x ◇ z)) ◇ w).

Definition Equation1082 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ (y ◇ x)) ◇ x).

Definition Equation1083 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ (y ◇ x)) ◇ y).

Definition Equation1084 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (y ◇ x)) ◇ z).

Definition Equation1085 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ (y ◇ y)) ◇ x).

Definition Equation1086 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((x ◇ (y ◇ y)) ◇ y).

Definition Equation1087 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (y ◇ y)) ◇ z).

Definition Equation1088 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (y ◇ z)) ◇ x).

Definition Equation1089 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (y ◇ z)) ◇ y).

Definition Equation1090 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (y ◇ z)) ◇ z).

Definition Equation1091 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ (y ◇ z)) ◇ w).

Definition Equation1092 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (z ◇ x)) ◇ x).

Definition Equation1093 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (z ◇ x)) ◇ y).

Definition Equation1094 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (z ◇ x)) ◇ z).

Definition Equation1095 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ (z ◇ x)) ◇ w).

Definition Equation1096 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (z ◇ y)) ◇ x).

Definition Equation1097 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (z ◇ y)) ◇ y).

Definition Equation1098 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (z ◇ y)) ◇ z).

Definition Equation1099 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ (z ◇ y)) ◇ w).

Definition Equation1100 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (z ◇ z)) ◇ x).

Definition Equation1101 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (z ◇ z)) ◇ y).

Definition Equation1102 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((x ◇ (z ◇ z)) ◇ z).

Definition Equation1103 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ (z ◇ z)) ◇ w).

Definition Equation1104 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ (z ◇ w)) ◇ x).

Definition Equation1105 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ (z ◇ w)) ◇ y).

Definition Equation1106 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ (z ◇ w)) ◇ z).

Definition Equation1107 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((x ◇ (z ◇ w)) ◇ w).

Definition Equation1108 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((x ◇ (z ◇ w)) ◇ u).

Definition Equation1109 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ (x ◇ x)) ◇ x).

Definition Equation1110 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ (x ◇ x)) ◇ y).

Definition Equation1111 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (x ◇ x)) ◇ z).

Definition Equation1112 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ (x ◇ y)) ◇ x).

Definition Equation1113 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ (x ◇ y)) ◇ y).

Definition Equation1114 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (x ◇ y)) ◇ z).

Definition Equation1115 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (x ◇ z)) ◇ x).

Definition Equation1116 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (x ◇ z)) ◇ y).

Definition Equation1117 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (x ◇ z)) ◇ z).

Definition Equation1118 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ (x ◇ z)) ◇ w).

Definition Equation1119 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ (y ◇ x)) ◇ x).

Definition Equation1120 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ (y ◇ x)) ◇ y).

Definition Equation1121 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (y ◇ x)) ◇ z).

Definition Equation1122 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ (y ◇ y)) ◇ x).

Definition Equation1123 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ ((y ◇ (y ◇ y)) ◇ y).

Definition Equation1124 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (y ◇ y)) ◇ z).

Definition Equation1125 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (y ◇ z)) ◇ x).

Definition Equation1126 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (y ◇ z)) ◇ y).

Definition Equation1127 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (y ◇ z)) ◇ z).

Definition Equation1128 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ (y ◇ z)) ◇ w).

Definition Equation1129 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (z ◇ x)) ◇ x).

Definition Equation1130 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (z ◇ x)) ◇ y).

Definition Equation1131 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (z ◇ x)) ◇ z).

Definition Equation1132 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ (z ◇ x)) ◇ w).

Definition Equation1133 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (z ◇ y)) ◇ x).

Definition Equation1134 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (z ◇ y)) ◇ y).

Definition Equation1135 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (z ◇ y)) ◇ z).

Definition Equation1136 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ (z ◇ y)) ◇ w).

Definition Equation1137 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (z ◇ z)) ◇ x).

Definition Equation1138 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (z ◇ z)) ◇ y).

Definition Equation1139 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((y ◇ (z ◇ z)) ◇ z).

Definition Equation1140 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ (z ◇ z)) ◇ w).

Definition Equation1141 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ (z ◇ w)) ◇ x).

Definition Equation1142 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ (z ◇ w)) ◇ y).

Definition Equation1143 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ (z ◇ w)) ◇ z).

Definition Equation1144 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((y ◇ (z ◇ w)) ◇ w).

Definition Equation1145 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((y ◇ (z ◇ w)) ◇ u).

Definition Equation1146 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (x ◇ x)) ◇ x).

Definition Equation1147 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (x ◇ x)) ◇ y).

Definition Equation1148 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (x ◇ x)) ◇ z).

Definition Equation1149 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (x ◇ x)) ◇ w).

Definition Equation1150 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (x ◇ y)) ◇ x).

Definition Equation1151 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (x ◇ y)) ◇ y).

Definition Equation1152 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (x ◇ y)) ◇ z).

Definition Equation1153 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (x ◇ y)) ◇ w).

Definition Equation1154 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (x ◇ z)) ◇ x).

Definition Equation1155 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (x ◇ z)) ◇ y).

Definition Equation1156 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (x ◇ z)) ◇ z).

Definition Equation1157 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (x ◇ z)) ◇ w).

Definition Equation1158 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (x ◇ w)) ◇ x).

Definition Equation1159 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (x ◇ w)) ◇ y).

Definition Equation1160 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (x ◇ w)) ◇ z).

Definition Equation1161 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (x ◇ w)) ◇ w).

Definition Equation1162 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ (x ◇ w)) ◇ u).

Definition Equation1163 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (y ◇ x)) ◇ x).

Definition Equation1164 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (y ◇ x)) ◇ y).

Definition Equation1165 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (y ◇ x)) ◇ z).

Definition Equation1166 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (y ◇ x)) ◇ w).

Definition Equation1167 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (y ◇ y)) ◇ x).

Definition Equation1168 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (y ◇ y)) ◇ y).

Definition Equation1169 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (y ◇ y)) ◇ z).

Definition Equation1170 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (y ◇ y)) ◇ w).

Definition Equation1171 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (y ◇ z)) ◇ x).

Definition Equation1172 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (y ◇ z)) ◇ y).

Definition Equation1173 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (y ◇ z)) ◇ z).

Definition Equation1174 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (y ◇ z)) ◇ w).

Definition Equation1175 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (y ◇ w)) ◇ x).

Definition Equation1176 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (y ◇ w)) ◇ y).

Definition Equation1177 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (y ◇ w)) ◇ z).

Definition Equation1178 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (y ◇ w)) ◇ w).

Definition Equation1179 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ (y ◇ w)) ◇ u).

Definition Equation1180 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (z ◇ x)) ◇ x).

Definition Equation1181 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (z ◇ x)) ◇ y).

Definition Equation1182 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (z ◇ x)) ◇ z).

Definition Equation1183 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (z ◇ x)) ◇ w).

Definition Equation1184 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (z ◇ y)) ◇ x).

Definition Equation1185 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (z ◇ y)) ◇ y).

Definition Equation1186 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (z ◇ y)) ◇ z).

Definition Equation1187 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (z ◇ y)) ◇ w).

Definition Equation1188 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (z ◇ z)) ◇ x).

Definition Equation1189 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (z ◇ z)) ◇ y).

Definition Equation1190 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ ((z ◇ (z ◇ z)) ◇ z).

Definition Equation1191 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (z ◇ z)) ◇ w).

Definition Equation1192 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (z ◇ w)) ◇ x).

Definition Equation1193 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (z ◇ w)) ◇ y).

Definition Equation1194 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (z ◇ w)) ◇ z).

Definition Equation1195 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (z ◇ w)) ◇ w).

Definition Equation1196 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ (z ◇ w)) ◇ u).

Definition Equation1197 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ x)) ◇ x).

Definition Equation1198 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ x)) ◇ y).

Definition Equation1199 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ x)) ◇ z).

Definition Equation1200 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ x)) ◇ w).

Definition Equation1201 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ (w ◇ x)) ◇ u).

Definition Equation1202 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ y)) ◇ x).

Definition Equation1203 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ y)) ◇ y).

Definition Equation1204 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ y)) ◇ z).

Definition Equation1205 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ y)) ◇ w).

Definition Equation1206 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ (w ◇ y)) ◇ u).

Definition Equation1207 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ z)) ◇ x).

Definition Equation1208 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ z)) ◇ y).

Definition Equation1209 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ z)) ◇ z).

Definition Equation1210 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ z)) ◇ w).

Definition Equation1211 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ (w ◇ z)) ◇ u).

Definition Equation1212 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ w)) ◇ x).

Definition Equation1213 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ w)) ◇ y).

Definition Equation1214 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ w)) ◇ z).

Definition Equation1215 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ ((z ◇ (w ◇ w)) ◇ w).

Definition Equation1216 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ (w ◇ w)) ◇ u).

Definition Equation1217 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ (w ◇ u)) ◇ x).

Definition Equation1218 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ (w ◇ u)) ◇ y).

Definition Equation1219 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ (w ◇ u)) ◇ z).

Definition Equation1220 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ (w ◇ u)) ◇ w).

Definition Equation1221 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ ((z ◇ (w ◇ u)) ◇ u).

Definition Equation1222 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = y ◇ ((z ◇ (w ◇ u)) ◇ v).

Definition Equation1223 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = x ◇ (((x ◇ x) ◇ x) ◇ x).

Definition Equation1224 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((x ◇ x) ◇ x) ◇ y).

Definition Equation1225 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((x ◇ x) ◇ y) ◇ x).

Definition Equation1226 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((x ◇ x) ◇ y) ◇ y).

Definition Equation1227 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((x ◇ x) ◇ y) ◇ z).

Definition Equation1228 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((x ◇ y) ◇ x) ◇ x).

Definition Equation1229 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((x ◇ y) ◇ x) ◇ y).

Definition Equation1230 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((x ◇ y) ◇ x) ◇ z).

Definition Equation1231 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((x ◇ y) ◇ y) ◇ x).

Definition Equation1232 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((x ◇ y) ◇ y) ◇ y).

Definition Equation1233 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((x ◇ y) ◇ y) ◇ z).

Definition Equation1234 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((x ◇ y) ◇ z) ◇ x).

Definition Equation1235 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((x ◇ y) ◇ z) ◇ y).

Definition Equation1236 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((x ◇ y) ◇ z) ◇ z).

Definition Equation1237 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (((x ◇ y) ◇ z) ◇ w).

Definition Equation1238 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((y ◇ x) ◇ x) ◇ x).

Definition Equation1239 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((y ◇ x) ◇ x) ◇ y).

Definition Equation1240 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ x) ◇ x) ◇ z).

Definition Equation1241 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((y ◇ x) ◇ y) ◇ x).

Definition Equation1242 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((y ◇ x) ◇ y) ◇ y).

Definition Equation1243 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ x) ◇ y) ◇ z).

Definition Equation1244 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ x) ◇ z) ◇ x).

Definition Equation1245 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ x) ◇ z) ◇ y).

Definition Equation1246 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ x) ◇ z) ◇ z).

Definition Equation1247 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (((y ◇ x) ◇ z) ◇ w).

Definition Equation1248 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((y ◇ y) ◇ x) ◇ x).

Definition Equation1249 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((y ◇ y) ◇ x) ◇ y).

Definition Equation1250 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ y) ◇ x) ◇ z).

Definition Equation1251 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((y ◇ y) ◇ y) ◇ x).

Definition Equation1252 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = x ◇ (((y ◇ y) ◇ y) ◇ y).

Definition Equation1253 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ y) ◇ y) ◇ z).

Definition Equation1254 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ y) ◇ z) ◇ x).

Definition Equation1255 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ y) ◇ z) ◇ y).

Definition Equation1256 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ y) ◇ z) ◇ z).

Definition Equation1257 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (((y ◇ y) ◇ z) ◇ w).

Definition Equation1258 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ z) ◇ x) ◇ x).

Definition Equation1259 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ z) ◇ x) ◇ y).

Definition Equation1260 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ z) ◇ x) ◇ z).

Definition Equation1261 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (((y ◇ z) ◇ x) ◇ w).

Definition Equation1262 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ z) ◇ y) ◇ x).

Definition Equation1263 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ z) ◇ y) ◇ y).

Definition Equation1264 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ z) ◇ y) ◇ z).

Definition Equation1265 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (((y ◇ z) ◇ y) ◇ w).

Definition Equation1266 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ z) ◇ z) ◇ x).

Definition Equation1267 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ z) ◇ z) ◇ y).

Definition Equation1268 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = x ◇ (((y ◇ z) ◇ z) ◇ z).

Definition Equation1269 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (((y ◇ z) ◇ z) ◇ w).

Definition Equation1270 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (((y ◇ z) ◇ w) ◇ x).

Definition Equation1271 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (((y ◇ z) ◇ w) ◇ y).

Definition Equation1272 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (((y ◇ z) ◇ w) ◇ z).

Definition Equation1273 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = x ◇ (((y ◇ z) ◇ w) ◇ w).

Definition Equation1274 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = x ◇ (((y ◇ z) ◇ w) ◇ u).

Definition Equation1275 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((x ◇ x) ◇ x) ◇ x).

Definition Equation1276 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((x ◇ x) ◇ x) ◇ y).

Definition Equation1277 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ x) ◇ x) ◇ z).

Definition Equation1278 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((x ◇ x) ◇ y) ◇ x).

Definition Equation1279 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((x ◇ x) ◇ y) ◇ y).

Definition Equation1280 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ x) ◇ y) ◇ z).

Definition Equation1281 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ x) ◇ z) ◇ x).

Definition Equation1282 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ x) ◇ z) ◇ y).

Definition Equation1283 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ x) ◇ z) ◇ z).

Definition Equation1284 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((x ◇ x) ◇ z) ◇ w).

Definition Equation1285 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((x ◇ y) ◇ x) ◇ x).

Definition Equation1286 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((x ◇ y) ◇ x) ◇ y).

Definition Equation1287 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ y) ◇ x) ◇ z).

Definition Equation1288 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((x ◇ y) ◇ y) ◇ x).

Definition Equation1289 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((x ◇ y) ◇ y) ◇ y).

Definition Equation1290 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ y) ◇ y) ◇ z).

Definition Equation1291 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ y) ◇ z) ◇ x).

Definition Equation1292 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ y) ◇ z) ◇ y).

Definition Equation1293 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ y) ◇ z) ◇ z).

Definition Equation1294 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((x ◇ y) ◇ z) ◇ w).

Definition Equation1295 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ z) ◇ x) ◇ x).

Definition Equation1296 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ z) ◇ x) ◇ y).

Definition Equation1297 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ z) ◇ x) ◇ z).

Definition Equation1298 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((x ◇ z) ◇ x) ◇ w).

Definition Equation1299 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ z) ◇ y) ◇ x).

Definition Equation1300 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ z) ◇ y) ◇ y).

Definition Equation1301 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ z) ◇ y) ◇ z).

Definition Equation1302 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((x ◇ z) ◇ y) ◇ w).

Definition Equation1303 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ z) ◇ z) ◇ x).

Definition Equation1304 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ z) ◇ z) ◇ y).

Definition Equation1305 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((x ◇ z) ◇ z) ◇ z).

Definition Equation1306 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((x ◇ z) ◇ z) ◇ w).

Definition Equation1307 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((x ◇ z) ◇ w) ◇ x).

Definition Equation1308 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((x ◇ z) ◇ w) ◇ y).

Definition Equation1309 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((x ◇ z) ◇ w) ◇ z).

Definition Equation1310 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((x ◇ z) ◇ w) ◇ w).

Definition Equation1311 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((x ◇ z) ◇ w) ◇ u).

Definition Equation1312 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((y ◇ x) ◇ x) ◇ x).

Definition Equation1313 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((y ◇ x) ◇ x) ◇ y).

Definition Equation1314 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ x) ◇ x) ◇ z).

Definition Equation1315 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((y ◇ x) ◇ y) ◇ x).

Definition Equation1316 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((y ◇ x) ◇ y) ◇ y).

Definition Equation1317 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ x) ◇ y) ◇ z).

Definition Equation1318 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ x) ◇ z) ◇ x).

Definition Equation1319 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ x) ◇ z) ◇ y).

Definition Equation1320 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ x) ◇ z) ◇ z).

Definition Equation1321 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((y ◇ x) ◇ z) ◇ w).

Definition Equation1322 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((y ◇ y) ◇ x) ◇ x).

Definition Equation1323 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((y ◇ y) ◇ x) ◇ y).

Definition Equation1324 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ y) ◇ x) ◇ z).

Definition Equation1325 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((y ◇ y) ◇ y) ◇ x).

Definition Equation1326 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = y ◇ (((y ◇ y) ◇ y) ◇ y).

Definition Equation1327 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ y) ◇ y) ◇ z).

Definition Equation1328 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ y) ◇ z) ◇ x).

Definition Equation1329 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ y) ◇ z) ◇ y).

Definition Equation1330 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ y) ◇ z) ◇ z).

Definition Equation1331 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((y ◇ y) ◇ z) ◇ w).

Definition Equation1332 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ z) ◇ x) ◇ x).

Definition Equation1333 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ z) ◇ x) ◇ y).

Definition Equation1334 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ z) ◇ x) ◇ z).

Definition Equation1335 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((y ◇ z) ◇ x) ◇ w).

Definition Equation1336 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ z) ◇ y) ◇ x).

Definition Equation1337 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ z) ◇ y) ◇ y).

Definition Equation1338 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ z) ◇ y) ◇ z).

Definition Equation1339 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((y ◇ z) ◇ y) ◇ w).

Definition Equation1340 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ z) ◇ z) ◇ x).

Definition Equation1341 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ z) ◇ z) ◇ y).

Definition Equation1342 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((y ◇ z) ◇ z) ◇ z).

Definition Equation1343 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((y ◇ z) ◇ z) ◇ w).

Definition Equation1344 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((y ◇ z) ◇ w) ◇ x).

Definition Equation1345 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((y ◇ z) ◇ w) ◇ y).

Definition Equation1346 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((y ◇ z) ◇ w) ◇ z).

Definition Equation1347 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((y ◇ z) ◇ w) ◇ w).

Definition Equation1348 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((y ◇ z) ◇ w) ◇ u).

Definition Equation1349 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ x) ◇ x) ◇ x).

Definition Equation1350 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ x) ◇ x) ◇ y).

Definition Equation1351 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ x) ◇ x) ◇ z).

Definition Equation1352 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ x) ◇ x) ◇ w).

Definition Equation1353 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ x) ◇ y) ◇ x).

Definition Equation1354 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ x) ◇ y) ◇ y).

Definition Equation1355 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ x) ◇ y) ◇ z).

Definition Equation1356 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ x) ◇ y) ◇ w).

Definition Equation1357 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ x) ◇ z) ◇ x).

Definition Equation1358 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ x) ◇ z) ◇ y).

Definition Equation1359 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ x) ◇ z) ◇ z).

Definition Equation1360 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ x) ◇ z) ◇ w).

Definition Equation1361 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ x) ◇ w) ◇ x).

Definition Equation1362 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ x) ◇ w) ◇ y).

Definition Equation1363 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ x) ◇ w) ◇ z).

Definition Equation1364 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ x) ◇ w) ◇ w).

Definition Equation1365 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((z ◇ x) ◇ w) ◇ u).

Definition Equation1366 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ y) ◇ x) ◇ x).

Definition Equation1367 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ y) ◇ x) ◇ y).

Definition Equation1368 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ y) ◇ x) ◇ z).

Definition Equation1369 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ y) ◇ x) ◇ w).

Definition Equation1370 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ y) ◇ y) ◇ x).

Definition Equation1371 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ y) ◇ y) ◇ y).

Definition Equation1372 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ y) ◇ y) ◇ z).

Definition Equation1373 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ y) ◇ y) ◇ w).

Definition Equation1374 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ y) ◇ z) ◇ x).

Definition Equation1375 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ y) ◇ z) ◇ y).

Definition Equation1376 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ y) ◇ z) ◇ z).

Definition Equation1377 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ y) ◇ z) ◇ w).

Definition Equation1378 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ y) ◇ w) ◇ x).

Definition Equation1379 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ y) ◇ w) ◇ y).

Definition Equation1380 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ y) ◇ w) ◇ z).

Definition Equation1381 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ y) ◇ w) ◇ w).

Definition Equation1382 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((z ◇ y) ◇ w) ◇ u).

Definition Equation1383 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ z) ◇ x) ◇ x).

Definition Equation1384 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ z) ◇ x) ◇ y).

Definition Equation1385 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ z) ◇ x) ◇ z).

Definition Equation1386 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ z) ◇ x) ◇ w).

Definition Equation1387 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ z) ◇ y) ◇ x).

Definition Equation1388 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ z) ◇ y) ◇ y).

Definition Equation1389 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ z) ◇ y) ◇ z).

Definition Equation1390 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ z) ◇ y) ◇ w).

Definition Equation1391 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ z) ◇ z) ◇ x).

Definition Equation1392 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ z) ◇ z) ◇ y).

Definition Equation1393 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (((z ◇ z) ◇ z) ◇ z).

Definition Equation1394 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ z) ◇ z) ◇ w).

Definition Equation1395 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ z) ◇ w) ◇ x).

Definition Equation1396 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ z) ◇ w) ◇ y).

Definition Equation1397 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ z) ◇ w) ◇ z).

Definition Equation1398 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ z) ◇ w) ◇ w).

Definition Equation1399 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((z ◇ z) ◇ w) ◇ u).

Definition Equation1400 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ x) ◇ x).

Definition Equation1401 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ x) ◇ y).

Definition Equation1402 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ x) ◇ z).

Definition Equation1403 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ x) ◇ w).

Definition Equation1404 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((z ◇ w) ◇ x) ◇ u).

Definition Equation1405 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ y) ◇ x).

Definition Equation1406 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ y) ◇ y).

Definition Equation1407 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ y) ◇ z).

Definition Equation1408 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ y) ◇ w).

Definition Equation1409 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((z ◇ w) ◇ y) ◇ u).

Definition Equation1410 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ z) ◇ x).

Definition Equation1411 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ z) ◇ y).

Definition Equation1412 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ z) ◇ z).

Definition Equation1413 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ z) ◇ w).

Definition Equation1414 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((z ◇ w) ◇ z) ◇ u).

Definition Equation1415 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ w) ◇ x).

Definition Equation1416 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ w) ◇ y).

Definition Equation1417 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ w) ◇ z).

Definition Equation1418 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = y ◇ (((z ◇ w) ◇ w) ◇ w).

Definition Equation1419 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((z ◇ w) ◇ w) ◇ u).

Definition Equation1420 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((z ◇ w) ◇ u) ◇ x).

Definition Equation1421 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((z ◇ w) ◇ u) ◇ y).

Definition Equation1422 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((z ◇ w) ◇ u) ◇ z).

Definition Equation1423 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((z ◇ w) ◇ u) ◇ w).

Definition Equation1424 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = y ◇ (((z ◇ w) ◇ u) ◇ u).

Definition Equation1425 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = y ◇ (((z ◇ w) ◇ u) ◇ v).

Definition Equation1426 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = (x ◇ x) ◇ (x ◇ (x ◇ x)).

Definition Equation1427 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ (x ◇ (x ◇ y)).

Definition Equation1428 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ (x ◇ (y ◇ x)).

Definition Equation1429 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ (x ◇ (y ◇ y)).

Definition Equation1430 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ x) ◇ (x ◇ (y ◇ z)).

Definition Equation1431 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ (y ◇ (x ◇ x)).

Definition Equation1432 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ (y ◇ (x ◇ y)).

Definition Equation1433 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ x) ◇ (y ◇ (x ◇ z)).

Definition Equation1434 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ (y ◇ (y ◇ x)).

Definition Equation1435 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ (y ◇ (y ◇ y)).

Definition Equation1436 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ x) ◇ (y ◇ (y ◇ z)).

Definition Equation1437 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ x) ◇ (y ◇ (z ◇ x)).

Definition Equation1438 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ x) ◇ (y ◇ (z ◇ y)).

Definition Equation1439 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ x) ◇ (y ◇ (z ◇ z)).

Definition Equation1440 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ x) ◇ (y ◇ (z ◇ w)).

Definition Equation1441 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ (x ◇ (x ◇ x)).

Definition Equation1442 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ (x ◇ (x ◇ y)).

Definition Equation1443 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (x ◇ (x ◇ z)).

Definition Equation1444 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ (x ◇ (y ◇ x)).

Definition Equation1445 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ (x ◇ (y ◇ y)).

Definition Equation1446 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (x ◇ (y ◇ z)).

Definition Equation1447 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (x ◇ (z ◇ x)).

Definition Equation1448 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (x ◇ (z ◇ y)).

Definition Equation1449 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (x ◇ (z ◇ z)).

Definition Equation1450 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ (x ◇ (z ◇ w)).

Definition Equation1451 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ (y ◇ (x ◇ x)).

Definition Equation1452 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ (y ◇ (x ◇ y)).

Definition Equation1453 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (y ◇ (x ◇ z)).

Definition Equation1454 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ (y ◇ (y ◇ x)).

Definition Equation1455 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ (y ◇ (y ◇ y)).

Definition Equation1456 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (y ◇ (y ◇ z)).

Definition Equation1457 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (y ◇ (z ◇ x)).

Definition Equation1458 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (y ◇ (z ◇ y)).

Definition Equation1459 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (y ◇ (z ◇ z)).

Definition Equation1460 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ (y ◇ (z ◇ w)).

Definition Equation1461 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (z ◇ (x ◇ x)).

Definition Equation1462 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (z ◇ (x ◇ y)).

Definition Equation1463 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (z ◇ (x ◇ z)).

Definition Equation1464 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ (z ◇ (x ◇ w)).

Definition Equation1465 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (z ◇ (y ◇ x)).

Definition Equation1466 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (z ◇ (y ◇ y)).

Definition Equation1467 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (z ◇ (y ◇ z)).

Definition Equation1468 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ (z ◇ (y ◇ w)).

Definition Equation1469 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (z ◇ (z ◇ x)).

Definition Equation1470 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (z ◇ (z ◇ y)).

Definition Equation1471 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ (z ◇ (z ◇ z)).

Definition Equation1472 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ (z ◇ (z ◇ w)).

Definition Equation1473 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ (z ◇ (w ◇ x)).

Definition Equation1474 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ (z ◇ (w ◇ y)).

Definition Equation1475 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ (z ◇ (w ◇ z)).

Definition Equation1476 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ (z ◇ (w ◇ w)).

Definition Equation1477 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (x ◇ y) ◇ (z ◇ (w ◇ u)).

Definition Equation1478 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ (x ◇ (x ◇ x)).

Definition Equation1479 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ (x ◇ (x ◇ y)).

Definition Equation1480 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (x ◇ (x ◇ z)).

Definition Equation1481 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ (x ◇ (y ◇ x)).

Definition Equation1482 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ (x ◇ (y ◇ y)).

Definition Equation1483 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (x ◇ (y ◇ z)).

Definition Equation1484 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (x ◇ (z ◇ x)).

Definition Equation1485 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (x ◇ (z ◇ y)).

Definition Equation1486 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (x ◇ (z ◇ z)).

Definition Equation1487 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ (x ◇ (z ◇ w)).

Definition Equation1488 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ (y ◇ (x ◇ x)).

Definition Equation1489 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ (y ◇ (x ◇ y)).

Definition Equation1490 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (y ◇ (x ◇ z)).

Definition Equation1491 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ (y ◇ (y ◇ x)).

Definition Equation1492 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ (y ◇ (y ◇ y)).

Definition Equation1493 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (y ◇ (y ◇ z)).

Definition Equation1494 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (y ◇ (z ◇ x)).

Definition Equation1495 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (y ◇ (z ◇ y)).

Definition Equation1496 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (y ◇ (z ◇ z)).

Definition Equation1497 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ (y ◇ (z ◇ w)).

Definition Equation1498 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (z ◇ (x ◇ x)).

Definition Equation1499 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (z ◇ (x ◇ y)).

Definition Equation1500 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (z ◇ (x ◇ z)).

Definition Equation1501 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ (z ◇ (x ◇ w)).

Definition Equation1502 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (z ◇ (y ◇ x)).

Definition Equation1503 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (z ◇ (y ◇ y)).

Definition Equation1504 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (z ◇ (y ◇ z)).

Definition Equation1505 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ (z ◇ (y ◇ w)).

Definition Equation1506 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (z ◇ (z ◇ x)).

Definition Equation1507 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (z ◇ (z ◇ y)).

Definition Equation1508 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ (z ◇ (z ◇ z)).

Definition Equation1509 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ (z ◇ (z ◇ w)).

Definition Equation1510 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ (z ◇ (w ◇ x)).

Definition Equation1511 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ (z ◇ (w ◇ y)).

Definition Equation1512 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ (z ◇ (w ◇ z)).

Definition Equation1513 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ (z ◇ (w ◇ w)).

Definition Equation1514 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ x) ◇ (z ◇ (w ◇ u)).

Definition Equation1515 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ (x ◇ (x ◇ x)).

Definition Equation1516 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ (x ◇ (x ◇ y)).

Definition Equation1517 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (x ◇ (x ◇ z)).

Definition Equation1518 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ (x ◇ (y ◇ x)).

Definition Equation1519 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ (x ◇ (y ◇ y)).

Definition Equation1520 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (x ◇ (y ◇ z)).

Definition Equation1521 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (x ◇ (z ◇ x)).

Definition Equation1522 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (x ◇ (z ◇ y)).

Definition Equation1523 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (x ◇ (z ◇ z)).

Definition Equation1524 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ (x ◇ (z ◇ w)).

Definition Equation1525 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ (y ◇ (x ◇ x)).

Definition Equation1526 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ (y ◇ (x ◇ y)).

Definition Equation1527 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (y ◇ (x ◇ z)).

Definition Equation1528 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ (y ◇ (y ◇ x)).

Definition Equation1529 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ (y ◇ (y ◇ y)).

Definition Equation1530 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (y ◇ (y ◇ z)).

Definition Equation1531 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (y ◇ (z ◇ x)).

Definition Equation1532 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (y ◇ (z ◇ y)).

Definition Equation1533 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (y ◇ (z ◇ z)).

Definition Equation1534 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ (y ◇ (z ◇ w)).

Definition Equation1535 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (z ◇ (x ◇ x)).

Definition Equation1536 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (z ◇ (x ◇ y)).

Definition Equation1537 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (z ◇ (x ◇ z)).

Definition Equation1538 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ (z ◇ (x ◇ w)).

Definition Equation1539 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (z ◇ (y ◇ x)).

Definition Equation1540 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (z ◇ (y ◇ y)).

Definition Equation1541 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (z ◇ (y ◇ z)).

Definition Equation1542 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ (z ◇ (y ◇ w)).

Definition Equation1543 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (z ◇ (z ◇ x)).

Definition Equation1544 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (z ◇ (z ◇ y)).

Definition Equation1545 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ (z ◇ (z ◇ z)).

Definition Equation1546 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ (z ◇ (z ◇ w)).

Definition Equation1547 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ (z ◇ (w ◇ x)).

Definition Equation1548 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ (z ◇ (w ◇ y)).

Definition Equation1549 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ (z ◇ (w ◇ z)).

Definition Equation1550 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ (z ◇ (w ◇ w)).

Definition Equation1551 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ y) ◇ (z ◇ (w ◇ u)).

Definition Equation1552 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (x ◇ (x ◇ x)).

Definition Equation1553 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (x ◇ (x ◇ y)).

Definition Equation1554 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (x ◇ (x ◇ z)).

Definition Equation1555 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (x ◇ (x ◇ w)).

Definition Equation1556 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (x ◇ (y ◇ x)).

Definition Equation1557 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (x ◇ (y ◇ y)).

Definition Equation1558 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (x ◇ (y ◇ z)).

Definition Equation1559 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (x ◇ (y ◇ w)).

Definition Equation1560 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (x ◇ (z ◇ x)).

Definition Equation1561 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (x ◇ (z ◇ y)).

Definition Equation1562 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (x ◇ (z ◇ z)).

Definition Equation1563 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (x ◇ (z ◇ w)).

Definition Equation1564 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (x ◇ (w ◇ x)).

Definition Equation1565 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (x ◇ (w ◇ y)).

Definition Equation1566 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (x ◇ (w ◇ z)).

Definition Equation1567 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (x ◇ (w ◇ w)).

Definition Equation1568 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ (x ◇ (w ◇ u)).

Definition Equation1569 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (y ◇ (x ◇ x)).

Definition Equation1570 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (y ◇ (x ◇ y)).

Definition Equation1571 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (y ◇ (x ◇ z)).

Definition Equation1572 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (y ◇ (x ◇ w)).

Definition Equation1573 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (y ◇ (y ◇ x)).

Definition Equation1574 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (y ◇ (y ◇ y)).

Definition Equation1575 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (y ◇ (y ◇ z)).

Definition Equation1576 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (y ◇ (y ◇ w)).

Definition Equation1577 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (y ◇ (z ◇ x)).

Definition Equation1578 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (y ◇ (z ◇ y)).

Definition Equation1579 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (y ◇ (z ◇ z)).

Definition Equation1580 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (y ◇ (z ◇ w)).

Definition Equation1581 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (y ◇ (w ◇ x)).

Definition Equation1582 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (y ◇ (w ◇ y)).

Definition Equation1583 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (y ◇ (w ◇ z)).

Definition Equation1584 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (y ◇ (w ◇ w)).

Definition Equation1585 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ (y ◇ (w ◇ u)).

Definition Equation1586 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (z ◇ (x ◇ x)).

Definition Equation1587 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (z ◇ (x ◇ y)).

Definition Equation1588 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (z ◇ (x ◇ z)).

Definition Equation1589 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (z ◇ (x ◇ w)).

Definition Equation1590 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (z ◇ (y ◇ x)).

Definition Equation1591 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (z ◇ (y ◇ y)).

Definition Equation1592 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (z ◇ (y ◇ z)).

Definition Equation1593 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (z ◇ (y ◇ w)).

Definition Equation1594 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (z ◇ (z ◇ x)).

Definition Equation1595 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (z ◇ (z ◇ y)).

Definition Equation1596 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ (z ◇ (z ◇ z)).

Definition Equation1597 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (z ◇ (z ◇ w)).

Definition Equation1598 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (z ◇ (w ◇ x)).

Definition Equation1599 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (z ◇ (w ◇ y)).

Definition Equation1600 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (z ◇ (w ◇ z)).

Definition Equation1601 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (z ◇ (w ◇ w)).

Definition Equation1602 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ (z ◇ (w ◇ u)).

Definition Equation1603 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (x ◇ x)).

Definition Equation1604 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (x ◇ y)).

Definition Equation1605 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (x ◇ z)).

Definition Equation1606 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (x ◇ w)).

Definition Equation1607 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ (w ◇ (x ◇ u)).

Definition Equation1608 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (y ◇ x)).

Definition Equation1609 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (y ◇ y)).

Definition Equation1610 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (y ◇ z)).

Definition Equation1611 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (y ◇ w)).

Definition Equation1612 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ (w ◇ (y ◇ u)).

Definition Equation1613 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (z ◇ x)).

Definition Equation1614 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (z ◇ y)).

Definition Equation1615 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (z ◇ z)).

Definition Equation1616 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (z ◇ w)).

Definition Equation1617 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ (w ◇ (z ◇ u)).

Definition Equation1618 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (w ◇ x)).

Definition Equation1619 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (w ◇ y)).

Definition Equation1620 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (w ◇ z)).

Definition Equation1621 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ (w ◇ (w ◇ w)).

Definition Equation1622 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ (w ◇ (w ◇ u)).

Definition Equation1623 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ (w ◇ (u ◇ x)).

Definition Equation1624 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ (w ◇ (u ◇ y)).

Definition Equation1625 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ (w ◇ (u ◇ z)).

Definition Equation1626 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ (w ◇ (u ◇ w)).

Definition Equation1627 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ (w ◇ (u ◇ u)).

Definition Equation1628 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = (y ◇ z) ◇ (w ◇ (u ◇ v)).

Definition Equation1629 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = (x ◇ x) ◇ ((x ◇ x) ◇ x).

Definition Equation1630 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ ((x ◇ x) ◇ y).

Definition Equation1631 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ ((x ◇ y) ◇ x).

Definition Equation1632 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ ((x ◇ y) ◇ y).

Definition Equation1633 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ x) ◇ ((x ◇ y) ◇ z).

Definition Equation1634 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ ((y ◇ x) ◇ x).

Definition Equation1635 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ ((y ◇ x) ◇ y).

Definition Equation1636 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ x) ◇ ((y ◇ x) ◇ z).

Definition Equation1637 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ ((y ◇ y) ◇ x).

Definition Equation1638 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ x) ◇ ((y ◇ y) ◇ y).

Definition Equation1639 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ x) ◇ ((y ◇ y) ◇ z).

Definition Equation1640 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ x) ◇ ((y ◇ z) ◇ x).

Definition Equation1641 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ x) ◇ ((y ◇ z) ◇ y).

Definition Equation1642 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ x) ◇ ((y ◇ z) ◇ z).

Definition Equation1643 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ x) ◇ ((y ◇ z) ◇ w).

Definition Equation1644 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ ((x ◇ x) ◇ x).

Definition Equation1645 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ ((x ◇ x) ◇ y).

Definition Equation1646 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((x ◇ x) ◇ z).

Definition Equation1647 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ ((x ◇ y) ◇ x).

Definition Equation1648 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ ((x ◇ y) ◇ y).

Definition Equation1649 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((x ◇ y) ◇ z).

Definition Equation1650 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((x ◇ z) ◇ x).

Definition Equation1651 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((x ◇ z) ◇ y).

Definition Equation1652 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((x ◇ z) ◇ z).

Definition Equation1653 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ ((x ◇ z) ◇ w).

Definition Equation1654 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ ((y ◇ x) ◇ x).

Definition Equation1655 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ ((y ◇ x) ◇ y).

Definition Equation1656 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((y ◇ x) ◇ z).

Definition Equation1657 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ ((y ◇ y) ◇ x).

Definition Equation1658 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ y) ◇ ((y ◇ y) ◇ y).

Definition Equation1659 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((y ◇ y) ◇ z).

Definition Equation1660 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((y ◇ z) ◇ x).

Definition Equation1661 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((y ◇ z) ◇ y).

Definition Equation1662 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((y ◇ z) ◇ z).

Definition Equation1663 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ ((y ◇ z) ◇ w).

Definition Equation1664 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((z ◇ x) ◇ x).

Definition Equation1665 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((z ◇ x) ◇ y).

Definition Equation1666 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((z ◇ x) ◇ z).

Definition Equation1667 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ ((z ◇ x) ◇ w).

Definition Equation1668 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((z ◇ y) ◇ x).

Definition Equation1669 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((z ◇ y) ◇ y).

Definition Equation1670 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((z ◇ y) ◇ z).

Definition Equation1671 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ ((z ◇ y) ◇ w).

Definition Equation1672 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((z ◇ z) ◇ x).

Definition Equation1673 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((z ◇ z) ◇ y).

Definition Equation1674 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ y) ◇ ((z ◇ z) ◇ z).

Definition Equation1675 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ ((z ◇ z) ◇ w).

Definition Equation1676 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ ((z ◇ w) ◇ x).

Definition Equation1677 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ ((z ◇ w) ◇ y).

Definition Equation1678 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ ((z ◇ w) ◇ z).

Definition Equation1679 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ y) ◇ ((z ◇ w) ◇ w).

Definition Equation1680 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (x ◇ y) ◇ ((z ◇ w) ◇ u).

Definition Equation1681 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ ((x ◇ x) ◇ x).

Definition Equation1682 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ ((x ◇ x) ◇ y).

Definition Equation1683 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((x ◇ x) ◇ z).

Definition Equation1684 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ ((x ◇ y) ◇ x).

Definition Equation1685 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ ((x ◇ y) ◇ y).

Definition Equation1686 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((x ◇ y) ◇ z).

Definition Equation1687 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((x ◇ z) ◇ x).

Definition Equation1688 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((x ◇ z) ◇ y).

Definition Equation1689 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((x ◇ z) ◇ z).

Definition Equation1690 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ ((x ◇ z) ◇ w).

Definition Equation1691 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ ((y ◇ x) ◇ x).

Definition Equation1692 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ ((y ◇ x) ◇ y).

Definition Equation1693 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((y ◇ x) ◇ z).

Definition Equation1694 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ ((y ◇ y) ◇ x).

Definition Equation1695 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ x) ◇ ((y ◇ y) ◇ y).

Definition Equation1696 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((y ◇ y) ◇ z).

Definition Equation1697 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((y ◇ z) ◇ x).

Definition Equation1698 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((y ◇ z) ◇ y).

Definition Equation1699 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((y ◇ z) ◇ z).

Definition Equation1700 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ ((y ◇ z) ◇ w).

Definition Equation1701 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((z ◇ x) ◇ x).

Definition Equation1702 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((z ◇ x) ◇ y).

Definition Equation1703 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((z ◇ x) ◇ z).

Definition Equation1704 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ ((z ◇ x) ◇ w).

Definition Equation1705 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((z ◇ y) ◇ x).

Definition Equation1706 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((z ◇ y) ◇ y).

Definition Equation1707 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((z ◇ y) ◇ z).

Definition Equation1708 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ ((z ◇ y) ◇ w).

Definition Equation1709 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((z ◇ z) ◇ x).

Definition Equation1710 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((z ◇ z) ◇ y).

Definition Equation1711 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ x) ◇ ((z ◇ z) ◇ z).

Definition Equation1712 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ ((z ◇ z) ◇ w).

Definition Equation1713 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ ((z ◇ w) ◇ x).

Definition Equation1714 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ ((z ◇ w) ◇ y).

Definition Equation1715 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ ((z ◇ w) ◇ z).

Definition Equation1716 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ x) ◇ ((z ◇ w) ◇ w).

Definition Equation1717 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ x) ◇ ((z ◇ w) ◇ u).

Definition Equation1718 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ ((x ◇ x) ◇ x).

Definition Equation1719 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ ((x ◇ x) ◇ y).

Definition Equation1720 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((x ◇ x) ◇ z).

Definition Equation1721 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ ((x ◇ y) ◇ x).

Definition Equation1722 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ ((x ◇ y) ◇ y).

Definition Equation1723 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((x ◇ y) ◇ z).

Definition Equation1724 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((x ◇ z) ◇ x).

Definition Equation1725 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((x ◇ z) ◇ y).

Definition Equation1726 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((x ◇ z) ◇ z).

Definition Equation1727 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ ((x ◇ z) ◇ w).

Definition Equation1728 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ ((y ◇ x) ◇ x).

Definition Equation1729 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ ((y ◇ x) ◇ y).

Definition Equation1730 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((y ◇ x) ◇ z).

Definition Equation1731 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ ((y ◇ y) ◇ x).

Definition Equation1732 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ y) ◇ ((y ◇ y) ◇ y).

Definition Equation1733 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((y ◇ y) ◇ z).

Definition Equation1734 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((y ◇ z) ◇ x).

Definition Equation1735 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((y ◇ z) ◇ y).

Definition Equation1736 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((y ◇ z) ◇ z).

Definition Equation1737 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ ((y ◇ z) ◇ w).

Definition Equation1738 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((z ◇ x) ◇ x).

Definition Equation1739 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((z ◇ x) ◇ y).

Definition Equation1740 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((z ◇ x) ◇ z).

Definition Equation1741 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ ((z ◇ x) ◇ w).

Definition Equation1742 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((z ◇ y) ◇ x).

Definition Equation1743 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((z ◇ y) ◇ y).

Definition Equation1744 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((z ◇ y) ◇ z).

Definition Equation1745 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ ((z ◇ y) ◇ w).

Definition Equation1746 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((z ◇ z) ◇ x).

Definition Equation1747 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((z ◇ z) ◇ y).

Definition Equation1748 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ y) ◇ ((z ◇ z) ◇ z).

Definition Equation1749 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ ((z ◇ z) ◇ w).

Definition Equation1750 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ ((z ◇ w) ◇ x).

Definition Equation1751 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ ((z ◇ w) ◇ y).

Definition Equation1752 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ ((z ◇ w) ◇ z).

Definition Equation1753 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ y) ◇ ((z ◇ w) ◇ w).

Definition Equation1754 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ y) ◇ ((z ◇ w) ◇ u).

Definition Equation1755 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((x ◇ x) ◇ x).

Definition Equation1756 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((x ◇ x) ◇ y).

Definition Equation1757 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((x ◇ x) ◇ z).

Definition Equation1758 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((x ◇ x) ◇ w).

Definition Equation1759 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((x ◇ y) ◇ x).

Definition Equation1760 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((x ◇ y) ◇ y).

Definition Equation1761 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((x ◇ y) ◇ z).

Definition Equation1762 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((x ◇ y) ◇ w).

Definition Equation1763 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((x ◇ z) ◇ x).

Definition Equation1764 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((x ◇ z) ◇ y).

Definition Equation1765 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((x ◇ z) ◇ z).

Definition Equation1766 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((x ◇ z) ◇ w).

Definition Equation1767 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((x ◇ w) ◇ x).

Definition Equation1768 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((x ◇ w) ◇ y).

Definition Equation1769 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((x ◇ w) ◇ z).

Definition Equation1770 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((x ◇ w) ◇ w).

Definition Equation1771 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ ((x ◇ w) ◇ u).

Definition Equation1772 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((y ◇ x) ◇ x).

Definition Equation1773 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((y ◇ x) ◇ y).

Definition Equation1774 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((y ◇ x) ◇ z).

Definition Equation1775 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((y ◇ x) ◇ w).

Definition Equation1776 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((y ◇ y) ◇ x).

Definition Equation1777 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((y ◇ y) ◇ y).

Definition Equation1778 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((y ◇ y) ◇ z).

Definition Equation1779 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((y ◇ y) ◇ w).

Definition Equation1780 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((y ◇ z) ◇ x).

Definition Equation1781 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((y ◇ z) ◇ y).

Definition Equation1782 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((y ◇ z) ◇ z).

Definition Equation1783 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((y ◇ z) ◇ w).

Definition Equation1784 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((y ◇ w) ◇ x).

Definition Equation1785 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((y ◇ w) ◇ y).

Definition Equation1786 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((y ◇ w) ◇ z).

Definition Equation1787 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((y ◇ w) ◇ w).

Definition Equation1788 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ ((y ◇ w) ◇ u).

Definition Equation1789 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((z ◇ x) ◇ x).

Definition Equation1790 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((z ◇ x) ◇ y).

Definition Equation1791 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((z ◇ x) ◇ z).

Definition Equation1792 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((z ◇ x) ◇ w).

Definition Equation1793 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((z ◇ y) ◇ x).

Definition Equation1794 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((z ◇ y) ◇ y).

Definition Equation1795 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((z ◇ y) ◇ z).

Definition Equation1796 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((z ◇ y) ◇ w).

Definition Equation1797 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((z ◇ z) ◇ x).

Definition Equation1798 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((z ◇ z) ◇ y).

Definition Equation1799 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ z) ◇ ((z ◇ z) ◇ z).

Definition Equation1800 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((z ◇ z) ◇ w).

Definition Equation1801 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((z ◇ w) ◇ x).

Definition Equation1802 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((z ◇ w) ◇ y).

Definition Equation1803 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((z ◇ w) ◇ z).

Definition Equation1804 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((z ◇ w) ◇ w).

Definition Equation1805 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ ((z ◇ w) ◇ u).

Definition Equation1806 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ x) ◇ x).

Definition Equation1807 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ x) ◇ y).

Definition Equation1808 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ x) ◇ z).

Definition Equation1809 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ x) ◇ w).

Definition Equation1810 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ ((w ◇ x) ◇ u).

Definition Equation1811 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ y) ◇ x).

Definition Equation1812 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ y) ◇ y).

Definition Equation1813 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ y) ◇ z).

Definition Equation1814 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ y) ◇ w).

Definition Equation1815 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ ((w ◇ y) ◇ u).

Definition Equation1816 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ z) ◇ x).

Definition Equation1817 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ z) ◇ y).

Definition Equation1818 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ z) ◇ z).

Definition Equation1819 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ z) ◇ w).

Definition Equation1820 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ ((w ◇ z) ◇ u).

Definition Equation1821 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ w) ◇ x).

Definition Equation1822 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ w) ◇ y).

Definition Equation1823 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ w) ◇ z).

Definition Equation1824 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ z) ◇ ((w ◇ w) ◇ w).

Definition Equation1825 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ ((w ◇ w) ◇ u).

Definition Equation1826 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ ((w ◇ u) ◇ x).

Definition Equation1827 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ ((w ◇ u) ◇ y).

Definition Equation1828 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ ((w ◇ u) ◇ z).

Definition Equation1829 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ ((w ◇ u) ◇ w).

Definition Equation1830 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ z) ◇ ((w ◇ u) ◇ u).

Definition Equation1831 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = (y ◇ z) ◇ ((w ◇ u) ◇ v).

Definition Equation1832 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = (x ◇ (x ◇ x)) ◇ (x ◇ x).

Definition Equation1833 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ x)) ◇ (x ◇ y).

Definition Equation1834 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ x)) ◇ (y ◇ x).

Definition Equation1835 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ x)) ◇ (y ◇ y).

Definition Equation1836 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (x ◇ x)) ◇ (y ◇ z).

Definition Equation1837 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ y)) ◇ (x ◇ x).

Definition Equation1838 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ y)) ◇ (x ◇ y).

Definition Equation1839 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (x ◇ y)) ◇ (x ◇ z).

Definition Equation1840 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ y)) ◇ (y ◇ x).

Definition Equation1841 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ y)) ◇ (y ◇ y).

Definition Equation1842 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (x ◇ y)) ◇ (y ◇ z).

Definition Equation1843 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (x ◇ y)) ◇ (z ◇ x).

Definition Equation1844 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (x ◇ y)) ◇ (z ◇ y).

Definition Equation1845 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (x ◇ y)) ◇ (z ◇ z).

Definition Equation1846 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (x ◇ y)) ◇ (z ◇ w).

Definition Equation1847 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ x)) ◇ (x ◇ x).

Definition Equation1848 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ x)) ◇ (x ◇ y).

Definition Equation1849 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ x)) ◇ (x ◇ z).

Definition Equation1850 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ x)) ◇ (y ◇ x).

Definition Equation1851 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ x)) ◇ (y ◇ y).

Definition Equation1852 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ x)) ◇ (y ◇ z).

Definition Equation1853 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ x)) ◇ (z ◇ x).

Definition Equation1854 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ x)) ◇ (z ◇ y).

Definition Equation1855 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ x)) ◇ (z ◇ z).

Definition Equation1856 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ x)) ◇ (z ◇ w).

Definition Equation1857 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ y)) ◇ (x ◇ x).

Definition Equation1858 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ y)) ◇ (x ◇ y).

Definition Equation1859 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ y)) ◇ (x ◇ z).

Definition Equation1860 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ y)) ◇ (y ◇ x).

Definition Equation1861 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ y)) ◇ (y ◇ y).

Definition Equation1862 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ y)) ◇ (y ◇ z).

Definition Equation1863 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ y)) ◇ (z ◇ x).

Definition Equation1864 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ y)) ◇ (z ◇ y).

Definition Equation1865 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ y)) ◇ (z ◇ z).

Definition Equation1866 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ y)) ◇ (z ◇ w).

Definition Equation1867 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ z)) ◇ (x ◇ x).

Definition Equation1868 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ z)) ◇ (x ◇ y).

Definition Equation1869 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ z)) ◇ (x ◇ z).

Definition Equation1870 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ z)) ◇ (x ◇ w).

Definition Equation1871 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ z)) ◇ (y ◇ x).

Definition Equation1872 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ z)) ◇ (y ◇ y).

Definition Equation1873 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ z)) ◇ (y ◇ z).

Definition Equation1874 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ z)) ◇ (y ◇ w).

Definition Equation1875 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ z)) ◇ (z ◇ x).

Definition Equation1876 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ z)) ◇ (z ◇ y).

Definition Equation1877 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ z)) ◇ (z ◇ z).

Definition Equation1878 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ z)) ◇ (z ◇ w).

Definition Equation1879 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ z)) ◇ (w ◇ x).

Definition Equation1880 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ z)) ◇ (w ◇ y).

Definition Equation1881 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ z)) ◇ (w ◇ z).

Definition Equation1882 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ z)) ◇ (w ◇ w).

Definition Equation1883 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (x ◇ (y ◇ z)) ◇ (w ◇ u).

Definition Equation1884 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ x)) ◇ (x ◇ x).

Definition Equation1885 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ x)) ◇ (x ◇ y).

Definition Equation1886 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ x)) ◇ (x ◇ z).

Definition Equation1887 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ x)) ◇ (y ◇ x).

Definition Equation1888 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ x)) ◇ (y ◇ y).

Definition Equation1889 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ x)) ◇ (y ◇ z).

Definition Equation1890 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ x)) ◇ (z ◇ x).

Definition Equation1891 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ x)) ◇ (z ◇ y).

Definition Equation1892 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ x)) ◇ (z ◇ z).

Definition Equation1893 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ x)) ◇ (z ◇ w).

Definition Equation1894 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ y)) ◇ (x ◇ x).

Definition Equation1895 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ y)) ◇ (x ◇ y).

Definition Equation1896 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ y)) ◇ (x ◇ z).

Definition Equation1897 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ y)) ◇ (y ◇ x).

Definition Equation1898 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ y)) ◇ (y ◇ y).

Definition Equation1899 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ y)) ◇ (y ◇ z).

Definition Equation1900 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ y)) ◇ (z ◇ x).

Definition Equation1901 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ y)) ◇ (z ◇ y).

Definition Equation1902 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ y)) ◇ (z ◇ z).

Definition Equation1903 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ y)) ◇ (z ◇ w).

Definition Equation1904 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ z)) ◇ (x ◇ x).

Definition Equation1905 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ z)) ◇ (x ◇ y).

Definition Equation1906 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ z)) ◇ (x ◇ z).

Definition Equation1907 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ z)) ◇ (x ◇ w).

Definition Equation1908 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ z)) ◇ (y ◇ x).

Definition Equation1909 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ z)) ◇ (y ◇ y).

Definition Equation1910 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ z)) ◇ (y ◇ z).

Definition Equation1911 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ z)) ◇ (y ◇ w).

Definition Equation1912 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ z)) ◇ (z ◇ x).

Definition Equation1913 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ z)) ◇ (z ◇ y).

Definition Equation1914 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ z)) ◇ (z ◇ z).

Definition Equation1915 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ z)) ◇ (z ◇ w).

Definition Equation1916 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ z)) ◇ (w ◇ x).

Definition Equation1917 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ z)) ◇ (w ◇ y).

Definition Equation1918 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ z)) ◇ (w ◇ z).

Definition Equation1919 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ z)) ◇ (w ◇ w).

Definition Equation1920 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (x ◇ z)) ◇ (w ◇ u).

Definition Equation1921 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ x)) ◇ (x ◇ x).

Definition Equation1922 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ x)) ◇ (x ◇ y).

Definition Equation1923 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ x)) ◇ (x ◇ z).

Definition Equation1924 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ x)) ◇ (y ◇ x).

Definition Equation1925 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ x)) ◇ (y ◇ y).

Definition Equation1926 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ x)) ◇ (y ◇ z).

Definition Equation1927 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ x)) ◇ (z ◇ x).

Definition Equation1928 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ x)) ◇ (z ◇ y).

Definition Equation1929 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ x)) ◇ (z ◇ z).

Definition Equation1930 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ x)) ◇ (z ◇ w).

Definition Equation1931 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ y)) ◇ (x ◇ x).

Definition Equation1932 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ y)) ◇ (x ◇ y).

Definition Equation1933 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ y)) ◇ (x ◇ z).

Definition Equation1934 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ y)) ◇ (y ◇ x).

Definition Equation1935 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ y)) ◇ (y ◇ y).

Definition Equation1936 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ y)) ◇ (y ◇ z).

Definition Equation1937 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ y)) ◇ (z ◇ x).

Definition Equation1938 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ y)) ◇ (z ◇ y).

Definition Equation1939 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ y)) ◇ (z ◇ z).

Definition Equation1940 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ y)) ◇ (z ◇ w).

Definition Equation1941 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ z)) ◇ (x ◇ x).

Definition Equation1942 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ z)) ◇ (x ◇ y).

Definition Equation1943 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ z)) ◇ (x ◇ z).

Definition Equation1944 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ z)) ◇ (x ◇ w).

Definition Equation1945 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ z)) ◇ (y ◇ x).

Definition Equation1946 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ z)) ◇ (y ◇ y).

Definition Equation1947 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ z)) ◇ (y ◇ z).

Definition Equation1948 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ z)) ◇ (y ◇ w).

Definition Equation1949 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ z)) ◇ (z ◇ x).

Definition Equation1950 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ z)) ◇ (z ◇ y).

Definition Equation1951 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ z)) ◇ (z ◇ z).

Definition Equation1952 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ z)) ◇ (z ◇ w).

Definition Equation1953 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ z)) ◇ (w ◇ x).

Definition Equation1954 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ z)) ◇ (w ◇ y).

Definition Equation1955 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ z)) ◇ (w ◇ z).

Definition Equation1956 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ z)) ◇ (w ◇ w).

Definition Equation1957 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (y ◇ z)) ◇ (w ◇ u).

Definition Equation1958 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ x)) ◇ (x ◇ x).

Definition Equation1959 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ x)) ◇ (x ◇ y).

Definition Equation1960 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ x)) ◇ (x ◇ z).

Definition Equation1961 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ x)) ◇ (x ◇ w).

Definition Equation1962 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ x)) ◇ (y ◇ x).

Definition Equation1963 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ x)) ◇ (y ◇ y).

Definition Equation1964 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ x)) ◇ (y ◇ z).

Definition Equation1965 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ x)) ◇ (y ◇ w).

Definition Equation1966 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ x)) ◇ (z ◇ x).

Definition Equation1967 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ x)) ◇ (z ◇ y).

Definition Equation1968 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ x)) ◇ (z ◇ z).

Definition Equation1969 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ x)) ◇ (z ◇ w).

Definition Equation1970 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ x)) ◇ (w ◇ x).

Definition Equation1971 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ x)) ◇ (w ◇ y).

Definition Equation1972 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ x)) ◇ (w ◇ z).

Definition Equation1973 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ x)) ◇ (w ◇ w).

Definition Equation1974 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ x)) ◇ (w ◇ u).

Definition Equation1975 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ y)) ◇ (x ◇ x).

Definition Equation1976 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ y)) ◇ (x ◇ y).

Definition Equation1977 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ y)) ◇ (x ◇ z).

Definition Equation1978 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ y)) ◇ (x ◇ w).

Definition Equation1979 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ y)) ◇ (y ◇ x).

Definition Equation1980 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ y)) ◇ (y ◇ y).

Definition Equation1981 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ y)) ◇ (y ◇ z).

Definition Equation1982 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ y)) ◇ (y ◇ w).

Definition Equation1983 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ y)) ◇ (z ◇ x).

Definition Equation1984 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ y)) ◇ (z ◇ y).

Definition Equation1985 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ y)) ◇ (z ◇ z).

Definition Equation1986 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ y)) ◇ (z ◇ w).

Definition Equation1987 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ y)) ◇ (w ◇ x).

Definition Equation1988 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ y)) ◇ (w ◇ y).

Definition Equation1989 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ y)) ◇ (w ◇ z).

Definition Equation1990 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ y)) ◇ (w ◇ w).

Definition Equation1991 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ y)) ◇ (w ◇ u).

Definition Equation1992 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ z)) ◇ (x ◇ x).

Definition Equation1993 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ z)) ◇ (x ◇ y).

Definition Equation1994 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ z)) ◇ (x ◇ z).

Definition Equation1995 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ z)) ◇ (x ◇ w).

Definition Equation1996 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ z)) ◇ (y ◇ x).

Definition Equation1997 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ z)) ◇ (y ◇ y).

Definition Equation1998 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ z)) ◇ (y ◇ z).

Definition Equation1999 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ z)) ◇ (y ◇ w).

