(** * Equations 3000–3999

    Auto-generated from the Lean4 Equational Theories Project. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.

Open Scope magma_scope.

Definition Equation3000 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ y)) ◇ z) ◇ z.

Definition Equation3001 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ y)) ◇ z) ◇ w.

Definition Equation3002 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ y)) ◇ w) ◇ x.

Definition Equation3003 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ y)) ◇ w) ◇ y.

Definition Equation3004 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ y)) ◇ w) ◇ z.

Definition Equation3005 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ y)) ◇ w) ◇ w.

Definition Equation3006 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (z ◇ y)) ◇ w) ◇ u.

Definition Equation3007 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ z)) ◇ x) ◇ x.

Definition Equation3008 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ z)) ◇ x) ◇ y.

Definition Equation3009 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ z)) ◇ x) ◇ z.

Definition Equation3010 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ z)) ◇ x) ◇ w.

Definition Equation3011 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ z)) ◇ y) ◇ x.

Definition Equation3012 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ z)) ◇ y) ◇ y.

Definition Equation3013 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ z)) ◇ y) ◇ z.

Definition Equation3014 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ z)) ◇ y) ◇ w.

Definition Equation3015 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ z)) ◇ z) ◇ x.

Definition Equation3016 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ z)) ◇ z) ◇ y.

Definition Equation3017 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ z)) ◇ z) ◇ z.

Definition Equation3018 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ z)) ◇ z) ◇ w.

Definition Equation3019 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ z)) ◇ w) ◇ x.

Definition Equation3020 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ z)) ◇ w) ◇ y.

Definition Equation3021 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ z)) ◇ w) ◇ z.

Definition Equation3022 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ z)) ◇ w) ◇ w.

Definition Equation3023 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (z ◇ z)) ◇ w) ◇ u.

Definition Equation3024 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ x) ◇ x.

Definition Equation3025 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ x) ◇ y.

Definition Equation3026 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ x) ◇ z.

Definition Equation3027 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ x) ◇ w.

Definition Equation3028 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (z ◇ w)) ◇ x) ◇ u.

Definition Equation3029 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ y) ◇ x.

Definition Equation3030 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ y) ◇ y.

Definition Equation3031 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ y) ◇ z.

Definition Equation3032 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ y) ◇ w.

Definition Equation3033 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (z ◇ w)) ◇ y) ◇ u.

Definition Equation3034 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ z) ◇ x.

Definition Equation3035 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ z) ◇ y.

Definition Equation3036 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ z) ◇ z.

Definition Equation3037 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ z) ◇ w.

Definition Equation3038 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (z ◇ w)) ◇ z) ◇ u.

Definition Equation3039 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ w) ◇ x.

Definition Equation3040 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ w) ◇ y.

Definition Equation3041 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ w) ◇ z.

Definition Equation3042 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ w)) ◇ w) ◇ w.

Definition Equation3043 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (z ◇ w)) ◇ w) ◇ u.

Definition Equation3044 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (z ◇ w)) ◇ u) ◇ x.

Definition Equation3045 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (z ◇ w)) ◇ u) ◇ y.

Definition Equation3046 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (z ◇ w)) ◇ u) ◇ z.

Definition Equation3047 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (z ◇ w)) ◇ u) ◇ w.

Definition Equation3048 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (z ◇ w)) ◇ u) ◇ u.

Definition Equation3049 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = ((y ◇ (z ◇ w)) ◇ u) ◇ v.

Definition Equation3050 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = (((x ◇ x) ◇ x) ◇ x) ◇ x.

Definition Equation3051 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ x) ◇ x) ◇ x) ◇ y.

Definition Equation3052 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ x) ◇ x) ◇ y) ◇ x.

Definition Equation3053 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ x) ◇ x) ◇ y) ◇ y.

Definition Equation3054 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ x) ◇ x) ◇ y) ◇ z.

Definition Equation3055 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ x) ◇ y) ◇ x) ◇ x.

Definition Equation3056 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ x) ◇ y) ◇ x) ◇ y.

Definition Equation3057 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ x) ◇ y) ◇ x) ◇ z.

Definition Equation3058 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ x) ◇ y) ◇ y) ◇ x.

Definition Equation3059 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ x) ◇ y) ◇ y) ◇ y.

Definition Equation3060 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ x) ◇ y) ◇ y) ◇ z.

Definition Equation3061 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ x) ◇ y) ◇ z) ◇ x.

Definition Equation3062 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ x) ◇ y) ◇ z) ◇ y.

Definition Equation3063 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ x) ◇ y) ◇ z) ◇ z.

Definition Equation3064 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((x ◇ x) ◇ y) ◇ z) ◇ w.

Definition Equation3065 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ y) ◇ x) ◇ x) ◇ x.

Definition Equation3066 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ y) ◇ x) ◇ x) ◇ y.

Definition Equation3067 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ x) ◇ x) ◇ z.

Definition Equation3068 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ y) ◇ x) ◇ y) ◇ x.

Definition Equation3069 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ y) ◇ x) ◇ y) ◇ y.

Definition Equation3070 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ x) ◇ y) ◇ z.

Definition Equation3071 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ x) ◇ z) ◇ x.

Definition Equation3072 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ x) ◇ z) ◇ y.

Definition Equation3073 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ x) ◇ z) ◇ z.

Definition Equation3074 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((x ◇ y) ◇ x) ◇ z) ◇ w.

Definition Equation3075 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ y) ◇ y) ◇ x) ◇ x.

Definition Equation3076 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ y) ◇ y) ◇ x) ◇ y.

Definition Equation3077 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ y) ◇ x) ◇ z.

Definition Equation3078 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ y) ◇ y) ◇ y) ◇ x.

Definition Equation3079 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((x ◇ y) ◇ y) ◇ y) ◇ y.

Definition Equation3080 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ y) ◇ y) ◇ z.

Definition Equation3081 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ y) ◇ z) ◇ x.

Definition Equation3082 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ y) ◇ z) ◇ y.

Definition Equation3083 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ y) ◇ z) ◇ z.

Definition Equation3084 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((x ◇ y) ◇ y) ◇ z) ◇ w.

Definition Equation3085 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ z) ◇ x) ◇ x.

Definition Equation3086 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ z) ◇ x) ◇ y.

Definition Equation3087 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ z) ◇ x) ◇ z.

Definition Equation3088 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((x ◇ y) ◇ z) ◇ x) ◇ w.

Definition Equation3089 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ z) ◇ y) ◇ x.

Definition Equation3090 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ z) ◇ y) ◇ y.

Definition Equation3091 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ z) ◇ y) ◇ z.

Definition Equation3092 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((x ◇ y) ◇ z) ◇ y) ◇ w.

Definition Equation3093 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ z) ◇ z) ◇ x.

Definition Equation3094 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ z) ◇ z) ◇ y.

Definition Equation3095 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((x ◇ y) ◇ z) ◇ z) ◇ z.

Definition Equation3096 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((x ◇ y) ◇ z) ◇ z) ◇ w.

Definition Equation3097 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((x ◇ y) ◇ z) ◇ w) ◇ x.

Definition Equation3098 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((x ◇ y) ◇ z) ◇ w) ◇ y.

Definition Equation3099 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((x ◇ y) ◇ z) ◇ w) ◇ z.

Definition Equation3100 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((x ◇ y) ◇ z) ◇ w) ◇ w.

Definition Equation3101 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((x ◇ y) ◇ z) ◇ w) ◇ u.

Definition Equation3102 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ x) ◇ x) ◇ x) ◇ x.

Definition Equation3103 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ x) ◇ x) ◇ x) ◇ y.

Definition Equation3104 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ x) ◇ x) ◇ z.

Definition Equation3105 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ x) ◇ x) ◇ y) ◇ x.

Definition Equation3106 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ x) ◇ x) ◇ y) ◇ y.

Definition Equation3107 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ x) ◇ y) ◇ z.

Definition Equation3108 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ x) ◇ z) ◇ x.

Definition Equation3109 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ x) ◇ z) ◇ y.

Definition Equation3110 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ x) ◇ z) ◇ z.

Definition Equation3111 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ x) ◇ x) ◇ z) ◇ w.

Definition Equation3112 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ x) ◇ y) ◇ x) ◇ x.

Definition Equation3113 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ x) ◇ y) ◇ x) ◇ y.

Definition Equation3114 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ y) ◇ x) ◇ z.

Definition Equation3115 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ x) ◇ y) ◇ y) ◇ x.

Definition Equation3116 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ x) ◇ y) ◇ y) ◇ y.

Definition Equation3117 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ y) ◇ y) ◇ z.

Definition Equation3118 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ y) ◇ z) ◇ x.

Definition Equation3119 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ y) ◇ z) ◇ y.

Definition Equation3120 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ y) ◇ z) ◇ z.

Definition Equation3121 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ x) ◇ y) ◇ z) ◇ w.

Definition Equation3122 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ z) ◇ x) ◇ x.

Definition Equation3123 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ z) ◇ x) ◇ y.

Definition Equation3124 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ z) ◇ x) ◇ z.

Definition Equation3125 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ x) ◇ z) ◇ x) ◇ w.

Definition Equation3126 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ z) ◇ y) ◇ x.

Definition Equation3127 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ z) ◇ y) ◇ y.

Definition Equation3128 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ z) ◇ y) ◇ z.

Definition Equation3129 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ x) ◇ z) ◇ y) ◇ w.

Definition Equation3130 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ z) ◇ z) ◇ x.

Definition Equation3131 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ z) ◇ z) ◇ y.

Definition Equation3132 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ x) ◇ z) ◇ z) ◇ z.

Definition Equation3133 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ x) ◇ z) ◇ z) ◇ w.

Definition Equation3134 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ x) ◇ z) ◇ w) ◇ x.

Definition Equation3135 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ x) ◇ z) ◇ w) ◇ y.

Definition Equation3136 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ x) ◇ z) ◇ w) ◇ z.

Definition Equation3137 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ x) ◇ z) ◇ w) ◇ w.

Definition Equation3138 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ x) ◇ z) ◇ w) ◇ u.

Definition Equation3139 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ y) ◇ x) ◇ x) ◇ x.

Definition Equation3140 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ y) ◇ x) ◇ x) ◇ y.

Definition Equation3141 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ x) ◇ x) ◇ z.

Definition Equation3142 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ y) ◇ x) ◇ y) ◇ x.

Definition Equation3143 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ y) ◇ x) ◇ y) ◇ y.

Definition Equation3144 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ x) ◇ y) ◇ z.

Definition Equation3145 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ x) ◇ z) ◇ x.

Definition Equation3146 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ x) ◇ z) ◇ y.

Definition Equation3147 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ x) ◇ z) ◇ z.

Definition Equation3148 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ y) ◇ x) ◇ z) ◇ w.

Definition Equation3149 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ y) ◇ y) ◇ x) ◇ x.

Definition Equation3150 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ y) ◇ y) ◇ x) ◇ y.

Definition Equation3151 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ y) ◇ x) ◇ z.

Definition Equation3152 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ y) ◇ y) ◇ y) ◇ x.

Definition Equation3153 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (((y ◇ y) ◇ y) ◇ y) ◇ y.

Definition Equation3154 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ y) ◇ y) ◇ z.

Definition Equation3155 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ y) ◇ z) ◇ x.

Definition Equation3156 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ y) ◇ z) ◇ y.

Definition Equation3157 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ y) ◇ z) ◇ z.

Definition Equation3158 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ y) ◇ y) ◇ z) ◇ w.

Definition Equation3159 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ z) ◇ x) ◇ x.

Definition Equation3160 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ z) ◇ x) ◇ y.

Definition Equation3161 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ z) ◇ x) ◇ z.

Definition Equation3162 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ y) ◇ z) ◇ x) ◇ w.

Definition Equation3163 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ z) ◇ y) ◇ x.

Definition Equation3164 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ z) ◇ y) ◇ y.

Definition Equation3165 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ z) ◇ y) ◇ z.

Definition Equation3166 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ y) ◇ z) ◇ y) ◇ w.

Definition Equation3167 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ z) ◇ z) ◇ x.

Definition Equation3168 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ z) ◇ z) ◇ y.

Definition Equation3169 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ z) ◇ z) ◇ z.

Definition Equation3170 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ y) ◇ z) ◇ z) ◇ w.

Definition Equation3171 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ y) ◇ z) ◇ w) ◇ x.

Definition Equation3172 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ y) ◇ z) ◇ w) ◇ y.

Definition Equation3173 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ y) ◇ z) ◇ w) ◇ z.

Definition Equation3174 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ y) ◇ z) ◇ w) ◇ w.

Definition Equation3175 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ y) ◇ z) ◇ w) ◇ u.

Definition Equation3176 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ x) ◇ x) ◇ x.

Definition Equation3177 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ x) ◇ x) ◇ y.

Definition Equation3178 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ x) ◇ x) ◇ z.

Definition Equation3179 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ x) ◇ x) ◇ w.

Definition Equation3180 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ x) ◇ y) ◇ x.

Definition Equation3181 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ x) ◇ y) ◇ y.

Definition Equation3182 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ x) ◇ y) ◇ z.

Definition Equation3183 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ x) ◇ y) ◇ w.

Definition Equation3184 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ x) ◇ z) ◇ x.

Definition Equation3185 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ x) ◇ z) ◇ y.

Definition Equation3186 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ x) ◇ z) ◇ z.

Definition Equation3187 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ x) ◇ z) ◇ w.

Definition Equation3188 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ x) ◇ w) ◇ x.

Definition Equation3189 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ x) ◇ w) ◇ y.

Definition Equation3190 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ x) ◇ w) ◇ z.

Definition Equation3191 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ x) ◇ w) ◇ w.

Definition Equation3192 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ z) ◇ x) ◇ w) ◇ u.

Definition Equation3193 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ y) ◇ x) ◇ x.

Definition Equation3194 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ y) ◇ x) ◇ y.

Definition Equation3195 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ y) ◇ x) ◇ z.

Definition Equation3196 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ y) ◇ x) ◇ w.

Definition Equation3197 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ y) ◇ y) ◇ x.

Definition Equation3198 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ y) ◇ y) ◇ y.

Definition Equation3199 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ y) ◇ y) ◇ z.

Definition Equation3200 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ y) ◇ y) ◇ w.

Definition Equation3201 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ y) ◇ z) ◇ x.

Definition Equation3202 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ y) ◇ z) ◇ y.

Definition Equation3203 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ y) ◇ z) ◇ z.

Definition Equation3204 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ y) ◇ z) ◇ w.

Definition Equation3205 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ y) ◇ w) ◇ x.

Definition Equation3206 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ y) ◇ w) ◇ y.

Definition Equation3207 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ y) ◇ w) ◇ z.

Definition Equation3208 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ y) ◇ w) ◇ w.

Definition Equation3209 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ z) ◇ y) ◇ w) ◇ u.

Definition Equation3210 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ z) ◇ x) ◇ x.

Definition Equation3211 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ z) ◇ x) ◇ y.

Definition Equation3212 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ z) ◇ x) ◇ z.

Definition Equation3213 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ z) ◇ x) ◇ w.

Definition Equation3214 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ z) ◇ y) ◇ x.

Definition Equation3215 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ z) ◇ y) ◇ y.

Definition Equation3216 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ z) ◇ y) ◇ z.

Definition Equation3217 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ z) ◇ y) ◇ w.

Definition Equation3218 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ z) ◇ z) ◇ x.

Definition Equation3219 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ z) ◇ z) ◇ y.

Definition Equation3220 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ z) ◇ z) ◇ z) ◇ z.

Definition Equation3221 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ z) ◇ z) ◇ w.

Definition Equation3222 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ z) ◇ w) ◇ x.

Definition Equation3223 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ z) ◇ w) ◇ y.

Definition Equation3224 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ z) ◇ w) ◇ z.

Definition Equation3225 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ z) ◇ w) ◇ w.

Definition Equation3226 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ z) ◇ z) ◇ w) ◇ u.

Definition Equation3227 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ x) ◇ x.

Definition Equation3228 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ x) ◇ y.

Definition Equation3229 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ x) ◇ z.

Definition Equation3230 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ x) ◇ w.

Definition Equation3231 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ z) ◇ w) ◇ x) ◇ u.

Definition Equation3232 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ y) ◇ x.

Definition Equation3233 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ y) ◇ y.

Definition Equation3234 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ y) ◇ z.

Definition Equation3235 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ y) ◇ w.

Definition Equation3236 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ z) ◇ w) ◇ y) ◇ u.

Definition Equation3237 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ z) ◇ x.

Definition Equation3238 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ z) ◇ y.

Definition Equation3239 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ z) ◇ z.

Definition Equation3240 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ z) ◇ w.

Definition Equation3241 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ z) ◇ w) ◇ z) ◇ u.

Definition Equation3242 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ w) ◇ x.

Definition Equation3243 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ w) ◇ y.

Definition Equation3244 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ w) ◇ z.

Definition Equation3245 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (((y ◇ z) ◇ w) ◇ w) ◇ w.

Definition Equation3246 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ z) ◇ w) ◇ w) ◇ u.

Definition Equation3247 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ z) ◇ w) ◇ u) ◇ x.

Definition Equation3248 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ z) ◇ w) ◇ u) ◇ y.

Definition Equation3249 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ z) ◇ w) ◇ u) ◇ z.

Definition Equation3250 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ z) ◇ w) ◇ u) ◇ w.

Definition Equation3251 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (((y ◇ z) ◇ w) ◇ u) ◇ u.

Definition Equation3252 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = (((y ◇ z) ◇ w) ◇ u) ◇ v.

Definition Equation3253 (G : Type) `{Magma G} : Prop :=
  forall x : G, x ◇ x = x ◇ (x ◇ (x ◇ x)).

Definition Equation3254 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ (x ◇ (x ◇ y)).

Definition Equation3255 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ (x ◇ (y ◇ x)).

Definition Equation3256 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ (x ◇ (y ◇ y)).

Definition Equation3257 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = x ◇ (x ◇ (y ◇ z)).

Definition Equation3258 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ (y ◇ (x ◇ x)).

Definition Equation3259 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ (y ◇ (x ◇ y)).

Definition Equation3260 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = x ◇ (y ◇ (x ◇ z)).

Definition Equation3261 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ (y ◇ (y ◇ x)).

Definition Equation3262 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ (y ◇ (y ◇ y)).

Definition Equation3263 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = x ◇ (y ◇ (y ◇ z)).

Definition Equation3264 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = x ◇ (y ◇ (z ◇ x)).

Definition Equation3265 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = x ◇ (y ◇ (z ◇ y)).

Definition Equation3266 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = x ◇ (y ◇ (z ◇ z)).

Definition Equation3267 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = x ◇ (y ◇ (z ◇ w)).

Definition Equation3268 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ (x ◇ (x ◇ x)).

Definition Equation3269 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ (x ◇ (x ◇ y)).

Definition Equation3270 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (x ◇ (x ◇ z)).

Definition Equation3271 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ (x ◇ (y ◇ x)).

Definition Equation3272 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ (x ◇ (y ◇ y)).

Definition Equation3273 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (x ◇ (y ◇ z)).

Definition Equation3274 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (x ◇ (z ◇ x)).

Definition Equation3275 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (x ◇ (z ◇ y)).

Definition Equation3276 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (x ◇ (z ◇ z)).

Definition Equation3277 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ (x ◇ (z ◇ w)).

Definition Equation3278 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ (y ◇ (x ◇ x)).

Definition Equation3279 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ (y ◇ (x ◇ y)).

Definition Equation3280 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (y ◇ (x ◇ z)).

Definition Equation3281 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ (y ◇ (y ◇ x)).

Definition Equation3282 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ (y ◇ (y ◇ y)).

Definition Equation3283 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (y ◇ (y ◇ z)).

Definition Equation3284 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (y ◇ (z ◇ x)).

Definition Equation3285 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (y ◇ (z ◇ y)).

Definition Equation3286 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (y ◇ (z ◇ z)).

Definition Equation3287 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ (y ◇ (z ◇ w)).

Definition Equation3288 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (z ◇ (x ◇ x)).

Definition Equation3289 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (z ◇ (x ◇ y)).

Definition Equation3290 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (z ◇ (x ◇ z)).

Definition Equation3291 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ (z ◇ (x ◇ w)).

Definition Equation3292 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (z ◇ (y ◇ x)).

Definition Equation3293 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (z ◇ (y ◇ y)).

Definition Equation3294 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (z ◇ (y ◇ z)).

Definition Equation3295 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ (z ◇ (y ◇ w)).

Definition Equation3296 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (z ◇ (z ◇ x)).

Definition Equation3297 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (z ◇ (z ◇ y)).

Definition Equation3298 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ (z ◇ (z ◇ z)).

Definition Equation3299 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ (z ◇ (z ◇ w)).

Definition Equation3300 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ (z ◇ (w ◇ x)).

Definition Equation3301 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ (z ◇ (w ◇ y)).

Definition Equation3302 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ (z ◇ (w ◇ z)).

Definition Equation3303 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ (z ◇ (w ◇ w)).

Definition Equation3304 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ x = y ◇ (z ◇ (w ◇ u)).

Definition Equation3305 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ (x ◇ (x ◇ x)).

Definition Equation3306 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ (x ◇ (x ◇ y)).

Definition Equation3307 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (x ◇ (x ◇ z)).

Definition Equation3308 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ (x ◇ (y ◇ x)).

Definition Equation3309 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ (x ◇ (y ◇ y)).

Definition Equation3310 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (x ◇ (y ◇ z)).

Definition Equation3311 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (x ◇ (z ◇ x)).

Definition Equation3312 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (x ◇ (z ◇ y)).

Definition Equation3313 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (x ◇ (z ◇ z)).

Definition Equation3314 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ (x ◇ (z ◇ w)).

Definition Equation3315 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ (y ◇ (x ◇ x)).

Definition Equation3316 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ (y ◇ (x ◇ y)).

Definition Equation3317 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (y ◇ (x ◇ z)).

Definition Equation3318 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ (y ◇ (y ◇ x)).

Definition Equation3319 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ (y ◇ (y ◇ y)).

Definition Equation3320 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (y ◇ (y ◇ z)).

Definition Equation3321 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (y ◇ (z ◇ x)).

Definition Equation3322 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (y ◇ (z ◇ y)).

Definition Equation3323 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (y ◇ (z ◇ z)).

Definition Equation3324 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ (y ◇ (z ◇ w)).

Definition Equation3325 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (z ◇ (x ◇ x)).

Definition Equation3326 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (z ◇ (x ◇ y)).

Definition Equation3327 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (z ◇ (x ◇ z)).

Definition Equation3328 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ (z ◇ (x ◇ w)).

Definition Equation3329 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (z ◇ (y ◇ x)).

Definition Equation3330 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (z ◇ (y ◇ y)).

Definition Equation3331 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (z ◇ (y ◇ z)).

Definition Equation3332 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ (z ◇ (y ◇ w)).

Definition Equation3333 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (z ◇ (z ◇ x)).

Definition Equation3334 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (z ◇ (z ◇ y)).

Definition Equation3335 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ (z ◇ (z ◇ z)).

Definition Equation3336 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ (z ◇ (z ◇ w)).

Definition Equation3337 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ (z ◇ (w ◇ x)).

Definition Equation3338 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ (z ◇ (w ◇ y)).

Definition Equation3339 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ (z ◇ (w ◇ z)).

Definition Equation3340 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ (z ◇ (w ◇ w)).

Definition Equation3341 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = x ◇ (z ◇ (w ◇ u)).

Definition Equation3342 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ (x ◇ (x ◇ x)).

Definition Equation3343 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ (x ◇ (x ◇ y)).

Definition Equation3344 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (x ◇ (x ◇ z)).

Definition Equation3345 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ (x ◇ (y ◇ x)).

Definition Equation3346 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ (x ◇ (y ◇ y)).

Definition Equation3347 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (x ◇ (y ◇ z)).

Definition Equation3348 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (x ◇ (z ◇ x)).

Definition Equation3349 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (x ◇ (z ◇ y)).

Definition Equation3350 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (x ◇ (z ◇ z)).

Definition Equation3351 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ (x ◇ (z ◇ w)).

Definition Equation3352 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ (y ◇ (x ◇ x)).

Definition Equation3353 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ (y ◇ (x ◇ y)).

Definition Equation3354 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (y ◇ (x ◇ z)).

Definition Equation3355 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ (y ◇ (y ◇ x)).

Definition Equation3356 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ (y ◇ (y ◇ y)).

Definition Equation3357 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (y ◇ (y ◇ z)).

Definition Equation3358 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (y ◇ (z ◇ x)).

Definition Equation3359 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (y ◇ (z ◇ y)).

Definition Equation3360 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (y ◇ (z ◇ z)).

Definition Equation3361 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ (y ◇ (z ◇ w)).

Definition Equation3362 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (z ◇ (x ◇ x)).

Definition Equation3363 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (z ◇ (x ◇ y)).

Definition Equation3364 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (z ◇ (x ◇ z)).

Definition Equation3365 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ (z ◇ (x ◇ w)).

Definition Equation3366 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (z ◇ (y ◇ x)).

Definition Equation3367 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (z ◇ (y ◇ y)).

Definition Equation3368 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (z ◇ (y ◇ z)).

Definition Equation3369 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ (z ◇ (y ◇ w)).

Definition Equation3370 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (z ◇ (z ◇ x)).

Definition Equation3371 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (z ◇ (z ◇ y)).

Definition Equation3372 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ (z ◇ (z ◇ z)).

Definition Equation3373 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ (z ◇ (z ◇ w)).

Definition Equation3374 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ (z ◇ (w ◇ x)).

Definition Equation3375 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ (z ◇ (w ◇ y)).

Definition Equation3376 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ (z ◇ (w ◇ z)).

Definition Equation3377 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ (z ◇ (w ◇ w)).

Definition Equation3378 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = y ◇ (z ◇ (w ◇ u)).

Definition Equation3379 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (x ◇ (x ◇ x)).

Definition Equation3380 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (x ◇ (x ◇ y)).

Definition Equation3381 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (x ◇ (x ◇ z)).

Definition Equation3382 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (x ◇ (x ◇ w)).

Definition Equation3383 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (x ◇ (y ◇ x)).

Definition Equation3384 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (x ◇ (y ◇ y)).

Definition Equation3385 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (x ◇ (y ◇ z)).

Definition Equation3386 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (x ◇ (y ◇ w)).

Definition Equation3387 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (x ◇ (z ◇ x)).

Definition Equation3388 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (x ◇ (z ◇ y)).

Definition Equation3389 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (x ◇ (z ◇ z)).

Definition Equation3390 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (x ◇ (z ◇ w)).

Definition Equation3391 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (x ◇ (w ◇ x)).

Definition Equation3392 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (x ◇ (w ◇ y)).

Definition Equation3393 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (x ◇ (w ◇ z)).

Definition Equation3394 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (x ◇ (w ◇ w)).

Definition Equation3395 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ (x ◇ (w ◇ u)).

Definition Equation3396 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (y ◇ (x ◇ x)).

Definition Equation3397 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (y ◇ (x ◇ y)).

Definition Equation3398 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (y ◇ (x ◇ z)).

Definition Equation3399 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (y ◇ (x ◇ w)).

Definition Equation3400 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (y ◇ (y ◇ x)).

Definition Equation3401 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (y ◇ (y ◇ y)).

Definition Equation3402 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (y ◇ (y ◇ z)).

Definition Equation3403 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (y ◇ (y ◇ w)).

Definition Equation3404 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (y ◇ (z ◇ x)).

Definition Equation3405 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (y ◇ (z ◇ y)).

Definition Equation3406 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (y ◇ (z ◇ z)).

Definition Equation3407 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (y ◇ (z ◇ w)).

Definition Equation3408 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (y ◇ (w ◇ x)).

Definition Equation3409 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (y ◇ (w ◇ y)).

Definition Equation3410 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (y ◇ (w ◇ z)).

Definition Equation3411 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (y ◇ (w ◇ w)).

Definition Equation3412 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ (y ◇ (w ◇ u)).

Definition Equation3413 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (z ◇ (x ◇ x)).

Definition Equation3414 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (z ◇ (x ◇ y)).

Definition Equation3415 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (z ◇ (x ◇ z)).

Definition Equation3416 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (z ◇ (x ◇ w)).

Definition Equation3417 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (z ◇ (y ◇ x)).

Definition Equation3418 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (z ◇ (y ◇ y)).

Definition Equation3419 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (z ◇ (y ◇ z)).

Definition Equation3420 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (z ◇ (y ◇ w)).

Definition Equation3421 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (z ◇ (z ◇ x)).

Definition Equation3422 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (z ◇ (z ◇ y)).

Definition Equation3423 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ (z ◇ (z ◇ z)).

Definition Equation3424 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (z ◇ (z ◇ w)).

Definition Equation3425 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (z ◇ (w ◇ x)).

Definition Equation3426 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (z ◇ (w ◇ y)).

Definition Equation3427 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (z ◇ (w ◇ z)).

Definition Equation3428 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (z ◇ (w ◇ w)).

Definition Equation3429 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ (z ◇ (w ◇ u)).

Definition Equation3430 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (x ◇ x)).

Definition Equation3431 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (x ◇ y)).

Definition Equation3432 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (x ◇ z)).

Definition Equation3433 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (x ◇ w)).

Definition Equation3434 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ (w ◇ (x ◇ u)).

Definition Equation3435 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (y ◇ x)).

Definition Equation3436 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (y ◇ y)).

Definition Equation3437 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (y ◇ z)).

Definition Equation3438 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (y ◇ w)).

Definition Equation3439 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ (w ◇ (y ◇ u)).

Definition Equation3440 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (z ◇ x)).

Definition Equation3441 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (z ◇ y)).

Definition Equation3442 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (z ◇ z)).

Definition Equation3443 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (z ◇ w)).

Definition Equation3444 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ (w ◇ (z ◇ u)).

Definition Equation3445 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (w ◇ x)).

Definition Equation3446 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (w ◇ y)).

Definition Equation3447 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (w ◇ z)).

Definition Equation3448 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ (w ◇ (w ◇ w)).

Definition Equation3449 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ (w ◇ (w ◇ u)).

Definition Equation3450 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ (w ◇ (u ◇ x)).

Definition Equation3451 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ (w ◇ (u ◇ y)).

Definition Equation3452 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ (w ◇ (u ◇ z)).

Definition Equation3453 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ (w ◇ (u ◇ w)).

Definition Equation3454 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ (w ◇ (u ◇ u)).

Definition Equation3455 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x ◇ y = z ◇ (w ◇ (u ◇ v)).

Definition Equation3456 (G : Type) `{Magma G} : Prop :=
  forall x : G, x ◇ x = x ◇ ((x ◇ x) ◇ x).

Definition Equation3457 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ ((x ◇ x) ◇ y).

Definition Equation3458 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ ((x ◇ y) ◇ x).

Definition Equation3459 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ ((x ◇ y) ◇ y).

Definition Equation3460 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = x ◇ ((x ◇ y) ◇ z).

Definition Equation3461 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ ((y ◇ x) ◇ x).

Definition Equation3462 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ ((y ◇ x) ◇ y).

Definition Equation3463 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = x ◇ ((y ◇ x) ◇ z).

Definition Equation3464 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ ((y ◇ y) ◇ x).

Definition Equation3465 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = x ◇ ((y ◇ y) ◇ y).

Definition Equation3466 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = x ◇ ((y ◇ y) ◇ z).

Definition Equation3467 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = x ◇ ((y ◇ z) ◇ x).

Definition Equation3468 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = x ◇ ((y ◇ z) ◇ y).

Definition Equation3469 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = x ◇ ((y ◇ z) ◇ z).

Definition Equation3470 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = x ◇ ((y ◇ z) ◇ w).

Definition Equation3471 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ ((x ◇ x) ◇ x).

Definition Equation3472 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ ((x ◇ x) ◇ y).

Definition Equation3473 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((x ◇ x) ◇ z).

Definition Equation3474 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ ((x ◇ y) ◇ x).

Definition Equation3475 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ ((x ◇ y) ◇ y).

Definition Equation3476 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((x ◇ y) ◇ z).

Definition Equation3477 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((x ◇ z) ◇ x).

Definition Equation3478 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((x ◇ z) ◇ y).

Definition Equation3479 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((x ◇ z) ◇ z).

Definition Equation3480 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ ((x ◇ z) ◇ w).

Definition Equation3481 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ ((y ◇ x) ◇ x).

Definition Equation3482 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ ((y ◇ x) ◇ y).

Definition Equation3483 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((y ◇ x) ◇ z).

Definition Equation3484 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ ((y ◇ y) ◇ x).

Definition Equation3485 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = y ◇ ((y ◇ y) ◇ y).

Definition Equation3486 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((y ◇ y) ◇ z).

Definition Equation3487 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((y ◇ z) ◇ x).

Definition Equation3488 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((y ◇ z) ◇ y).

Definition Equation3489 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((y ◇ z) ◇ z).

Definition Equation3490 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ ((y ◇ z) ◇ w).

Definition Equation3491 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((z ◇ x) ◇ x).

Definition Equation3492 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((z ◇ x) ◇ y).

Definition Equation3493 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((z ◇ x) ◇ z).

Definition Equation3494 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ ((z ◇ x) ◇ w).

Definition Equation3495 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((z ◇ y) ◇ x).

Definition Equation3496 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((z ◇ y) ◇ y).

Definition Equation3497 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((z ◇ y) ◇ z).

Definition Equation3498 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ ((z ◇ y) ◇ w).

Definition Equation3499 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((z ◇ z) ◇ x).

Definition Equation3500 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((z ◇ z) ◇ y).

Definition Equation3501 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = y ◇ ((z ◇ z) ◇ z).

Definition Equation3502 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ ((z ◇ z) ◇ w).

Definition Equation3503 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ ((z ◇ w) ◇ x).

Definition Equation3504 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ ((z ◇ w) ◇ y).

Definition Equation3505 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ ((z ◇ w) ◇ z).

Definition Equation3506 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = y ◇ ((z ◇ w) ◇ w).

Definition Equation3507 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ x = y ◇ ((z ◇ w) ◇ u).

Definition Equation3508 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ ((x ◇ x) ◇ x).

Definition Equation3509 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ ((x ◇ x) ◇ y).

Definition Equation3510 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((x ◇ x) ◇ z).

Definition Equation3511 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ ((x ◇ y) ◇ x).

Definition Equation3512 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ ((x ◇ y) ◇ y).

Definition Equation3513 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((x ◇ y) ◇ z).

Definition Equation3514 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((x ◇ z) ◇ x).

Definition Equation3515 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((x ◇ z) ◇ y).

Definition Equation3516 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((x ◇ z) ◇ z).

Definition Equation3517 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ ((x ◇ z) ◇ w).

Definition Equation3518 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ ((y ◇ x) ◇ x).

Definition Equation3519 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ ((y ◇ x) ◇ y).

Definition Equation3520 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((y ◇ x) ◇ z).

Definition Equation3521 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ ((y ◇ y) ◇ x).

Definition Equation3522 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = x ◇ ((y ◇ y) ◇ y).

Definition Equation3523 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((y ◇ y) ◇ z).

Definition Equation3524 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((y ◇ z) ◇ x).

Definition Equation3525 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((y ◇ z) ◇ y).

Definition Equation3526 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((y ◇ z) ◇ z).

Definition Equation3527 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ ((y ◇ z) ◇ w).

Definition Equation3528 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((z ◇ x) ◇ x).

Definition Equation3529 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((z ◇ x) ◇ y).

Definition Equation3530 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((z ◇ x) ◇ z).

Definition Equation3531 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ ((z ◇ x) ◇ w).

Definition Equation3532 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((z ◇ y) ◇ x).

Definition Equation3533 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((z ◇ y) ◇ y).

Definition Equation3534 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((z ◇ y) ◇ z).

Definition Equation3535 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ ((z ◇ y) ◇ w).

Definition Equation3536 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((z ◇ z) ◇ x).

Definition Equation3537 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((z ◇ z) ◇ y).

Definition Equation3538 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = x ◇ ((z ◇ z) ◇ z).

Definition Equation3539 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ ((z ◇ z) ◇ w).

Definition Equation3540 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ ((z ◇ w) ◇ x).

Definition Equation3541 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ ((z ◇ w) ◇ y).

Definition Equation3542 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ ((z ◇ w) ◇ z).

Definition Equation3543 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = x ◇ ((z ◇ w) ◇ w).

Definition Equation3544 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = x ◇ ((z ◇ w) ◇ u).

Definition Equation3545 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ ((x ◇ x) ◇ x).

Definition Equation3546 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ ((x ◇ x) ◇ y).

Definition Equation3547 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((x ◇ x) ◇ z).

Definition Equation3548 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ ((x ◇ y) ◇ x).

Definition Equation3549 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ ((x ◇ y) ◇ y).

Definition Equation3550 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((x ◇ y) ◇ z).

Definition Equation3551 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((x ◇ z) ◇ x).

Definition Equation3552 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((x ◇ z) ◇ y).

Definition Equation3553 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((x ◇ z) ◇ z).

Definition Equation3554 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ ((x ◇ z) ◇ w).

Definition Equation3555 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ ((y ◇ x) ◇ x).

Definition Equation3556 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ ((y ◇ x) ◇ y).

Definition Equation3557 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((y ◇ x) ◇ z).

Definition Equation3558 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ ((y ◇ y) ◇ x).

Definition Equation3559 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = y ◇ ((y ◇ y) ◇ y).

Definition Equation3560 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((y ◇ y) ◇ z).

Definition Equation3561 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((y ◇ z) ◇ x).

Definition Equation3562 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((y ◇ z) ◇ y).

Definition Equation3563 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((y ◇ z) ◇ z).

Definition Equation3564 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ ((y ◇ z) ◇ w).

Definition Equation3565 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((z ◇ x) ◇ x).

Definition Equation3566 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((z ◇ x) ◇ y).

Definition Equation3567 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((z ◇ x) ◇ z).

Definition Equation3568 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ ((z ◇ x) ◇ w).

Definition Equation3569 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((z ◇ y) ◇ x).

Definition Equation3570 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((z ◇ y) ◇ y).

Definition Equation3571 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((z ◇ y) ◇ z).

Definition Equation3572 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ ((z ◇ y) ◇ w).

Definition Equation3573 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((z ◇ z) ◇ x).

Definition Equation3574 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((z ◇ z) ◇ y).

Definition Equation3575 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = y ◇ ((z ◇ z) ◇ z).

Definition Equation3576 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ ((z ◇ z) ◇ w).

Definition Equation3577 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ ((z ◇ w) ◇ x).

Definition Equation3578 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ ((z ◇ w) ◇ y).

Definition Equation3579 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ ((z ◇ w) ◇ z).

Definition Equation3580 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = y ◇ ((z ◇ w) ◇ w).

Definition Equation3581 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = y ◇ ((z ◇ w) ◇ u).

Definition Equation3582 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((x ◇ x) ◇ x).

Definition Equation3583 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((x ◇ x) ◇ y).

Definition Equation3584 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((x ◇ x) ◇ z).

Definition Equation3585 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((x ◇ x) ◇ w).

Definition Equation3586 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((x ◇ y) ◇ x).

Definition Equation3587 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((x ◇ y) ◇ y).

Definition Equation3588 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((x ◇ y) ◇ z).

Definition Equation3589 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((x ◇ y) ◇ w).

Definition Equation3590 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((x ◇ z) ◇ x).

Definition Equation3591 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((x ◇ z) ◇ y).

Definition Equation3592 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((x ◇ z) ◇ z).

Definition Equation3593 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((x ◇ z) ◇ w).

Definition Equation3594 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((x ◇ w) ◇ x).

Definition Equation3595 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((x ◇ w) ◇ y).

Definition Equation3596 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((x ◇ w) ◇ z).

Definition Equation3597 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((x ◇ w) ◇ w).

Definition Equation3598 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ ((x ◇ w) ◇ u).

Definition Equation3599 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((y ◇ x) ◇ x).

Definition Equation3600 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((y ◇ x) ◇ y).

Definition Equation3601 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((y ◇ x) ◇ z).

Definition Equation3602 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((y ◇ x) ◇ w).

Definition Equation3603 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((y ◇ y) ◇ x).

Definition Equation3604 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((y ◇ y) ◇ y).

Definition Equation3605 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((y ◇ y) ◇ z).

Definition Equation3606 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((y ◇ y) ◇ w).

Definition Equation3607 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((y ◇ z) ◇ x).

Definition Equation3608 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((y ◇ z) ◇ y).

Definition Equation3609 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((y ◇ z) ◇ z).

Definition Equation3610 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((y ◇ z) ◇ w).

Definition Equation3611 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((y ◇ w) ◇ x).

Definition Equation3612 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((y ◇ w) ◇ y).

Definition Equation3613 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((y ◇ w) ◇ z).

Definition Equation3614 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((y ◇ w) ◇ w).

Definition Equation3615 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ ((y ◇ w) ◇ u).

Definition Equation3616 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((z ◇ x) ◇ x).

Definition Equation3617 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((z ◇ x) ◇ y).

Definition Equation3618 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((z ◇ x) ◇ z).

Definition Equation3619 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((z ◇ x) ◇ w).

Definition Equation3620 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((z ◇ y) ◇ x).

Definition Equation3621 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((z ◇ y) ◇ y).

Definition Equation3622 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((z ◇ y) ◇ z).

Definition Equation3623 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((z ◇ y) ◇ w).

Definition Equation3624 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((z ◇ z) ◇ x).

Definition Equation3625 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((z ◇ z) ◇ y).

Definition Equation3626 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = z ◇ ((z ◇ z) ◇ z).

Definition Equation3627 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((z ◇ z) ◇ w).

Definition Equation3628 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((z ◇ w) ◇ x).

Definition Equation3629 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((z ◇ w) ◇ y).

Definition Equation3630 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((z ◇ w) ◇ z).

Definition Equation3631 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((z ◇ w) ◇ w).

Definition Equation3632 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ ((z ◇ w) ◇ u).

Definition Equation3633 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ x) ◇ x).

Definition Equation3634 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ x) ◇ y).

Definition Equation3635 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ x) ◇ z).

Definition Equation3636 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ x) ◇ w).

Definition Equation3637 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ ((w ◇ x) ◇ u).

Definition Equation3638 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ y) ◇ x).

Definition Equation3639 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ y) ◇ y).

Definition Equation3640 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ y) ◇ z).

Definition Equation3641 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ y) ◇ w).

Definition Equation3642 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ ((w ◇ y) ◇ u).

Definition Equation3643 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ z) ◇ x).

Definition Equation3644 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ z) ◇ y).

Definition Equation3645 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ z) ◇ z).

Definition Equation3646 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ z) ◇ w).

Definition Equation3647 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ ((w ◇ z) ◇ u).

Definition Equation3648 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ w) ◇ x).

Definition Equation3649 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ w) ◇ y).

Definition Equation3650 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ w) ◇ z).

Definition Equation3651 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = z ◇ ((w ◇ w) ◇ w).

Definition Equation3652 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ ((w ◇ w) ◇ u).

Definition Equation3653 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ ((w ◇ u) ◇ x).

Definition Equation3654 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ ((w ◇ u) ◇ y).

Definition Equation3655 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ ((w ◇ u) ◇ z).

Definition Equation3656 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ ((w ◇ u) ◇ w).

Definition Equation3657 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = z ◇ ((w ◇ u) ◇ u).

Definition Equation3658 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x ◇ y = z ◇ ((w ◇ u) ◇ v).

Definition Equation3659 (G : Type) `{Magma G} : Prop :=
  forall x : G, x ◇ x = (x ◇ x) ◇ (x ◇ x).

Definition Equation3660 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ x) ◇ (x ◇ y).

Definition Equation3661 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ x) ◇ (y ◇ x).

Definition Equation3662 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ x) ◇ (y ◇ y).

Definition Equation3663 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (x ◇ x) ◇ (y ◇ z).

Definition Equation3664 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ y) ◇ (x ◇ x).

Definition Equation3665 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ y) ◇ (x ◇ y).

Definition Equation3666 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (x ◇ y) ◇ (x ◇ z).

Definition Equation3667 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ y) ◇ (y ◇ x).

Definition Equation3668 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ y) ◇ (y ◇ y).

Definition Equation3669 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (x ◇ y) ◇ (y ◇ z).

Definition Equation3670 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (x ◇ y) ◇ (z ◇ x).

Definition Equation3671 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (x ◇ y) ◇ (z ◇ y).

Definition Equation3672 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (x ◇ y) ◇ (z ◇ z).

Definition Equation3673 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (x ◇ y) ◇ (z ◇ w).

Definition Equation3674 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ x) ◇ (x ◇ x).

Definition Equation3675 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ x) ◇ (x ◇ y).

Definition Equation3676 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ x) ◇ (x ◇ z).

Definition Equation3677 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ x) ◇ (y ◇ x).

Definition Equation3678 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ x) ◇ (y ◇ y).

Definition Equation3679 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ x) ◇ (y ◇ z).

Definition Equation3680 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ x) ◇ (z ◇ x).

Definition Equation3681 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ x) ◇ (z ◇ y).

Definition Equation3682 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ x) ◇ (z ◇ z).

Definition Equation3683 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ x) ◇ (z ◇ w).

Definition Equation3684 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ y) ◇ (x ◇ x).

Definition Equation3685 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ y) ◇ (x ◇ y).

Definition Equation3686 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ y) ◇ (x ◇ z).

Definition Equation3687 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ y) ◇ (y ◇ x).

Definition Equation3688 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ y) ◇ (y ◇ y).

Definition Equation3689 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ y) ◇ (y ◇ z).

Definition Equation3690 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ y) ◇ (z ◇ x).

Definition Equation3691 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ y) ◇ (z ◇ y).

Definition Equation3692 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ y) ◇ (z ◇ z).

Definition Equation3693 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ y) ◇ (z ◇ w).

Definition Equation3694 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ z) ◇ (x ◇ x).

Definition Equation3695 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ z) ◇ (x ◇ y).

Definition Equation3696 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ z) ◇ (x ◇ z).

Definition Equation3697 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ z) ◇ (x ◇ w).

Definition Equation3698 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ z) ◇ (y ◇ x).

Definition Equation3699 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ z) ◇ (y ◇ y).

Definition Equation3700 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ z) ◇ (y ◇ z).

Definition Equation3701 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ z) ◇ (y ◇ w).

Definition Equation3702 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ z) ◇ (z ◇ x).

Definition Equation3703 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ z) ◇ (z ◇ y).

Definition Equation3704 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ z) ◇ (z ◇ z).

Definition Equation3705 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ z) ◇ (z ◇ w).

Definition Equation3706 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ z) ◇ (w ◇ x).

Definition Equation3707 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ z) ◇ (w ◇ y).

Definition Equation3708 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ z) ◇ (w ◇ z).

Definition Equation3709 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ z) ◇ (w ◇ w).

Definition Equation3710 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ x = (y ◇ z) ◇ (w ◇ u).

Definition Equation3711 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ x) ◇ (x ◇ x).

Definition Equation3712 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ x) ◇ (x ◇ y).

Definition Equation3713 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ x) ◇ (x ◇ z).

Definition Equation3714 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ x) ◇ (y ◇ x).

Definition Equation3715 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ x) ◇ (y ◇ y).

Definition Equation3716 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ x) ◇ (y ◇ z).

Definition Equation3717 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ x) ◇ (z ◇ x).

Definition Equation3718 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ x) ◇ (z ◇ y).

Definition Equation3719 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ x) ◇ (z ◇ z).

Definition Equation3720 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ x) ◇ (z ◇ w).

Definition Equation3721 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ y) ◇ (x ◇ x).

Definition Equation3722 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ y) ◇ (x ◇ y).

Definition Equation3723 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ y) ◇ (x ◇ z).

Definition Equation3724 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ y) ◇ (y ◇ x).

Definition Equation3725 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ y) ◇ (y ◇ y).

Definition Equation3726 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ y) ◇ (y ◇ z).

Definition Equation3727 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ y) ◇ (z ◇ x).

Definition Equation3728 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ y) ◇ (z ◇ y).

Definition Equation3729 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ y) ◇ (z ◇ z).

Definition Equation3730 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ y) ◇ (z ◇ w).

Definition Equation3731 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ z) ◇ (x ◇ x).

Definition Equation3732 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ z) ◇ (x ◇ y).

Definition Equation3733 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ z) ◇ (x ◇ z).

Definition Equation3734 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ z) ◇ (x ◇ w).

Definition Equation3735 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ z) ◇ (y ◇ x).

Definition Equation3736 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ z) ◇ (y ◇ y).

Definition Equation3737 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ z) ◇ (y ◇ z).

Definition Equation3738 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ z) ◇ (y ◇ w).

Definition Equation3739 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ z) ◇ (z ◇ x).

Definition Equation3740 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ z) ◇ (z ◇ y).

Definition Equation3741 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ z) ◇ (z ◇ z).

Definition Equation3742 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ z) ◇ (z ◇ w).

Definition Equation3743 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ z) ◇ (w ◇ x).

Definition Equation3744 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ z) ◇ (w ◇ y).

Definition Equation3745 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ z) ◇ (w ◇ z).

Definition Equation3746 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ z) ◇ (w ◇ w).

Definition Equation3747 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (x ◇ z) ◇ (w ◇ u).

Definition Equation3748 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ x) ◇ (x ◇ x).

Definition Equation3749 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ x) ◇ (x ◇ y).

Definition Equation3750 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ x) ◇ (x ◇ z).

Definition Equation3751 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ x) ◇ (y ◇ x).

Definition Equation3752 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ x) ◇ (y ◇ y).

Definition Equation3753 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ x) ◇ (y ◇ z).

Definition Equation3754 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ x) ◇ (z ◇ x).

Definition Equation3755 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ x) ◇ (z ◇ y).

Definition Equation3756 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ x) ◇ (z ◇ z).

Definition Equation3757 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ x) ◇ (z ◇ w).

Definition Equation3758 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ y) ◇ (x ◇ x).

Definition Equation3759 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ y) ◇ (x ◇ y).

Definition Equation3760 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ y) ◇ (x ◇ z).

Definition Equation3761 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ y) ◇ (y ◇ x).

Definition Equation3762 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ y) ◇ (y ◇ y).

Definition Equation3763 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ y) ◇ (y ◇ z).

Definition Equation3764 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ y) ◇ (z ◇ x).

Definition Equation3765 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ y) ◇ (z ◇ y).

Definition Equation3766 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ y) ◇ (z ◇ z).

Definition Equation3767 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ y) ◇ (z ◇ w).

Definition Equation3768 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ z) ◇ (x ◇ x).

Definition Equation3769 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ z) ◇ (x ◇ y).

Definition Equation3770 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ z) ◇ (x ◇ z).

Definition Equation3771 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ z) ◇ (x ◇ w).

Definition Equation3772 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ z) ◇ (y ◇ x).

Definition Equation3773 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ z) ◇ (y ◇ y).

Definition Equation3774 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ z) ◇ (y ◇ z).

Definition Equation3775 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ z) ◇ (y ◇ w).

Definition Equation3776 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ z) ◇ (z ◇ x).

Definition Equation3777 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ z) ◇ (z ◇ y).

Definition Equation3778 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ z) ◇ (z ◇ z).

Definition Equation3779 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ z) ◇ (z ◇ w).

Definition Equation3780 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ z) ◇ (w ◇ x).

Definition Equation3781 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ z) ◇ (w ◇ y).

Definition Equation3782 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ z) ◇ (w ◇ z).

Definition Equation3783 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ z) ◇ (w ◇ w).

Definition Equation3784 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (y ◇ z) ◇ (w ◇ u).

Definition Equation3785 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ x) ◇ (x ◇ x).

Definition Equation3786 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ x) ◇ (x ◇ y).

Definition Equation3787 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ x) ◇ (x ◇ z).

Definition Equation3788 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ x) ◇ (x ◇ w).

Definition Equation3789 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ x) ◇ (y ◇ x).

Definition Equation3790 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ x) ◇ (y ◇ y).

Definition Equation3791 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ x) ◇ (y ◇ z).

Definition Equation3792 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ x) ◇ (y ◇ w).

Definition Equation3793 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ x) ◇ (z ◇ x).

Definition Equation3794 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ x) ◇ (z ◇ y).

Definition Equation3795 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ x) ◇ (z ◇ z).

Definition Equation3796 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ x) ◇ (z ◇ w).

Definition Equation3797 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ x) ◇ (w ◇ x).

Definition Equation3798 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ x) ◇ (w ◇ y).

Definition Equation3799 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ x) ◇ (w ◇ z).

Definition Equation3800 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ x) ◇ (w ◇ w).

Definition Equation3801 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ x) ◇ (w ◇ u).

Definition Equation3802 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ y) ◇ (x ◇ x).

Definition Equation3803 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ y) ◇ (x ◇ y).

Definition Equation3804 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ y) ◇ (x ◇ z).

Definition Equation3805 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ y) ◇ (x ◇ w).

Definition Equation3806 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ y) ◇ (y ◇ x).

Definition Equation3807 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ y) ◇ (y ◇ y).

Definition Equation3808 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ y) ◇ (y ◇ z).

Definition Equation3809 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ y) ◇ (y ◇ w).

Definition Equation3810 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ y) ◇ (z ◇ x).

Definition Equation3811 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ y) ◇ (z ◇ y).

Definition Equation3812 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ y) ◇ (z ◇ z).

Definition Equation3813 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ y) ◇ (z ◇ w).

Definition Equation3814 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ y) ◇ (w ◇ x).

Definition Equation3815 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ y) ◇ (w ◇ y).

Definition Equation3816 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ y) ◇ (w ◇ z).

Definition Equation3817 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ y) ◇ (w ◇ w).

Definition Equation3818 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ y) ◇ (w ◇ u).

Definition Equation3819 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ z) ◇ (x ◇ x).

Definition Equation3820 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ z) ◇ (x ◇ y).

Definition Equation3821 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ z) ◇ (x ◇ z).

Definition Equation3822 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ z) ◇ (x ◇ w).

Definition Equation3823 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ z) ◇ (y ◇ x).

Definition Equation3824 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ z) ◇ (y ◇ y).

Definition Equation3825 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ z) ◇ (y ◇ z).

Definition Equation3826 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ z) ◇ (y ◇ w).

Definition Equation3827 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ z) ◇ (z ◇ x).

Definition Equation3828 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ z) ◇ (z ◇ y).

Definition Equation3829 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ z) ◇ (z ◇ z).

Definition Equation3830 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ z) ◇ (z ◇ w).

Definition Equation3831 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ z) ◇ (w ◇ x).

Definition Equation3832 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ z) ◇ (w ◇ y).

Definition Equation3833 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ z) ◇ (w ◇ z).

Definition Equation3834 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ z) ◇ (w ◇ w).

Definition Equation3835 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ z) ◇ (w ◇ u).

Definition Equation3836 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (x ◇ x).

Definition Equation3837 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (x ◇ y).

Definition Equation3838 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (x ◇ z).

Definition Equation3839 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (x ◇ w).

Definition Equation3840 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ w) ◇ (x ◇ u).

Definition Equation3841 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (y ◇ x).

Definition Equation3842 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (y ◇ y).

Definition Equation3843 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (y ◇ z).

Definition Equation3844 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (y ◇ w).

Definition Equation3845 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ w) ◇ (y ◇ u).

Definition Equation3846 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (z ◇ x).

Definition Equation3847 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (z ◇ y).

Definition Equation3848 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (z ◇ z).

Definition Equation3849 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (z ◇ w).

Definition Equation3850 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ w) ◇ (z ◇ u).

Definition Equation3851 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (w ◇ x).

Definition Equation3852 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (w ◇ y).

Definition Equation3853 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (w ◇ z).

Definition Equation3854 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ w) ◇ (w ◇ w).

Definition Equation3855 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ w) ◇ (w ◇ u).

Definition Equation3856 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ w) ◇ (u ◇ x).

Definition Equation3857 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ w) ◇ (u ◇ y).

Definition Equation3858 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ w) ◇ (u ◇ z).

Definition Equation3859 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ w) ◇ (u ◇ w).

Definition Equation3860 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ w) ◇ (u ◇ u).

Definition Equation3861 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x ◇ y = (z ◇ w) ◇ (u ◇ v).

Definition Equation3862 (G : Type) `{Magma G} : Prop :=
  forall x : G, x ◇ x = (x ◇ (x ◇ x)) ◇ x.

Definition Equation3863 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ (x ◇ x)) ◇ y.

Definition Equation3864 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ (x ◇ y)) ◇ x.

Definition Equation3865 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ (x ◇ y)) ◇ y.

Definition Equation3866 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (x ◇ (x ◇ y)) ◇ z.

Definition Equation3867 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ (y ◇ x)) ◇ x.

Definition Equation3868 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ (y ◇ x)) ◇ y.

Definition Equation3869 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (x ◇ (y ◇ x)) ◇ z.

Definition Equation3870 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ (y ◇ y)) ◇ x.

Definition Equation3871 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (x ◇ (y ◇ y)) ◇ y.

Definition Equation3872 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (x ◇ (y ◇ y)) ◇ z.

Definition Equation3873 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (x ◇ (y ◇ z)) ◇ x.

Definition Equation3874 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (x ◇ (y ◇ z)) ◇ y.

Definition Equation3875 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (x ◇ (y ◇ z)) ◇ z.

Definition Equation3876 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (x ◇ (y ◇ z)) ◇ w.

Definition Equation3877 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ (x ◇ x)) ◇ x.

Definition Equation3878 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ (x ◇ x)) ◇ y.

Definition Equation3879 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (x ◇ x)) ◇ z.

Definition Equation3880 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ (x ◇ y)) ◇ x.

Definition Equation3881 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ (x ◇ y)) ◇ y.

Definition Equation3882 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (x ◇ y)) ◇ z.

Definition Equation3883 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (x ◇ z)) ◇ x.

Definition Equation3884 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (x ◇ z)) ◇ y.

Definition Equation3885 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (x ◇ z)) ◇ z.

Definition Equation3886 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ (x ◇ z)) ◇ w.

Definition Equation3887 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ (y ◇ x)) ◇ x.

Definition Equation3888 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ (y ◇ x)) ◇ y.

Definition Equation3889 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (y ◇ x)) ◇ z.

Definition Equation3890 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ (y ◇ y)) ◇ x.

Definition Equation3891 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = (y ◇ (y ◇ y)) ◇ y.

Definition Equation3892 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (y ◇ y)) ◇ z.

Definition Equation3893 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (y ◇ z)) ◇ x.

Definition Equation3894 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (y ◇ z)) ◇ y.

Definition Equation3895 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (y ◇ z)) ◇ z.

Definition Equation3896 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ (y ◇ z)) ◇ w.

Definition Equation3897 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (z ◇ x)) ◇ x.

Definition Equation3898 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (z ◇ x)) ◇ y.

Definition Equation3899 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (z ◇ x)) ◇ z.

Definition Equation3900 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ (z ◇ x)) ◇ w.

Definition Equation3901 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (z ◇ y)) ◇ x.

Definition Equation3902 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (z ◇ y)) ◇ y.

Definition Equation3903 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (z ◇ y)) ◇ z.

Definition Equation3904 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ (z ◇ y)) ◇ w.

Definition Equation3905 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (z ◇ z)) ◇ x.

Definition Equation3906 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (z ◇ z)) ◇ y.

Definition Equation3907 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = (y ◇ (z ◇ z)) ◇ z.

Definition Equation3908 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ (z ◇ z)) ◇ w.

Definition Equation3909 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ (z ◇ w)) ◇ x.

Definition Equation3910 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ (z ◇ w)) ◇ y.

Definition Equation3911 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ (z ◇ w)) ◇ z.

Definition Equation3912 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = (y ◇ (z ◇ w)) ◇ w.

Definition Equation3913 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ x = (y ◇ (z ◇ w)) ◇ u.

Definition Equation3914 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ (x ◇ x)) ◇ x.

Definition Equation3915 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ (x ◇ x)) ◇ y.

Definition Equation3916 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (x ◇ x)) ◇ z.

Definition Equation3917 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ (x ◇ y)) ◇ x.

Definition Equation3918 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ (x ◇ y)) ◇ y.

Definition Equation3919 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (x ◇ y)) ◇ z.

Definition Equation3920 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (x ◇ z)) ◇ x.

Definition Equation3921 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (x ◇ z)) ◇ y.

Definition Equation3922 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (x ◇ z)) ◇ z.

Definition Equation3923 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ (x ◇ z)) ◇ w.

Definition Equation3924 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ (y ◇ x)) ◇ x.

Definition Equation3925 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ (y ◇ x)) ◇ y.

Definition Equation3926 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (y ◇ x)) ◇ z.

Definition Equation3927 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ (y ◇ y)) ◇ x.

Definition Equation3928 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (x ◇ (y ◇ y)) ◇ y.

Definition Equation3929 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (y ◇ y)) ◇ z.

Definition Equation3930 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (y ◇ z)) ◇ x.

Definition Equation3931 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (y ◇ z)) ◇ y.

Definition Equation3932 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (y ◇ z)) ◇ z.

Definition Equation3933 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ (y ◇ z)) ◇ w.

Definition Equation3934 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (z ◇ x)) ◇ x.

Definition Equation3935 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (z ◇ x)) ◇ y.

Definition Equation3936 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (z ◇ x)) ◇ z.

Definition Equation3937 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ (z ◇ x)) ◇ w.

Definition Equation3938 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (z ◇ y)) ◇ x.

Definition Equation3939 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (z ◇ y)) ◇ y.

Definition Equation3940 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (z ◇ y)) ◇ z.

Definition Equation3941 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ (z ◇ y)) ◇ w.

Definition Equation3942 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (z ◇ z)) ◇ x.

Definition Equation3943 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (z ◇ z)) ◇ y.

Definition Equation3944 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (x ◇ (z ◇ z)) ◇ z.

Definition Equation3945 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ (z ◇ z)) ◇ w.

Definition Equation3946 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ (z ◇ w)) ◇ x.

Definition Equation3947 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ (z ◇ w)) ◇ y.

Definition Equation3948 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ (z ◇ w)) ◇ z.

Definition Equation3949 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (x ◇ (z ◇ w)) ◇ w.

Definition Equation3950 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (x ◇ (z ◇ w)) ◇ u.

Definition Equation3951 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ (x ◇ x)) ◇ x.

Definition Equation3952 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ (x ◇ x)) ◇ y.

Definition Equation3953 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (x ◇ x)) ◇ z.

Definition Equation3954 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ (x ◇ y)) ◇ x.

Definition Equation3955 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ (x ◇ y)) ◇ y.

Definition Equation3956 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (x ◇ y)) ◇ z.

Definition Equation3957 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (x ◇ z)) ◇ x.

Definition Equation3958 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (x ◇ z)) ◇ y.

Definition Equation3959 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (x ◇ z)) ◇ z.

Definition Equation3960 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ (x ◇ z)) ◇ w.

Definition Equation3961 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ (y ◇ x)) ◇ x.

Definition Equation3962 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ (y ◇ x)) ◇ y.

Definition Equation3963 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (y ◇ x)) ◇ z.

Definition Equation3964 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ (y ◇ y)) ◇ x.

Definition Equation3965 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = (y ◇ (y ◇ y)) ◇ y.

Definition Equation3966 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (y ◇ y)) ◇ z.

Definition Equation3967 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (y ◇ z)) ◇ x.

Definition Equation3968 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (y ◇ z)) ◇ y.

Definition Equation3969 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (y ◇ z)) ◇ z.

Definition Equation3970 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ (y ◇ z)) ◇ w.

Definition Equation3971 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (z ◇ x)) ◇ x.

Definition Equation3972 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (z ◇ x)) ◇ y.

Definition Equation3973 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (z ◇ x)) ◇ z.

Definition Equation3974 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ (z ◇ x)) ◇ w.

Definition Equation3975 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (z ◇ y)) ◇ x.

Definition Equation3976 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (z ◇ y)) ◇ y.

Definition Equation3977 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (z ◇ y)) ◇ z.

Definition Equation3978 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ (z ◇ y)) ◇ w.

Definition Equation3979 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (z ◇ z)) ◇ x.

Definition Equation3980 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (z ◇ z)) ◇ y.

Definition Equation3981 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (y ◇ (z ◇ z)) ◇ z.

Definition Equation3982 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ (z ◇ z)) ◇ w.

Definition Equation3983 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ (z ◇ w)) ◇ x.

Definition Equation3984 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ (z ◇ w)) ◇ y.

Definition Equation3985 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ (z ◇ w)) ◇ z.

Definition Equation3986 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (y ◇ (z ◇ w)) ◇ w.

Definition Equation3987 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (y ◇ (z ◇ w)) ◇ u.

Definition Equation3988 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (x ◇ x)) ◇ x.

Definition Equation3989 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (x ◇ x)) ◇ y.

Definition Equation3990 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (x ◇ x)) ◇ z.

Definition Equation3991 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (x ◇ x)) ◇ w.

Definition Equation3992 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (x ◇ y)) ◇ x.

Definition Equation3993 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (x ◇ y)) ◇ y.

Definition Equation3994 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (x ◇ y)) ◇ z.

Definition Equation3995 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (x ◇ y)) ◇ w.

Definition Equation3996 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (x ◇ z)) ◇ x.

Definition Equation3997 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (x ◇ z)) ◇ y.

Definition Equation3998 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (x ◇ z)) ◇ z.

Definition Equation3999 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (x ◇ z)) ◇ w.

