(** * Equations 4000–1875916474

    Auto-generated from the Lean4 Equational Theories Project. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.

Open Scope magma_scope.

Definition Equation4000 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (x ◇ w)) ◇ x.

Definition Equation4001 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (x ◇ w)) ◇ y.

Definition Equation4002 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (x ◇ w)) ◇ z.

Definition Equation4003 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (x ◇ w)) ◇ w.

Definition Equation4004 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ (x ◇ w)) ◇ u.

Definition Equation4005 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (y ◇ x)) ◇ x.

Definition Equation4006 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (y ◇ x)) ◇ y.

Definition Equation4007 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (y ◇ x)) ◇ z.

Definition Equation4008 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (y ◇ x)) ◇ w.

Definition Equation4009 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (y ◇ y)) ◇ x.

Definition Equation4010 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (y ◇ y)) ◇ y.

Definition Equation4011 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (y ◇ y)) ◇ z.

Definition Equation4012 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (y ◇ y)) ◇ w.

Definition Equation4013 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (y ◇ z)) ◇ x.

Definition Equation4014 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (y ◇ z)) ◇ y.

Definition Equation4015 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (y ◇ z)) ◇ z.

Definition Equation4016 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (y ◇ z)) ◇ w.

Definition Equation4017 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (y ◇ w)) ◇ x.

Definition Equation4018 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (y ◇ w)) ◇ y.

Definition Equation4019 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (y ◇ w)) ◇ z.

Definition Equation4020 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (y ◇ w)) ◇ w.

Definition Equation4021 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ (y ◇ w)) ◇ u.

Definition Equation4022 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (z ◇ x)) ◇ x.

Definition Equation4023 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (z ◇ x)) ◇ y.

Definition Equation4024 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (z ◇ x)) ◇ z.

Definition Equation4025 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (z ◇ x)) ◇ w.

Definition Equation4026 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (z ◇ y)) ◇ x.

Definition Equation4027 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (z ◇ y)) ◇ y.

Definition Equation4028 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (z ◇ y)) ◇ z.

Definition Equation4029 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (z ◇ y)) ◇ w.

Definition Equation4030 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (z ◇ z)) ◇ x.

Definition Equation4031 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (z ◇ z)) ◇ y.

Definition Equation4032 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = (z ◇ (z ◇ z)) ◇ z.

Definition Equation4033 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (z ◇ z)) ◇ w.

Definition Equation4034 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (z ◇ w)) ◇ x.

Definition Equation4035 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (z ◇ w)) ◇ y.

Definition Equation4036 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (z ◇ w)) ◇ z.

Definition Equation4037 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (z ◇ w)) ◇ w.

Definition Equation4038 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ (z ◇ w)) ◇ u.

Definition Equation4039 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ x)) ◇ x.

Definition Equation4040 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ x)) ◇ y.

Definition Equation4041 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ x)) ◇ z.

Definition Equation4042 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ x)) ◇ w.

Definition Equation4043 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ (w ◇ x)) ◇ u.

Definition Equation4044 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ y)) ◇ x.

Definition Equation4045 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ y)) ◇ y.

Definition Equation4046 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ y)) ◇ z.

Definition Equation4047 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ y)) ◇ w.

Definition Equation4048 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ (w ◇ y)) ◇ u.

Definition Equation4049 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ z)) ◇ x.

Definition Equation4050 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ z)) ◇ y.

Definition Equation4051 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ z)) ◇ z.

Definition Equation4052 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ z)) ◇ w.

Definition Equation4053 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ (w ◇ z)) ◇ u.

Definition Equation4054 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ w)) ◇ x.

Definition Equation4055 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ w)) ◇ y.

Definition Equation4056 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ w)) ◇ z.

Definition Equation4057 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = (z ◇ (w ◇ w)) ◇ w.

Definition Equation4058 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ (w ◇ w)) ◇ u.

Definition Equation4059 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ (w ◇ u)) ◇ x.

Definition Equation4060 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ (w ◇ u)) ◇ y.

Definition Equation4061 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ (w ◇ u)) ◇ z.

Definition Equation4062 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ (w ◇ u)) ◇ w.

Definition Equation4063 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = (z ◇ (w ◇ u)) ◇ u.

Definition Equation4064 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x ◇ y = (z ◇ (w ◇ u)) ◇ v.

Definition Equation4065 (G : Type) `{Magma G} : Prop :=
  forall x : G, x ◇ x = ((x ◇ x) ◇ x) ◇ x.

Definition Equation4066 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((x ◇ x) ◇ x) ◇ y.

Definition Equation4067 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((x ◇ x) ◇ y) ◇ x.

Definition Equation4068 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((x ◇ x) ◇ y) ◇ y.

Definition Equation4069 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((x ◇ x) ◇ y) ◇ z.

Definition Equation4070 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((x ◇ y) ◇ x) ◇ x.

Definition Equation4071 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((x ◇ y) ◇ x) ◇ y.

Definition Equation4072 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((x ◇ y) ◇ x) ◇ z.

Definition Equation4073 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((x ◇ y) ◇ y) ◇ x.

Definition Equation4074 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((x ◇ y) ◇ y) ◇ y.

Definition Equation4075 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((x ◇ y) ◇ y) ◇ z.

Definition Equation4076 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((x ◇ y) ◇ z) ◇ x.

Definition Equation4077 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((x ◇ y) ◇ z) ◇ y.

Definition Equation4078 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((x ◇ y) ◇ z) ◇ z.

Definition Equation4079 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = ((x ◇ y) ◇ z) ◇ w.

Definition Equation4080 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((y ◇ x) ◇ x) ◇ x.

Definition Equation4081 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((y ◇ x) ◇ x) ◇ y.

Definition Equation4082 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ x) ◇ x) ◇ z.

Definition Equation4083 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((y ◇ x) ◇ y) ◇ x.

Definition Equation4084 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((y ◇ x) ◇ y) ◇ y.

Definition Equation4085 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ x) ◇ y) ◇ z.

Definition Equation4086 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ x) ◇ z) ◇ x.

Definition Equation4087 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ x) ◇ z) ◇ y.

Definition Equation4088 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ x) ◇ z) ◇ z.

Definition Equation4089 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = ((y ◇ x) ◇ z) ◇ w.

Definition Equation4090 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((y ◇ y) ◇ x) ◇ x.

Definition Equation4091 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((y ◇ y) ◇ x) ◇ y.

Definition Equation4092 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ y) ◇ x) ◇ z.

Definition Equation4093 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((y ◇ y) ◇ y) ◇ x.

Definition Equation4094 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ x = ((y ◇ y) ◇ y) ◇ y.

Definition Equation4095 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ y) ◇ y) ◇ z.

Definition Equation4096 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ y) ◇ z) ◇ x.

Definition Equation4097 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ y) ◇ z) ◇ y.

Definition Equation4098 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ y) ◇ z) ◇ z.

Definition Equation4099 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = ((y ◇ y) ◇ z) ◇ w.

Definition Equation4100 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ z) ◇ x) ◇ x.

Definition Equation4101 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ z) ◇ x) ◇ y.

Definition Equation4102 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ z) ◇ x) ◇ z.

Definition Equation4103 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = ((y ◇ z) ◇ x) ◇ w.

Definition Equation4104 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ z) ◇ y) ◇ x.

Definition Equation4105 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ z) ◇ y) ◇ y.

Definition Equation4106 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ z) ◇ y) ◇ z.

Definition Equation4107 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = ((y ◇ z) ◇ y) ◇ w.

Definition Equation4108 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ z) ◇ z) ◇ x.

Definition Equation4109 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ z) ◇ z) ◇ y.

Definition Equation4110 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ x = ((y ◇ z) ◇ z) ◇ z.

Definition Equation4111 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = ((y ◇ z) ◇ z) ◇ w.

Definition Equation4112 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = ((y ◇ z) ◇ w) ◇ x.

Definition Equation4113 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = ((y ◇ z) ◇ w) ◇ y.

Definition Equation4114 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = ((y ◇ z) ◇ w) ◇ z.

Definition Equation4115 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ x = ((y ◇ z) ◇ w) ◇ w.

Definition Equation4116 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ x = ((y ◇ z) ◇ w) ◇ u.

Definition Equation4117 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((x ◇ x) ◇ x) ◇ x.

Definition Equation4118 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((x ◇ x) ◇ x) ◇ y.

Definition Equation4119 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ x) ◇ x) ◇ z.

Definition Equation4120 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((x ◇ x) ◇ y) ◇ x.

Definition Equation4121 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((x ◇ x) ◇ y) ◇ y.

Definition Equation4122 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ x) ◇ y) ◇ z.

Definition Equation4123 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ x) ◇ z) ◇ x.

Definition Equation4124 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ x) ◇ z) ◇ y.

Definition Equation4125 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ x) ◇ z) ◇ z.

Definition Equation4126 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((x ◇ x) ◇ z) ◇ w.

Definition Equation4127 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((x ◇ y) ◇ x) ◇ x.

Definition Equation4128 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((x ◇ y) ◇ x) ◇ y.

Definition Equation4129 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ y) ◇ x) ◇ z.

Definition Equation4130 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((x ◇ y) ◇ y) ◇ x.

Definition Equation4131 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((x ◇ y) ◇ y) ◇ y.

Definition Equation4132 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ y) ◇ y) ◇ z.

Definition Equation4133 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ y) ◇ z) ◇ x.

Definition Equation4134 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ y) ◇ z) ◇ y.

Definition Equation4135 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ y) ◇ z) ◇ z.

Definition Equation4136 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((x ◇ y) ◇ z) ◇ w.

Definition Equation4137 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ z) ◇ x) ◇ x.

Definition Equation4138 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ z) ◇ x) ◇ y.

Definition Equation4139 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ z) ◇ x) ◇ z.

Definition Equation4140 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((x ◇ z) ◇ x) ◇ w.

Definition Equation4141 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ z) ◇ y) ◇ x.

Definition Equation4142 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ z) ◇ y) ◇ y.

Definition Equation4143 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ z) ◇ y) ◇ z.

Definition Equation4144 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((x ◇ z) ◇ y) ◇ w.

Definition Equation4145 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ z) ◇ z) ◇ x.

Definition Equation4146 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ z) ◇ z) ◇ y.

Definition Equation4147 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((x ◇ z) ◇ z) ◇ z.

Definition Equation4148 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((x ◇ z) ◇ z) ◇ w.

Definition Equation4149 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((x ◇ z) ◇ w) ◇ x.

Definition Equation4150 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((x ◇ z) ◇ w) ◇ y.

Definition Equation4151 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((x ◇ z) ◇ w) ◇ z.

Definition Equation4152 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((x ◇ z) ◇ w) ◇ w.

Definition Equation4153 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((x ◇ z) ◇ w) ◇ u.

Definition Equation4154 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((y ◇ x) ◇ x) ◇ x.

Definition Equation4155 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((y ◇ x) ◇ x) ◇ y.

Definition Equation4156 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ x) ◇ x) ◇ z.

Definition Equation4157 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((y ◇ x) ◇ y) ◇ x.

Definition Equation4158 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((y ◇ x) ◇ y) ◇ y.

Definition Equation4159 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ x) ◇ y) ◇ z.

Definition Equation4160 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ x) ◇ z) ◇ x.

Definition Equation4161 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ x) ◇ z) ◇ y.

Definition Equation4162 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ x) ◇ z) ◇ z.

Definition Equation4163 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((y ◇ x) ◇ z) ◇ w.

Definition Equation4164 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((y ◇ y) ◇ x) ◇ x.

Definition Equation4165 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((y ◇ y) ◇ x) ◇ y.

Definition Equation4166 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ y) ◇ x) ◇ z.

Definition Equation4167 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((y ◇ y) ◇ y) ◇ x.

Definition Equation4168 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ y = ((y ◇ y) ◇ y) ◇ y.

Definition Equation4169 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ y) ◇ y) ◇ z.

Definition Equation4170 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ y) ◇ z) ◇ x.

Definition Equation4171 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ y) ◇ z) ◇ y.

Definition Equation4172 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ y) ◇ z) ◇ z.

Definition Equation4173 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((y ◇ y) ◇ z) ◇ w.

Definition Equation4174 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ z) ◇ x) ◇ x.

Definition Equation4175 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ z) ◇ x) ◇ y.

Definition Equation4176 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ z) ◇ x) ◇ z.

Definition Equation4177 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((y ◇ z) ◇ x) ◇ w.

Definition Equation4178 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ z) ◇ y) ◇ x.

Definition Equation4179 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ z) ◇ y) ◇ y.

Definition Equation4180 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ z) ◇ y) ◇ z.

Definition Equation4181 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((y ◇ z) ◇ y) ◇ w.

Definition Equation4182 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ z) ◇ z) ◇ x.

Definition Equation4183 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ z) ◇ z) ◇ y.

Definition Equation4184 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((y ◇ z) ◇ z) ◇ z.

Definition Equation4185 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((y ◇ z) ◇ z) ◇ w.

Definition Equation4186 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((y ◇ z) ◇ w) ◇ x.

Definition Equation4187 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((y ◇ z) ◇ w) ◇ y.

Definition Equation4188 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((y ◇ z) ◇ w) ◇ z.

Definition Equation4189 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((y ◇ z) ◇ w) ◇ w.

Definition Equation4190 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((y ◇ z) ◇ w) ◇ u.

Definition Equation4191 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ x) ◇ x) ◇ x.

Definition Equation4192 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ x) ◇ x) ◇ y.

Definition Equation4193 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ x) ◇ x) ◇ z.

Definition Equation4194 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ x) ◇ x) ◇ w.

Definition Equation4195 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ x) ◇ y) ◇ x.

Definition Equation4196 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ x) ◇ y) ◇ y.

Definition Equation4197 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ x) ◇ y) ◇ z.

Definition Equation4198 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ x) ◇ y) ◇ w.

Definition Equation4199 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ x) ◇ z) ◇ x.

Definition Equation4200 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ x) ◇ z) ◇ y.

Definition Equation4201 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ x) ◇ z) ◇ z.

Definition Equation4202 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ x) ◇ z) ◇ w.

Definition Equation4203 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ x) ◇ w) ◇ x.

Definition Equation4204 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ x) ◇ w) ◇ y.

Definition Equation4205 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ x) ◇ w) ◇ z.

Definition Equation4206 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ x) ◇ w) ◇ w.

Definition Equation4207 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((z ◇ x) ◇ w) ◇ u.

Definition Equation4208 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ y) ◇ x) ◇ x.

Definition Equation4209 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ y) ◇ x) ◇ y.

Definition Equation4210 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ y) ◇ x) ◇ z.

Definition Equation4211 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ y) ◇ x) ◇ w.

Definition Equation4212 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ y) ◇ y) ◇ x.

Definition Equation4213 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ y) ◇ y) ◇ y.

Definition Equation4214 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ y) ◇ y) ◇ z.

Definition Equation4215 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ y) ◇ y) ◇ w.

Definition Equation4216 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ y) ◇ z) ◇ x.

Definition Equation4217 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ y) ◇ z) ◇ y.

Definition Equation4218 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ y) ◇ z) ◇ z.

Definition Equation4219 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ y) ◇ z) ◇ w.

Definition Equation4220 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ y) ◇ w) ◇ x.

Definition Equation4221 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ y) ◇ w) ◇ y.

Definition Equation4222 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ y) ◇ w) ◇ z.

Definition Equation4223 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ y) ◇ w) ◇ w.

Definition Equation4224 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((z ◇ y) ◇ w) ◇ u.

Definition Equation4225 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ z) ◇ x) ◇ x.

Definition Equation4226 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ z) ◇ x) ◇ y.

Definition Equation4227 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ z) ◇ x) ◇ z.

Definition Equation4228 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ z) ◇ x) ◇ w.

Definition Equation4229 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ z) ◇ y) ◇ x.

Definition Equation4230 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ z) ◇ y) ◇ y.

Definition Equation4231 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ z) ◇ y) ◇ z.

Definition Equation4232 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ z) ◇ y) ◇ w.

Definition Equation4233 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ z) ◇ z) ◇ x.

Definition Equation4234 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ z) ◇ z) ◇ y.

Definition Equation4235 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ y = ((z ◇ z) ◇ z) ◇ z.

Definition Equation4236 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ z) ◇ z) ◇ w.

Definition Equation4237 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ z) ◇ w) ◇ x.

Definition Equation4238 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ z) ◇ w) ◇ y.

Definition Equation4239 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ z) ◇ w) ◇ z.

Definition Equation4240 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ z) ◇ w) ◇ w.

Definition Equation4241 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((z ◇ z) ◇ w) ◇ u.

Definition Equation4242 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ x) ◇ x.

Definition Equation4243 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ x) ◇ y.

Definition Equation4244 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ x) ◇ z.

Definition Equation4245 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ x) ◇ w.

Definition Equation4246 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((z ◇ w) ◇ x) ◇ u.

Definition Equation4247 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ y) ◇ x.

Definition Equation4248 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ y) ◇ y.

Definition Equation4249 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ y) ◇ z.

Definition Equation4250 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ y) ◇ w.

Definition Equation4251 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((z ◇ w) ◇ y) ◇ u.

Definition Equation4252 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ z) ◇ x.

Definition Equation4253 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ z) ◇ y.

Definition Equation4254 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ z) ◇ z.

Definition Equation4255 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ z) ◇ w.

Definition Equation4256 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((z ◇ w) ◇ z) ◇ u.

Definition Equation4257 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ w) ◇ x.

Definition Equation4258 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ w) ◇ y.

Definition Equation4259 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ w) ◇ z.

Definition Equation4260 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ y = ((z ◇ w) ◇ w) ◇ w.

Definition Equation4261 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((z ◇ w) ◇ w) ◇ u.

Definition Equation4262 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((z ◇ w) ◇ u) ◇ x.

Definition Equation4263 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((z ◇ w) ◇ u) ◇ y.

Definition Equation4264 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((z ◇ w) ◇ u) ◇ z.

Definition Equation4265 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((z ◇ w) ◇ u) ◇ w.

Definition Equation4266 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ y = ((z ◇ w) ◇ u) ◇ u.

Definition Equation4267 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x ◇ y = ((z ◇ w) ◇ u) ◇ v.

Definition Equation4268 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = x ◇ (x ◇ y).

Definition Equation4269 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = x ◇ (y ◇ x).

Definition Equation4270 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = x ◇ (y ◇ y).

Definition Equation4271 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ x) = x ◇ (y ◇ z).

Definition Equation4272 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = y ◇ (x ◇ x).

Definition Equation4273 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = y ◇ (x ◇ y).

Definition Equation4274 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ x) = y ◇ (x ◇ z).

Definition Equation4275 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = y ◇ (y ◇ x).

Definition Equation4276 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = y ◇ (y ◇ y).

Definition Equation4277 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ x) = y ◇ (y ◇ z).

Definition Equation4278 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ x) = y ◇ (z ◇ x).

Definition Equation4279 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ x) = y ◇ (z ◇ y).

Definition Equation4280 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ x) = y ◇ (z ◇ z).

Definition Equation4281 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ x) = y ◇ (z ◇ w).

Definition Equation4282 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = x ◇ (x ◇ z).

Definition Equation4283 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ y) = x ◇ (y ◇ x).

Definition Equation4284 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ y) = x ◇ (y ◇ y).

Definition Equation4285 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = x ◇ (y ◇ z).

Definition Equation4286 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = x ◇ (z ◇ x).

Definition Equation4287 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = x ◇ (z ◇ y).

Definition Equation4288 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = x ◇ (z ◇ z).

Definition Equation4289 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = x ◇ (z ◇ w).

Definition Equation4290 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ y) = y ◇ (x ◇ x).

Definition Equation4291 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ y) = y ◇ (x ◇ y).

Definition Equation4292 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = y ◇ (x ◇ z).

Definition Equation4293 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ y) = y ◇ (y ◇ x).

Definition Equation4294 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = y ◇ (y ◇ z).

Definition Equation4295 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = y ◇ (z ◇ x).

Definition Equation4296 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = y ◇ (z ◇ y).

Definition Equation4297 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = y ◇ (z ◇ z).

Definition Equation4298 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = y ◇ (z ◇ w).

Definition Equation4299 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = z ◇ (x ◇ x).

Definition Equation4300 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = z ◇ (x ◇ y).

Definition Equation4301 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = z ◇ (x ◇ z).

Definition Equation4302 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = z ◇ (x ◇ w).

Definition Equation4303 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = z ◇ (y ◇ x).

Definition Equation4304 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = z ◇ (y ◇ y).

Definition Equation4305 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = z ◇ (y ◇ z).

Definition Equation4306 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = z ◇ (y ◇ w).

Definition Equation4307 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = z ◇ (z ◇ y).

Definition Equation4308 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = z ◇ (z ◇ w).

Definition Equation4309 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = z ◇ (w ◇ x).

Definition Equation4310 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = z ◇ (w ◇ y).

Definition Equation4311 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = z ◇ (w ◇ z).

Definition Equation4312 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = z ◇ (w ◇ w).

Definition Equation4313 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (x ◇ y) = z ◇ (w ◇ u).

Definition Equation4314 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ x) = x ◇ (y ◇ y).

Definition Equation4315 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = x ◇ (y ◇ z).

Definition Equation4316 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = x ◇ (z ◇ x).

Definition Equation4317 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = x ◇ (z ◇ y).

Definition Equation4318 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = x ◇ (z ◇ z).

Definition Equation4319 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = x ◇ (z ◇ w).

Definition Equation4320 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ x) = y ◇ (x ◇ x).

Definition Equation4321 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ x) = y ◇ (x ◇ y).

Definition Equation4322 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = y ◇ (x ◇ z).

Definition Equation4323 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = y ◇ (z ◇ x).

Definition Equation4324 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = y ◇ (z ◇ y).

Definition Equation4325 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = y ◇ (z ◇ z).

Definition Equation4326 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = y ◇ (z ◇ w).

Definition Equation4327 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = z ◇ (x ◇ x).

Definition Equation4328 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = z ◇ (x ◇ y).

Definition Equation4329 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = z ◇ (x ◇ w).

Definition Equation4330 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = z ◇ (y ◇ x).

Definition Equation4331 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = z ◇ (y ◇ y).

Definition Equation4332 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = z ◇ (y ◇ z).

Definition Equation4333 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = z ◇ (y ◇ w).

Definition Equation4334 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = z ◇ (w ◇ x).

Definition Equation4335 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = z ◇ (w ◇ y).

Definition Equation4336 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = z ◇ (w ◇ z).

Definition Equation4337 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = z ◇ (w ◇ w).

Definition Equation4338 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ x) = z ◇ (w ◇ u).

Definition Equation4339 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = x ◇ (y ◇ z).

Definition Equation4340 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = x ◇ (z ◇ y).

Definition Equation4341 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = x ◇ (z ◇ z).

Definition Equation4342 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = x ◇ (z ◇ w).

Definition Equation4343 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ y) = y ◇ (x ◇ x).

Definition Equation4344 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = y ◇ (x ◇ z).

Definition Equation4345 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = y ◇ (z ◇ x).

Definition Equation4346 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = y ◇ (z ◇ z).

Definition Equation4347 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = y ◇ (z ◇ w).

Definition Equation4348 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = z ◇ (x ◇ y).

Definition Equation4349 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = z ◇ (x ◇ w).

Definition Equation4350 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = z ◇ (y ◇ x).

Definition Equation4351 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = z ◇ (y ◇ y).

Definition Equation4352 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = z ◇ (y ◇ w).

Definition Equation4353 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = z ◇ (w ◇ x).

Definition Equation4354 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = z ◇ (w ◇ y).

Definition Equation4355 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = z ◇ (w ◇ w).

Definition Equation4356 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ y) = z ◇ (w ◇ u).

Definition Equation4357 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = x ◇ (y ◇ w).

Definition Equation4358 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = x ◇ (z ◇ y).

Definition Equation4359 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = x ◇ (z ◇ w).

Definition Equation4360 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = x ◇ (w ◇ z).

Definition Equation4361 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = x ◇ (w ◇ u).

Definition Equation4362 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = y ◇ (x ◇ z).

Definition Equation4363 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = y ◇ (x ◇ w).

Definition Equation4364 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = y ◇ (z ◇ x).

Definition Equation4365 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = y ◇ (z ◇ w).

Definition Equation4366 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = y ◇ (w ◇ x).

Definition Equation4367 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = y ◇ (w ◇ z).

Definition Equation4368 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = y ◇ (w ◇ u).

Definition Equation4369 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = z ◇ (y ◇ x).

Definition Equation4370 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = z ◇ (y ◇ w).

Definition Equation4371 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = z ◇ (w ◇ x).

Definition Equation4372 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = z ◇ (w ◇ y).

Definition Equation4373 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = z ◇ (w ◇ u).

Definition Equation4374 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = w ◇ (y ◇ z).

Definition Equation4375 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = w ◇ (y ◇ u).

Definition Equation4376 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = w ◇ (z ◇ y).

Definition Equation4377 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = w ◇ (z ◇ u).

Definition Equation4378 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = w ◇ (u ◇ z).

Definition Equation4379 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x ◇ (y ◇ z) = w ◇ (u ◇ v).

Definition Equation4380 (G : Type) `{Magma G} : Prop :=
  forall x : G, x ◇ (x ◇ x) = (x ◇ x) ◇ x.

Definition Equation4381 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = (x ◇ x) ◇ y.

Definition Equation4382 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = (x ◇ y) ◇ x.

Definition Equation4383 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = (x ◇ y) ◇ y.

Definition Equation4384 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ x) = (x ◇ y) ◇ z.

Definition Equation4385 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = (y ◇ x) ◇ x.

Definition Equation4386 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = (y ◇ x) ◇ y.

Definition Equation4387 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ x) = (y ◇ x) ◇ z.

Definition Equation4388 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = (y ◇ y) ◇ x.

Definition Equation4389 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ x) = (y ◇ y) ◇ y.

Definition Equation4390 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ x) = (y ◇ y) ◇ z.

Definition Equation4391 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ x) = (y ◇ z) ◇ x.

Definition Equation4392 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ x) = (y ◇ z) ◇ y.

Definition Equation4393 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ x) = (y ◇ z) ◇ z.

Definition Equation4394 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ x) = (y ◇ z) ◇ w.

Definition Equation4395 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ y) = (x ◇ x) ◇ x.

Definition Equation4396 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ y) = (x ◇ x) ◇ y.

Definition Equation4397 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (x ◇ x) ◇ z.

Definition Equation4398 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ y) = (x ◇ y) ◇ x.

Definition Equation4399 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ y) = (x ◇ y) ◇ y.

Definition Equation4400 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (x ◇ y) ◇ z.

Definition Equation4401 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (x ◇ z) ◇ x.

Definition Equation4402 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (x ◇ z) ◇ y.

Definition Equation4403 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (x ◇ z) ◇ z.

Definition Equation4404 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = (x ◇ z) ◇ w.

Definition Equation4405 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ y) = (y ◇ x) ◇ x.

Definition Equation4406 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ y) = (y ◇ x) ◇ y.

Definition Equation4407 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (y ◇ x) ◇ z.

Definition Equation4408 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ y) = (y ◇ y) ◇ x.

Definition Equation4409 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (x ◇ y) = (y ◇ y) ◇ y.

Definition Equation4410 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (y ◇ y) ◇ z.

Definition Equation4411 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (y ◇ z) ◇ x.

Definition Equation4412 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (y ◇ z) ◇ y.

Definition Equation4413 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (y ◇ z) ◇ z.

Definition Equation4414 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = (y ◇ z) ◇ w.

Definition Equation4415 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (z ◇ x) ◇ x.

Definition Equation4416 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (z ◇ x) ◇ y.

Definition Equation4417 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (z ◇ x) ◇ z.

Definition Equation4418 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = (z ◇ x) ◇ w.

Definition Equation4419 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (z ◇ y) ◇ x.

Definition Equation4420 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (z ◇ y) ◇ y.

Definition Equation4421 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (z ◇ y) ◇ z.

Definition Equation4422 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = (z ◇ y) ◇ w.

Definition Equation4423 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (z ◇ z) ◇ x.

Definition Equation4424 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (z ◇ z) ◇ y.

Definition Equation4425 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (x ◇ y) = (z ◇ z) ◇ z.

Definition Equation4426 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = (z ◇ z) ◇ w.

Definition Equation4427 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = (z ◇ w) ◇ x.

Definition Equation4428 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = (z ◇ w) ◇ y.

Definition Equation4429 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = (z ◇ w) ◇ z.

Definition Equation4430 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (x ◇ y) = (z ◇ w) ◇ w.

Definition Equation4431 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (x ◇ y) = (z ◇ w) ◇ u.

Definition Equation4432 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ x) = (x ◇ x) ◇ x.

Definition Equation4433 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ x) = (x ◇ x) ◇ y.

Definition Equation4434 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (x ◇ x) ◇ z.

Definition Equation4435 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ x) = (x ◇ y) ◇ x.

Definition Equation4436 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ x) = (x ◇ y) ◇ y.

Definition Equation4437 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (x ◇ y) ◇ z.

Definition Equation4438 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (x ◇ z) ◇ x.

Definition Equation4439 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (x ◇ z) ◇ y.

Definition Equation4440 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (x ◇ z) ◇ z.

Definition Equation4441 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = (x ◇ z) ◇ w.

Definition Equation4442 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ x) = (y ◇ x) ◇ x.

Definition Equation4443 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ x) = (y ◇ x) ◇ y.

Definition Equation4444 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (y ◇ x) ◇ z.

Definition Equation4445 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ x) = (y ◇ y) ◇ x.

Definition Equation4446 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ x) = (y ◇ y) ◇ y.

Definition Equation4447 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (y ◇ y) ◇ z.

Definition Equation4448 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (y ◇ z) ◇ x.

Definition Equation4449 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (y ◇ z) ◇ y.

Definition Equation4450 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (y ◇ z) ◇ z.

Definition Equation4451 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = (y ◇ z) ◇ w.

Definition Equation4452 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (z ◇ x) ◇ x.

Definition Equation4453 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (z ◇ x) ◇ y.

Definition Equation4454 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (z ◇ x) ◇ z.

Definition Equation4455 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = (z ◇ x) ◇ w.

Definition Equation4456 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (z ◇ y) ◇ x.

Definition Equation4457 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (z ◇ y) ◇ y.

Definition Equation4458 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (z ◇ y) ◇ z.

Definition Equation4459 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = (z ◇ y) ◇ w.

Definition Equation4460 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (z ◇ z) ◇ x.

Definition Equation4461 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (z ◇ z) ◇ y.

Definition Equation4462 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ x) = (z ◇ z) ◇ z.

Definition Equation4463 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = (z ◇ z) ◇ w.

Definition Equation4464 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = (z ◇ w) ◇ x.

Definition Equation4465 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = (z ◇ w) ◇ y.

Definition Equation4466 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = (z ◇ w) ◇ z.

Definition Equation4467 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ x) = (z ◇ w) ◇ w.

Definition Equation4468 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ x) = (z ◇ w) ◇ u.

Definition Equation4469 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ y) = (x ◇ x) ◇ x.

Definition Equation4470 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ y) = (x ◇ x) ◇ y.

Definition Equation4471 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (x ◇ x) ◇ z.

Definition Equation4472 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ y) = (x ◇ y) ◇ x.

Definition Equation4473 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ y) = (x ◇ y) ◇ y.

Definition Equation4474 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (x ◇ y) ◇ z.

Definition Equation4475 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (x ◇ z) ◇ x.

Definition Equation4476 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (x ◇ z) ◇ y.

Definition Equation4477 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (x ◇ z) ◇ z.

Definition Equation4478 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = (x ◇ z) ◇ w.

Definition Equation4479 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ y) = (y ◇ x) ◇ x.

Definition Equation4480 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ y) = (y ◇ x) ◇ y.

Definition Equation4481 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (y ◇ x) ◇ z.

Definition Equation4482 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ y) = (y ◇ y) ◇ x.

Definition Equation4483 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x ◇ (y ◇ y) = (y ◇ y) ◇ y.

Definition Equation4484 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (y ◇ y) ◇ z.

Definition Equation4485 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (y ◇ z) ◇ x.

Definition Equation4486 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (y ◇ z) ◇ y.

Definition Equation4487 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (y ◇ z) ◇ z.

Definition Equation4488 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = (y ◇ z) ◇ w.

Definition Equation4489 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (z ◇ x) ◇ x.

Definition Equation4490 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (z ◇ x) ◇ y.

Definition Equation4491 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (z ◇ x) ◇ z.

Definition Equation4492 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = (z ◇ x) ◇ w.

Definition Equation4493 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (z ◇ y) ◇ x.

Definition Equation4494 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (z ◇ y) ◇ y.

Definition Equation4495 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (z ◇ y) ◇ z.

Definition Equation4496 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = (z ◇ y) ◇ w.

Definition Equation4497 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (z ◇ z) ◇ x.

Definition Equation4498 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (z ◇ z) ◇ y.

Definition Equation4499 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ y) = (z ◇ z) ◇ z.

Definition Equation4500 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = (z ◇ z) ◇ w.

Definition Equation4501 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = (z ◇ w) ◇ x.

Definition Equation4502 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = (z ◇ w) ◇ y.

Definition Equation4503 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = (z ◇ w) ◇ z.

Definition Equation4504 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ y) = (z ◇ w) ◇ w.

Definition Equation4505 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ y) = (z ◇ w) ◇ u.

Definition Equation4506 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (x ◇ x) ◇ x.

Definition Equation4507 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (x ◇ x) ◇ y.

Definition Equation4508 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (x ◇ x) ◇ z.

Definition Equation4509 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (x ◇ x) ◇ w.

Definition Equation4510 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (x ◇ y) ◇ x.

Definition Equation4511 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (x ◇ y) ◇ y.

Definition Equation4512 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (x ◇ y) ◇ z.

Definition Equation4513 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (x ◇ y) ◇ w.

Definition Equation4514 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (x ◇ z) ◇ x.

Definition Equation4515 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (x ◇ z) ◇ y.

Definition Equation4516 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (x ◇ z) ◇ z.

Definition Equation4517 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (x ◇ z) ◇ w.

Definition Equation4518 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (x ◇ w) ◇ x.

Definition Equation4519 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (x ◇ w) ◇ y.

Definition Equation4520 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (x ◇ w) ◇ z.

Definition Equation4521 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (x ◇ w) ◇ w.

Definition Equation4522 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = (x ◇ w) ◇ u.

Definition Equation4523 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (y ◇ x) ◇ x.

Definition Equation4524 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (y ◇ x) ◇ y.

Definition Equation4525 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (y ◇ x) ◇ z.

Definition Equation4526 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (y ◇ x) ◇ w.

Definition Equation4527 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (y ◇ y) ◇ x.

Definition Equation4528 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (y ◇ y) ◇ y.

Definition Equation4529 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (y ◇ y) ◇ z.

Definition Equation4530 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (y ◇ y) ◇ w.

Definition Equation4531 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (y ◇ z) ◇ x.

Definition Equation4532 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (y ◇ z) ◇ y.

Definition Equation4533 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (y ◇ z) ◇ z.

Definition Equation4534 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (y ◇ z) ◇ w.

Definition Equation4535 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (y ◇ w) ◇ x.

Definition Equation4536 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (y ◇ w) ◇ y.

Definition Equation4537 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (y ◇ w) ◇ z.

Definition Equation4538 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (y ◇ w) ◇ w.

Definition Equation4539 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = (y ◇ w) ◇ u.

Definition Equation4540 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (z ◇ x) ◇ x.

Definition Equation4541 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (z ◇ x) ◇ y.

Definition Equation4542 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (z ◇ x) ◇ z.

Definition Equation4543 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (z ◇ x) ◇ w.

Definition Equation4544 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (z ◇ y) ◇ x.

Definition Equation4545 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (z ◇ y) ◇ y.

Definition Equation4546 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (z ◇ y) ◇ z.

Definition Equation4547 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (z ◇ y) ◇ w.

Definition Equation4548 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (z ◇ z) ◇ x.

Definition Equation4549 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (z ◇ z) ◇ y.

Definition Equation4550 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ z) = (z ◇ z) ◇ z.

Definition Equation4551 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (z ◇ z) ◇ w.

Definition Equation4552 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (z ◇ w) ◇ x.

Definition Equation4553 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (z ◇ w) ◇ y.

Definition Equation4554 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (z ◇ w) ◇ z.

Definition Equation4555 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (z ◇ w) ◇ w.

Definition Equation4556 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = (z ◇ w) ◇ u.

Definition Equation4557 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ x) ◇ x.

Definition Equation4558 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ x) ◇ y.

Definition Equation4559 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ x) ◇ z.

Definition Equation4560 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ x) ◇ w.

Definition Equation4561 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = (w ◇ x) ◇ u.

Definition Equation4562 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ y) ◇ x.

Definition Equation4563 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ y) ◇ y.

Definition Equation4564 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ y) ◇ z.

Definition Equation4565 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ y) ◇ w.

Definition Equation4566 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = (w ◇ y) ◇ u.

Definition Equation4567 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ z) ◇ x.

Definition Equation4568 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ z) ◇ y.

Definition Equation4569 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ z) ◇ z.

Definition Equation4570 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ z) ◇ w.

Definition Equation4571 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = (w ◇ z) ◇ u.

Definition Equation4572 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ w) ◇ x.

Definition Equation4573 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ w) ◇ y.

Definition Equation4574 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ w) ◇ z.

Definition Equation4575 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x ◇ (y ◇ z) = (w ◇ w) ◇ w.

Definition Equation4576 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = (w ◇ w) ◇ u.

Definition Equation4577 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = (w ◇ u) ◇ x.

Definition Equation4578 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = (w ◇ u) ◇ y.

Definition Equation4579 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = (w ◇ u) ◇ z.

Definition Equation4580 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = (w ◇ u) ◇ w.

Definition Equation4581 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x ◇ (y ◇ z) = (w ◇ u) ◇ u.

Definition Equation4582 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x ◇ (y ◇ z) = (w ◇ u) ◇ v.

Definition Equation4583 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ x) ◇ x = (x ◇ x) ◇ y.

Definition Equation4584 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ x) ◇ x = (x ◇ y) ◇ x.

Definition Equation4585 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ x) ◇ x = (x ◇ y) ◇ y.

Definition Equation4586 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ x = (x ◇ y) ◇ z.

Definition Equation4587 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ x) ◇ x = (y ◇ x) ◇ x.

Definition Equation4588 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ x) ◇ x = (y ◇ x) ◇ y.

Definition Equation4589 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ x = (y ◇ x) ◇ z.

Definition Equation4590 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ x) ◇ x = (y ◇ y) ◇ x.

Definition Equation4591 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ x) ◇ x = (y ◇ y) ◇ y.

Definition Equation4592 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ x = (y ◇ y) ◇ z.

Definition Equation4593 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ x = (y ◇ z) ◇ x.

Definition Equation4594 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ x = (y ◇ z) ◇ y.

Definition Equation4595 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ x = (y ◇ z) ◇ z.

Definition Equation4596 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ x) ◇ x = (y ◇ z) ◇ w.

Definition Equation4597 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (x ◇ x) ◇ z.

Definition Equation4598 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ x) ◇ y = (x ◇ y) ◇ x.

Definition Equation4599 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ x) ◇ y = (x ◇ y) ◇ y.

Definition Equation4600 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (x ◇ y) ◇ z.

Definition Equation4601 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (x ◇ z) ◇ x.

Definition Equation4602 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (x ◇ z) ◇ y.

Definition Equation4603 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (x ◇ z) ◇ z.

Definition Equation4604 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ x) ◇ y = (x ◇ z) ◇ w.

Definition Equation4605 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ x) ◇ y = (y ◇ x) ◇ x.

Definition Equation4606 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ x) ◇ y = (y ◇ x) ◇ y.

Definition Equation4607 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (y ◇ x) ◇ z.

Definition Equation4608 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ x) ◇ y = (y ◇ y) ◇ x.

Definition Equation4609 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (y ◇ y) ◇ z.

Definition Equation4610 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (y ◇ z) ◇ x.

Definition Equation4611 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (y ◇ z) ◇ y.

Definition Equation4612 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (y ◇ z) ◇ z.

Definition Equation4613 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ x) ◇ y = (y ◇ z) ◇ w.

Definition Equation4614 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (z ◇ x) ◇ x.

Definition Equation4615 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (z ◇ x) ◇ y.

Definition Equation4616 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (z ◇ x) ◇ z.

Definition Equation4617 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ x) ◇ y = (z ◇ x) ◇ w.

Definition Equation4618 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (z ◇ y) ◇ x.

Definition Equation4619 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (z ◇ y) ◇ y.

Definition Equation4620 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (z ◇ y) ◇ z.

Definition Equation4621 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ x) ◇ y = (z ◇ y) ◇ w.

Definition Equation4622 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ x) ◇ y = (z ◇ z) ◇ y.

Definition Equation4623 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ x) ◇ y = (z ◇ z) ◇ w.

Definition Equation4624 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ x) ◇ y = (z ◇ w) ◇ x.

Definition Equation4625 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ x) ◇ y = (z ◇ w) ◇ y.

Definition Equation4626 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ x) ◇ y = (z ◇ w) ◇ z.

Definition Equation4627 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ x) ◇ y = (z ◇ w) ◇ w.

Definition Equation4628 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, (x ◇ x) ◇ y = (z ◇ w) ◇ u.

Definition Equation4629 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ y) ◇ x = (x ◇ y) ◇ y.

Definition Equation4630 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ x = (x ◇ y) ◇ z.

Definition Equation4631 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ x = (x ◇ z) ◇ x.

Definition Equation4632 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ x = (x ◇ z) ◇ y.

Definition Equation4633 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ x = (x ◇ z) ◇ z.

Definition Equation4634 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ x = (x ◇ z) ◇ w.

Definition Equation4635 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ y) ◇ x = (y ◇ x) ◇ x.

Definition Equation4636 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ y) ◇ x = (y ◇ x) ◇ y.

Definition Equation4637 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ x = (y ◇ x) ◇ z.

Definition Equation4638 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ x = (y ◇ z) ◇ x.

Definition Equation4639 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ x = (y ◇ z) ◇ y.

Definition Equation4640 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ x = (y ◇ z) ◇ z.

Definition Equation4641 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ x = (y ◇ z) ◇ w.

Definition Equation4642 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ x = (z ◇ x) ◇ x.

Definition Equation4643 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ x = (z ◇ x) ◇ y.

Definition Equation4644 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ x = (z ◇ x) ◇ w.

Definition Equation4645 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ x = (z ◇ y) ◇ x.

Definition Equation4646 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ x = (z ◇ y) ◇ y.

Definition Equation4647 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ x = (z ◇ y) ◇ z.

Definition Equation4648 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ x = (z ◇ y) ◇ w.

Definition Equation4649 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ x = (z ◇ w) ◇ x.

Definition Equation4650 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ x = (z ◇ w) ◇ y.

Definition Equation4651 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ x = (z ◇ w) ◇ z.

Definition Equation4652 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ x = (z ◇ w) ◇ w.

Definition Equation4653 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, (x ◇ y) ◇ x = (z ◇ w) ◇ u.

Definition Equation4654 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ y = (x ◇ y) ◇ z.

Definition Equation4655 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ y = (x ◇ z) ◇ y.

Definition Equation4656 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ y = (x ◇ z) ◇ z.

Definition Equation4657 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ y = (x ◇ z) ◇ w.

Definition Equation4658 (G : Type) `{Magma G} : Prop :=
  forall x y : G, (x ◇ y) ◇ y = (y ◇ x) ◇ x.

Definition Equation4659 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ y = (y ◇ x) ◇ z.

Definition Equation4660 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ y = (y ◇ z) ◇ x.

Definition Equation4661 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ y = (y ◇ z) ◇ z.

Definition Equation4662 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ y = (y ◇ z) ◇ w.

Definition Equation4663 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ y = (z ◇ x) ◇ y.

Definition Equation4664 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ y = (z ◇ x) ◇ w.

Definition Equation4665 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ y = (z ◇ y) ◇ x.

Definition Equation4666 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ y = (z ◇ y) ◇ y.

Definition Equation4667 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ y = (z ◇ y) ◇ w.

Definition Equation4668 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ y = (z ◇ w) ◇ x.

Definition Equation4669 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ y = (z ◇ w) ◇ y.

Definition Equation4670 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ y = (z ◇ w) ◇ w.

Definition Equation4671 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, (x ◇ y) ◇ y = (z ◇ w) ◇ u.

Definition Equation4672 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ z = (x ◇ y) ◇ w.

Definition Equation4673 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ z = (x ◇ z) ◇ y.

Definition Equation4674 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ z = (x ◇ z) ◇ w.

Definition Equation4675 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ z = (x ◇ w) ◇ z.

Definition Equation4676 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, (x ◇ y) ◇ z = (x ◇ w) ◇ u.

Definition Equation4677 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ z = (y ◇ x) ◇ z.

Definition Equation4678 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ z = (y ◇ x) ◇ w.

Definition Equation4679 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ z = (y ◇ z) ◇ x.

Definition Equation4680 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ z = (y ◇ z) ◇ w.

Definition Equation4681 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ z = (y ◇ w) ◇ x.

Definition Equation4682 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ z = (y ◇ w) ◇ z.

Definition Equation4683 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, (x ◇ y) ◇ z = (y ◇ w) ◇ u.

Definition Equation4684 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ z = (z ◇ y) ◇ x.

Definition Equation4685 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ z = (z ◇ y) ◇ w.

Definition Equation4686 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ z = (z ◇ w) ◇ x.

Definition Equation4687 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ z = (z ◇ w) ◇ y.

Definition Equation4688 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, (x ◇ y) ◇ z = (z ◇ w) ◇ u.

Definition Equation4689 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ z = (w ◇ y) ◇ z.

Definition Equation4690 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, (x ◇ y) ◇ z = (w ◇ y) ◇ u.

Definition Equation4691 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, (x ◇ y) ◇ z = (w ◇ z) ◇ y.

Definition Equation4692 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, (x ◇ y) ◇ z = (w ◇ z) ◇ u.

Definition Equation4693 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, (x ◇ y) ◇ z = (w ◇ u) ◇ z.

Definition Equation4694 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, (x ◇ y) ◇ z = (w ◇ u) ◇ v.

Definition Equation5093 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = y ◇ (y ◇ (y ◇ (x ◇ (z ◇ y)))).

Definition Equation26302 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ x) ◇ w)) ◇ (x ◇ w).

Definition Equation28770 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ y) ◇ x) ◇ (y ◇ z).

Definition Equation345169 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ y) ◇ y)) ◇ (x ◇ (z ◇ y)).

Definition Equation374794 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ y) ◇ x) ◇ ((y ◇ y) ◇ z).

Definition Equation910472 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ (x ◇ z)) = (x ◇ (y ◇ x)) ◇ z.

Definition Equation914612 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ (x ◇ z)) = ((x ◇ y) ◇ x) ◇ z.

Definition Equation916037 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ (y ◇ (z ◇ y)) = ((x ◇ y) ◇ z) ◇ y.

Definition Equation921941 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ ((y ◇ z) ◇ x) = (x ◇ y) ◇ (z ◇ x).

Definition Equation930594 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x ◇ ((y ◇ z) ◇ y) = ((x ◇ y) ◇ z) ◇ y.

Definition Equation936498 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, (x ◇ y) ◇ (z ◇ x) = (x ◇ (y ◇ z)) ◇ x.

Definition Equation1875916474 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (((y ◇ y) ◇ y) ◇ x) ◇ (((y ◇ y) ◇ ((y ◇ y) ◇ y)) ◇ z).

