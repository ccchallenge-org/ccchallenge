(** * Equations 2000–2999

    Auto-generated from the Lean4 Equational Theories Project. *)

From Stdlib Require Import Utf8.

From ETP Require Import Magma.

Open Scope magma_scope.

Definition Equation2000 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ z)) ◇ (z ◇ x).

Definition Equation2001 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ z)) ◇ (z ◇ y).

Definition Equation2002 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ z)) ◇ (z ◇ z).

Definition Equation2003 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ z)) ◇ (z ◇ w).

Definition Equation2004 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ z)) ◇ (w ◇ x).

Definition Equation2005 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ z)) ◇ (w ◇ y).

Definition Equation2006 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ z)) ◇ (w ◇ z).

Definition Equation2007 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ z)) ◇ (w ◇ w).

Definition Equation2008 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ z)) ◇ (w ◇ u).

Definition Equation2009 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (x ◇ x).

Definition Equation2010 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (x ◇ y).

Definition Equation2011 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (x ◇ z).

Definition Equation2012 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (x ◇ w).

Definition Equation2013 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ w)) ◇ (x ◇ u).

Definition Equation2014 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (y ◇ x).

Definition Equation2015 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (y ◇ y).

Definition Equation2016 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (y ◇ z).

Definition Equation2017 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (y ◇ w).

Definition Equation2018 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ w)) ◇ (y ◇ u).

Definition Equation2019 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (z ◇ x).

Definition Equation2020 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (z ◇ y).

Definition Equation2021 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (z ◇ z).

Definition Equation2022 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (z ◇ w).

Definition Equation2023 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ w)) ◇ (z ◇ u).

Definition Equation2024 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (w ◇ x).

Definition Equation2025 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (w ◇ y).

Definition Equation2026 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (w ◇ z).

Definition Equation2027 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ w)) ◇ (w ◇ w).

Definition Equation2028 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ w)) ◇ (w ◇ u).

Definition Equation2029 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ w)) ◇ (u ◇ x).

Definition Equation2030 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ w)) ◇ (u ◇ y).

Definition Equation2031 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ w)) ◇ (u ◇ z).

Definition Equation2032 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ w)) ◇ (u ◇ w).

Definition Equation2033 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ w)) ◇ (u ◇ u).

Definition Equation2034 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = (y ◇ (z ◇ w)) ◇ (u ◇ v).

Definition Equation2035 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = ((x ◇ x) ◇ x) ◇ (x ◇ x).

Definition Equation2036 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ x) ◇ (x ◇ y).

Definition Equation2037 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ x) ◇ (y ◇ x).

Definition Equation2038 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ x) ◇ (y ◇ y).

Definition Equation2039 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ x) ◇ x) ◇ (y ◇ z).

Definition Equation2040 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ y) ◇ (x ◇ x).

Definition Equation2041 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ y) ◇ (x ◇ y).

Definition Equation2042 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ x) ◇ y) ◇ (x ◇ z).

Definition Equation2043 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ y) ◇ (y ◇ x).

Definition Equation2044 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ y) ◇ (y ◇ y).

Definition Equation2045 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ x) ◇ y) ◇ (y ◇ z).

Definition Equation2046 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ x) ◇ y) ◇ (z ◇ x).

Definition Equation2047 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ x) ◇ y) ◇ (z ◇ y).

Definition Equation2048 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ x) ◇ y) ◇ (z ◇ z).

Definition Equation2049 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ x) ◇ y) ◇ (z ◇ w).

Definition Equation2050 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ x) ◇ (x ◇ x).

Definition Equation2051 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ x) ◇ (x ◇ y).

Definition Equation2052 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ x) ◇ (x ◇ z).

Definition Equation2053 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ x) ◇ (y ◇ x).

Definition Equation2054 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ x) ◇ (y ◇ y).

Definition Equation2055 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ x) ◇ (y ◇ z).

Definition Equation2056 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ x) ◇ (z ◇ x).

Definition Equation2057 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ x) ◇ (z ◇ y).

Definition Equation2058 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ x) ◇ (z ◇ z).

Definition Equation2059 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ x) ◇ (z ◇ w).

Definition Equation2060 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ y) ◇ (x ◇ x).

Definition Equation2061 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ y) ◇ (x ◇ y).

Definition Equation2062 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ y) ◇ (x ◇ z).

Definition Equation2063 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ y) ◇ (y ◇ x).

Definition Equation2064 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ y) ◇ (y ◇ y).

Definition Equation2065 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ y) ◇ (y ◇ z).

Definition Equation2066 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ y) ◇ (z ◇ x).

Definition Equation2067 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ y) ◇ (z ◇ y).

Definition Equation2068 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ y) ◇ (z ◇ z).

Definition Equation2069 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ y) ◇ (z ◇ w).

Definition Equation2070 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ z) ◇ (x ◇ x).

Definition Equation2071 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ z) ◇ (x ◇ y).

Definition Equation2072 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ z) ◇ (x ◇ z).

Definition Equation2073 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ z) ◇ (x ◇ w).

Definition Equation2074 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ z) ◇ (y ◇ x).

Definition Equation2075 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ z) ◇ (y ◇ y).

Definition Equation2076 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ z) ◇ (y ◇ z).

Definition Equation2077 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ z) ◇ (y ◇ w).

Definition Equation2078 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ z) ◇ (z ◇ x).

Definition Equation2079 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ z) ◇ (z ◇ y).

Definition Equation2080 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ z) ◇ (z ◇ z).

Definition Equation2081 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ z) ◇ (z ◇ w).

Definition Equation2082 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ z) ◇ (w ◇ x).

Definition Equation2083 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ z) ◇ (w ◇ y).

Definition Equation2084 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ z) ◇ (w ◇ z).

Definition Equation2085 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ z) ◇ (w ◇ w).

Definition Equation2086 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((x ◇ y) ◇ z) ◇ (w ◇ u).

Definition Equation2087 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ x) ◇ (x ◇ x).

Definition Equation2088 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ x) ◇ (x ◇ y).

Definition Equation2089 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ x) ◇ (x ◇ z).

Definition Equation2090 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ x) ◇ (y ◇ x).

Definition Equation2091 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ x) ◇ (y ◇ y).

Definition Equation2092 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ x) ◇ (y ◇ z).

Definition Equation2093 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ x) ◇ (z ◇ x).

Definition Equation2094 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ x) ◇ (z ◇ y).

Definition Equation2095 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ x) ◇ (z ◇ z).

Definition Equation2096 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ x) ◇ (z ◇ w).

Definition Equation2097 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ y) ◇ (x ◇ x).

Definition Equation2098 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ y) ◇ (x ◇ y).

Definition Equation2099 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ y) ◇ (x ◇ z).

Definition Equation2100 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ y) ◇ (y ◇ x).

Definition Equation2101 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ y) ◇ (y ◇ y).

Definition Equation2102 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ y) ◇ (y ◇ z).

Definition Equation2103 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ y) ◇ (z ◇ x).

Definition Equation2104 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ y) ◇ (z ◇ y).

Definition Equation2105 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ y) ◇ (z ◇ z).

Definition Equation2106 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ y) ◇ (z ◇ w).

Definition Equation2107 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ z) ◇ (x ◇ x).

Definition Equation2108 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ z) ◇ (x ◇ y).

Definition Equation2109 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ z) ◇ (x ◇ z).

Definition Equation2110 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ z) ◇ (x ◇ w).

Definition Equation2111 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ z) ◇ (y ◇ x).

Definition Equation2112 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ z) ◇ (y ◇ y).

Definition Equation2113 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ z) ◇ (y ◇ z).

Definition Equation2114 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ z) ◇ (y ◇ w).

Definition Equation2115 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ z) ◇ (z ◇ x).

Definition Equation2116 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ z) ◇ (z ◇ y).

Definition Equation2117 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ z) ◇ (z ◇ z).

Definition Equation2118 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ z) ◇ (z ◇ w).

Definition Equation2119 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ z) ◇ (w ◇ x).

Definition Equation2120 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ z) ◇ (w ◇ y).

Definition Equation2121 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ z) ◇ (w ◇ z).

Definition Equation2122 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ z) ◇ (w ◇ w).

Definition Equation2123 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ x) ◇ z) ◇ (w ◇ u).

Definition Equation2124 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ x) ◇ (x ◇ x).

Definition Equation2125 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ x) ◇ (x ◇ y).

Definition Equation2126 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ x) ◇ (x ◇ z).

Definition Equation2127 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ x) ◇ (y ◇ x).

Definition Equation2128 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ x) ◇ (y ◇ y).

Definition Equation2129 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ x) ◇ (y ◇ z).

Definition Equation2130 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ x) ◇ (z ◇ x).

Definition Equation2131 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ x) ◇ (z ◇ y).

Definition Equation2132 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ x) ◇ (z ◇ z).

Definition Equation2133 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ x) ◇ (z ◇ w).

Definition Equation2134 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ y) ◇ (x ◇ x).

Definition Equation2135 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ y) ◇ (x ◇ y).

Definition Equation2136 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ y) ◇ (x ◇ z).

Definition Equation2137 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ y) ◇ (y ◇ x).

Definition Equation2138 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ y) ◇ (y ◇ y).

Definition Equation2139 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ y) ◇ (y ◇ z).

Definition Equation2140 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ y) ◇ (z ◇ x).

Definition Equation2141 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ y) ◇ (z ◇ y).

Definition Equation2142 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ y) ◇ (z ◇ z).

Definition Equation2143 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ y) ◇ (z ◇ w).

Definition Equation2144 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ z) ◇ (x ◇ x).

Definition Equation2145 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ z) ◇ (x ◇ y).

Definition Equation2146 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ z) ◇ (x ◇ z).

Definition Equation2147 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ z) ◇ (x ◇ w).

Definition Equation2148 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ z) ◇ (y ◇ x).

Definition Equation2149 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ z) ◇ (y ◇ y).

Definition Equation2150 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ z) ◇ (y ◇ z).

Definition Equation2151 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ z) ◇ (y ◇ w).

Definition Equation2152 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ z) ◇ (z ◇ x).

Definition Equation2153 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ z) ◇ (z ◇ y).

Definition Equation2154 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ z) ◇ (z ◇ z).

Definition Equation2155 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ z) ◇ (z ◇ w).

Definition Equation2156 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ z) ◇ (w ◇ x).

Definition Equation2157 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ z) ◇ (w ◇ y).

Definition Equation2158 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ z) ◇ (w ◇ z).

Definition Equation2159 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ z) ◇ (w ◇ w).

Definition Equation2160 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ y) ◇ z) ◇ (w ◇ u).

Definition Equation2161 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ x) ◇ (x ◇ x).

Definition Equation2162 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ x) ◇ (x ◇ y).

Definition Equation2163 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ x) ◇ (x ◇ z).

Definition Equation2164 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ x) ◇ (x ◇ w).

Definition Equation2165 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ x) ◇ (y ◇ x).

Definition Equation2166 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ x) ◇ (y ◇ y).

Definition Equation2167 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ x) ◇ (y ◇ z).

Definition Equation2168 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ x) ◇ (y ◇ w).

Definition Equation2169 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ x) ◇ (z ◇ x).

Definition Equation2170 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ x) ◇ (z ◇ y).

Definition Equation2171 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ x) ◇ (z ◇ z).

Definition Equation2172 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ x) ◇ (z ◇ w).

Definition Equation2173 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ x) ◇ (w ◇ x).

Definition Equation2174 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ x) ◇ (w ◇ y).

Definition Equation2175 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ x) ◇ (w ◇ z).

Definition Equation2176 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ x) ◇ (w ◇ w).

Definition Equation2177 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ x) ◇ (w ◇ u).

Definition Equation2178 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ y) ◇ (x ◇ x).

Definition Equation2179 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ y) ◇ (x ◇ y).

Definition Equation2180 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ y) ◇ (x ◇ z).

Definition Equation2181 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ y) ◇ (x ◇ w).

Definition Equation2182 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ y) ◇ (y ◇ x).

Definition Equation2183 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ y) ◇ (y ◇ y).

Definition Equation2184 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ y) ◇ (y ◇ z).

Definition Equation2185 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ y) ◇ (y ◇ w).

Definition Equation2186 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ y) ◇ (z ◇ x).

Definition Equation2187 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ y) ◇ (z ◇ y).

Definition Equation2188 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ y) ◇ (z ◇ z).

Definition Equation2189 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ y) ◇ (z ◇ w).

Definition Equation2190 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ y) ◇ (w ◇ x).

Definition Equation2191 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ y) ◇ (w ◇ y).

Definition Equation2192 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ y) ◇ (w ◇ z).

Definition Equation2193 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ y) ◇ (w ◇ w).

Definition Equation2194 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ y) ◇ (w ◇ u).

Definition Equation2195 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ z) ◇ (x ◇ x).

Definition Equation2196 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ z) ◇ (x ◇ y).

Definition Equation2197 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ z) ◇ (x ◇ z).

Definition Equation2198 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ z) ◇ (x ◇ w).

Definition Equation2199 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ z) ◇ (y ◇ x).

Definition Equation2200 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ z) ◇ (y ◇ y).

Definition Equation2201 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ z) ◇ (y ◇ z).

Definition Equation2202 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ z) ◇ (y ◇ w).

Definition Equation2203 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ z) ◇ (z ◇ x).

Definition Equation2204 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ z) ◇ (z ◇ y).

Definition Equation2205 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ z) ◇ (z ◇ z).

Definition Equation2206 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ z) ◇ (z ◇ w).

Definition Equation2207 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ z) ◇ (w ◇ x).

Definition Equation2208 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ z) ◇ (w ◇ y).

Definition Equation2209 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ z) ◇ (w ◇ z).

Definition Equation2210 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ z) ◇ (w ◇ w).

Definition Equation2211 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ z) ◇ (w ◇ u).

Definition Equation2212 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (x ◇ x).

Definition Equation2213 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (x ◇ y).

Definition Equation2214 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (x ◇ z).

Definition Equation2215 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (x ◇ w).

Definition Equation2216 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ w) ◇ (x ◇ u).

Definition Equation2217 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (y ◇ x).

Definition Equation2218 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (y ◇ y).

Definition Equation2219 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (y ◇ z).

Definition Equation2220 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (y ◇ w).

Definition Equation2221 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ w) ◇ (y ◇ u).

Definition Equation2222 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (z ◇ x).

Definition Equation2223 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (z ◇ y).

Definition Equation2224 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (z ◇ z).

Definition Equation2225 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (z ◇ w).

Definition Equation2226 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ w) ◇ (z ◇ u).

Definition Equation2227 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (w ◇ x).

Definition Equation2228 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (w ◇ y).

Definition Equation2229 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (w ◇ z).

Definition Equation2230 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ w) ◇ (w ◇ w).

Definition Equation2231 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ w) ◇ (w ◇ u).

Definition Equation2232 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ w) ◇ (u ◇ x).

Definition Equation2233 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ w) ◇ (u ◇ y).

Definition Equation2234 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ w) ◇ (u ◇ z).

Definition Equation2235 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ w) ◇ (u ◇ w).

Definition Equation2236 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ w) ◇ (u ◇ u).

Definition Equation2237 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = ((y ◇ z) ◇ w) ◇ (u ◇ v).

Definition Equation2238 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = (x ◇ (x ◇ (x ◇ x))) ◇ x.

Definition Equation2239 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ (x ◇ x))) ◇ y.

Definition Equation2240 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ (x ◇ y))) ◇ x.

Definition Equation2241 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ (x ◇ y))) ◇ y.

Definition Equation2242 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (x ◇ (x ◇ y))) ◇ z.

Definition Equation2243 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ (y ◇ x))) ◇ x.

Definition Equation2244 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ (y ◇ x))) ◇ y.

Definition Equation2245 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (x ◇ (y ◇ x))) ◇ z.

Definition Equation2246 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ (y ◇ y))) ◇ x.

Definition Equation2247 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (x ◇ (y ◇ y))) ◇ y.

Definition Equation2248 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (x ◇ (y ◇ y))) ◇ z.

Definition Equation2249 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (x ◇ (y ◇ z))) ◇ x.

Definition Equation2250 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (x ◇ (y ◇ z))) ◇ y.

Definition Equation2251 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (x ◇ (y ◇ z))) ◇ z.

Definition Equation2252 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (x ◇ (y ◇ z))) ◇ w.

Definition Equation2253 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ (x ◇ x))) ◇ x.

Definition Equation2254 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ (x ◇ x))) ◇ y.

Definition Equation2255 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (x ◇ x))) ◇ z.

Definition Equation2256 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ (x ◇ y))) ◇ x.

Definition Equation2257 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ (x ◇ y))) ◇ y.

Definition Equation2258 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (x ◇ y))) ◇ z.

Definition Equation2259 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (x ◇ z))) ◇ x.

Definition Equation2260 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (x ◇ z))) ◇ y.

Definition Equation2261 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (x ◇ z))) ◇ z.

Definition Equation2262 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ (x ◇ z))) ◇ w.

Definition Equation2263 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ (y ◇ x))) ◇ x.

Definition Equation2264 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ (y ◇ x))) ◇ y.

Definition Equation2265 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (y ◇ x))) ◇ z.

Definition Equation2266 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ (y ◇ y))) ◇ x.

Definition Equation2267 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ (y ◇ (y ◇ y))) ◇ y.

Definition Equation2268 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (y ◇ y))) ◇ z.

Definition Equation2269 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (y ◇ z))) ◇ x.

Definition Equation2270 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (y ◇ z))) ◇ y.

Definition Equation2271 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (y ◇ z))) ◇ z.

Definition Equation2272 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ (y ◇ z))) ◇ w.

Definition Equation2273 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (z ◇ x))) ◇ x.

Definition Equation2274 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (z ◇ x))) ◇ y.

Definition Equation2275 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (z ◇ x))) ◇ z.

Definition Equation2276 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ (z ◇ x))) ◇ w.

Definition Equation2277 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (z ◇ y))) ◇ x.

Definition Equation2278 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (z ◇ y))) ◇ y.

Definition Equation2279 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (z ◇ y))) ◇ z.

Definition Equation2280 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ (z ◇ y))) ◇ w.

Definition Equation2281 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (z ◇ z))) ◇ x.

Definition Equation2282 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (z ◇ z))) ◇ y.

Definition Equation2283 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ (y ◇ (z ◇ z))) ◇ z.

Definition Equation2284 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ (z ◇ z))) ◇ w.

Definition Equation2285 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ (z ◇ w))) ◇ x.

Definition Equation2286 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ (z ◇ w))) ◇ y.

Definition Equation2287 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ (z ◇ w))) ◇ z.

Definition Equation2288 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ (y ◇ (z ◇ w))) ◇ w.

Definition Equation2289 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (x ◇ (y ◇ (z ◇ w))) ◇ u.

Definition Equation2290 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ (x ◇ x))) ◇ x.

Definition Equation2291 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ (x ◇ x))) ◇ y.

Definition Equation2292 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (x ◇ x))) ◇ z.

Definition Equation2293 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ (x ◇ y))) ◇ x.

Definition Equation2294 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ (x ◇ y))) ◇ y.

Definition Equation2295 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (x ◇ y))) ◇ z.

Definition Equation2296 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (x ◇ z))) ◇ x.

Definition Equation2297 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (x ◇ z))) ◇ y.

Definition Equation2298 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (x ◇ z))) ◇ z.

Definition Equation2299 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ (x ◇ z))) ◇ w.

Definition Equation2300 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ (y ◇ x))) ◇ x.

Definition Equation2301 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ (y ◇ x))) ◇ y.

Definition Equation2302 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (y ◇ x))) ◇ z.

Definition Equation2303 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ (y ◇ y))) ◇ x.

Definition Equation2304 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (x ◇ (y ◇ y))) ◇ y.

Definition Equation2305 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (y ◇ y))) ◇ z.

Definition Equation2306 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (y ◇ z))) ◇ x.

Definition Equation2307 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (y ◇ z))) ◇ y.

Definition Equation2308 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (y ◇ z))) ◇ z.

Definition Equation2309 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ (y ◇ z))) ◇ w.

Definition Equation2310 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (z ◇ x))) ◇ x.

Definition Equation2311 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (z ◇ x))) ◇ y.

Definition Equation2312 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (z ◇ x))) ◇ z.

Definition Equation2313 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ (z ◇ x))) ◇ w.

Definition Equation2314 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (z ◇ y))) ◇ x.

Definition Equation2315 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (z ◇ y))) ◇ y.

Definition Equation2316 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (z ◇ y))) ◇ z.

Definition Equation2317 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ (z ◇ y))) ◇ w.

Definition Equation2318 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (z ◇ z))) ◇ x.

Definition Equation2319 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (z ◇ z))) ◇ y.

Definition Equation2320 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (x ◇ (z ◇ z))) ◇ z.

Definition Equation2321 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ (z ◇ z))) ◇ w.

Definition Equation2322 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ (z ◇ w))) ◇ x.

Definition Equation2323 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ (z ◇ w))) ◇ y.

Definition Equation2324 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ (z ◇ w))) ◇ z.

Definition Equation2325 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (x ◇ (z ◇ w))) ◇ w.

Definition Equation2326 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (x ◇ (z ◇ w))) ◇ u.

Definition Equation2327 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ (x ◇ x))) ◇ x.

Definition Equation2328 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ (x ◇ x))) ◇ y.

Definition Equation2329 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (x ◇ x))) ◇ z.

Definition Equation2330 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ (x ◇ y))) ◇ x.

Definition Equation2331 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ (x ◇ y))) ◇ y.

Definition Equation2332 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (x ◇ y))) ◇ z.

Definition Equation2333 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (x ◇ z))) ◇ x.

Definition Equation2334 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (x ◇ z))) ◇ y.

Definition Equation2335 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (x ◇ z))) ◇ z.

Definition Equation2336 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ (x ◇ z))) ◇ w.

Definition Equation2337 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ (y ◇ x))) ◇ x.

Definition Equation2338 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ (y ◇ x))) ◇ y.

Definition Equation2339 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (y ◇ x))) ◇ z.

Definition Equation2340 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ (y ◇ y))) ◇ x.

Definition Equation2341 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ (y ◇ (y ◇ y))) ◇ y.

Definition Equation2342 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (y ◇ y))) ◇ z.

Definition Equation2343 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (y ◇ z))) ◇ x.

Definition Equation2344 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (y ◇ z))) ◇ y.

Definition Equation2345 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (y ◇ z))) ◇ z.

Definition Equation2346 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ (y ◇ z))) ◇ w.

Definition Equation2347 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (z ◇ x))) ◇ x.

Definition Equation2348 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (z ◇ x))) ◇ y.

Definition Equation2349 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (z ◇ x))) ◇ z.

Definition Equation2350 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ (z ◇ x))) ◇ w.

Definition Equation2351 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (z ◇ y))) ◇ x.

Definition Equation2352 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (z ◇ y))) ◇ y.

Definition Equation2353 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (z ◇ y))) ◇ z.

Definition Equation2354 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ (z ◇ y))) ◇ w.

Definition Equation2355 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (z ◇ z))) ◇ x.

Definition Equation2356 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (z ◇ z))) ◇ y.

Definition Equation2357 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (y ◇ (z ◇ z))) ◇ z.

Definition Equation2358 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ (z ◇ z))) ◇ w.

Definition Equation2359 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ (z ◇ w))) ◇ x.

Definition Equation2360 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ (z ◇ w))) ◇ y.

Definition Equation2361 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ (z ◇ w))) ◇ z.

Definition Equation2362 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (y ◇ (z ◇ w))) ◇ w.

Definition Equation2363 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (y ◇ (z ◇ w))) ◇ u.

Definition Equation2364 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (x ◇ x))) ◇ x.

Definition Equation2365 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (x ◇ x))) ◇ y.

Definition Equation2366 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (x ◇ x))) ◇ z.

Definition Equation2367 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (x ◇ x))) ◇ w.

Definition Equation2368 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (x ◇ y))) ◇ x.

Definition Equation2369 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (x ◇ y))) ◇ y.

Definition Equation2370 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (x ◇ y))) ◇ z.

Definition Equation2371 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (x ◇ y))) ◇ w.

Definition Equation2372 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (x ◇ z))) ◇ x.

Definition Equation2373 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (x ◇ z))) ◇ y.

Definition Equation2374 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (x ◇ z))) ◇ z.

Definition Equation2375 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (x ◇ z))) ◇ w.

Definition Equation2376 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (x ◇ w))) ◇ x.

Definition Equation2377 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (x ◇ w))) ◇ y.

Definition Equation2378 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (x ◇ w))) ◇ z.

Definition Equation2379 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (x ◇ w))) ◇ w.

Definition Equation2380 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ (x ◇ w))) ◇ u.

Definition Equation2381 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (y ◇ x))) ◇ x.

Definition Equation2382 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (y ◇ x))) ◇ y.

Definition Equation2383 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (y ◇ x))) ◇ z.

Definition Equation2384 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (y ◇ x))) ◇ w.

Definition Equation2385 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (y ◇ y))) ◇ x.

Definition Equation2386 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (y ◇ y))) ◇ y.

Definition Equation2387 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (y ◇ y))) ◇ z.

Definition Equation2388 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (y ◇ y))) ◇ w.

Definition Equation2389 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (y ◇ z))) ◇ x.

Definition Equation2390 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (y ◇ z))) ◇ y.

Definition Equation2391 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (y ◇ z))) ◇ z.

Definition Equation2392 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (y ◇ z))) ◇ w.

Definition Equation2393 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (y ◇ w))) ◇ x.

Definition Equation2394 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (y ◇ w))) ◇ y.

Definition Equation2395 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (y ◇ w))) ◇ z.

Definition Equation2396 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (y ◇ w))) ◇ w.

Definition Equation2397 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ (y ◇ w))) ◇ u.

Definition Equation2398 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (z ◇ x))) ◇ x.

Definition Equation2399 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (z ◇ x))) ◇ y.

Definition Equation2400 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (z ◇ x))) ◇ z.

Definition Equation2401 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (z ◇ x))) ◇ w.

Definition Equation2402 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (z ◇ y))) ◇ x.

Definition Equation2403 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (z ◇ y))) ◇ y.

Definition Equation2404 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (z ◇ y))) ◇ z.

Definition Equation2405 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (z ◇ y))) ◇ w.

Definition Equation2406 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (z ◇ z))) ◇ x.

Definition Equation2407 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (z ◇ z))) ◇ y.

Definition Equation2408 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ (z ◇ (z ◇ z))) ◇ z.

Definition Equation2409 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (z ◇ z))) ◇ w.

Definition Equation2410 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (z ◇ w))) ◇ x.

Definition Equation2411 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (z ◇ w))) ◇ y.

Definition Equation2412 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (z ◇ w))) ◇ z.

Definition Equation2413 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (z ◇ w))) ◇ w.

Definition Equation2414 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ (z ◇ w))) ◇ u.

Definition Equation2415 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ x))) ◇ x.

Definition Equation2416 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ x))) ◇ y.

Definition Equation2417 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ x))) ◇ z.

Definition Equation2418 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ x))) ◇ w.

Definition Equation2419 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ (w ◇ x))) ◇ u.

Definition Equation2420 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ y))) ◇ x.

Definition Equation2421 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ y))) ◇ y.

Definition Equation2422 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ y))) ◇ z.

Definition Equation2423 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ y))) ◇ w.

Definition Equation2424 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ (w ◇ y))) ◇ u.

Definition Equation2425 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ z))) ◇ x.

Definition Equation2426 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ z))) ◇ y.

Definition Equation2427 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ z))) ◇ z.

Definition Equation2428 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ z))) ◇ w.

Definition Equation2429 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ (w ◇ z))) ◇ u.

Definition Equation2430 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ w))) ◇ x.

Definition Equation2431 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ w))) ◇ y.

Definition Equation2432 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ w))) ◇ z.

Definition Equation2433 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ (z ◇ (w ◇ w))) ◇ w.

Definition Equation2434 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ (w ◇ w))) ◇ u.

Definition Equation2435 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ (w ◇ u))) ◇ x.

Definition Equation2436 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ (w ◇ u))) ◇ y.

Definition Equation2437 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ (w ◇ u))) ◇ z.

Definition Equation2438 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ (w ◇ u))) ◇ w.

Definition Equation2439 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ (z ◇ (w ◇ u))) ◇ u.

Definition Equation2440 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = (y ◇ (z ◇ (w ◇ u))) ◇ v.

Definition Equation2441 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = (x ◇ ((x ◇ x) ◇ x)) ◇ x.

Definition Equation2442 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((x ◇ x) ◇ x)) ◇ y.

Definition Equation2443 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((x ◇ x) ◇ y)) ◇ x.

Definition Equation2444 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((x ◇ x) ◇ y)) ◇ y.

Definition Equation2445 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((x ◇ x) ◇ y)) ◇ z.

Definition Equation2446 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((x ◇ y) ◇ x)) ◇ x.

Definition Equation2447 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((x ◇ y) ◇ x)) ◇ y.

Definition Equation2448 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((x ◇ y) ◇ x)) ◇ z.

Definition Equation2449 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((x ◇ y) ◇ y)) ◇ x.

Definition Equation2450 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((x ◇ y) ◇ y)) ◇ y.

Definition Equation2451 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((x ◇ y) ◇ y)) ◇ z.

Definition Equation2452 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((x ◇ y) ◇ z)) ◇ x.

Definition Equation2453 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((x ◇ y) ◇ z)) ◇ y.

Definition Equation2454 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((x ◇ y) ◇ z)) ◇ z.

Definition Equation2455 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ ((x ◇ y) ◇ z)) ◇ w.

Definition Equation2456 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((y ◇ x) ◇ x)) ◇ x.

Definition Equation2457 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((y ◇ x) ◇ x)) ◇ y.

Definition Equation2458 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ x) ◇ x)) ◇ z.

Definition Equation2459 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((y ◇ x) ◇ y)) ◇ x.

Definition Equation2460 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((y ◇ x) ◇ y)) ◇ y.

Definition Equation2461 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ x) ◇ y)) ◇ z.

Definition Equation2462 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ x) ◇ z)) ◇ x.

Definition Equation2463 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ x) ◇ z)) ◇ y.

Definition Equation2464 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ x) ◇ z)) ◇ z.

Definition Equation2465 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ ((y ◇ x) ◇ z)) ◇ w.

Definition Equation2466 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((y ◇ y) ◇ x)) ◇ x.

Definition Equation2467 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((y ◇ y) ◇ x)) ◇ y.

Definition Equation2468 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ y) ◇ x)) ◇ z.

Definition Equation2469 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((y ◇ y) ◇ y)) ◇ x.

Definition Equation2470 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (x ◇ ((y ◇ y) ◇ y)) ◇ y.

Definition Equation2471 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ y) ◇ y)) ◇ z.

Definition Equation2472 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ y) ◇ z)) ◇ x.

Definition Equation2473 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ y) ◇ z)) ◇ y.

Definition Equation2474 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ y) ◇ z)) ◇ z.

Definition Equation2475 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ ((y ◇ y) ◇ z)) ◇ w.

Definition Equation2476 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ z) ◇ x)) ◇ x.

Definition Equation2477 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ z) ◇ x)) ◇ y.

Definition Equation2478 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ z) ◇ x)) ◇ z.

Definition Equation2479 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ ((y ◇ z) ◇ x)) ◇ w.

Definition Equation2480 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ z) ◇ y)) ◇ x.

Definition Equation2481 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ z) ◇ y)) ◇ y.

Definition Equation2482 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ z) ◇ y)) ◇ z.

Definition Equation2483 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ ((y ◇ z) ◇ y)) ◇ w.

Definition Equation2484 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ z) ◇ z)) ◇ x.

Definition Equation2485 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ z) ◇ z)) ◇ y.

Definition Equation2486 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (x ◇ ((y ◇ z) ◇ z)) ◇ z.

Definition Equation2487 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ ((y ◇ z) ◇ z)) ◇ w.

Definition Equation2488 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ ((y ◇ z) ◇ w)) ◇ x.

Definition Equation2489 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ ((y ◇ z) ◇ w)) ◇ y.

Definition Equation2490 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ ((y ◇ z) ◇ w)) ◇ z.

Definition Equation2491 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (x ◇ ((y ◇ z) ◇ w)) ◇ w.

Definition Equation2492 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (x ◇ ((y ◇ z) ◇ w)) ◇ u.

Definition Equation2493 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((x ◇ x) ◇ x)) ◇ x.

Definition Equation2494 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((x ◇ x) ◇ x)) ◇ y.

Definition Equation2495 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ x) ◇ x)) ◇ z.

Definition Equation2496 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((x ◇ x) ◇ y)) ◇ x.

Definition Equation2497 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((x ◇ x) ◇ y)) ◇ y.

Definition Equation2498 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ x) ◇ y)) ◇ z.

Definition Equation2499 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ x) ◇ z)) ◇ x.

Definition Equation2500 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ x) ◇ z)) ◇ y.

Definition Equation2501 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ x) ◇ z)) ◇ z.

Definition Equation2502 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((x ◇ x) ◇ z)) ◇ w.

Definition Equation2503 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((x ◇ y) ◇ x)) ◇ x.

Definition Equation2504 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((x ◇ y) ◇ x)) ◇ y.

Definition Equation2505 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ y) ◇ x)) ◇ z.

Definition Equation2506 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((x ◇ y) ◇ y)) ◇ x.

Definition Equation2507 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((x ◇ y) ◇ y)) ◇ y.

Definition Equation2508 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ y) ◇ y)) ◇ z.

Definition Equation2509 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ y) ◇ z)) ◇ x.

Definition Equation2510 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ y) ◇ z)) ◇ y.

Definition Equation2511 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ y) ◇ z)) ◇ z.

Definition Equation2512 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((x ◇ y) ◇ z)) ◇ w.

Definition Equation2513 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ z) ◇ x)) ◇ x.

Definition Equation2514 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ z) ◇ x)) ◇ y.

Definition Equation2515 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ z) ◇ x)) ◇ z.

Definition Equation2516 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((x ◇ z) ◇ x)) ◇ w.

Definition Equation2517 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ z) ◇ y)) ◇ x.

Definition Equation2518 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ z) ◇ y)) ◇ y.

Definition Equation2519 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ z) ◇ y)) ◇ z.

Definition Equation2520 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((x ◇ z) ◇ y)) ◇ w.

Definition Equation2521 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ z) ◇ z)) ◇ x.

Definition Equation2522 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ z) ◇ z)) ◇ y.

Definition Equation2523 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((x ◇ z) ◇ z)) ◇ z.

Definition Equation2524 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((x ◇ z) ◇ z)) ◇ w.

Definition Equation2525 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((x ◇ z) ◇ w)) ◇ x.

Definition Equation2526 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((x ◇ z) ◇ w)) ◇ y.

Definition Equation2527 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((x ◇ z) ◇ w)) ◇ z.

Definition Equation2528 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((x ◇ z) ◇ w)) ◇ w.

Definition Equation2529 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((x ◇ z) ◇ w)) ◇ u.

Definition Equation2530 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((y ◇ x) ◇ x)) ◇ x.

Definition Equation2531 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((y ◇ x) ◇ x)) ◇ y.

Definition Equation2532 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ x) ◇ x)) ◇ z.

Definition Equation2533 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((y ◇ x) ◇ y)) ◇ x.

Definition Equation2534 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((y ◇ x) ◇ y)) ◇ y.

Definition Equation2535 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ x) ◇ y)) ◇ z.

Definition Equation2536 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ x) ◇ z)) ◇ x.

Definition Equation2537 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ x) ◇ z)) ◇ y.

Definition Equation2538 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ x) ◇ z)) ◇ z.

Definition Equation2539 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((y ◇ x) ◇ z)) ◇ w.

Definition Equation2540 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((y ◇ y) ◇ x)) ◇ x.

Definition Equation2541 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((y ◇ y) ◇ x)) ◇ y.

Definition Equation2542 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ y) ◇ x)) ◇ z.

Definition Equation2543 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((y ◇ y) ◇ y)) ◇ x.

Definition Equation2544 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = (y ◇ ((y ◇ y) ◇ y)) ◇ y.

Definition Equation2545 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ y) ◇ y)) ◇ z.

Definition Equation2546 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ y) ◇ z)) ◇ x.

Definition Equation2547 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ y) ◇ z)) ◇ y.

Definition Equation2548 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ y) ◇ z)) ◇ z.

Definition Equation2549 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((y ◇ y) ◇ z)) ◇ w.

Definition Equation2550 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ z) ◇ x)) ◇ x.

Definition Equation2551 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ z) ◇ x)) ◇ y.

Definition Equation2552 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ z) ◇ x)) ◇ z.

Definition Equation2553 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((y ◇ z) ◇ x)) ◇ w.

Definition Equation2554 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ z) ◇ y)) ◇ x.

Definition Equation2555 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ z) ◇ y)) ◇ y.

Definition Equation2556 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ z) ◇ y)) ◇ z.

Definition Equation2557 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((y ◇ z) ◇ y)) ◇ w.

Definition Equation2558 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ z) ◇ z)) ◇ x.

Definition Equation2559 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ z) ◇ z)) ◇ y.

Definition Equation2560 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((y ◇ z) ◇ z)) ◇ z.

Definition Equation2561 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((y ◇ z) ◇ z)) ◇ w.

Definition Equation2562 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((y ◇ z) ◇ w)) ◇ x.

Definition Equation2563 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((y ◇ z) ◇ w)) ◇ y.

Definition Equation2564 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((y ◇ z) ◇ w)) ◇ z.

Definition Equation2565 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((y ◇ z) ◇ w)) ◇ w.

Definition Equation2566 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((y ◇ z) ◇ w)) ◇ u.

Definition Equation2567 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ x) ◇ x)) ◇ x.

Definition Equation2568 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ x) ◇ x)) ◇ y.

Definition Equation2569 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ x) ◇ x)) ◇ z.

Definition Equation2570 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ x) ◇ x)) ◇ w.

Definition Equation2571 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ x) ◇ y)) ◇ x.

Definition Equation2572 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ x) ◇ y)) ◇ y.

Definition Equation2573 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ x) ◇ y)) ◇ z.

Definition Equation2574 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ x) ◇ y)) ◇ w.

Definition Equation2575 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ x) ◇ z)) ◇ x.

Definition Equation2576 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ x) ◇ z)) ◇ y.

Definition Equation2577 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ x) ◇ z)) ◇ z.

Definition Equation2578 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ x) ◇ z)) ◇ w.

Definition Equation2579 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ x) ◇ w)) ◇ x.

Definition Equation2580 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ x) ◇ w)) ◇ y.

Definition Equation2581 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ x) ◇ w)) ◇ z.

Definition Equation2582 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ x) ◇ w)) ◇ w.

Definition Equation2583 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((z ◇ x) ◇ w)) ◇ u.

Definition Equation2584 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ y) ◇ x)) ◇ x.

Definition Equation2585 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ y) ◇ x)) ◇ y.

Definition Equation2586 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ y) ◇ x)) ◇ z.

Definition Equation2587 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ y) ◇ x)) ◇ w.

Definition Equation2588 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ y) ◇ y)) ◇ x.

Definition Equation2589 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ y) ◇ y)) ◇ y.

Definition Equation2590 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ y) ◇ y)) ◇ z.

Definition Equation2591 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ y) ◇ y)) ◇ w.

Definition Equation2592 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ y) ◇ z)) ◇ x.

Definition Equation2593 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ y) ◇ z)) ◇ y.

Definition Equation2594 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ y) ◇ z)) ◇ z.

Definition Equation2595 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ y) ◇ z)) ◇ w.

Definition Equation2596 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ y) ◇ w)) ◇ x.

Definition Equation2597 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ y) ◇ w)) ◇ y.

Definition Equation2598 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ y) ◇ w)) ◇ z.

Definition Equation2599 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ y) ◇ w)) ◇ w.

Definition Equation2600 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((z ◇ y) ◇ w)) ◇ u.

Definition Equation2601 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ z) ◇ x)) ◇ x.

Definition Equation2602 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ z) ◇ x)) ◇ y.

Definition Equation2603 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ z) ◇ x)) ◇ z.

Definition Equation2604 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ z) ◇ x)) ◇ w.

Definition Equation2605 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ z) ◇ y)) ◇ x.

Definition Equation2606 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ z) ◇ y)) ◇ y.

Definition Equation2607 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ z) ◇ y)) ◇ z.

Definition Equation2608 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ z) ◇ y)) ◇ w.

Definition Equation2609 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ z) ◇ z)) ◇ x.

Definition Equation2610 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ z) ◇ z)) ◇ y.

Definition Equation2611 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = (y ◇ ((z ◇ z) ◇ z)) ◇ z.

Definition Equation2612 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ z) ◇ z)) ◇ w.

Definition Equation2613 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ z) ◇ w)) ◇ x.

Definition Equation2614 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ z) ◇ w)) ◇ y.

Definition Equation2615 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ z) ◇ w)) ◇ z.

Definition Equation2616 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ z) ◇ w)) ◇ w.

Definition Equation2617 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((z ◇ z) ◇ w)) ◇ u.

Definition Equation2618 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ x)) ◇ x.

Definition Equation2619 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ x)) ◇ y.

Definition Equation2620 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ x)) ◇ z.

Definition Equation2621 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ x)) ◇ w.

Definition Equation2622 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((z ◇ w) ◇ x)) ◇ u.

Definition Equation2623 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ y)) ◇ x.

Definition Equation2624 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ y)) ◇ y.

Definition Equation2625 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ y)) ◇ z.

Definition Equation2626 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ y)) ◇ w.

Definition Equation2627 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((z ◇ w) ◇ y)) ◇ u.

Definition Equation2628 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ z)) ◇ x.

Definition Equation2629 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ z)) ◇ y.

Definition Equation2630 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ z)) ◇ z.

Definition Equation2631 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ z)) ◇ w.

Definition Equation2632 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((z ◇ w) ◇ z)) ◇ u.

Definition Equation2633 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ w)) ◇ x.

Definition Equation2634 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ w)) ◇ y.

Definition Equation2635 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ w)) ◇ z.

Definition Equation2636 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = (y ◇ ((z ◇ w) ◇ w)) ◇ w.

Definition Equation2637 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((z ◇ w) ◇ w)) ◇ u.

Definition Equation2638 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((z ◇ w) ◇ u)) ◇ x.

Definition Equation2639 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((z ◇ w) ◇ u)) ◇ y.

Definition Equation2640 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((z ◇ w) ◇ u)) ◇ z.

Definition Equation2641 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((z ◇ w) ◇ u)) ◇ w.

Definition Equation2642 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = (y ◇ ((z ◇ w) ◇ u)) ◇ u.

Definition Equation2643 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = (y ◇ ((z ◇ w) ◇ u)) ◇ v.

Definition Equation2644 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = ((x ◇ x) ◇ (x ◇ x)) ◇ x.

Definition Equation2645 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ (x ◇ x)) ◇ y.

Definition Equation2646 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ (x ◇ y)) ◇ x.

Definition Equation2647 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ (x ◇ y)) ◇ y.

Definition Equation2648 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ x) ◇ (x ◇ y)) ◇ z.

Definition Equation2649 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ (y ◇ x)) ◇ x.

Definition Equation2650 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ (y ◇ x)) ◇ y.

Definition Equation2651 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ x) ◇ (y ◇ x)) ◇ z.

Definition Equation2652 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ (y ◇ y)) ◇ x.

Definition Equation2653 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ x) ◇ (y ◇ y)) ◇ y.

Definition Equation2654 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ x) ◇ (y ◇ y)) ◇ z.

Definition Equation2655 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ x) ◇ (y ◇ z)) ◇ x.

Definition Equation2656 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ x) ◇ (y ◇ z)) ◇ y.

Definition Equation2657 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ x) ◇ (y ◇ z)) ◇ z.

Definition Equation2658 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ x) ◇ (y ◇ z)) ◇ w.

Definition Equation2659 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ (x ◇ x)) ◇ x.

Definition Equation2660 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ (x ◇ x)) ◇ y.

Definition Equation2661 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (x ◇ x)) ◇ z.

Definition Equation2662 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ (x ◇ y)) ◇ x.

Definition Equation2663 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ (x ◇ y)) ◇ y.

Definition Equation2664 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (x ◇ y)) ◇ z.

Definition Equation2665 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (x ◇ z)) ◇ x.

Definition Equation2666 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (x ◇ z)) ◇ y.

Definition Equation2667 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (x ◇ z)) ◇ z.

Definition Equation2668 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ (x ◇ z)) ◇ w.

Definition Equation2669 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ (y ◇ x)) ◇ x.

Definition Equation2670 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ (y ◇ x)) ◇ y.

Definition Equation2671 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (y ◇ x)) ◇ z.

Definition Equation2672 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ (y ◇ y)) ◇ x.

Definition Equation2673 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ y) ◇ (y ◇ y)) ◇ y.

Definition Equation2674 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (y ◇ y)) ◇ z.

Definition Equation2675 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (y ◇ z)) ◇ x.

Definition Equation2676 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (y ◇ z)) ◇ y.

Definition Equation2677 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (y ◇ z)) ◇ z.

Definition Equation2678 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ (y ◇ z)) ◇ w.

Definition Equation2679 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (z ◇ x)) ◇ x.

Definition Equation2680 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (z ◇ x)) ◇ y.

Definition Equation2681 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (z ◇ x)) ◇ z.

Definition Equation2682 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ (z ◇ x)) ◇ w.

Definition Equation2683 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (z ◇ y)) ◇ x.

Definition Equation2684 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (z ◇ y)) ◇ y.

Definition Equation2685 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (z ◇ y)) ◇ z.

Definition Equation2686 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ (z ◇ y)) ◇ w.

Definition Equation2687 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (z ◇ z)) ◇ x.

Definition Equation2688 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (z ◇ z)) ◇ y.

Definition Equation2689 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ y) ◇ (z ◇ z)) ◇ z.

Definition Equation2690 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ (z ◇ z)) ◇ w.

Definition Equation2691 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ (z ◇ w)) ◇ x.

Definition Equation2692 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ (z ◇ w)) ◇ y.

Definition Equation2693 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ (z ◇ w)) ◇ z.

Definition Equation2694 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ y) ◇ (z ◇ w)) ◇ w.

Definition Equation2695 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((x ◇ y) ◇ (z ◇ w)) ◇ u.

Definition Equation2696 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ (x ◇ x)) ◇ x.

Definition Equation2697 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ (x ◇ x)) ◇ y.

Definition Equation2698 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (x ◇ x)) ◇ z.

Definition Equation2699 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ (x ◇ y)) ◇ x.

Definition Equation2700 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ (x ◇ y)) ◇ y.

Definition Equation2701 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (x ◇ y)) ◇ z.

Definition Equation2702 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (x ◇ z)) ◇ x.

Definition Equation2703 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (x ◇ z)) ◇ y.

Definition Equation2704 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (x ◇ z)) ◇ z.

Definition Equation2705 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ (x ◇ z)) ◇ w.

Definition Equation2706 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ (y ◇ x)) ◇ x.

Definition Equation2707 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ (y ◇ x)) ◇ y.

Definition Equation2708 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (y ◇ x)) ◇ z.

Definition Equation2709 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ (y ◇ y)) ◇ x.

Definition Equation2710 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ x) ◇ (y ◇ y)) ◇ y.

Definition Equation2711 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (y ◇ y)) ◇ z.

Definition Equation2712 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (y ◇ z)) ◇ x.

Definition Equation2713 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (y ◇ z)) ◇ y.

Definition Equation2714 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (y ◇ z)) ◇ z.

Definition Equation2715 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ (y ◇ z)) ◇ w.

Definition Equation2716 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (z ◇ x)) ◇ x.

Definition Equation2717 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (z ◇ x)) ◇ y.

Definition Equation2718 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (z ◇ x)) ◇ z.

Definition Equation2719 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ (z ◇ x)) ◇ w.

Definition Equation2720 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (z ◇ y)) ◇ x.

Definition Equation2721 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (z ◇ y)) ◇ y.

Definition Equation2722 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (z ◇ y)) ◇ z.

Definition Equation2723 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ (z ◇ y)) ◇ w.

Definition Equation2724 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (z ◇ z)) ◇ x.

Definition Equation2725 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (z ◇ z)) ◇ y.

Definition Equation2726 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ x) ◇ (z ◇ z)) ◇ z.

Definition Equation2727 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ (z ◇ z)) ◇ w.

Definition Equation2728 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ (z ◇ w)) ◇ x.

Definition Equation2729 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ (z ◇ w)) ◇ y.

Definition Equation2730 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ (z ◇ w)) ◇ z.

Definition Equation2731 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ x) ◇ (z ◇ w)) ◇ w.

Definition Equation2732 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ x) ◇ (z ◇ w)) ◇ u.

Definition Equation2733 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ (x ◇ x)) ◇ x.

Definition Equation2734 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ (x ◇ x)) ◇ y.

Definition Equation2735 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (x ◇ x)) ◇ z.

Definition Equation2736 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ (x ◇ y)) ◇ x.

Definition Equation2737 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ (x ◇ y)) ◇ y.

Definition Equation2738 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (x ◇ y)) ◇ z.

Definition Equation2739 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (x ◇ z)) ◇ x.

Definition Equation2740 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (x ◇ z)) ◇ y.

Definition Equation2741 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (x ◇ z)) ◇ z.

Definition Equation2742 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ (x ◇ z)) ◇ w.

Definition Equation2743 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ (y ◇ x)) ◇ x.

Definition Equation2744 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ (y ◇ x)) ◇ y.

Definition Equation2745 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (y ◇ x)) ◇ z.

Definition Equation2746 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ (y ◇ y)) ◇ x.

Definition Equation2747 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ y) ◇ (y ◇ y)) ◇ y.

Definition Equation2748 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (y ◇ y)) ◇ z.

Definition Equation2749 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (y ◇ z)) ◇ x.

Definition Equation2750 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (y ◇ z)) ◇ y.

Definition Equation2751 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (y ◇ z)) ◇ z.

Definition Equation2752 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ (y ◇ z)) ◇ w.

Definition Equation2753 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (z ◇ x)) ◇ x.

Definition Equation2754 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (z ◇ x)) ◇ y.

Definition Equation2755 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (z ◇ x)) ◇ z.

Definition Equation2756 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ (z ◇ x)) ◇ w.

Definition Equation2757 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (z ◇ y)) ◇ x.

Definition Equation2758 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (z ◇ y)) ◇ y.

Definition Equation2759 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (z ◇ y)) ◇ z.

Definition Equation2760 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ (z ◇ y)) ◇ w.

Definition Equation2761 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (z ◇ z)) ◇ x.

Definition Equation2762 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (z ◇ z)) ◇ y.

Definition Equation2763 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ y) ◇ (z ◇ z)) ◇ z.

Definition Equation2764 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ (z ◇ z)) ◇ w.

Definition Equation2765 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ (z ◇ w)) ◇ x.

Definition Equation2766 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ (z ◇ w)) ◇ y.

Definition Equation2767 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ (z ◇ w)) ◇ z.

Definition Equation2768 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ y) ◇ (z ◇ w)) ◇ w.

Definition Equation2769 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ y) ◇ (z ◇ w)) ◇ u.

Definition Equation2770 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (x ◇ x)) ◇ x.

Definition Equation2771 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (x ◇ x)) ◇ y.

Definition Equation2772 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (x ◇ x)) ◇ z.

Definition Equation2773 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (x ◇ x)) ◇ w.

Definition Equation2774 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (x ◇ y)) ◇ x.

Definition Equation2775 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (x ◇ y)) ◇ y.

Definition Equation2776 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (x ◇ y)) ◇ z.

Definition Equation2777 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (x ◇ y)) ◇ w.

Definition Equation2778 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (x ◇ z)) ◇ x.

Definition Equation2779 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (x ◇ z)) ◇ y.

Definition Equation2780 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (x ◇ z)) ◇ z.

Definition Equation2781 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (x ◇ z)) ◇ w.

Definition Equation2782 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (x ◇ w)) ◇ x.

Definition Equation2783 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (x ◇ w)) ◇ y.

Definition Equation2784 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (x ◇ w)) ◇ z.

Definition Equation2785 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (x ◇ w)) ◇ w.

Definition Equation2786 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ (x ◇ w)) ◇ u.

Definition Equation2787 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (y ◇ x)) ◇ x.

Definition Equation2788 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (y ◇ x)) ◇ y.

Definition Equation2789 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (y ◇ x)) ◇ z.

Definition Equation2790 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (y ◇ x)) ◇ w.

Definition Equation2791 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (y ◇ y)) ◇ x.

Definition Equation2792 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (y ◇ y)) ◇ y.

Definition Equation2793 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (y ◇ y)) ◇ z.

Definition Equation2794 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (y ◇ y)) ◇ w.

Definition Equation2795 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (y ◇ z)) ◇ x.

Definition Equation2796 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (y ◇ z)) ◇ y.

Definition Equation2797 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (y ◇ z)) ◇ z.

Definition Equation2798 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (y ◇ z)) ◇ w.

Definition Equation2799 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (y ◇ w)) ◇ x.

Definition Equation2800 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (y ◇ w)) ◇ y.

Definition Equation2801 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (y ◇ w)) ◇ z.

Definition Equation2802 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (y ◇ w)) ◇ w.

Definition Equation2803 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ (y ◇ w)) ◇ u.

Definition Equation2804 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (z ◇ x)) ◇ x.

Definition Equation2805 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (z ◇ x)) ◇ y.

Definition Equation2806 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (z ◇ x)) ◇ z.

Definition Equation2807 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (z ◇ x)) ◇ w.

Definition Equation2808 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (z ◇ y)) ◇ x.

Definition Equation2809 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (z ◇ y)) ◇ y.

Definition Equation2810 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (z ◇ y)) ◇ z.

Definition Equation2811 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (z ◇ y)) ◇ w.

Definition Equation2812 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (z ◇ z)) ◇ x.

Definition Equation2813 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (z ◇ z)) ◇ y.

Definition Equation2814 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ z) ◇ (z ◇ z)) ◇ z.

Definition Equation2815 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (z ◇ z)) ◇ w.

Definition Equation2816 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (z ◇ w)) ◇ x.

Definition Equation2817 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (z ◇ w)) ◇ y.

Definition Equation2818 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (z ◇ w)) ◇ z.

Definition Equation2819 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (z ◇ w)) ◇ w.

Definition Equation2820 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ (z ◇ w)) ◇ u.

Definition Equation2821 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ x)) ◇ x.

Definition Equation2822 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ x)) ◇ y.

Definition Equation2823 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ x)) ◇ z.

Definition Equation2824 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ x)) ◇ w.

Definition Equation2825 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ (w ◇ x)) ◇ u.

Definition Equation2826 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ y)) ◇ x.

Definition Equation2827 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ y)) ◇ y.

Definition Equation2828 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ y)) ◇ z.

Definition Equation2829 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ y)) ◇ w.

Definition Equation2830 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ (w ◇ y)) ◇ u.

Definition Equation2831 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ z)) ◇ x.

Definition Equation2832 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ z)) ◇ y.

Definition Equation2833 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ z)) ◇ z.

Definition Equation2834 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ z)) ◇ w.

Definition Equation2835 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ (w ◇ z)) ◇ u.

Definition Equation2836 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ w)) ◇ x.

Definition Equation2837 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ w)) ◇ y.

Definition Equation2838 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ w)) ◇ z.

Definition Equation2839 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ z) ◇ (w ◇ w)) ◇ w.

Definition Equation2840 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ (w ◇ w)) ◇ u.

Definition Equation2841 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ (w ◇ u)) ◇ x.

Definition Equation2842 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ (w ◇ u)) ◇ y.

Definition Equation2843 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ (w ◇ u)) ◇ z.

Definition Equation2844 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ (w ◇ u)) ◇ w.

Definition Equation2845 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ z) ◇ (w ◇ u)) ◇ u.

Definition Equation2846 (G : Type) `{Magma G} : Prop :=
  forall x y z w u v : G, x = ((y ◇ z) ◇ (w ◇ u)) ◇ v.

Definition Equation2847 (G : Type) `{Magma G} : Prop :=
  forall x : G, x = ((x ◇ (x ◇ x)) ◇ x) ◇ x.

Definition Equation2848 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (x ◇ x)) ◇ x) ◇ y.

Definition Equation2849 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (x ◇ x)) ◇ y) ◇ x.

Definition Equation2850 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (x ◇ x)) ◇ y) ◇ y.

Definition Equation2851 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (x ◇ x)) ◇ y) ◇ z.

Definition Equation2852 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (x ◇ y)) ◇ x) ◇ x.

Definition Equation2853 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (x ◇ y)) ◇ x) ◇ y.

Definition Equation2854 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (x ◇ y)) ◇ x) ◇ z.

Definition Equation2855 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (x ◇ y)) ◇ y) ◇ x.

Definition Equation2856 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (x ◇ y)) ◇ y) ◇ y.

Definition Equation2857 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (x ◇ y)) ◇ y) ◇ z.

Definition Equation2858 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (x ◇ y)) ◇ z) ◇ x.

Definition Equation2859 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (x ◇ y)) ◇ z) ◇ y.

Definition Equation2860 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (x ◇ y)) ◇ z) ◇ z.

Definition Equation2861 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ (x ◇ y)) ◇ z) ◇ w.

Definition Equation2862 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (y ◇ x)) ◇ x) ◇ x.

Definition Equation2863 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (y ◇ x)) ◇ x) ◇ y.

Definition Equation2864 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ x)) ◇ x) ◇ z.

Definition Equation2865 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (y ◇ x)) ◇ y) ◇ x.

Definition Equation2866 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (y ◇ x)) ◇ y) ◇ y.

Definition Equation2867 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ x)) ◇ y) ◇ z.

Definition Equation2868 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ x)) ◇ z) ◇ x.

Definition Equation2869 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ x)) ◇ z) ◇ y.

Definition Equation2870 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ x)) ◇ z) ◇ z.

Definition Equation2871 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ (y ◇ x)) ◇ z) ◇ w.

Definition Equation2872 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (y ◇ y)) ◇ x) ◇ x.

Definition Equation2873 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (y ◇ y)) ◇ x) ◇ y.

Definition Equation2874 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ y)) ◇ x) ◇ z.

Definition Equation2875 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (y ◇ y)) ◇ y) ◇ x.

Definition Equation2876 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((x ◇ (y ◇ y)) ◇ y) ◇ y.

Definition Equation2877 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ y)) ◇ y) ◇ z.

Definition Equation2878 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ y)) ◇ z) ◇ x.

Definition Equation2879 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ y)) ◇ z) ◇ y.

Definition Equation2880 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ y)) ◇ z) ◇ z.

Definition Equation2881 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ (y ◇ y)) ◇ z) ◇ w.

Definition Equation2882 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ z)) ◇ x) ◇ x.

Definition Equation2883 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ z)) ◇ x) ◇ y.

Definition Equation2884 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ z)) ◇ x) ◇ z.

Definition Equation2885 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ (y ◇ z)) ◇ x) ◇ w.

Definition Equation2886 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ z)) ◇ y) ◇ x.

Definition Equation2887 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ z)) ◇ y) ◇ y.

Definition Equation2888 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ z)) ◇ y) ◇ z.

Definition Equation2889 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ (y ◇ z)) ◇ y) ◇ w.

Definition Equation2890 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ z)) ◇ z) ◇ x.

Definition Equation2891 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ z)) ◇ z) ◇ y.

Definition Equation2892 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((x ◇ (y ◇ z)) ◇ z) ◇ z.

Definition Equation2893 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ (y ◇ z)) ◇ z) ◇ w.

Definition Equation2894 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ (y ◇ z)) ◇ w) ◇ x.

Definition Equation2895 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ (y ◇ z)) ◇ w) ◇ y.

Definition Equation2896 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ (y ◇ z)) ◇ w) ◇ z.

Definition Equation2897 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((x ◇ (y ◇ z)) ◇ w) ◇ w.

Definition Equation2898 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((x ◇ (y ◇ z)) ◇ w) ◇ u.

Definition Equation2899 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (x ◇ x)) ◇ x) ◇ x.

Definition Equation2900 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (x ◇ x)) ◇ x) ◇ y.

Definition Equation2901 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ x)) ◇ x) ◇ z.

Definition Equation2902 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (x ◇ x)) ◇ y) ◇ x.

Definition Equation2903 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (x ◇ x)) ◇ y) ◇ y.

Definition Equation2904 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ x)) ◇ y) ◇ z.

Definition Equation2905 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ x)) ◇ z) ◇ x.

Definition Equation2906 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ x)) ◇ z) ◇ y.

Definition Equation2907 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ x)) ◇ z) ◇ z.

Definition Equation2908 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (x ◇ x)) ◇ z) ◇ w.

Definition Equation2909 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (x ◇ y)) ◇ x) ◇ x.

Definition Equation2910 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (x ◇ y)) ◇ x) ◇ y.

Definition Equation2911 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ y)) ◇ x) ◇ z.

Definition Equation2912 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (x ◇ y)) ◇ y) ◇ x.

Definition Equation2913 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (x ◇ y)) ◇ y) ◇ y.

Definition Equation2914 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ y)) ◇ y) ◇ z.

Definition Equation2915 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ y)) ◇ z) ◇ x.

Definition Equation2916 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ y)) ◇ z) ◇ y.

Definition Equation2917 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ y)) ◇ z) ◇ z.

Definition Equation2918 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (x ◇ y)) ◇ z) ◇ w.

Definition Equation2919 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ z)) ◇ x) ◇ x.

Definition Equation2920 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ z)) ◇ x) ◇ y.

Definition Equation2921 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ z)) ◇ x) ◇ z.

Definition Equation2922 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (x ◇ z)) ◇ x) ◇ w.

Definition Equation2923 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ z)) ◇ y) ◇ x.

Definition Equation2924 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ z)) ◇ y) ◇ y.

Definition Equation2925 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ z)) ◇ y) ◇ z.

Definition Equation2926 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (x ◇ z)) ◇ y) ◇ w.

Definition Equation2927 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ z)) ◇ z) ◇ x.

Definition Equation2928 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ z)) ◇ z) ◇ y.

Definition Equation2929 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (x ◇ z)) ◇ z) ◇ z.

Definition Equation2930 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (x ◇ z)) ◇ z) ◇ w.

Definition Equation2931 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (x ◇ z)) ◇ w) ◇ x.

Definition Equation2932 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (x ◇ z)) ◇ w) ◇ y.

Definition Equation2933 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (x ◇ z)) ◇ w) ◇ z.

Definition Equation2934 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (x ◇ z)) ◇ w) ◇ w.

Definition Equation2935 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (x ◇ z)) ◇ w) ◇ u.

Definition Equation2936 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (y ◇ x)) ◇ x) ◇ x.

Definition Equation2937 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (y ◇ x)) ◇ x) ◇ y.

Definition Equation2938 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ x)) ◇ x) ◇ z.

Definition Equation2939 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (y ◇ x)) ◇ y) ◇ x.

Definition Equation2940 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (y ◇ x)) ◇ y) ◇ y.

Definition Equation2941 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ x)) ◇ y) ◇ z.

Definition Equation2942 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ x)) ◇ z) ◇ x.

Definition Equation2943 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ x)) ◇ z) ◇ y.

Definition Equation2944 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ x)) ◇ z) ◇ z.

Definition Equation2945 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (y ◇ x)) ◇ z) ◇ w.

Definition Equation2946 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (y ◇ y)) ◇ x) ◇ x.

Definition Equation2947 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (y ◇ y)) ◇ x) ◇ y.

Definition Equation2948 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ y)) ◇ x) ◇ z.

Definition Equation2949 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (y ◇ y)) ◇ y) ◇ x.

Definition Equation2950 (G : Type) `{Magma G} : Prop :=
  forall x y : G, x = ((y ◇ (y ◇ y)) ◇ y) ◇ y.

Definition Equation2951 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ y)) ◇ y) ◇ z.

Definition Equation2952 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ y)) ◇ z) ◇ x.

Definition Equation2953 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ y)) ◇ z) ◇ y.

Definition Equation2954 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ y)) ◇ z) ◇ z.

Definition Equation2955 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (y ◇ y)) ◇ z) ◇ w.

Definition Equation2956 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ z)) ◇ x) ◇ x.

Definition Equation2957 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ z)) ◇ x) ◇ y.

Definition Equation2958 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ z)) ◇ x) ◇ z.

Definition Equation2959 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (y ◇ z)) ◇ x) ◇ w.

Definition Equation2960 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ z)) ◇ y) ◇ x.

Definition Equation2961 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ z)) ◇ y) ◇ y.

Definition Equation2962 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ z)) ◇ y) ◇ z.

Definition Equation2963 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (y ◇ z)) ◇ y) ◇ w.

Definition Equation2964 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ z)) ◇ z) ◇ x.

Definition Equation2965 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ z)) ◇ z) ◇ y.

Definition Equation2966 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (y ◇ z)) ◇ z) ◇ z.

Definition Equation2967 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (y ◇ z)) ◇ z) ◇ w.

Definition Equation2968 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (y ◇ z)) ◇ w) ◇ x.

Definition Equation2969 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (y ◇ z)) ◇ w) ◇ y.

Definition Equation2970 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (y ◇ z)) ◇ w) ◇ z.

Definition Equation2971 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (y ◇ z)) ◇ w) ◇ w.

Definition Equation2972 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (y ◇ z)) ◇ w) ◇ u.

Definition Equation2973 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ x)) ◇ x) ◇ x.

Definition Equation2974 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ x)) ◇ x) ◇ y.

Definition Equation2975 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ x)) ◇ x) ◇ z.

Definition Equation2976 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ x)) ◇ x) ◇ w.

Definition Equation2977 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ x)) ◇ y) ◇ x.

Definition Equation2978 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ x)) ◇ y) ◇ y.

Definition Equation2979 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ x)) ◇ y) ◇ z.

Definition Equation2980 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ x)) ◇ y) ◇ w.

Definition Equation2981 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ x)) ◇ z) ◇ x.

Definition Equation2982 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ x)) ◇ z) ◇ y.

Definition Equation2983 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ x)) ◇ z) ◇ z.

Definition Equation2984 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ x)) ◇ z) ◇ w.

Definition Equation2985 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ x)) ◇ w) ◇ x.

Definition Equation2986 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ x)) ◇ w) ◇ y.

Definition Equation2987 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ x)) ◇ w) ◇ z.

Definition Equation2988 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ x)) ◇ w) ◇ w.

Definition Equation2989 (G : Type) `{Magma G} : Prop :=
  forall x y z w u : G, x = ((y ◇ (z ◇ x)) ◇ w) ◇ u.

Definition Equation2990 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ y)) ◇ x) ◇ x.

Definition Equation2991 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ y)) ◇ x) ◇ y.

Definition Equation2992 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ y)) ◇ x) ◇ z.

Definition Equation2993 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ y)) ◇ x) ◇ w.

Definition Equation2994 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ y)) ◇ y) ◇ x.

Definition Equation2995 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ y)) ◇ y) ◇ y.

Definition Equation2996 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ y)) ◇ y) ◇ z.

Definition Equation2997 (G : Type) `{Magma G} : Prop :=
  forall x y z w : G, x = ((y ◇ (z ◇ y)) ◇ y) ◇ w.

Definition Equation2998 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ y)) ◇ z) ◇ x.

Definition Equation2999 (G : Type) `{Magma G} : Prop :=
  forall x y z : G, x = ((y ◇ (z ◇ y)) ◇ z) ◇ y.

